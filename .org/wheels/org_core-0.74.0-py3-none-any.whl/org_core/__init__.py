"""org-core — the org builder.

Installs, verifies and measures a named cast of engineering agent roles into a
repository. See SPEC.md at the repository root; this package is phase 1 of it.
"""

from __future__ import annotations

__version__ = "0.74.0"

ROLE_IDS: tuple[str, ...] = (
    "ceo",
    "dispatcher",
    "builder",
    "reviewer",
    "verifier",
    "checks-watch",
    "registrar",
    "account-manager",
    "methods",
    "doctor",
    "planner",
    "fleet-head",
    "launcher",
    "tess",
    "chase",
)

#: roles that exist only in the org that keeps the fleet registry (`fleet/orgs.yaml` — org-core): `org init` never drafts
#: them into an installed org (the operator, 2026-10-17: a fleet head above every Link, SPEC row 191; and 2026-10-19/20, a
#: launcher on every account but gald33 — arc fleet-accounts-and-pools, rulings 3 and 4)
FLEET_ROLE_IDS: tuple[str, ...] = ("fleet-head", "launcher")

#: roles that send as the operator to people outside the org (SPEC §16 decisions 15–17): `org init` never drafts them — each is
#: enabled by hand, in one org first (d15: "proven in Lucille alone"; item `chase-and-tess-enabled-in-lucille-alone`)
OUTWARD_ROLE_IDS: tuple[str, ...] = ("tess", "chase")

RUNTIMES: tuple[str, ...] = ("fresh", "session", "spawned")
