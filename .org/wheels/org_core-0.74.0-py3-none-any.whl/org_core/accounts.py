"""The fleet's account registry (arc fleet-accounts-and-pools; the operator's rulings of 2026-10-19/20).

The fleet runs on several claude.ai accounts and the package modelled one: `org.account`, a display-only scalar
(org.schema.json; read as text at routine.py). Routines and sessions are account-local, so a reading taken from one
account says nothing about another. This module is the map the account-aware checks read:

- `fleet/accounts.yaml` — per account label: `uuid`, `environment_id`, `pool`, `seats`, `launcher`, `connectors`.
  Ruling 15: ids and labels only, **never an email address** — a login is a person's address, and this file is in git.
- `fleet/orgs.yaml` — each org gains `pool` (required), `seat_account`, `workspace`, `tenant`, `operated_by`.
- an org's own manifest names its pool (`org.pool`); where the fleet registry lists the org, the two must agree.
- every record the package writes says which account wrote it: `claude_account` (with `session_id`) from the
  container's environment — `account` is already a word in outward_connectors.py (whose mailbox), hence the prefix.

A `uuid` is the full id, an 8-hex prefix when only the prefix was read, or null when the account was never read
(item measure-every-account): an unread value stays null, never a guess.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Mapping

import jsonschema
import yaml

SCHEMAS = Path(__file__).parent / "schemas"
ACCOUNTS_SCHEMA = SCHEMAS / "accounts.schema.json"
FLEET_ORGS_SCHEMA = SCHEMAS / "fleet-orgs.schema.json"
ACCOUNTS_FILE = Path("fleet") / "accounts.yaml"
ORGS_FILE = Path("fleet") / "orgs.yaml"
#: what the cloud container exports (read 2026-10-21 in an org-core builder session: both set; no variable carries the
#: environment id, so `environment_id` is read from the registry, not the container). Whether a fresh routine's
#: container carries them is unmeasured (item measure-every-account).
ENV_ACCOUNT = "CLAUDE_CODE_ACCOUNT_UUID"
ENV_SESSION = "CLAUDE_CODE_REMOTE_SESSION_ID"
#: anything shaped like an address, anywhere in either file — comments included, since YAML drops them before a schema
#: sees them. Broken looks like: `gal@example.com` in a comment that validates.
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
SEAT_RE = re.compile(r"^(?:fleet/[a-z][a-z0-9-]*|[a-z][a-z0-9-]*(?:/[a-z][a-z0-9-]*)?)$")


def _schema_problems(data: Any, schema_path: Path, label: str) -> list[str]:
    v = jsonschema.Draft202012Validator(json.loads(schema_path.read_text()))
    out = []
    for err in sorted(v.iter_errors(data), key=lambda e: list(e.absolute_path)):
        where = "/".join(str(p) for p in err.absolute_path) or "<root>"
        out.append(f"{label}: {where}: {err.message}")
    return out


def email_problems(text: str, label: str) -> list[str]:
    """One line per address-shaped string in `text` (ruling 15). The address itself is not repeated in the output."""
    out = []
    for n, line in enumerate(text.splitlines(), 1):
        if EMAIL_RE.search(line):
            out.append(f"{label}:{n}: an email address — the registry carries uuid, environment id and a label, never a login (ruling 15)")
    return out


def pools(accounts_doc: Mapping[str, Any]) -> dict[str, list[str]]:
    """pool -> account labels in it, in file order."""
    out: dict[str, list[str]] = {}
    for label, a in ((accounts_doc or {}).get("accounts") or {}).items():
        if isinstance(a, dict) and a.get("pool"):
            out.setdefault(a["pool"], []).append(label)
    return out


def problems(accounts_doc: Any, orgs_doc: Any) -> list[str]:
    """Every way the two registries disagree with their schemas or with each other; empty means both are sound.

    Broken looks like: an org with no pool that passes, a pool no account belongs to, a seat on an account outside its
    org's pool, two accounts with one uuid, or a `seat_account` that does not hold the org's seats."""
    out = _schema_problems(accounts_doc, ACCOUNTS_SCHEMA, str(ACCOUNTS_FILE)) + _schema_problems(orgs_doc, FLEET_ORGS_SCHEMA, str(ORGS_FILE))
    if out:
        return out
    accounts = accounts_doc["accounts"]
    by_pool = pools(accounts_doc)
    orgs = {o["id"]: o for o in orgs_doc["orgs"]}
    seen: dict[str, str] = {}
    for label, a in accounts.items():
        u = (a.get("uuid") or "").lower()
        if u:
            for other_u, other in seen.items():
                if u.startswith(other_u) or other_u.startswith(u):
                    out.append(f"{ACCOUNTS_FILE}: {label} and {other} carry the same uuid {u[:8]}")
            seen[u] = label
        for seat in a.get("seats") or []:
            if not SEAT_RE.match(seat):
                out.append(f"{ACCOUNTS_FILE}: {label}: seat {seat!r} is not `<org>`, `<org>/<role>` or `fleet/<seat>` (a launcher is `launcher: true`)")
                continue
            if seat.startswith("fleet/"):
                continue
            org_id = seat.split("/")[0]
            if org_id not in orgs:
                out.append(f"{ACCOUNTS_FILE}: {label}: seat {seat!r} names an org {ORGS_FILE} does not list")
            elif orgs[org_id]["pool"] != a["pool"]:
                out.append(f"{ACCOUNTS_FILE}: {label}: seat {seat!r} is on pool {a['pool']}, but {org_id} is served by pool {orgs[org_id]['pool']}")
    for org_id, o in orgs.items():
        if o["pool"] not in by_pool:
            out.append(f"{ORGS_FILE}: {org_id}: pool {o['pool']!r} has no account in {ACCOUNTS_FILE}")
            continue
        sa = o.get("seat_account")
        if sa is not None:
            if sa not in accounts:
                out.append(f"{ORGS_FILE}: {org_id}: seat_account {sa!r} is not an account in {ACCOUNTS_FILE}")
            elif accounts[sa]["pool"] != o["pool"]:
                out.append(f"{ORGS_FILE}: {org_id}: seat_account {sa!r} is in pool {accounts[sa]['pool']}, outside its pool {o['pool']}")
            elif not any(s == org_id or s.startswith(org_id + "/") for s in accounts[sa].get("seats") or []):
                out.append(f"{ORGS_FILE}: {org_id}: seat_account {sa!r} holds none of {org_id}'s seats in {ACCOUNTS_FILE}")
        if o.get("operated_by") and EMAIL_RE.search(str(o["operated_by"])):
            out.append(f"{ORGS_FILE}: {org_id}: operated_by is an email address — name a GitHub login or a label (ruling 15)")
    return out


def manifest_problems(manifest: Mapping[str, Any], orgs_doc: Any) -> list[str]:
    """An org's manifest against the fleet registry that lists it: the manifest names its pool, and it is the same one.

    Only where a registry is present (org-core keeps it): an installed org's repo has no `fleet/`, and its manifest's
    `org.pool` is read by the fleet, not checked against itself."""
    org = (manifest or {}).get("org") or {}
    listed = {o.get("id"): o for o in ((orgs_doc or {}).get("orgs") or []) if isinstance(o, dict)}
    entry = listed.get(org.get("id"))
    if entry is None:
        return []
    if not org.get("pool"):
        return [f"org/pool: {org.get('id')} is listed in {ORGS_FILE} on pool {entry.get('pool')!r}, and its manifest names no pool"]
    if entry.get("pool") and org["pool"] != entry["pool"]:
        return [f"org/pool: the manifest says {org['pool']!r}, {ORGS_FILE} says {entry['pool']!r}"]
    return []


def check_repo(repo: Path, manifest: Mapping[str, Any] | None = None) -> list[str] | None:
    """The registry problems of a repo that keeps one; None when it keeps neither file (an installed org)."""
    a_path, o_path = repo / ACCOUNTS_FILE, repo / ORGS_FILE
    if not a_path.exists() and not o_path.exists():
        return None
    out: list[str] = []
    if not a_path.exists():
        return [f"{ACCOUNTS_FILE}: missing — {ORGS_FILE} names pools and no file says which accounts are in them"]
    if not o_path.exists():
        return [f"{ORGS_FILE}: missing — {ACCOUNTS_FILE} names pools and no file says which orgs they serve"]
    a_text, o_text = a_path.read_text(), o_path.read_text()
    out += email_problems(a_text, str(ACCOUNTS_FILE)) + email_problems(o_text, str(ORGS_FILE))
    a_doc, o_doc = yaml.safe_load(a_text) or {}, yaml.safe_load(o_text) or {}
    out += problems(a_doc, o_doc)
    if manifest is not None and not out:
        out += manifest_problems(manifest, o_doc)
    return out


def whoami(env: Mapping[str, str] | None = None) -> dict[str, str | None]:
    """{claude_account, session_id} of the container that runs this: the values every package-written record carries.
    None is "this container does not say", never a default account."""
    env = os.environ if env is None else env
    return {"claude_account": env.get(ENV_ACCOUNT) or None, "session_id": env.get(ENV_SESSION) or None}
