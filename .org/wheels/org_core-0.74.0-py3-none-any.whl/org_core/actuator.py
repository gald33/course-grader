"""The actuator — the variable half of tempo, executed (SPEC §13.1).

`plan` is a pure function of the facts and the manifest: the events past target, the acts a session holding
the sessions port should perform now — spawn a one-shot, fire a sourced fresh routine, forward a blocked
field, ask a human, hold — with every one-shot prompt fully rendered, and when to wake next. `record_wake`
turns the plan and the port's answers into the ledger row, the heartbeat and the lease. The CLI writes those
to the board; this module writes nothing, so a plan can be tested from a facts file.

Measured 2026-09-19 (fidelity/tempo-design-2026-09-19): the actuator's working channels are `create_session`
(24 spawns read, fire→spawn 76–95 s), `send_later` to itself (delivery within a minute), and `fire_trigger`
on a *sourced fresh* routine. `fire_trigger` on a session-bound routine mints a sourceless fresh session and
never reaches the bound session, so no plan ever fires one. A persistent session's wake grows with its
context ($2.34 → $16.67 → $42.09 a fire), so the plan refuses to arm past `rotate_at_tokens`.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import uuid
from pathlib import Path
from typing import Any

from . import tempo as tp

ACTS = ("arm", "dm", "spawn", "fire_trigger", "forward", "ask", "hold", "settle", "rotate")

#: org-level tempo defaults; `tempo.*` in the manifest overrides key by key
DEFAULTS: dict[str, Any] = {
    "actuator": "dispatcher",
    "wake_interval_minutes": {"busy": 20, "quiet": None},
    "after_spawn_minutes": {"builder": 30, "reviewer": 20, "ceo": 15, "registrar": 25, "account-manager": 25},
    "hold_if_cron_due_within_minutes": 15,
    "rotate_at_tokens": 250_000,
    "suppress_after_wake_lost": 2,
    "spawned_merge_proven": False,
    "listen_minutes": tp.DEFAULT_LISTEN_MINUTES,
    "ledger_key": "coord/tempo/wakes",
    "heartbeat_key": "coord/tempo/actuator",
    "lease_key": "coord/tempo/lease",
    "triggers_key": "coord/tempo/triggers",
    "sessions_key": "coord/tempo/sessions",
    "operator_queue_key": "coord/tempo/operator-queue",
}
ONESHOT_PREFIXES = ("tempo:", "Re-check", "Check-in", "Peek", "reviewer —", "builder —", "ceo —", "registrar —", "account-manager —")

DEFAULT_ONESHOT = """{[ woken_by ]}

You are {[ role.name ]}, the {[ role_id ]} of the {[ org_id ]} org, woken for one thing: {[ what ]}{[ scope_line ]}
Read `.claude/agents/{[ role_id ]}.md`, invoke the `{[ role_id ]}` skill for that one thing, write your run record with the `woken_by` line above echoed verbatim, then end — a spawned or fresh session parks no listener (ruling 7: persistent seats only). Do not poll, do not arm a check-in, do not widen the scope.

Repository: {[ repo_url ]}, expected at `{[ checkout ]}`.
"""


def org_tempo(manifest: dict[str, Any]) -> dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULTS))
    for k, v in (manifest.get("tempo") or {}).items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        elif k != "targets":
            cfg[k] = v
    return cfg


def _sid(x: Any) -> str:
    """Session ids arrive as `session_01…` from the sessions port and `cse_01…` from a trigger's last_run; compare the tail."""
    s = str(x or "")
    return s.split("_", 1)[-1] if "_" in s else s


def session_facts(session_json: Any) -> dict[str, Any]:
    """{id, context_tokens, cost_usd} from a get_session answer (wrapped in `ccr` or not) — or an already-flat dict."""
    s = session_json or {}
    if isinstance(s, dict) and "ccr" in s:
        s = s["ccr"]
    em = s.get("external_metadata") or {}
    return {
        "id": s.get("id") or s.get("session_id"),
        "context_tokens": s.get("context_tokens") or (em.get("context_usage") or {}).get("used_tokens"),
        "cost_usd": s.get("cost_usd") or (em.get("usage") or {}).get("cost_usd"),
    }


# --- the ledger on the board -------------------------------------------------------

def ledger_rows(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Every actuator wake row under coord/tempo/wakes-<date>, oldest first (a key holds {"rows": [...]})."""
    prefix = (cfg or DEFAULTS)["ledger_key"] + "-"
    rows: dict[str, dict[str, Any]] = {}
    for r in board:
        if not r["key"].startswith(prefix):
            continue
        v = r.get("value")
        for row in (v.get("rows") if isinstance(v, dict) else v) or []:
            if isinstance(row, dict) and row.get("run_id"):
                rows[row["run_id"]] = row
    return sorted(rows.values(), key=lambda x: x.get("at") or "")


def _key(board: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
    return tp._latest_records(board).get(key)


def heartbeat(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> dict[str, Any] | None:
    row = _key(board, (cfg or DEFAULTS)["heartbeat_key"])
    return tp._value(row) if row else None


def lease(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> dict[str, Any] | None:
    row = _key(board, (cfg or DEFAULTS)["lease_key"])
    return tp._value(row) if row else None


QUEUE_EXPIRY_DAYS = 7  # as the handoff cards: a row nobody has seen again in a week leaves the board on its own

_HANDOFF_KEY = re.compile(r"coord/handoffs/[\w./-]+")


def queue_subject(role: str | None, ask: str | None) -> str:
    """What a forwarded row is about, written by the forwarder (the row's `subject`): the handoff key the text names,
    else the text with its digits masked. The role is part of the identity, so the same words from two roles stay two
    rows. A PR number is deliberately not a subject: two different conditions of one role can name the same PR (Reed,
    UNSOUND on #147). The ask wording drifts between wakes (Reed on #146, 2026-10-08: 50 rows, at most 20 distinct),
    which is why a reader prefers the stored subject and only derives one for a row written without it."""
    text = " ".join(str(ask or "").split())
    m = _HANDOFF_KEY.search(text)
    if m:
        return f"{role or '?'}|{m.group(0).lower()}"
    masked = re.sub(r"\d+", "#", text.lower())[:120]
    return f"{role or '?'}|{masked}"


def _ts(row: dict[str, Any], *keys: str) -> str | None:
    return next((row[k] for k in keys if row.get(k)), None)


def fold_queue(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """One row per (role, subject), in order of first sighting. The row is dated by its FIRST sighting — `event_at` is
    the first one (what every reader ages it by: the page's `oldest`, check 15's 3-day alarm), `last_event_at` and
    `forwarded_at` the latest — so a condition forwarded daily for five days reads four days old, not an hour (Reed,
    UNSOUND on #147). `seen` counts sightings."""
    by: dict[str, dict[str, Any]] = {}
    for r in rows:
        subj = r.get("subject") or queue_subject(r.get("role"), r.get("ask") or r.get("what"))
        prev = by.get(subj)
        if prev is None:
            by[subj] = {**r, "subject": subj, "seen": int(r.get("seen") or 1), "last_event_at": r.get("last_event_at") or r.get("event_at")}
            continue
        first = _ts(prev, "event_at", "forwarded_at")
        first_new = _ts(r, "event_at", "forwarded_at")
        keep_first = first if (first_new is None or (first is not None and first <= first_new)) else first_new
        newer = r if (_ts(r, "last_event_at", "event_at", "forwarded_at") or "") >= (_ts(prev, "last_event_at", "event_at", "forwarded_at") or "") else prev
        by[subj] = {**newer, "subject": subj, "event_at": keep_first, "seen": int(prev.get("seen") or 1) + int(r.get("seen") or 1),
                    "last_event_at": _ts(newer, "last_event_at", "event_at")}
    return list(by.values())


def blocked_conditions(u: dict[str, Any]) -> list[tuple[str, str]]:
    """(subject, text) per condition of an unforwarded blocked field: a subject the role wrote into its own record
    (`subjects` map: one row per condition) is the row's identity; the masked text is only the fallback, because the
    role's wording drifts between wakes."""
    return [(f"{u['role']}|{n}", t or u["text"]) for n, t in (u.get("subjects") or {}).items()] \
        or [(queue_subject(u["role"], u["text"]), u["text"])]


def current_subjects(b: dict[str, Any]) -> list[str]:
    """The queue subjects a role's record states this wake (a `blocked_now` entry): its `subjects` map, else the subject
    of its blocked text, cut as `orphans` cuts it so the two derive the same subject; none when it is not blocked."""
    if not b.get("blocked"):
        return []
    return [f"{b['role']}|{n}" for n in (b.get("subjects") or {})] or [queue_subject(b["role"], tp._cut(b["blocked"], 160))]


def queue_current(board: list[dict[str, Any]], roles: dict[str, Any], now: dt.datetime) -> dict[str, list[str]]:
    """role -> the subjects its record states now, for every role whose record was read this wake. A role whose record
    could not be read is absent, so its rows stay: unread is not cleared."""
    return {b["role"]: current_subjects(b) for b in tp.blocked_now(board, roles, now) if "record_at" in b}


def merge_queue(existing: list[dict[str, Any]], add: list[dict[str, Any]], now: dt.datetime,
                expiry_days: int = QUEUE_EXPIRY_DAYS, current: dict[str, list[str]] | None = None) -> list[dict[str, Any]]:
    """The queue after a wake: a forward whose (role, subject) is already a row updates that row (see `fold_queue`)
    instead of adding another; a row whose latest `forwarded_at` is older than `expiry_days` is dropped; and a forwarded
    row of a role in `current` whose subject that role's record no longer states is dropped. The rows follow the record:
    org-core 2026-10-11, 42 of 43 rows on the page were forwards the roles had stopped writing hours or days before —
    the wording drifted, each wake added a subject, and nothing removed the old one short of the week's expiry. An `ask`
    row is the actuator's own, not a forward of the role's record, so it is never pruned this way."""
    keep = []
    for r in fold_queue(list(existing) + list(add)):
        if current and r.get("role") in current and r.get("kind", "forward") == "forward" and r["subject"] not in current[r["role"]]:
            continue
        age = tp.hours(r.get("forwarded_at") or r.get("event_at"), now.isoformat())
        if age is None or age <= expiry_days * 24:
            keep.append(r)
    return keep


def operator_queue(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """The rows, one per (role, subject): rows written before `subject` existed are folded on read, so the figure
    on the page does not wait for the board key to be rewritten."""
    row = _key(board, (cfg or DEFAULTS)["operator_queue_key"])
    v = row.get("value") if row else None
    if isinstance(v, dict):
        v = v.get("items") or v.get("queue") or []
    return fold_queue([x for x in (v or []) if isinstance(x, dict)])


def compact_triggers(triggers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The fields a plan reads, from a full list_triggers dump (56 KB for 14 triggers, measured) — what the actuator
    writes to `coord/tempo/triggers` once a day instead of dumping per wake."""
    out = []
    for t in triggers or []:
        lr = t.get("last_run") or {}
        cfg = (t.get("session_request") or {}).get("config") or {}
        out.append({"id": t.get("id"), "name": t.get("name"), "cron_expression": t.get("cron_expression"), "enabled": t.get("enabled"),
                    "persistent_session_id": t.get("persistent_session_id"), "next_run_at": t.get("next_run_at"),
                    "sources": cfg.get("sources") if cfg else t.get("sources"),
                    "last_run": {"fired_at": lr.get("fired_at") or t.get("last_fired_at"), "finished_at": lr.get("finished_at"), "status": lr.get("status"), "session_id": lr.get("session_id")},
                    "mcp_connections": [c.get("name") if isinstance(c, dict) else c for c in (t.get("mcp_connections") or [])]})
    return out


def compact_sessions(sessions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The fields the page and the spend tile read, from a list_sessions dump — what the CEO writes to
    `coord/tempo/sessions` each wake (0.44.0), in the shape `doctor._session_row` reads back."""
    from .doctor import _session_row
    out = []
    for raw in sessions or []:
        r = _session_row(raw)
        if r["status"].upper().endswith("ARCHIVED"):
            # gone from the page, but a lease it still holds is taken over only if a wake reading this key can see it is
            # archived (`_archived`): the id and the status are all that survive (2026-10-08, the board-key path)
            out.append({"id": r["id"], "session_status": r["status"]})
            continue
        doing = tp._doing(raw)
        out.append({"id": r["id"], "title": r["title"][:120], "tags": r["tags"], "sources": r["repos"],
                    "session_status": r["status"], "status_bucket": r["bucket"], "created_at": r["created_at"],
                    "updated_at": r["updated_at"], "configured_model": r["model"],
                    **({"cost_usd": r["cost"]} if r["cost_known"] else {}),
                    **({"context_tokens": r["tokens"]} if r["tokens_known"] else {}),
                    **({"post_turn_summary": {k: v for k, v in (("needs_action", r["needs"][:200]), ("status_detail", doing)) if v}}
                       if r["needs"] or doing else {})})
    return out


def _echoed_run(wb: Any) -> str | None:
    """The run id a `woken_by` value names: its first word, after the `woken_by:` prefix when the value carries it. The one-shot
    says to echo the line verbatim, and a role that stores it in a field already named `woken_by` drops the prefix (the verifier,
    2026-10-13 18:32:16Z: "wake-20261013T182116-4f86ee handoff_written …"), so both forms are the same echo."""
    if not isinstance(wb, str):
        return None
    text = wb.strip()
    if text.startswith("woken_by:"):
        text = text[len("woken_by:"):]
    parts = text.split()
    return parts[0] if parts else None


def receiver_echoes(board: list[dict[str, Any]], runs: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> dict[str, str]:
    """run_id -> the earliest `at` of a receiver record whose `woken_by` line names it — or of the echo a wake's ledger row
    carries. The live board keeps one record per key, so a role's next record replaces its echo (the verifier, 2026-10-13: its
    18:32Z record echoed 4f86ee, its 20:30Z record replaced it); each wake writes the echoes it saw into its own row (`plan`'s
    `echoes`, `record_wake`), and the ledger keeps them."""
    out: dict[str, str] = {}
    for row in board:
        v = tp._value(row)
        rid = _echoed_run(v.get("woken_by") if v else None)
        if rid:
            at = v.get("at") or row.get("updated_at") or ""
            out[rid] = tp._min_ts(out.get(rid), at) or at
    for r in runs:
        rid = _echoed_run(r.get("woken_by"))
        if rid:
            at = r.get("started_at") or r.get("ended_at") or ""
            out[rid] = tp._min_ts(out.get(rid), at) or at
    for row in ledger_rows(board, cfg):
        for rid, at in (row.get("echoes") or {}).items() if isinstance(row.get("echoes"), dict) else ():
            out[rid] = tp._min_ts(out.get(rid), at) or at
    return out


def echoes_to_record(rows: list[dict[str, Any]], echoes: dict[str, str]) -> dict[str, str]:
    """The echoes a wake writes into its ledger row: those of the spawns and fires the ledger holds that no row carries yet."""
    carried = {rid for r in rows for rid in ((r.get("echoes") or {}) if isinstance(r.get("echoes"), dict) else {})}
    fired = {f.get("run_id") or r.get("run_id") for r in rows for f in (r.get("fired") or [])
             if f.get("kind") in ("spawn", "fire_trigger") and not f.get("could_not")}
    return {rid: echoes[rid] for rid in sorted(fired) if rid in echoes and rid not in carried}


def registrations(board: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """role -> every registration the board rows show in coord/tempo/agents, oldest first. The live board keeps the newest
    one per role; merged facts keep one per gathered snapshot, which is how a DM fired before 0.60.29 finds the agent it reached."""
    out: dict[str, dict[tuple[str, str], dict[str, Any]]] = {}
    for row in board:
        key = str(row.get("key") or "")
        if key.startswith(tp.SPAWNED_SLOT_PREFIX) and key.count("/") == tp.SPAWNED_SLOT_PREFIX.count("/") + 1:
            # a spawned session's own slot key (0.60.36), which an older package's `register` cannot drop
            role, aid = key[len(tp.SPAWNED_SLOT_PREFIX):].split("/", 1)
            e = tp._value(row)
            if e and tp.parse_ts(e.get("registered_at")):
                e = dict(e, agent_id=e.get("agent_id") or aid, side_by_side=True)
                out.setdefault(role, {})[(str(e["registered_at"]), str(e["agent_id"]))] = e
            continue
        if key != tp.AGENTS_KEY:
            continue
        for role, e in (tp._value(row).get("roles") or {}).items():
            if isinstance(e, dict) and e.get("agent_id") and tp.parse_ts(e.get("registered_at")):
                out.setdefault(role, {})[(str(e["registered_at"]), str(e["agent_id"]))] = e
        # a spawned role's sessions side by side (0.60.31): each is a registration of its own, marked as one of several
        for role, by_aid in (tp._value(row).get("spawned") or {}).items():
            for aid, e in (by_aid or {}).items() if isinstance(by_aid, dict) else ():
                if isinstance(e, dict) and tp.parse_ts(e.get("registered_at")):
                    e = dict(e, agent_id=e.get("agent_id") or aid, side_by_side=True)
                    out.setdefault(role, {})[(str(e["registered_at"]), str(e["agent_id"]))] = e
    return {r: sorted(v.values(), key=lambda e: tp.parse_ts(e["registered_at"])) for r, v in out.items()}


def _agent_at(role: str, t: dt.datetime, regs: dict[str, list[dict[str, Any]]]) -> str | None:
    """The agent registered for `role` at instant `t`: its newest registration at or before it; None when none is known —
    and None when two sessions of a spawned role were registered side by side and still listening then: the newest of two
    builders is not the one that wrote a given record, nor the one a given DM reached."""
    got = [e for e in regs.get(role, []) if tp.parse_ts(e["registered_at"]) <= t]
    live = {str(e["agent_id"]) for e in got if e.get("side_by_side") and (tp.parse_ts(e.get("listen_until")) or t) >= t}
    if len(live) > 1:
        return None
    return str(got[-1]["agent_id"]) if got else None


def _rotations_of(aid: str, regs: list[dict[str, Any]]) -> set[str]:
    """Every agent whose registration names `aid` in its `rotated_from` lineage — a session that took over the one a DM
    reached while that one's listener was alive (`org tempo register`, 0.60.29), never a fresh session after it lapsed."""
    return {str(e["agent_id"]) for e in regs if aid in (e.get("rotated_from") or [])}


def role_records_at(board: list[dict[str, Any]]) -> dict[str, list[tuple[str, str | None]]]:
    """role -> (`at`, writer) of every record under roles/<role>/* — a DM's receipt (`orphans`). The writer is the board's
    `updated_by` (gathered since 0.60.29); None for a row gathered before it."""
    out: dict[str, list[tuple[str, str | None]]] = {}
    for row in board:
        m = tp.ROLE_KEY_RE.match(row.get("key") or "")
        at = tp._record_at(row) if m else None
        if at:
            out.setdefault(m["role"], []).append((str(at), row.get("updated_by")))
    return out


def _answered_since(role: str | None, at: str | None, records: dict[str, list[tuple[str, str | None]]],
                    regs: dict[str, list[dict[str, Any]]] | None = None, agent_id: str | None = None) -> bool:
    """A DM is answered by a record newer than it, written by the session it reached or by a rotation of that session.
    The reached agent is the fired entry's `agent_id` (recorded since 0.60.29), else the registration in force when the DM
    went; a record's writer is its `updated_by`, else the registration in force when it was written. Where either side is
    unknown the record still counts, as it did on 0.60.28: an unprovable receipt is not evidence of a loss."""
    return _answer_at(role, at, records, regs, agent_id) is not None


def _answer_at(role: str | None, at: str | None, records: dict[str, list[tuple[str, str | None]]],
               regs: dict[str, list[dict[str, Any]]] | None = None, agent_id: str | None = None) -> str | None:
    """The `at` of the first record that answers a DM (`_answered_since`), None when none does."""
    t = tp.parse_ts(at)
    if not t:
        return None
    regs = regs or {}
    role = role or ""
    target = agent_id or _agent_at(role, t, regs)
    successors = _rotations_of(target, regs.get(role, [])) if target else set()
    for rat, writer in sorted(records.get(role, []), key=lambda r: str(r[0])):
        rt = tp.parse_ts(rat)
        if not rt or rt <= t:
            continue
        w = writer or _agent_at(role, rt, regs)
        if target is None or w is None or w == target or w in successors:
            return rat
    return None


def _receipt_key(f: dict[str, Any], row: dict[str, Any]) -> str:
    """A DM's address in a ledger row's `receipts`: its run and its role — one wake DMs the CEO and the registrar under one run id."""
    return f"{f.get('run_id') or row.get('run_id')} {f.get('role')}"


def carried_receipts(rows: list[dict[str, Any]]) -> dict[str, str]:
    """`_receipt_key` -> the `at` of the record that answered that DM, as the wakes that saw it wrote it into their rows."""
    out: dict[str, str] = {}
    for row in rows:
        for k, at in (row.get("receipts") or {}).items() if isinstance(row.get("receipts"), dict) else ():
            out[k] = tp._min_ts(out.get(k), at) or at
    return out


def receipts_to_record(board: list[dict[str, Any]], rows: list[dict[str, Any]]) -> dict[str, str]:
    """The DM receipts a wake writes into its ledger row: each DM the ledger holds that a record on the board answers now
    and no row carries yet. The live board keeps one record per key, so the answer to a DM is gone once the role's next
    session records — measured on org-core's registrar: a DM at 2026-10-11 21:25:42Z to the parked c5mqsn…, answered by a
    record the plan read by 21:41Z (its #196 and #202 `merged` events cleared), replaced by psGdfm…'s cron record at
    2026-10-12 07:12Z, after which the DM counted as a lost wake toward the registrar's suppression."""
    records, regs, carried = role_records_at(board), registrations(board), carried_receipts(rows)
    out: dict[str, str] = {}
    for row in rows:
        for f in row.get("fired") or []:
            if f.get("kind") != "dm" or f.get("could_not") or _receipt_key(f, row) in carried:
                continue
            at = _answer_at(f.get("role"), f.get("at") or row.get("at"), records, regs, f.get("agent_id"))
            if at:
                out[_receipt_key(f, row)] = at
    return out


_NOT_PARKED_RE = re.compile(r"peer[_ ]parked\W*(?:false|no)\b", re.I)


def undelivered(f: dict[str, Any]) -> bool:
    """A DM the hub said reached no parked listener: `peer_parked: false` in the act's result (recorded since 0.60.55), or in
    the readback the session wrote before then (org-core 2026-10-12 00:25Z–01:45Z: four DMs to the registrar's lapsed
    c5mqsn… read back `peer_parked false`). Nobody received it, so it is the plan's miss, not a wake the role lost."""
    if f.get("kind") != "dm":
        return False
    if f.get("peer_parked") is False:
        return True
    return bool(_NOT_PARKED_RE.search(str(f.get("readback") or "")))


def orphans(facts: dict[str, Any], now: dt.datetime, cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """What the ledger shows went wrong: a fire nobody answered, a role that lost two wakes, a blocked field nobody
    forwarded, an event past target with no fired row since it happened."""
    cfg = cfg or org_tempo({})
    board, runs = facts.get("board", []), facts.get("runs", [])
    rows = ledger_rows(board, cfg)
    echoes = receiver_echoes(board, runs, cfg)
    # a DM wakes a listener that answers in its own record and is never told to echo a `woken_by` line (only a spawned
    # one-shot's prompt carries one), so a record the role wrote after the DM is its receipt. Measured 2026-10-11 on 0.60.25:
    # 237 of 245 unanswered fires were DMs to the listening CEO, held as "suppressed" though it recorded all day
    # — and only by the session it reached: a record by the role's next session after that listener lapsed (the registrar,
    # 2026-10-08: a DM to the parked O8cDjv… at 21:45Z, a cron fire into a new session psGdfm… at 07:12Z) is not its answer
    records = role_records_at(board)
    regs = registrations(board)
    receipts = carried_receipts(rows)
    fired_no_receiver: list[dict[str, Any]] = []
    losses: dict[str, int] = {}
    for row in rows:
        for f in row.get("fired") or []:
            if f.get("kind") not in ("spawn", "fire_trigger", "dm") or f.get("could_not"):
                continue
            rid = f.get("run_id") or row.get("run_id")
            wait = 3 * float(cfg["after_spawn_minutes"].get(f.get("role"), 30))
            age_min = (tp.hours(f.get("at") or row.get("at"), now.isoformat()) or 0) * 60
            if rid in echoes:
                continue
            if f.get("kind") == "dm" and (_receipt_key(f, row) in receipts
                                          or _answered_since(f.get("role"), f.get("at") or row.get("at"), records, regs, f.get("agent_id"))):
                continue
            if age_min > wait:
                lost = {"role": f.get("role"), "run_id": rid, "what": f.get("what"), "at": f.get("at") or row.get("at"), "age_hours": round(age_min / 60, 2)}
                if undelivered(f):
                    # still listed — nobody received it — but never counted toward suppressing a role that was never woken
                    fired_no_receiver.append(dict(lost, undelivered=True))
                    continue
                fired_no_receiver.append(lost)
                losses[f.get("role", "?")] = losses.get(f.get("role", "?"), 0) + 1
    suppressed = sorted(r for r, n in losses.items() if n >= int(cfg["suppress_after_wake_lost"]))
    queued = {(q.get("role"), q.get("at")) for q in operator_queue(board, cfg)}
    queued |= {(q.get("role"), q.get("last_event_at")) for q in operator_queue(board, cfg)}
    forwarded = {(f.get("role"), f.get("event_at")) for row in rows for f in (row.get("fired") or []) if f.get("kind") == "forward"}
    in_queue = {q.get("subject") for q in operator_queue(board, cfg)}
    unforwarded = []
    for b in tp.blocked_now(board, facts.get("roles", {}), now):
        if b.get("blocked") and (b["role"], b.get("record_at")) not in queued and (b["role"], b.get("record_at")) not in forwarded:
            u = {"role": b["role"], "at": b.get("record_at"), "age_hours": b.get("record_age_hours"), "text": tp._cut(b["blocked"], 160),
                 "subjects": b.get("subjects") or {}}
            # a role rewrites its record every wake, so `record_at` is new each time and the field is re-forwarded (which
            # refreshes its row); `new` is whether any of its conditions is not yet a queue row — only that wakes the CEO
            # (org-core 2026-10-11: the dispatcher's unchanged field DMed the CEO on eight wakes in a row, 06:59Z-09:21Z)
            u["new"] = any(subj not in in_queue for subj, _ in blocked_conditions(u))
            unforwarded.append(u)
    return {"fired_no_receiver": fired_no_receiver, "suppressed": suppressed, "unforwarded": unforwarded, "losses": losses}


#: unanswered fires a plan carries by name; the rest are a count. The session reads the plan file to perform its acts, so
#: whatever the file holds is paid for in the actuator's context every wake
PLAN_ORPHANS_SHOWN = 5


def plan_orphans(orph: dict[str, Any]) -> dict[str, Any]:
    """`orphans` as the plan file carries it: the newest unanswered fires and their count, never the whole history.
    Measured 2026-10-11 13:48Z on org-core (0.60.25): plan.json was 46,658 bytes, 33,547 of them `fired_no_receiver` —
    every unanswered fire back to 2026-10-05, 149 h old — while the plan's stdout was 2,001 bytes and `render_plan`, the
    list's only reader, prints 300 characters of it. The doctor and the status page call `orphans` themselves, uncut."""
    out = {k: v for k, v in orph.items() if k != "losses"}
    fnr = sorted(orph.get("fired_no_receiver") or [], key=lambda f: str(f.get("at") or ""), reverse=True)
    out["fired_no_receiver"] = fnr[:PLAN_ORPHANS_SHOWN]
    out["fired_no_receiver_total"] = len(fnr)
    return out


# --- the plan ---------------------------------------------------------------------

SUBJECT_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,}$")


def subject_tags(what: str) -> list[str]:
    """`pr-<n>` for a PR, `item:<key>` for an item key: the census reads the subject from the tags, never from the
    title (NumeroTech 2026-09-21: 35 of 35 spawned sessions carried a role tag, 18 of 35 the documented title, and the
    title format has no slot for a PR)."""
    from .tempo import pr_numbers
    nums = pr_numbers(what)
    if nums:
        return [f"pr-{n}" for n in nums[:3]]
    key = (what or "").strip()
    return [f"item:{key}"] if SUBJECT_KEY_RE.match(key) and "#" not in key else []


def _trigger_for_role(role: str, facts: dict[str, Any]) -> dict[str, Any] | None:
    return tp._triggers_by_role(facts).get(role)


def _minutes_until(ts: str | None, now: dt.datetime) -> float | None:
    h = tp.hours(now.isoformat(), ts) if ts else None
    return None if h is None else h * 60


def render_oneshot(manifest: dict[str, Any], role: str, *, woken_by: str, what: str, scope: str = "",
                   packages: dict[str, Any] | None = None) -> str:
    """The receiver's whole prompt: the `woken_by:` line first, then one thing to do. Template `prompt.oneshot.md`
    in the role package when it has one, else DEFAULT_ONESHOT."""
    from .manifest import flat_vars
    from .render import render_base
    from .roles import discover
    pk = (packages or discover()).get(role)
    tpl = None
    if pk is not None:
        p = Path(pk.dir) / "prompt.oneshot.md"
        tpl = p.read_text() if p.exists() else None
    ctx = flat_vars(manifest)
    entry = manifest["roles"].get(role) or {"name": role}
    ctx.update({"role": entry, "role_id": role, "woken_by": woken_by, "what": what, "scope": scope,
                "scope_line": f" ({scope})." if scope else "."})
    return render_base(tpl or DEFAULT_ONESHOT, ctx)


def _archived(sessions: Any, session_id: Any) -> bool:
    """True only when the sessions list carries that session and says it is archived; a session the list does not carry
    is unknown, never archived (a dump page can be partial), so its lease stays held."""
    rows = sessions.get("data") if isinstance(sessions, dict) else sessions
    for raw in rows or []:
        if isinstance(raw, dict) and _sid(raw.get("id") or raw.get("session_id")) == _sid(session_id):
            return str(raw.get("status") or raw.get("session_status") or "").upper().endswith("ARCHIVED")
    return False


#: the status a merge settles from. Not `ready`: an item the verifier sent back to `ready` after its merge did not work
#: (registrar/verifier: "back to `ready` on dated evidence") would be settled again by that same old merge every wake.
#: Read 2026-10-10 on org-core's store: three `ready` items named by merged builder PRs (#98, #130, #140)
SETTLE_FROM = ("claimed",)


def settle_merged(facts: dict[str, Any], manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Close-on-merge (the operator, 2026-10-10: "close-on-merge - agree"): every item a merged pull request says it built
    (`tempo.built_items` — its `Item:` line or its branch) that the served store still holds `claimed`, by a claim taken
    before the merge (a claim taken after it is a new build, not this one), gets one
    `settle` act, `<cli> status <key> verifying`, which the actuator runs on this wake. Measured 2026-10-10 on org-core's
    store: 19 claims 1.6 to 5 days old, at least six of them on merged pull requests, because the move was nobody's step.

    Only a served store whose statuses were read live: a files-mode org moves an item by PR, and a reading that fell back
    to the committed files carries no live status to compare. A pull request that touches only `roadmap/` files an item,
    so it settles nothing. Broken looks like: a merged builder PR naming a `claimed` item and no `settle` act, or an act
    for an item already `verifying`/`done`/`ready`, for a claim taken after the merge, or for a key no item has."""
    rm = facts.get("roadmap") or {}
    if rm.get("mode") != "served" or rm.get("source") != "the served store":
        return []
    status = {str(r.get("key")): str(r.get("status") or "") for r in (rm.get("items") or [])}
    claimed_at = {str(r.get("key")): r.get("claimed_at") for r in (rm.get("items") or [])}
    cli = str(((manifest.get("ports") or {}).get("work_store") or {}).get("cli") or "roadmap")
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for p in sorted((p for p in facts.get("prs") or [] if p.get("merged_at")), key=lambda p: str(p["merged_at"])):
        if p.get("kind") == "roadmap":
            continue
        for key in p.get("builds") or []:
            if key in seen or status.get(key) not in SETTLE_FROM:
                continue
            c = tp.parse_ts(claimed_at.get(key))
            if c and c > (tp.parse_ts(p["merged_at"]) or c):
                continue
            seen.add(key)
            out.append({"act": "settle", "role": "work_store", "what": key, "pr": p.get("number"), "from": status[key],
                        "event": "merged", "event_at": p["merged_at"], "command": f"{cli} status {key} verifying",
                        "reason": f"#{p.get('number')} merged {p['merged_at']} and names it; the store still says {status[key]}"})
    return out


def _old_still_live(facts: dict[str, Any], old_session: Any) -> bool:
    """A refused rotation still owes a step while any enabled routine is bound to the old session, or the sessions read list
    the old session and it is not archived. A session the list does not carry is unknown, so it counts as not owed."""
    if any(t.get("enabled") and _sid(t.get("persistent_session_id")) == _sid(old_session) for t in facts.get("triggers") or []):
        return True
    rows = facts.get("sessions")
    rows = rows.get("data") if isinstance(rows, dict) else rows
    listed = any(isinstance(x, dict) and _sid(x.get("id") or x.get("session_id")) == _sid(old_session) for x in rows or [])
    return listed and not _archived(rows, old_session)


def pending_rotations(facts: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """role -> the rotation a lapsed-listener one-shot owes (the operator, 2026-10-11 18:49-19:06Z: "Treat it as a rotation").
    A spawn the plan made for a persistent role whose listener lapsed names the session-bound routine and the session it
    replaces (`replaces_trigger`, `replaces_session`: the lineage #191's `rotated_from` cannot carry, since a lapsed listener has
    no heartbeat to read). Once that one-shot echoed (a record whose `woken_by` names its run), its routine is still bound to the
    session it replaces, and the ledger has no `rotate` for that new session, the rotation is pending. The newest such spawn per
    role; `registered` says whether the role registered at or after the spawn.

    A `rotate` the ledger holds for that new session, performed or refused, is never listed again: a refusal part-way may already
    have created the successor, and the triggers key is read once a day (Reed's UNSOUND on #201, 2026-10-11: create ok, archive
    refused, and the next wake listed a second `create_trigger`). A refused one comes back as `refused` while a step is still owed
    (`_old_still_live`), which the plan turns into an ask. Broken looks like: a pending rotation for a one-shot that never echoed,
    one that is archived, one whose routine already moved, or a second rotate for a new session the ledger already rotated."""
    echoes = receiver_echoes(facts.get("board", []), facts.get("runs", []))
    attempts: dict[str, dict[str, Any]] = {}
    for r in rows:
        for f in r.get("fired") or []:
            if f.get("kind") == "rotate" and f.get("new_session"):
                attempts[str(f["new_session"])] = f           # the newest attempt per new session
    regs = registrations(facts.get("board", []))
    out: dict[str, dict[str, Any]] = {}
    for r in rows:
        for f in r.get("fired") or []:
            if f.get("kind") != "spawn" or f.get("could_not") or not f.get("replaces_session") or not f.get("session"):
                continue
            rid = f.get("run_id") or r.get("run_id")
            role, new = f.get("role"), str(f["session"])
            if rid not in echoes or _archived(facts.get("sessions"), new):
                continue
            tried = attempts.get(new)
            if tried:
                if tried.get("could_not") and _old_still_live(facts, f["replaces_session"]):
                    out[role] = {"role": role, "trigger": tried.get("old_trigger") or f.get("replaces_trigger"), "old_session": f["replaces_session"],
                                 "new_session": new, "spawned_by": rid, "echoed_at": echoes[rid],
                                 "refused": {"could_not": tried["could_not"], "new_trigger": tried.get("trigger"), "at": tried.get("at")}}
                continue
            t = _trigger_for_role(role, facts)
            if not t or not t.get("enabled") or _sid(t.get("persistent_session_id")) != _sid(f["replaces_session"]):
                continue
            at = tp.parse_ts(f.get("at") or r.get("at"))
            out[role] = {"role": role, "trigger": t.get("id"), "old_session": f["replaces_session"], "new_session": new,
                         "cron_expression": t.get("cron_expression"), "name": t.get("name"), "spawned_by": rid, "echoed_at": echoes[rid],
                         "registered": bool(at and any((tp.parse_ts(e["registered_at"]) or at) >= at for e in regs.get(role, [])))}
    return out


def plan(facts: dict[str, Any], manifest: dict[str, Any], now: dt.datetime, *, session: Any = None, run_id: str | None = None,
         packages: dict[str, Any] | None = None, requests: list[dict[str, Any]] | None = None, holder: Any = None) -> dict[str, Any]:
    """Events past target → acts, in the order the actuator performs them: `arm` first (a dead session still leaves a
    wake behind), then spawns oldest-first, fires, forwards, asks; holds are listed so the record says why nothing
    happened. `requests` are the routed DMs in this wake's inbox (row 75: a sender's DM to a spawned role lands here as
    `wake <role>: <event> <what>`): the event they name is acted on now, target or not, and one that matches nothing in the
    facts is held with the reason. `holder` is the lease holder's own get_session answer (`--holder-json`): read before the
    sessions list, so a rotation's first wake sees the archived holder whether or not anybody wrote `coord/tempo/sessions`
    (2026-10-08 the key was absent; 2026-10-11 09:29:49Z it held 30 rows, `complete: false`, and not the holder). Nothing
    here touches a port."""
    cfg = org_tempo(manifest)
    sess = session_facts(session)
    run_id = run_id or f"wake-{now:%Y%m%dT%H%M%S}-{uuid.uuid4().hex[:6]}"
    board = facts.get("board", [])
    rep = tp.report(facts, now)
    requests = [r for r in (requests or []) if r.get("role") and r.get("what")]
    if requests:
        rep["wake_now"] = tp.wake_now(facts, now, requested=requests)
    rows = ledger_rows(board, cfg)
    orph = orphans(facts, now, cfg)
    echoes = receiver_echoes(board, facts.get("runs", []), cfg)
    ws_url = manifest["org"]["repo"]
    source_url = f"https://github.com/{ws_url}"
    actions: list[dict[str, Any]] = []
    events: list[dict[str, Any]] = []
    in_flight: dict[str, int] = {}
    for row in rows:
        for f in row.get("fired") or []:
            if f.get("kind") == "spawn" and not f.get("could_not"):
                age_min = (tp.hours(f.get("at") or row.get("at"), now.isoformat()) or 0) * 60
                if age_min <= float(cfg["after_spawn_minutes"].get(f.get("role"), 30)) and (f.get("run_id") or row.get("run_id")) not in echoes:
                    in_flight[f["role"]] = in_flight.get(f["role"], 0) + 1
    rotations = pending_rotations(facts, rows)
    spawned_roles: list[str] = []
    fired_roles: set[str] = set()
    # roles whose events this wake held on a clock no sooner wake moves (its own min interval, its own cron, the actuator's own
    # events, a suppression): their events do not re-arm the busy interval — the floor cron re-reads them
    clock_held: set[str] = set()
    registry = tp.agents_registry(board)
    spawned_reg = tp.spawned_registry(board)
    present = tp.roster_ids(facts.get("agents") or [])
    # a spawned role that is parked right now is addressed, not spawned again (row 178) — since ruling 7 only an older package's session is
    parked_spawned = {l["role"] for l in tp.listeners(facts, now) if l.get("runtime") == "spawned" and l.get("listening")}
    roster_read = facts.get("agents") is not None
    for w in rep["wake_now"]:
        role = w["role"]
        rcfg = dict(tp.DEFAULT_ROLE_TEMPO.get(role, {}))
        rcfg.update((manifest["roles"].get(role) or {}).get("tempo") or {})
        runtime = (facts.get("roles", {}).get(role) or {}).get("runtime") or (manifest["roles"].get(role) or {}).get("runtime")
        on_demand = tp.on_demand_act(rcfg, runtime)
        if on_demand == "spawn" and role in parked_spawned and role != "ceo":
            on_demand = "dm"
        fire_note = ""
        for e in w["events"]:
            events.append({"role": role, "event": e["event"], "what": e["what"], "waiting_hours": e["waiting_hours"], "event_at": e.get("event_at"),
                           **({"requested": True} if e.get("requested") else {})})
        if role == cfg["actuator"]:
            clock_held.add(role)
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "reason": "the actuator's own events — this wake is the actuator, and its dispatch is what answers them"})
            continue
        if not w["fire"]:
            clock_held.add(role)
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": w["why"]})
            continue
        if role in orph["suppressed"]:
            clock_held.add(role)
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "reason": f"suppressed: {orph['losses'].get(role)} wakes fired and no record came back — never pay a third time; the operator decides"})
            continue
        if on_demand == "none":
            continue
        if on_demand == "dm":
            e0 = w["events"][0]
            entry = registry.get(role) or {}
            if runtime == "spawned":
                # the session registered for the event's PR or item, when one did: the newest of two builders is not the one
                # whose PR it is, and since 0.60.29 only the session a DM reached answers it (org-core 2026-10-11)
                entry = next((m for m in (tp.address(spawned_reg.get(role, []), item=ev["what"], prs=tp.pr_numbers(ev["what"]))
                                          for ev in w["events"]) if m), None) or entry
            aid = entry.get("agent_id")
            text = f"tempo {run_id}: " + "; ".join(f"{e['event']} {e['what']} waiting {e['waiting_hours']}h" for e in w["events"][:4])
            lapsed = None
            if not aid:
                lapsed = {"reason": "a persistent role that never registered in coord/tempo/agents — no address to DM; its session has not run `org tempo register`"}
            elif roster_read and aid not in present:
                lapsed = {"agent_id": aid, "reason": f"registered as {aid} but not on the roster — its listener lapsed (parked until {entry.get('listen_until')}); the DM would not be delivered; its cron is the floor"}
            elif why := tp.not_listening(facts, now, entry, runtime or "", present=present):
                # the roster keeps an away row for hours after its listener is gone: the heartbeat says whether a DM wakes it
                # (org-core 2026-10-13 23:27Z–00:09Z: three DMs to the verifier read back `peer_parked false`, each re-armed 20 min out)
                lapsed = {"agent_id": aid, "reason": f"registered as {aid} but {why} — its listener lapsed; the DM would not be delivered; its cron is the floor"}
            if lapsed:
                # a lapsed listener is not a wake that cannot happen: the role's own sourced routine is fired (never the CEO's,
                # never a session-bound one — measured 2026-09-17: that mints a sourceless session), and the plan says it chose that route
                lt = _trigger_for_role(role, facts)
                if role != "ceo" and lt and not lt.get("persistent_session_id"):
                    fire_note = "listener lapsed (" + lapsed["reason"].split(" — ")[0] + "); fired its own routine instead of a DM into nothing"
                    on_demand = "fire_trigger"
                elif role != "ceo" and lt and cfg.get("spawn_lapsed_persistent", True):
                    # a session-bound routine: its cron revives the bound session — the registrar's daily cron did so every
                    # day 2026-10-08..11 and the verifier's on 10-11, a record 2–3 min after each fire — but a forced fire
                    # does not (2026-09-17, 2026-10-07 19:42Z) and `send_later` only wakes its caller. Measured to wake inside the
                    # day: a fresh session (the registrar's rotation, 2026-10-07 20:07Z, record 20:09Z). So: hold when the cron
                    # is due within the window, else one one-shot for all the role's events. Never a rebind or a cron rewrite.
                    whats = ", ".join(e["what"] for e in w["events"][:6])
                    head = lapsed["reason"].split(" — ")[0]
                    due = _minutes_until(lt.get("next_run_at"), now)
                    if due is not None and 0 <= due <= float(cfg["hold_if_cron_due_within_minutes"]):
                        clock_held.add(role)
                        actions.append({"act": "hold", "role": role, "what": whats, **lapsed,
                                        "reason": f"listener lapsed ({head}); its session-bound cron fires in {due:.0f} min and revives the bound session — the wake is free"})
                        continue
                    if role in rotations:
                        clock_held.add(role)
                        actions.append({"act": "hold", "role": role, "what": whats, **lapsed,
                                        "reason": f"listener lapsed ({head}); the one-shot {rotations[role]['new_session']} echoed and its rotation is "
                                                  + ("refused part-way and asked" if rotations[role].get("refused") else "pending") + " — never a second spawn"})
                        continue
                    if in_flight.get(role):
                        clock_held.add(role)
                        actions.append({"act": "hold", "role": role, "what": whats, **lapsed,
                                        "reason": f"listener lapsed ({head}); a one-shot spawned for it within {cfg['after_spawn_minutes'].get(role, 30)} min has not echoed yet — never two"})
                        continue
                    expected = now + dt.timedelta(minutes=float(cfg["after_spawn_minutes"].get(role, 30)))
                    woken_by = f"woken_by: {run_id} {e0['event']} {whats} event_at={e0.get('event_at') or '?'} fired_at={now.isoformat(timespec='seconds')} expected_by={expected.isoformat(timespec='seconds')}"
                    actions.append({"act": "spawn", "role": role, "what": whats, "event": e0["event"], "event_at": e0.get("event_at"), "run_id": run_id,
                                    "title": f"{role} — {whats}"[:120], "source_url": source_url,
                                    # the lineage: once this one-shot echoes, a later plan rotates the routine onto it (`pending_rotations`)
                                    "replaces_trigger": lt.get("id"), "replaces_session": lt.get("persistent_session_id"),
                                    "tags": [f"org:{manifest['org']['id']}", f"role:{role}", f"woken-by:{run_id}", f"event:{e0['event']}", "lapsed-listener"],
                                    "prompt": render_oneshot(manifest, role, woken_by=woken_by, what=whats, packages=packages),
                                    "reason": f"{len(w['events'])} event(s) past the {w['target_hours']}h target; listener lapsed ({head}) and its routine is "
                                              f"session-bound ({lt.get('id')}: a forced fire never reaches the bound session; its cron is "
                                              + (f"{due / 60:.1f} h away" if due is not None else "not scheduled")
                                              + ") — spawned a one-shot instead of an ask that reaches nobody"})
                    spawned_roles.append(role)
                    continue
                else:
                    actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "event": e0["event"], "event_at": e0.get("event_at"), **lapsed})
                    continue
            if on_demand == "dm":
                actions.append({"act": "dm", "role": role, "agent_id": aid, "what": ", ".join(e["what"] for e in w["events"][:4]), "event": e0["event"], "event_at": e0.get("event_at"),
                                "run_id": run_id, "text": text, "reason": f"{len(w['events'])} event(s) past the {w['target_hours']}h target; the receiver is listening" + ("" if roster_read else " (roster unread — sent on the registry alone)")})
                fired_roles.add(role)
            if on_demand == "dm":
                continue
        if role == "ceo" and on_demand == "spawn" and not cfg.get("spawned_merge_proven"):
            actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:6]), "event": w["events"][0]["event"],
                            "reason": "a spawned CEO one-shot merging is unproven (tempo.spawned_merge_proven: false) — a human-started CEO session merges, or the operator says the grant covers a one-shot"})
            continue
        if on_demand == "spawn":
            cap = int(rcfg.get("max_concurrent", 1))
            room = max(0, cap - in_flight.get(role, 0))
            ordered = sorted(w["events"], key=lambda e: -(e["waiting_hours"] or 0)) if rcfg.get("order", "oldest_first") == "oldest_first" else sorted(w["events"], key=lambda e: (e["waiting_hours"] or 0))
            for e in ordered[:room]:
                expected = now + dt.timedelta(minutes=float(cfg["after_spawn_minutes"].get(role, 30)))
                woken_by = f"woken_by: {run_id} {e['event']} {e['what']} event_at={e.get('event_at') or '?'} fired_at={now.isoformat(timespec='seconds')} expected_by={expected.isoformat(timespec='seconds')}"
                scope = e.get("scope", "")
                actions.append({"act": "spawn", "role": role, "what": e["what"], "event": e["event"], "event_at": e.get("event_at"), "run_id": run_id,
                                "title": f"{role} — {e['what']}" + (f" ({scope})" if scope else ""), "source_url": source_url,
                                "tags": [f"org:{manifest['org']['id']}", f"role:{role}", f"woken-by:{run_id}", f"event:{e['event']}"] + subject_tags(e["what"]),
                                "prompt": render_oneshot(manifest, role, woken_by=woken_by, what=e["what"], scope=scope, packages=packages),
                                "reason": (f"requested by DM: {e['event']} {e['what']}" if e.get("requested") else f"{e['event']} {e['what']} waiting {e['waiting_hours']}h (target {w['target_hours']}h)")})
                spawned_roles.append(role)
            if len(ordered) > room:
                actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in ordered[room:][:4]),
                                "reason": f"max_concurrent {cap}: {in_flight.get(role, 0)} in flight, {min(room, len(ordered))} spawned this wake"})
            continue
        if on_demand == "fire_trigger":
            t = _trigger_for_role(role, facts)
            if not t:
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": "no routine seen for this role in the triggers facts — nothing to fire"})
                continue
            if t.get("persistent_session_id"):
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                                "reason": f"routine {t.get('id')} is session-bound: a forced fire mints a sourceless fresh session and never reaches the bound session (measured 2026-09-17); never fire it"})
                continue
            due = _minutes_until(t.get("next_run_at"), now)
            if due is not None and 0 <= due <= float(cfg["hold_if_cron_due_within_minutes"]):
                clock_held.add(role)
                actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": f"its own cron fires in {due:.0f} min — the wake is free"})
                continue
            text = "tempo: " + ", ".join(f"{e['event']} {e['what']} waiting {e['waiting_hours']}h" for e in w["events"][:4])
            actions.append({"act": "fire_trigger", "role": role, "trigger": t.get("id"), "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "event": w["events"][0]["event"], "event_at": w["events"][0].get("event_at"), "run_id": run_id, "text": text,
                            "reason": f"{len(w['events'])} event(s) past the {w['target_hours']}h target; " + (f"{fire_note}" if fire_note else "sourced fresh routine")})
            fired_roles.add(role)
    matched = {(e["role"], e["what"]) for e in events if e.get("requested")}
    for r in requests:
        if (r["role"], str(r["what"])) not in matched:
            actions.append({"act": "hold", "role": r["role"], "what": str(r["what"]), "event": r.get("event"),
                            "reason": f"requested by DM from {r.get('from') or '?'} ({r.get('event')} {r['what']}) but the facts show no such open event — already answered, not a role this plan wakes, or not yet visible to gh"})
    for u in orph["unforwarded"]:
        for subj, text in blocked_conditions(u):
            actions.append({"act": "forward", "role": u["role"], "subject": subj, "what": text, "event": "blocked_written", "event_at": u["at"], "run_id": run_id,
                            "reason": f"blocked field {u['age_hours']}h old and not in the operator queue"})
        events.append({"role": u["role"], "event": "blocked_written", "what": u["text"][:80], "waiting_hours": u["age_hours"], "event_at": u["at"]})
    ceo_cfg = dict(tp.DEFAULT_ROLE_TEMPO.get("ceo", {}))
    ceo_cfg.update((manifest["roles"].get("ceo") or {}).get("tempo") or {})
    ceo_rt = (facts.get("roles", {}).get("ceo") or {}).get("runtime") or (manifest["roles"].get("ceo") or {}).get("runtime")
    fresh = [u for u in orph["unforwarded"] if u.get("new", True)]
    if fresh and "blocked_written" in (ceo_cfg.get("wake_on") or []) and tp.on_demand_act(ceo_cfg, ceo_rt) == "dm" \
            and (manifest["roles"].get("ceo") or {}).get("enabled", True) and cfg["actuator"] != "ceo":
        # row 86: the CEO listens for blocked fields — the forward above puts them in the operator queue, the DM wakes the reader
        entry = registry.get("ceo") or {}
        aid = entry.get("agent_id")
        whats = ", ".join(u["role"] for u in fresh[:4])
        text = f"tempo {run_id}: " + "; ".join(f"blocked_written {u['role']} waiting {u['age_hours']}h" for u in fresh[:4])
        if not aid:
            actions.append({"act": "ask", "role": "ceo", "what": whats, "event": "blocked_written", "event_at": fresh[0]["at"],
                            "reason": "the CEO listens for blocked fields but never registered in coord/tempo/agents — no address to DM; the operator queue holds the forward"})
        elif roster_read and aid not in present or (why := tp.not_listening(facts, now, entry, ceo_rt or "", present=present)):
            how = "not on the roster" if roster_read and aid not in present else why
            actions.append({"act": "ask", "role": "ceo", "what": whats, "event": "blocked_written", "event_at": fresh[0]["at"], "agent_id": aid,
                            "reason": f"registered as {aid} but {how} — its listener lapsed (parked until {entry.get('listen_until')}); the operator queue holds the forward; its cron is the floor"})
        else:
            actions.append({"act": "dm", "role": "ceo", "agent_id": aid, "what": whats, "event": "blocked_written", "event_at": fresh[0]["at"],
                            "run_id": run_id, "text": text, "reason": f"{len(orph['unforwarded'])} blocked field(s) forwarded; the CEO listens for them" + ("" if roster_read else " (roster unread — sent on the registry alone)")})
    for role, rot in rotations.items():
        if rot.get("refused"):
            ref = rot["refused"]
            made = f"it created {ref['new_trigger']} — never create another" if ref.get("new_trigger") else "no successor routine was recorded as created"
            actions.append({"act": "ask", "role": role, "what": f"rotate {rot['trigger']} → {rot['new_session']}", "event": "rotation_refused", "event_at": ref.get("at"),
                            "reason": f"the rotation onto {rot['new_session']} was refused part-way at {ref.get('at')} ({ref['could_not']}); {made}; "
                                      f"the routine {rot['trigger']} or the session {rot['old_session']} is still live — the operator finishes it, and no plan lists it again"})
            continue
        if not rot["registered"]:
            actions.append({"act": "hold", "role": role, "what": f"rotate {rot['trigger']} → {rot['new_session']}",
                            "reason": f"the one-shot {rot['new_session']} echoed {rot['echoed_at']} but {role} has not registered since it was spawned — the rotation waits for an address"})
            continue
        from .render import UndeclaredVariable
        from .roles import discover
        from .routine import spec as routine_spec
        try:
            prompt = routine_spec(manifest, packages or discover(), role)["prompt"]
        except (ValueError, KeyError, UndeclaredVariable):   # one unrenderable prompt degrades its act, never the plan
            prompt = None
        actions.append({"act": "rotate", "role": role, "what": f"{rot['trigger']} → {rot['new_session']}", "event": "rotation", "event_at": rot["echoed_at"],
                        "run_id": run_id, "trigger": rot["trigger"], "old_session": rot["old_session"], "new_session": rot["new_session"],
                        "cron_expression": rot["cron_expression"], "name": rot["name"], "prompt": prompt, "spawned_by": rot["spawned_by"],
                        "reason": f"the one-shot {rot['new_session']} spawned by {rot['spawned_by']} for a lapsed listener echoed {rot['echoed_at']} and registered; "
                                  f"routine {rot['trigger']} is still bound to {rot['old_session']} — a rotation (the operator, 2026-10-11): same cron, new session, old archived"})
    for a in settle_merged(facts, manifest):
        actions.append({**a, "run_id": run_id})
    for f in orph["fired_no_receiver"]:
        if f["role"] not in orph["suppressed"] and f["role"] not in spawned_roles:
            actions.append({"act": "ask", "role": f["role"], "what": f["what"], "event": "receiver_missing", "event_at": f["at"],
                            "reason": f"fired {f['run_id']} {f['age_hours']}h ago and no record echoed it — re-spawn is the next plan's call once; two losses suppress the role"})
    # when to wake next
    waits: list[float] = []
    for role in spawned_roles:
        waits.append(float(cfg["after_spawn_minutes"].get(role, 30)))
    for role in fired_roles:
        waits.append(float(cfg["after_spawn_minutes"].get(role, 25)))
    # measured 2026-10-11 on coord/tempo/wakes-2026-10-11: session …EqCqJ8 armed every one of its ten wakes 20 min out on
    # events held by the CEO's and the registrar's min interval alone, so it woke ~3 times an hour, +5,464 to +37,020 tokens
    # each, and hit ROTATE 3 h after its first row (128,989 → 253,769). Broken looks like: an arm whose reason is only held events
    open_events = [e for e in events if e["event"] != "blocked_written" and e["role"] not in clock_held]
    if open_events and cfg["wake_interval_minutes"].get("busy"):
        waits.append(float(cfg["wake_interval_minutes"]["busy"]))
    next_wake = (now + dt.timedelta(minutes=min(waits))).replace(microsecond=0) if waits else None
    rotate = bool(sess.get("context_tokens") and int(sess["context_tokens"]) > int(cfg["rotate_at_tokens"]))
    lz = lease(board, cfg)
    lease_held = bool(lz and lz.get("session_id") and _sid(lz["session_id"]) != _sid(sess.get("id")) and (tp.parse_ts(lz.get("until")) or now) > now and sess.get("id"))
    listed = facts.get("sessions")
    listed = listed.get("data") if isinstance(listed, dict) else listed
    # the holder's own answer first: it is read this wake, by id, where the list is whatever page somebody last wrote
    known = ([holder.get("ccr", holder)] if isinstance(holder, dict) else []) + list(listed or [])
    lease_taken_over = bool(lease_held and _archived(known, lz["session_id"]))
    if lease_taken_over:
        lease_held = False        # a rotation archives the old session: its lease is a dead holder's, not two hours of dispatch lost
    arm = bool(next_wake) and not rotate and not lease_held
    if arm:
        actions.insert(0, {"act": "arm", "at": next_wake.isoformat(timespec="seconds"), "run_id": run_id,
                           "text": f"tempo wake (armed by {run_id} at {now.isoformat(timespec='seconds')}): run the four-call wake — plan, execute, record. Reason: " + "; ".join(f"{e['event']} {e['what']}" for e in open_events[:5]),
                           "reason": "the earliest of: after-spawn expectation, the busy interval"})
    real = [a for a in actions if a["act"] in ("spawn", "fire_trigger", "forward", "ask", "dm", "settle", "rotate")]
    exit_code = 5 if lease_held else 4 if rotate else 3 if (real or arm) else 0
    return {
        "run_id": run_id, "at": now.isoformat(timespec="seconds"), "org": manifest["org"]["id"], "session_id": sess.get("id"),
        "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"),
        "events": events, "actions": actions, "next_wake_at": next_wake.isoformat(timespec="seconds") if next_wake else None,
        "arm": arm, "idle": not real and not arm, "rotate": rotate, "lease_held": lease_held, "lease_taken_over": lease_taken_over,
        "lease_holder": (lz or {}).get("session_id") if (lease_held or lease_taken_over) else None,
        "orphans": plan_orphans(orph), "slow": rep["slow"], "exit_code": exit_code,
        "could_not_read": facts.get("could_not_read", []),
        "queue_current": queue_current(board, facts.get("roles", {}), now),
        "echoes": echoes_to_record(rows, echoes),
        "receipts": receipts_to_record(board, rows),
    }


def render_plan(p: dict[str, Any]) -> str:
    L = [f"tempo wake plan {p['run_id']} — {p['org']} at {p['at']}" + (f", session {p['session_id']}" if p.get("session_id") else "")
         + (f", {p['context_tokens']} tokens" if p.get("context_tokens") else "")]
    if p["rotate"]:
        L.append(f"  ROTATE: context over the threshold — nothing is armed; spawns and fires below still run once, then the operator rebinds the floor routine to a fresh session")
    if p["lease_held"]:
        L.append("  LEASE: another live session holds coord/tempo/lease — do nothing this wake")
    if p.get("lease_taken_over"):
        L.append("  LEASE: the holder is archived — this wake takes coord/tempo/lease over")
    for a in p["actions"]:
        if a["act"] == "arm":
            L.append(f"  ARM      send_later at {a['at']} — {a['reason']}")
        elif a["act"] == "spawn":
            L.append(f"  SPAWN    {a['role']:<16} {a['what']:<28} create_session(source_url, prompt, title={a['title']!r}) — {a['reason']}")
        elif a["act"] == "dm":
            L.append(f"  DM       {a['role']:<16} {a['what']:<28} switchboard dm {a['agent_id']} — {a['reason']}")
        elif a["act"] == "fire_trigger":
            L.append(f"  FIRE     {a['role']:<16} {a['what']:<28} fire_trigger({a['trigger']}, text) — {a['reason']}")
        elif a["act"] == "forward":
            L.append(f"  FORWARD  {a['role']:<16} blocked: {a['what'][:90]}")
        elif a["act"] == "ask":
            L.append(f"  ASK      {a['role']:<16} {a['what']:<28} — {a['reason']}")
        elif a["act"] == "rotate":
            L.append(f"  ROTATE   {a['role']:<16} create_trigger({a['cron_expression']}, persistent_session_id={a['new_session']}), disable {a['trigger']}, archive {a['old_session']} — {a['reason']}")
        elif a["act"] == "settle":
            L.append(f"  SETTLE   {a['what']:<45} {a['command']} — {a['reason']}")
        else:
            L.append(f"  HOLD     {a['role']:<16} {a['what']:<28} — {a['reason']}")
    if p["idle"]:
        L.append("  idle: nothing this wake can act on, nothing armed — the org waits on its cron floor")
    if p["orphans"].get("fired_no_receiver_total", 0) > len(p["orphans"].get("fired_no_receiver") or []):
        L.append(f"  orphans fired_no_receiver: {p['orphans']['fired_no_receiver_total']} unanswered, the newest {len(p['orphans']['fired_no_receiver'])} below")
    for k in ("fired_no_receiver", "suppressed", "unforwarded"):
        if p["orphans"].get(k):
            L.append(f"  orphans {k}: {json.dumps(p['orphans'][k], ensure_ascii=False)[:300]}")
    if p.get("could_not_read"):
        L.append("  could not read: " + "; ".join(p["could_not_read"]))
    L.append(f"  next wake {p['next_wake_at'] or 'none (cron floor)'}; exit {p['exit_code']}")
    return "\n".join(L) + "\n"


# --- the record -------------------------------------------------------------------

def record_wake(p: dict[str, Any], results: list[dict[str, Any]], now: dt.datetime, *, session: Any = None,
                previous: dict[str, Any] | None = None, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """The ledger row, the heartbeat and the lease from a plan and the port's answers. `results` is one entry per
    action index the session performed: {i, ok, id, readback, could_not, peer_parked}. A planned spawn/fire/arm with no result is
    a problem the row carries — a wake that says it fired and cannot show the id did not fire."""
    cfg = org_tempo(manifest or {})
    sess = session_facts(session) if session else {"id": p.get("session_id"), "context_tokens": p.get("context_tokens"), "cost_usd": p.get("cost_usd")}
    by_i = {int(r["i"]): r for r in results if "i" in r}
    fired: list[dict[str, Any]] = []
    problems: list[str] = []
    for i, a in enumerate(p["actions"]):
        r = by_i.get(i)
        entry = {"role": a.get("role"), "kind": a["act"], "what": a.get("what") or a.get("at"), "event": a.get("event"), "event_at": a.get("event_at"),
                 "run_id": a.get("run_id") or p["run_id"], "at": (r or {}).get("at") or now.isoformat(timespec="seconds")}
        if a["act"] == "rotate":
            # the ids, performed or refused: a refusal part-way may already have created the successor (Reed, #201)
            entry.update({"trigger": (r or {}).get("id"), "old_trigger": a.get("trigger"), "old_session": a.get("old_session"), "new_session": a.get("new_session")})
        if a["act"] in ("spawn", "fire_trigger", "arm", "dm", "settle", "rotate"):
            if r is None:
                entry["could_not"] = "no result recorded for this action"
                problems.append(f"{a['act']} {a.get('role') or a.get('at')}: no result")
            elif r.get("could_not") or not r.get("ok", True):
                entry["could_not"] = r.get("could_not") or "refused"
                problems.append(f"{a['act']} {a.get('role') or a.get('at')}: {entry['could_not']}")
            else:
                if a["act"] == "settle":
                    entry["pr"], entry["command"] = a.get("pr"), a.get("command")
                elif a["act"] != "rotate":
                    entry[{"spawn": "session", "dm": "message"}.get(a["act"], "trigger")] = r.get("id") or a.get("trigger") or a.get("agent_id")
                if a["act"] == "spawn" and a.get("replaces_session"):
                    entry["replaces_trigger"], entry["replaces_session"] = a.get("replaces_trigger"), a["replaces_session"]
                if a["act"] == "dm" and a.get("agent_id"):
                    entry["agent_id"] = a["agent_id"]     # the session the DM reached: only its record (or its rotation's) answers it
                if a["act"] == "dm" and isinstance(r.get("peer_parked"), bool):
                    entry["peer_parked"] = r["peer_parked"]     # the hub's answer: false is a DM nobody received (`undelivered`)
                entry["readback"] = r.get("readback")
        elif a["act"] == "ask":
            entry["readback"] = (r or {}).get("readback")
        fired.append(entry)
    cost_prev = (previous or {}).get("cost_usd")
    delta = round(float(sess["cost_usd"]) - float(cost_prev), 4) if sess.get("cost_usd") is not None and cost_prev is not None else None
    interval_min = _minutes_until(p.get("next_wake_at"), now) if p.get("next_wake_at") else None
    ttl = int(max(1800, 2 * 60 * (interval_min if interval_min and interval_min > 0 else 60)))
    row = {"run_id": p["run_id"], "at": p["at"], "recorded_at": now.isoformat(timespec="seconds"), "session_id": sess.get("id"),
           "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"), "cost_delta_usd": delta,
           "events": p["events"], "fired": fired, "next_wake_at": p.get("next_wake_at"), "idle": p["idle"], "rotate": p["rotate"], "problems": problems}
    if p.get("echoes"):
        row["echoes"] = p["echoes"]     # the echoes this wake saw, kept after the receiver's next record replaces them
    if p.get("receipts"):
        row["receipts"] = p["receipts"]     # the DM answers this wake saw, kept after the role's next session records
    hb = {"at": now.isoformat(timespec="seconds"), "run_id": p["run_id"], "next_wake_at": p.get("next_wake_at"), "session_id": sess.get("id"),
          "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"), "cost_delta_usd": delta,
          "wakes_today": int((previous or {}).get("wakes_today") or 0) + 1 if str((previous or {}).get("at", ""))[:10] == now.strftime("%Y-%m-%d") else 1,
          "rotate": p["rotate"], "ttl_seconds": ttl}
    lz = {"session_id": sess.get("id"), "until": (now + dt.timedelta(seconds=ttl)).isoformat(timespec="seconds"), "run_id": p["run_id"]}
    queue_add = [{"role": a.get("role"), "subject": a.get("subject") or queue_subject(a.get("role"), a.get("what")), "ask": a.get("what"),
                  "kind": a["act"], "event_at": a.get("event_at"), "from": p["run_id"], "forwarded_at": now.isoformat(timespec="seconds")}
                 for a in p["actions"] if a["act"] in ("forward", "ask")]
    return {"row": row, "heartbeat": hb, "lease": lz, "ledger_key": f"{cfg['ledger_key']}-{now:%Y-%m-%d}", "heartbeat_key": cfg["heartbeat_key"],
            "lease_key": cfg["lease_key"], "operator_queue_key": cfg["operator_queue_key"], "queue_add": queue_add,
            "queue_current": p.get("queue_current"), "ttl_seconds": ttl,
            "fired": fired, "problems": problems}


def wake_cost_series(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """$ per wake from consecutive ledger rows' cost_usd (the session total read at each wake), not a total divided by a guess."""
    rows = ledger_rows(board, cfg)
    out = []
    prev = None
    for r in rows:
        c = r.get("cost_usd")
        if c is not None and prev is not None and r.get("session_id") == prev.get("session_id") and prev.get("cost_usd") is not None:
            out.append({"run_id": r["run_id"], "at": r.get("at"), "usd": round(float(c) - float(prev["cost_usd"]), 4), "context_tokens": r.get("context_tokens"), "idle": r.get("idle")})
        prev = r
    return out
