"""The admission gate: an outward role admits only people on a batch card the operator approved, and never past the readiness
number — which is zero with no fresh reading (item `tess-admits-only-inside-an-approved-batch-under-a-fresh-readiness-number`,
SPEC §16 decision 17, §10, §12).

Why. Two rulings, and only these, are the contract:

  - d17's admission question, ruled on 2026-09-27, *"Role, inside the batch"*: once the operator approves a batch, the customer
    role admits those people, never past the readiness number. Lucille's launch doctrine says where the number comes from:
    "Before each new batch, a production readiness reading sets how many people the system can carry through a working first week";
  - the operator, asked in the planning session of 2026-10-11 to 13 (by 2026-10-13 02:23Z) what the number is when no reading is
    current: *"Zero until a reading"*. The last reading recorded on d17 was taken 2026-09-26 and marked stale by Lucille's CEO on
    2026-09-30 — a number nobody re-read is the case the ruling exists for.

What it does (the shapes below are the item's proposal, undated, not ruled — each is an open question on the PR that added this):

  - a **reading** — `{number, taken_at, source, by}`: how many people production can carry, when (a UTC instant), where it was read,
    and who took it. `effective_number` reads it as of now: no reading, an unreadable one, one older than the window (`WINDOW_DAYS`,
    a knob in `WINDOW_RANGE`), or one whose number is outside its range (`NUMBER_RANGE`, or the manifest's `knobs:
    {"<role>.readiness_number": {range: [..]}}`) is **zero**. Outside the range is `knob_outside_range`, the operator's: it is read
    as zero, never clamped to the range's edge;
  - a **batch card** — the role, the people as production ids (never a name or an address: CLAUDE.md, the outward guard), and a
    number — and the operator's **approval** of it, bound to the card's hash;
  - one **admit helper**, `admit`, which refuses unless an approval of this exact card is on record, the person is on it, has not
    been admitted from it, and the batch's admissions so far are under both the card's number and the effective readiness number
    *as of this admission*. It writes the ledger row **before** the org's admission path runs, so a path that fails uses its slot
    and never makes room for one past the number;
  - **admitted** is the person's served state read back from production (`mark_admitted`), never the path's return — until then
    the row reads `requested`.

What it is not. It admits nobody on its own (CLAUDE.md rule 6): `path` is the caller's — in Lucille a `user_visible` scoped route,
per Lucille's docs — and every test hands it a fake. It does not decide where readings, cards, approvals and the ledger are kept;
the caller passes them in. Every refusal is `AdmissionRefused`, raised before `path` is called.

Broken looks like: `path` called with no fresh reading, past the number, for a person not on the approved card, on a card edited
after approval, or twice for one person; a reading read as its number when it is stale, undated, unsourced or out of range; or a
row read as admitted with no served state beside it.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from typing import Any, Callable

from .claim_gate import _utc
from .knobs import declared_range

#: the freshness window, in days: the item's proposal (undated, not ruled). Inside `WINDOW_RANGE` it is the CEO's; outside,
#: `knob_outside_range`, the operator's
WINDOW_DAYS = 7
WINDOW_RANGE = (1, 30)
#: the readiness number's range when the manifest declares none: a proposal. Inside it the number is the CEO's; outside, the operator's
NUMBER_RANGE = (0, 50)
#: a reading taken a little in the future of `now` is clock skew between containers; beyond it, unreadable
SKEW = dt.timedelta(minutes=5)
KNOB = "readiness_number"

KIND = "batch_card"
REQUESTED, ADMITTED = "requested", "admitted"
#: a production id: letters, digits and `-_.:`, no `@` and no space — a name or an address is refused at the card
_PERSON_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}")
PEOPLE_MAX = 500


class AdmissionError(ValueError):
    pass


class AdmissionRefused(RuntimeError):
    pass


def window(days: Any = None) -> float:
    """The freshness window in days: `WINDOW_DAYS` when none is set, refused outside `WINDOW_RANGE` — never clamped."""
    if days is None:
        return WINDOW_DAYS
    if isinstance(days, bool) or not isinstance(days, (int, float)):
        raise AdmissionError(f"the readiness window is a number of days, not {days!r}")
    lo, hi = WINDOW_RANGE
    if not lo <= days <= hi:
        raise AdmissionError(f"readiness window {days:g} d is outside its range {lo}–{hi} d — outside it is the operator's "
                             "(knob_outside_range)")
    return days


def number_range(role: str = "tess", manifest: dict[str, Any] | None = None) -> tuple[float, float]:
    return declared_range(f"{role}.{KNOB}", manifest) or NUMBER_RANGE


def effective_number(reading: Any, *, now: dt.datetime | None = None, window_days: Any = None, role: str = "tess",
                     manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """The number this role may admit up to, as of `now`: the reading's number when it is dated, sourced, signed, inside the window
    and inside its range — otherwise **0** ("Zero until a reading"). Returns `{number, state, why, taken_at}`, `state` one of
    `fresh`, `absent`, `unreadable`, `stale`, `outside_range`."""
    now = now or dt.datetime.now(dt.timezone.utc)
    days = window(window_days)

    def zero(state: str, why: str) -> dict[str, Any]:
        return {"number": 0, "state": state, "why": why + " — the number is zero until a reading", "taken_at": None}

    if reading is None:
        return zero("absent", "no readiness reading")
    if not isinstance(reading, dict):
        return zero("unreadable", "a readiness reading is {number, taken_at, source, by}")
    n = reading.get("number")
    if isinstance(n, bool) or not isinstance(n, int) or n < 0:
        return zero("unreadable", f"the readiness number is a whole number of people, not {n!r}")
    taken = _utc(reading.get("taken_at"))
    if taken is None:
        return zero("unreadable", "the readiness reading carries no UTC instant it was taken at")
    if not str(reading.get("source") or "").strip():
        return zero("unreadable", "the readiness reading names no source")
    if not str(reading.get("by") or "").strip():
        return zero("unreadable", "the readiness reading names nobody who took it")
    if taken > now + SKEW:
        return zero("unreadable", f"the readiness reading is dated {taken.isoformat()}, after now")
    if now - taken > dt.timedelta(days=days):
        return zero("stale", f"the readiness reading of {taken.isoformat()} is older than {days:g} d")
    lo, hi = number_range(role, manifest)
    if not lo <= n <= hi:
        return zero("outside_range", f"readiness number {n} is outside its range {lo:g}–{hi:g} — outside it is the operator's "
                                     "(knob_outside_range)")
    return {"number": n, "state": "fresh", "why": "", "taken_at": taken.isoformat()}


def _hash(c: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps([c.get("role"), c.get("people"), c.get("number")], sort_keys=True).encode()).hexdigest()


def batch_card(raw: Any, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """A batch card: `{role, people, number}` — the people as production ids, distinct, and the number the operator is asked to
    approve. The card's id is its hash; it carries no name or address (an id with `@` or a space is refused)."""
    if not isinstance(raw, dict):
        raise AdmissionError("a batch card is {role, people, number}")
    role = str(raw.get("role") or "").strip()
    people = raw.get("people")
    n = raw.get("number")
    if not role:
        raise AdmissionError("a batch card names the role that admits from it")
    if not isinstance(people, list) or not people:
        raise AdmissionError("a batch card lists at least one person, by production id")
    if len(people) > PEOPLE_MAX:
        raise AdmissionError(f"a batch card lists at most {PEOPLE_MAX} people")
    for p in people:
        if not isinstance(p, str) or not _PERSON_ID.fullmatch(p):
            raise AdmissionError("a batch card lists production ids only — never a name or an address")
    if len(set(people)) != len(people):
        raise AdmissionError("a batch card lists each person once")
    if isinstance(n, bool) or not isinstance(n, int) or n < 1:
        raise AdmissionError(f"a batch card's number is a whole number of people, at least 1, not {n!r}")
    c = {"kind": KIND, "role": role, "people": list(people), "number": n,
         "filed_at": (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")}
    c["sha256"] = _hash(c)
    c["id"] = c["sha256"][:12]
    return c


def approve_batch(c: dict[str, Any], by: str, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """The operator's approval of the card as shown: its hash, who, and when."""
    if not str(by or "").strip():
        raise AdmissionError("an approval says who approved it")
    if c.get("sha256") != _hash(c):
        raise AdmissionError(f"card {c.get('id')}: its people or number changed after it was filed — file a new card")
    a = {"card": c["id"], "sha256": c["sha256"], "number": c["number"], "people": len(c["people"]), "by": str(by).strip()[:120],
         "at": (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")}
    a["id"] = hashlib.sha256(json.dumps([a["card"], a["sha256"], a["by"], a["at"]]).encode()).hexdigest()[:12]
    return a


def _approval(c: dict[str, Any], approvals: list[dict[str, Any]] | None) -> dict[str, Any]:
    mine = [a for a in approvals or [] if a.get("card") == c.get("id")]
    if not mine:
        raise AdmissionRefused(f"batch {c.get('id')}: no approval on record — nobody is admitted from a batch the operator did not approve")
    h = _hash(c)
    match = [a for a in mine if a.get("sha256") == h == c.get("sha256")]
    if not match:
        raise AdmissionRefused(f"batch {c.get('id')}: this card is not the batch approved — its people or number changed; file a new card")
    return match[0]


def admit(person: str, c: dict[str, Any], approvals: list[dict[str, Any]], ledger: list[dict[str, Any]],
          path: Callable[[str], Any], *, reading: Any, now: dt.datetime | None = None, window_days: Any = None,
          manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """Admit `person` through the org's own `path` if, and only if, the operator approved this exact card, the person is on it and
    not yet admitted from it, and the batch's admissions so far are under the card's number and the readiness number read **now**.
    The ledger row is written before `path` runs. Returns the row, `state` `requested`; `mark_admitted` makes it `admitted`."""
    now = now or dt.datetime.now(dt.timezone.utc)
    a = _approval(c, approvals)
    if person not in c["people"]:
        raise AdmissionRefused(f"batch {c['id']}: this person is not on the approved batch — a new person is a new card")
    mine = [r for r in ledger if r.get("card") == c["id"]]
    if any(r.get("person") == person for r in mine):
        raise AdmissionRefused(f"batch {c['id']}: this person was already admitted from it")
    try:
        e = effective_number(reading, now=now, window_days=window_days, role=c["role"], manifest=manifest)
    except AdmissionError as err:
        raise AdmissionRefused(f"batch {c['id']}: {err}") from err
    if e["number"] == 0:
        raise AdmissionRefused(f"batch {c['id']}: {e['why']}")
    cap = min(e["number"], c["number"])
    if len(mine) >= cap:
        which = "the readiness number" if e["number"] <= c["number"] else "the approved batch's number"
        raise AdmissionRefused(f"batch {c['id']}: {len(mine)} admitted, at {which} ({cap}) — a higher number is a new reading, "
                               "and outside its range the operator's (knob_outside_range)")
    row = {"card": c["id"], "approval": a["id"], "person": person, "role": c["role"], "at": now.isoformat(timespec="seconds"),
           "reading": {"number": e["number"], "taken_at": e["taken_at"]}, "state": REQUESTED, "served": None}
    ledger.append(row)
    path(person)
    return row


def mark_admitted(row: dict[str, Any], served: str, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """Admitted is the person's served state read back from production after the path ran — never the path's return."""
    s = str(served or "").strip()
    if not s:
        raise AdmissionError("admitted is the served state read back from production; with none, the row stays `requested`")
    row.update(state=ADMITTED, served=s[:80], served_read_at=(now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"))
    return row


def is_admitted(row: dict[str, Any] | None) -> bool:
    return bool(row) and row.get("state") == ADMITTED and bool(str(row.get("served") or "").strip())


def batch_reading(c: dict[str, Any] | None, approvals: list[dict[str, Any]] | None, ledger: list[dict[str, Any]], *, reading: Any,
                  now: dt.datetime | None = None, window_days: Any = None, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """The record's `batch` field: how many people the approved card lists (0 with no approved card), the readiness number as of
    now (0 with no fresh reading), how many were admitted from it, the card id, and the reading's state."""
    approved = None
    if c is not None:
        try:
            _approval(c, approvals)
            approved = c
        except AdmissionRefused:
            approved = None
    e = effective_number(reading, now=now, window_days=window_days, role=(c or {}).get("role") or "tess", manifest=manifest)
    return {"approved": len(approved["people"]) if approved else 0, "readiness_number": e["number"],
            "admitted": sum(1 for r in ledger if approved and r.get("card") == approved["id"]),
            "card": approved["id"] if approved else None, "reading": e["state"]}
