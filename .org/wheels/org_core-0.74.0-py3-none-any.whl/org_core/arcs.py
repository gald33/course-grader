"""The arc board (0.48.0): every arc on one page, read as work — how far it is, how it moved, what is left, who holds it.

The operator, 2026-10-01, opening Lucille's dashboard: *"I want to see all the roles reporting, see what they are doing.
I want to see the arcs, see how it progressed, a gantt, what items are complete and what's left. I need to understand
it in terms of the tasks, and in terms of the arcs. I need to be able to speed up or prioritize work of arcs."*

What this draws, and from what. Everything comes from `brief.roadmap` — the arcs' counts, their open items, and the
item lifetimes `brief.arc_gantt` reads from git history — so a number here is a number the roadmap section already
prints, placed differently:

- one **portfolio gantt**: a row per arc, from the day its first item's file landed to its last item closing (or now,
  if anything is still open), cut into the arc's items by status. It is the arc's *span*, not a schedule: nothing here
  says when an arc will finish, because nothing measured does;
- one **card** per arc: items done, shipped and being verified, ready, blocked; the roles holding items; a burn-up of
  filed, shipped and done over the arc's life; the items still open; and the **controls** (`controls.JS`, `arcRows`).

A burn-up is drawn only from dated events (`opened_at`, `verifying_at`, `end_at`); an item with no date is counted in
the words and left off the line, and the card says how many. A `done` set on the server alone has no commit, so its
date is the last commit that touched its file (`end_undated`), which the card names. Controls never act (rule 6): they
ask — `prioritize` (the CEO lands it as a file edit, `org priorities`) and `speed` (the CEO puts builders on the arc's
ready items, or says why not). Broken looks like: a card whose counts disagree with the roadmap section's bar for the
same arc, a burn-up line that ends above the arc's item count, or a control that reports "recorded" for an ask the
reader refused.
"""

from __future__ import annotations

import datetime as dt
import html
from typing import Any

from . import brief as bf
from . import tempo as tp

#: the status order of every bar on this page, left to right: finished work first, then what is left
ORDER = ("done", "verifying", "claimed", "ready", "blocked", "deferred")
#: the days an arc's recent pace is read over — a measured window, not a forecast
PACE_DAYS = 7
SHOW_LEFT = 4


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""), quote=True)


def _ts(s: Any) -> dt.datetime | None:
    return tp.parse_ts(s) if s else None


def _shipped_at(r: dict[str, Any]) -> dt.datetime | None:
    """When an item shipped, if the history dates it: its verifying date, or — done with none — the day it closed."""
    v, e = _ts(r.get("verifying_at")), _ts(r.get("end_at"))
    if r["open"]:
        return v
    return v if v and e and v <= e else e


def _step(events: list[tuple[dt.datetime, int]], t0: dt.datetime, t1: dt.datetime, top: int, w: float, h: float) -> str:
    """A cumulative step line as SVG points: it rises at each event and stays there until the next."""
    span = max((t1 - t0).total_seconds(), 1.0)
    n, pts = 0, [(0.0, h)]
    for t, k in sorted(events):
        x = round(min(max((t - t0).total_seconds() / span, 0.0), 1.0) * w, 2)
        pts.append((x, round(h - n / top * h, 2)))
        n += k
        pts.append((x, round(h - n / top * h, 2)))
    pts.append((w, round(h - n / top * h, 2)))
    return " ".join(f"{x:g},{y:g}" for x, y in pts)


def _burn(rows: list[dict[str, Any]], t0: dt.datetime, t1: dt.datetime, total: int) -> dict[str, Any]:
    filed, shipped, done = [], [], []
    for r in rows:
        filed.append((_ts(r["opened_at"]), 1))
        if _shipped_at(r):
            shipped.append((_shipped_at(r), 1))
        if not r["open"] and _ts(r.get("end_at")):
            done.append((_ts(r["end_at"]), 1))
    top = max(total, len(filed), 1)
    w, h = 100.0, 28.0
    return {"w": w, "h": h, "top": top, "filed": _step(filed, t0, t1, top, w, h), "shipped": _step(shipped, t0, t1, top, w, h),
            "done": _step(done, t0, t1, top, w, h), "n_filed": len(filed), "n_shipped": len(shipped), "n_done": len(done)}


def model(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """The arc board from one status reading. Not read is said as not read (row 65); an arc with no dated item is a
    card without a burn-up, and says so."""
    now = now or _ts(st.get("at")) or dt.datetime.now(dt.timezone.utc)
    r = bf.roadmap(st, now)
    if not r.get("read"):
        return {"read": False, "why": r.get("why")}
    labels = {x["status"]: x["label"] for x in r.get("legend") or []} | bf.ROADMAP_LABELS
    arcs = []
    for a in r["arcs"]:
        counts = {g["status"]: g["n"] for g in a["segs"]}
        g = a.get("gantt") or {}
        rows = g.get("rows") or []
        firsts = [t for t in (_ts(x["opened_at"]) for x in rows) if t]
        lasts = [t for t in (_ts(x.get("end_at") or x.get("verifying_at") or x["opened_at"]) for x in rows) if t]
        still_open = a["total"] - a["done"] > 0
        first = min(firsts) if firsts else None
        last = now if still_open else (max(lasts) if lasts else None)
        events = [t for x in rows for t in (_ts(x["opened_at"]), _ts(x.get("verifying_at")), _ts(x.get("end_at"))) if t]
        recent = now - dt.timedelta(days=PACE_DAYS)
        holders = sorted({i["claimed_by"] for i in a["open_items"] if i.get("claimed_by")})
        arcs.append({
            "arc": a["arc"], "title": a.get("title") or "", "priority": a.get("priority"), "total": a["total"], "done": a["done"],
            "shipped": a["done"] + counts.get("verifying", 0), "counts": counts, "still_open": still_open,
            "pct_done": round(100 * a["done"] / a["total"], 1) if a["total"] else 0.0,
            "pct_shipped": round(100 * (a["done"] + counts.get("verifying", 0)) / a["total"], 1) if a["total"] else 0.0,
            "first": first, "last": last, "undated": a["total"] - len(rows),
            "last_event": max(events) if events else None,
            "pace": {"days": PACE_DAYS, "filed": sum(1 for t in firsts if t >= recent),
                     "shipped": sum(1 for x in rows if (_shipped_at(x) or tp.parse_ts("1970-01-01T00:00:00Z")) >= recent),
                     "done": sum(1 for x in rows if not x["open"] and x.get("end_at") and _ts(x["end_at"]) >= recent)},
            "holders": holders, "open_items": a["open_items"], "rows": rows, "gantt": g,
        })
    dated = [a for a in arcs if a["first"]]
    t0 = min((a["first"] for a in dated), default=None)
    for a in arcs:
        a["burn"] = _burn(a["rows"], a["first"], now, a["total"]) if a["first"] and a["rows"] else None
    return {"read": True, "now": now, "t0": t0, "labels": labels, "arcs": arcs, "source": r.get("source"),
            "total": r["total"], "done": sum(a["done"] for a in arcs), "open": sum(a["total"] - a["done"] for a in arcs),
            "ticks": bf._day_ticks(t0, now, lambda x, y: max(0.0, (y - x).total_seconds()) / max((now - t0).total_seconds(), 1) * 100)
            if t0 else []}


# --- the page --------------------------------------------------------------------------------------------------------

def _gantt(m: dict[str, Any]) -> str:
    t0, now = m["t0"], m["now"]
    if not t0:
        return "<p class='gnote'>No gantt — no arc has an item with a dated file in this reading.</p>"
    span = max((now - t0).total_seconds(), 1.0)
    pct = lambda t: max(0.0, min(100.0, (t - t0).total_seconds() / span * 100))
    rows = []
    for a in m["arcs"]:
        if not a["first"]:
            rows.append(f"<div class='grow'><span class='glabel' title='{_e(a['arc'])}'>{_e(a['arc'])}</span>"
                        "<span class='gtrack'><span class='agundated'>no dated item</span></span></div>")
            continue
        left, right = pct(a["first"]), pct(a["last"] or now)
        width = max(right - left, 0.9)
        segs = "".join(f"<i class='st-{s}' style='flex:{a['counts'][s]}' title='{_e(a['arc'])}: {a['counts'][s]} "
                       f"{_e(m['labels'].get(s, s))}'></i>" for s in ORDER if a["counts"].get(s))
        tip = (f"{a['arc']} — {a['done']} of {a['total']} done, {a['shipped']} shipped · first item filed "
               f"{a['first'].strftime('%b %-d')}" + (", still open" if a["still_open"] else f", closed {a['last'].strftime('%b %-d')}"))
        rows.append(f"<div class='grow'><span class='glabel' title='{_e(a['title'] or a['arc'])}'>{_e(a['arc'])}</span>"
                    f"<span class='gtrack'><span class='gspan rmg agspan{' open' if a['still_open'] else ''}' title='{_e(tip)}' "
                    f"style='left:{left:.3f}%;width:{width:.3f}%'>{segs}</span></span></div>")
    grid = "".join(f"<b style='left:{x['left']}%'></b>" for x in m["ticks"])
    axis = "".join(f"<b style='left:{x['left']}%'>{_e(x['label'])}</b>" for x in m["ticks"])
    key = "".join(f"<span><i class='st-{s}'></i>{_e(m['labels'].get(s, s))}</span>" for s in ORDER
                  if any(a["counts"].get(s) for a in m["arcs"]))
    return (f"<div class='gkey'>{key}<span><s>▶</s>still open</span></div>"
            f"<div class='gplot agplot'><div class='ggrid'>{grid}</div>{''.join(rows)}<div class='gaxis'>{axis}</div></div>"
            "<p class='gnote'>Each bar runs from the day the arc's first item was written down to the day its last item closed — "
            "or to now, if anything is still open — and is cut into the arc's items by status. It is the arc's span, "
            "not a schedule: nothing here forecasts a finish. Times UTC.</p>")


def _spark(b: dict[str, Any] | None, a: dict[str, Any]) -> str:
    if not b:
        return "<span class='agnone'>no dated item, so no history is drawn</span>"
    w, h = b["w"], b["h"]
    return (f"<svg class='agspark' viewBox='0 0 {w:g} {h:g}' preserveAspectRatio='none' role='img' aria-label='{_e(a['arc'])}: "
            f"{b['n_filed']} filed, {b['n_shipped']} shipped, {b['n_done']} done over the arc's life'>"
            f"<polyline class='sf' points='{b['filed']}'/><polyline class='ss' points='{b['shipped']}'/>"
            f"<polyline class='sd' points='{b['done']}'/></svg>")


def _card(a: dict[str, Any], m: dict[str, Any]) -> str:
    lab = m["labels"]
    segs = "".join(f"<i class='st-{s}' style='flex:{a['counts'][s]}' title='{a['counts'][s]} {_e(lab.get(s, s))}'></i>"
                   for s in ORDER if a["counts"].get(s))
    words = " · ".join(f"{a['counts'][s]} {lab.get(s, s)}" for s in ORDER if a["counts"].get(s))
    chip = f"<em class='rmchip {_e(a['priority'])}'>{_e(a['priority'])}</em>" if a.get("priority") else ""
    holders = (f"<span class='agholders'>held by {', '.join(_e(h) for h in a['holders'])}</span>" if a["holders"]
               else ("<span class='agholders none'>nobody holds an item</span>" if a["still_open"] else ""))
    left = a["open_items"]
    item = lambda i: (f"<li><code>{_e(i['key'])}</code> <span class='agst st-{_e(i['status'])}'></span>"
                      f"{_e(lab.get(i['status'], i['status']))}"
                      + (f" · <b>{_e(i['priority'])}</b>" if i.get("priority") else "")
                      + (f" · held by {_e(i['claimed_by'])}" if i.get("claimed_by") else "")
                      + f" — {_e(i['title'])}</li>")
    shown, more = left[:SHOW_LEFT], left[SHOW_LEFT:]
    lefthtml = ("<p class='agdone'>Nothing left — every item is done.</p>" if not left else
                f"<ul class='agleft'>{''.join(item(i) for i in shown)}</ul>"
                + (f"<details class='agmore'><summary>{len(more)} more left</summary><ul class='agleft'>"
                   f"{''.join(item(i) for i in more)}</ul></details>" if more else ""))
    p = a["pace"]
    pace = (f"last {p['days']} days: {p['filed']} filed, {p['shipped']} shipped, {p['done']} closed" if a["first"] else
            "no dated item, so no pace is read")
    span = (f" · first filed {a['first'].strftime('%b %-d')}" if a["first"] else "") + \
           (f" · last movement {a['last_event'].strftime('%b %-d')}" if a["last_event"] else "")
    undated = (f"<span class='agnote'>{a['undated']} item(s) undated: counted above, left off the line</span>"
               if a["undated"] > 0 else "")
    return (f"<article class='agcard' id='arc-{_e(a['arc'])}' data-arc='{_e(a['arc'])}'>"
            f"<header><h3><i class='ic ic-arc'></i><code>{_e(a['arc'])}</code>{chip}</h3><span class='agpct'><b>{a['pct_done']:g}%</b> done · "
            f"{a['pct_shipped']:g}% shipped</span></header>"
            + (f"<p class='agtitle'>{_e(a['title'])}</p>" if a["title"] else "")
            + f"<div class='agbar' role='img' aria-label='{_e(a['arc'])}: {_e(words)}'>{segs}</div>"
              f"<p class='agwords'>{a['done']} of {a['total']} done — {_e(words)}</p>"
              f"<div class='agrow'>{_spark(a.get('burn'), a)}<div class='agside'>{holders}"
              f"<span class='agpace'>{_e(pace)}{_e(span)}</span>{undated}</div></div>"
              f"<div class='agleftbox'><h4>What is left</h4>{lefthtml}</div>"
              f"<div class='arcctl' data-arc='{_e(a['arc'])}' data-title='{_e(a['title'])}' data-priority='{_e(a['priority'] or '')}'></div>"
              "</article>")


def html_section(m: dict[str, Any]) -> str:
    if not m.get("read"):
        return ("<section class='sec ag'><div class='sechead'><h2>The arcs</h2>"
                f"<p>Not read — {_e(m.get('why'))}.</p></div></section>")
    lead = (f"{len(m['arcs'])} arcs, {m['total']} items: {m['done']} done, {m['open']} left. Each arc is read as work — how far "
            "it is, how it moved, who holds it, what is left — and carries the operator's two controls: set its priority, "
            "or ask for it to be sped up. A control asks the CEO; it does not act.")
    key = ("<div class='gkey agkey'><span><i class='sf'></i>filed</span><span><i class='ss'></i>shipped</span>"
           "<span><i class='sd'></i>done</span></div>")
    cards = "".join(_card(a, m) for a in m["arcs"])
    return (f"<section class='sec ag' id='arcs'><div class='sechead'><span class='ct'>{len(m['arcs'])}</span><h2>The arcs</h2>"
            f"<p>{_e(lead)}</p></div><div class='agbody'><h3 class='agh'>All arcs on one time axis</h3>{_gantt(m)}"
            f"<h3 class='agh'>Arc by arc</h3>{key}<div class='agcards'>{cards}</div></div></section>")


CSS = """
.ag .agbody{padding:14px 18px 18px}
.agh{font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);font-weight:600;margin:14px 0 8px}
.agh:first-child{margin-top:0}
.agplot{--lab:150px}
.agplot .gspan.agspan i:last-child{border-radius:0 4px 4px 0}
.agundated{font-size:11px;color:var(--muted)}
.agcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,420px),1fr));gap:12px}
.agcard{border:1px solid var(--border);border-radius:8px;padding:12px 14px;background:var(--surface)}
.agcard header{display:flex;justify-content:space-between;align-items:baseline;gap:8px;flex-wrap:wrap}
.agcard h3{margin:0;font-size:14px;font-weight:600}
.agcard h3 code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px}
.agcard h4{margin:10px 0 4px;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);font-weight:600}
.agpct{font-size:12px;color:var(--ink-2)}.agpct b{font-size:15px;color:var(--ink)}
.agtitle{margin:4px 0 0;font-size:12.5px;color:var(--ink-2)}
.agbar{display:flex;gap:2px;height:10px;margin:10px 0 4px;border-radius:4px;overflow:hidden}
.agbar i{display:block;height:10px;min-width:3px}
.agwords{margin:0 0 8px;font-size:12px;color:var(--ink-2)}
.agrow{display:grid;grid-template-columns:minmax(110px,40%) 1fr;gap:12px;align-items:center}
.agspark{width:100%;height:46px;border-left:1px solid var(--border);border-bottom:1px solid var(--border);overflow:visible}
.agspark polyline{fill:none;stroke-width:1.8;vector-effect:non-scaling-stroke;stroke-linejoin:round}
/* filed is the idle grey, shipped is the in-motion blue, done is the page's dark ink — green is not a work state */
.agspark .sf,.agkey i.sf{stroke:var(--c-idle);background:var(--c-idle)}
.agspark .ss,.agkey i.ss{stroke:var(--c-live);background:var(--c-live)}
.agspark .sd,.agkey i.sd{stroke:var(--ink-2);background:var(--ink-2)}
.agside{display:flex;flex-direction:column;gap:3px;font-size:12px;color:var(--ink-2)}
.agholders{color:var(--ink);font-weight:500}.agholders.none{color:var(--muted);font-weight:400}
.agnote,.agnone{font-size:11.5px;color:var(--muted)}
.agleft{list-style:none;margin:0;padding:0;font-size:12.5px}
.agleft li{padding:3px 0;border-top:1px solid var(--border)}.agleft li:first-child{border-top:none}
.agleft code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px}
.agst{display:inline-block;width:8px;height:8px;border-radius:50%;margin:0 4px 0 2px}
.agdone{font-size:12.5px;color:var(--muted);margin:0}
.agmore summary{cursor:pointer;font-size:12px;color:var(--accent);padding:4px 0}
.arcctl{margin-top:10px;padding-top:10px;border-top:1px solid var(--border)}
"""
