"""The same reading, for somebody who does not know how org-core works (SPEC §9).

`org status` is an **instrument**. Every line names the mechanism it measured — `handoff_received`, `suite`,
`row 62`, the tier each number came from — because a finding that cannot be traced to its source is not a
measurement, and most of Appendix A is the record of what happens when one is. That is the right shape for the
terminal and for the person maintaining the tool.

It is the wrong shape for the page. Measured 2026-09-22: the operator opened the published dashboard and could
not use it. The words on it are the tool's words — the reader wanted to know what is stopped, who can move it,
and what needs them, and every line answered in the vocabulary of the machine that measured it.

So this module translates, and only translates. Three rules keep it honest:

1. **It reads `status()["subjects"]`, never the tiles' prose.** A surface that parses another surface's
   sentences is two readings that drift, and this file has already paid for that twice (rows 119, 121).
2. **It adds no judgement.** Every plain sentence is a restatement of a finding the reading already made; the
   states are the reading's own, and a `DARK` subject becomes "not checked", never "fine".
3. **Every finding is translated or the tests fail.** A finding kind with no plain sentence is the same defect
   as a check that cannot fail (CLAUDE.md rule 2), read from the reader's side.

The grouping is the whole point: **by who can clear it**, not by which mechanism found it. A person opening
this page is themselves one of the three answers, and until now that was the one thing the page never said.
"""

from __future__ import annotations

import hashlib
import datetime as dt
import re
from typing import Any

from . import tempo as tp
from .status import CLEAR, DARK, RED

#: who can actually clear a finding. The page is grouped by this and nothing else, because it is the only
#: question its reader has: the org cannot move `you`, and no person can move `machinery` by answering it.
YOU, TEAM, MACHINERY, UNCHECKED = "you", "team", "machinery", "unchecked"
#: a fourth tone, for a thing that is waiting but not yet overdue. It cannot be `CLEAR`: green means resolved,
#: and every row in the reader's own queue is unresolved by definition — the young ones are just not late yet.
OPEN = "OPEN"
#: how many rows a group shows before the rest fold away. The page's job is the SHAPE of the situation —
#: 25 rows of one group is an enumeration, and the reader stops at about the third. Nothing is dropped: the
#: rest are one click down, and the instrument below still carries every finding in the tool's own words.
SECTION_ROWS = 3
SECTIONS = {
    YOU: ("Waiting on you", "Nobody in the org can clear these — they were written for a person."),
    TEAM: ("Stuck inside the team", "A role could move each of these, and none of them has."),
    MACHINERY: ("The machinery that runs it", "Plumbing, not work. While it is broken the org runs on its clocks alone."),
    UNCHECKED: ("Not checked", "This reading could not see these. Not measured is neither fine nor broken."),
}


def _stamp_note(ck: dict | None) -> str:
    """The commit and time a repo-read count was taken at. A count with no commit says so and is drawn as unchecked
    (CLAUDE.md rule 9): broken looks like a bare number over a checkout nobody named."""
    if not ck or not ck.get("read_commit"):
        return "no commit recorded for the operator file — this count may be stale" + (f" ({ck['why']})" if ck and ck.get("why") else "")
    behind = f"; the remote is {ck['behind']} commit(s) ahead of the checkout" if ck.get("behind") else ""
    return f"read at {ck['read_commit'][:7]}, {ck.get('read_at')}{behind}" + (f" — {ck['why']}" if ck.get("why") else "")


def ago(hours: float | None) -> str:
    """A duration a person reads without arithmetic. `None` when the reading has no clock for it."""
    if hours is None:
        return ""
    if hours < 1:
        m = max(1, round(hours * 60))
        return f"{m} minute{'s' if m != 1 else ''}"
    if hours < 36:                      # above this, hours and days appear side by side in one list and read
        h = round(hours)                # as two different measurements of the same span
        return f"{h} hour{'s' if h != 1 else ''}"
    d = hours / 24
    return "1 day" if d < 1.5 else f"{round(d)} days"


def fallback_words(fb: dict[str, Any] | None) -> str:
    """What a queue row read from the operator file says beside its source when the board was not read (`status` sets `fallback`):
    the file, the commit it was read at and how long ago — so it never passes as the live queue. Empty when the board was read.

    Broken looks like: a row of an org whose could_not_read names the board, with only the file's path as its source."""
    if not fb:
        return ""
    at = f" at {str(fb['commit'])[:7]}" if fb.get("commit") else ""
    when = f", {ago(fb['age_hours'])} ago" if fb.get("age_hours") is not None else ", when unknown"
    return f"the board was not read — from {fb.get('file') or 'the operator file'} as read{at}{when}, not the live queue"


def _sentence(text: str) -> str:
    """One sentence from a fragment the tool wrote. `str.capitalize()` lower-cases everything after the first
    letter, which turned `ci red: pytest` into `Ci red: pytest` — only the first character moves."""
    t = " ".join(str(text or "").split())
    if not t:
        return ""
    t = t[0].upper() + t[1:]
    return t if t.endswith((".", "!", "?")) else t + "."


#: `needs_action` writes the tool's shorthand (`ci red: pytest`). Capitalising it yields `Ci red: pytest`;
#: these are the sentences a person would say instead.
WHY_PR = (("ci red: ", "CI is failing ({})"), ("status failure: ", "a required check failed ({})"),
          ("conflicted", "it has merge conflicts"), ("changes requested", "a reviewer asked for changes"))


def why_pr(reasons: list[str]) -> str:
    """Why an open pull request is waiting on somebody, in words. Anything unmapped is passed through rather
    than dropped: a reason nobody translated is still a reason, and silence would be the worse failure."""
    out = []
    for r in reasons or []:
        for prefix, plain in WHY_PR:
            if r == prefix:
                out.append(plain)
                break
            if prefix.endswith(": ") and r.startswith(prefix):
                out.append(plain.format(r[len(prefix):]))
                break
        else:
            out.append(r)
    return _sentence(" and ".join(out)) if out else ""


def _name(subjects: dict[str, Any], role: str) -> str:
    """`Reed (reviewer)` — the org named its roles, and a reader knows them by those names."""
    n = (subjects.get("names") or {}).get(role)
    return f"{n} ({role})" if n and n.lower() != role.lower() else role


#: a token worth matching on: backticked, or SCREAMING_SNAKE, or `#1234`, or a path. Anything shorter or
#: plainer matches by accident — two texts both containing `RESOLVED` are not two views of one thing.
TOKEN_RE = re.compile(r"`([^`\s]{3,60})`|\b([A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+)\b|(#\d{2,6})\b|\b([\w.-]+/[\w./-]{3,})")


def tokens(text: str) -> set[str]:
    """The distinctive names a piece of text mentions. Lower-cased; a bare capitalised word is not one."""
    out: set[str] = set()
    for m in TOKEN_RE.finditer(str(text or "")):
        t = (m.group(1) or m.group(2) or m.group(3) or m.group(4) or "").strip("`.,;:()[]").lower()
        if len(t) < 4:
            continue
        if t.startswith("#") or "_" in t or "/" in t or "." in t or len(t) >= 8:
            out.add(t)
    return out


def costs(item_tokens: set[str], st: dict[str, Any]) -> dict[str, Any]:
    """Who is stopped naming the same thing this item names. Returns the roles, the sessions, and — always —
    the tokens the match was made on, because a link the reader cannot check is a link they have to trust.
    Here since 0.38.0 (moved from `command`), so the org's own page and the fleet console make one match."""
    s = st.get("subjects") or {}
    roles, sessions, shared = [], [], set()
    for g in s.get("blocked") or []:
        hit = item_tokens & tokens(g.get("text", ""))
        if hit:
            roles += list(g.get("roles") or [])
            shared |= hit
    for r in (s.get("spend") or {}).get("stopped") or []:
        hit = item_tokens & (tokens(r.get("needs", "")) | tokens(r.get("title", "")))
        if hit:
            sessions.append(r.get("title", "")[:60])
            shared |= hit
    return {"roles": sorted(set(roles)), "sessions": sessions, "on": sorted(shared)}


def _item(what: str, why: str = "", *, quote: str = "", hours: float | None = None, at: str = "",
          tone: str = RED, source: str = "", rank: int = 5, clause: str = "", key: str) -> dict[str, Any]:
    """`hours` is kept beside `ago`, because sorting on the sentence means parsing it back — which is the
    mistake this whole module exists to stop making. `rank` orders a group where age does not: a dead
    scheduler outranks a role that went quiet an hour earlier. `clause` is the same fact as a lower-case
    fragment, so the verdict can splice it without doing surgery on a proper noun.

    `key` is the item's identity, said by the call that makes it and REQUIRED: what a link to this one item names (the focused
    view, SPEC row 184). It must not carry anything that moves while the item stays the same thing — an age, a count, a list
    of the roles it concerns — so a link pasted yesterday opens the same item today. The first version hashed the headline and
    the `source` label, and `source` carried the age in days: the id changed every 2.4 hours (Reed, UNSOUND on #75)."""
    fid = hashlib.sha1(key.encode()).hexdigest()[:10]
    return {"what": what, "why": why, "quote": quote, "ago": ago(hours), "hours": hours, "at": at,
            "tone": tone, "source": source, "rank": rank, "clause": clause or what, "fid": fid}


def _you(s: dict[str, Any]) -> list[dict[str, Any]]:
    """The operator queue: the org's roles cannot touch it, which is why it is first and why it ages fastest.
    Each row carries what it holds up (`holds`, the fleet console's match — row 128), and the group sorts on it."""
    out = _queue_items(s, s.get("queue") or [])
    ow = s.get("operator_file")
    if isinstance(ow, dict) and not ow.get("has_section"):
        out.append(_item("There is nowhere for the org to write to you",
                         f"{ow.get('file')} has no “Waiting on the operator” section, so anything a role "
                         "needs from you has no place to land.", source="NO OPERATOR SURFACE", key="no-operator-surface"))
    return out


def _answered(s: dict[str, Any]) -> list[dict[str, Any]]:
    """What the operator already answered and the CEO has not yet closed (`status.answered_apart`): the same items as `_you` draws,
    each with what the board says was said (`said`), whether the CEO marked every answer acted on (`acted`) and when the newest
    answer was given — kept apart from *Waiting on you*, so a card the operator answered is never counted as waiting on them."""
    rows = s.get("queue_answered") or []
    out = _queue_items(s, rows)
    for i, q in zip(out, rows):
        i["said"], i["acted"], i["answered_at"] = q.get("said") or [], bool(q.get("acted")), q.get("answered_at")
    return out


def _queue_items(s: dict[str, Any], rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """One item per row of the operator queue, as `_you` and `_answered` both draw it, so an answered card keeps the address it had."""
    out = []
    for q in rows:
        holds = costs(tokens(q.get("head", "")) | tokens(q.get("body", "")), {"subjects": s})
        days = q.get("age_days")
        head = str(q.get("head") or "").strip()
        who, sep, rest = head.partition(": ")
        if sep and who in (s.get("names") or {}) or who == "chair":
            head = rest or head                       # `chair: <ask>` is the key's shape, not the ask
            who = _name(s, "ceo") if who == "chair" else _name(s, who)
        else:
            who = ""
        where = ("your state-of-the-org file" if str(q.get("source", "")).endswith(".md")
                 else f"the record {who or 'the chair'} last wrote" if "blocked" in str(q.get("source", ""))
                 else f"the queue the roles write to{f', by {who}' if who else ''}")
        # the headline names the thing; the body says what it is and what it is waiting for. A row with only
        # the first is a label, and a page of labels is what "hard to understand from those titles" means.
        undated = ("" if days is not None else
                   " It carries no date, and nothing in this checkout can say when it was written — so its "
                   "age here is unknown, not zero.")
        out.append(_item(_sentence(head),
                         (str(q.get("body_full") or q.get("body") or "").strip() or f"Written in {where}.") + undated,
                         hours=(days * 24) if days is not None else None,
                         at=str(q.get("since") or ""),
                         tone=RED if (days or 0) >= float(s.get("queue_alarm_days") or 3) else
                              (DARK if days is None else OPEN),
                         source=f"WAITING ON A PERSON {days}d ({q.get('source')})", key=f"queue|{q.get('source')}|{head}"))
        out[-1]["holds"] = holds
        out[-1]["where"] = str(q.get("source") or "") + (f" — {fallback_words(q['fallback'])}" if q.get("fallback") else "")
        # the file or board key it lives in, for the focused view, and with the board unread, that this is the file and how old
        if q.get("handoff") and not q.get("attached"):
            out[-1]["fid"] = "h" + str(q["handoff"].get("id"))      # a handoff is named by its own id
        # …unless it was recorded for a heading in the operator file: that card keeps the address the operator was given (row 184)
        out[-1]["handoff"] = q.get("handoff")        # who decides it, what is recommended, what waiting costs, what to do (row 181)
        out[-1]["hread"] = bool((s.get("operator_handoffs") or {}).get("read"))   # were the board's handoffs read: else "not checked"
        out[-1]["counts"] = bool(q.get("counts", True))     # counted among decisions missing a recommendation, or shown only (handoffs.missing)
        out[-1]["norec"] = not q.get("handoff")      # a waiting item the CEO has recorded no recommendation for (row 182)
        out[-1]["item"], out[-1]["arc"] = q.get("item"), q.get("arc")   # what Decide's arc filter reads (status.item_arc)
        out[-1]["item_moved"] = q.get("item_moved")     # its item moved, or left the roadmap, since the card was written (handoffs.item_moved)
        out[-1]["holding"] = ", ".join([_name(s, r) for r in holds["roles"]] + holds["sessions"])
        # what a ruling from the page names (0.42.0): the arc item's key, or the ask's own key in the operator file
        from .status import ask_key
        # a heading's code spans are the file's markup, not the ask (the operator, 2026-09-25: approving "Set
        # `LUCILLE_ADMIN_JWT` as an environment secret on the routines." answered "target.key is missing or malformed")
        out[-1]["ask_key"] = str(q.get("id") or ask_key(head.replace("`", "")) or "")[:160]
    return out


def _team(s: dict[str, Any]) -> list[dict[str, Any]]:
    """What a role could move. Each item names the role, because the reader's next question is always "who"."""
    out: list[dict[str, Any]] = []
    unfwd = {r: g for g in (s.get("unforwarded") or []) for r in g["roles"]}
    # the chair's blocked field is also an operator-queue row, so the same ask arrives here and in `you`.
    # It belongs to whoever can clear it, and that is the reader — printing it twice is row 118 in prose.
    from .status import ask_key
    on_your_list = {ask_key(q.get("head", "").split(": ", 1)[-1]) for q in (s.get("queue") or []) + (s.get("queue_answered") or [])}
    # …and one held for the CEO's recommendation (status `queue_ceo`) has not reached the operator: it stays here, and says so
    with_ceo = {ask_key(q.get("head", "").split(": ", 1)[-1]) for q in (s.get("queue_ceo") or [])}
    for g in s.get("blocked") or []:
        if ask_key(g.get("text")) in on_your_list:
            continue
        roles = ", ".join(_name(s, r) for r in g["roles"])
        never = [r for r in g["roles"] if r in unfwd]
        out.append(_item(f"{roles} reported being stuck" if len(g["roles"]) == 1 else
                         f"{len(g['roles'])} roles reported the same blocker",
                         ("Nobody passed it on to you, so it is stuck twice over." if never else
                          "It waits on the CEO's recommendation before it reaches you." if ask_key(g.get("text")) in with_ceo else
                          "It reached the queue you read.") + ("" if len(g["roles"]) == 1 else f" ({roles}.)"),
                         quote=str(g.get("text") or ""), source="BLOCKED " + ", ".join(g["roles"]), key="blocked|" + ask_key(str(g.get("text") or ""))))
    for g in s.get("handoffs", {}).get("groups") or []:
        to, n, oldest = _name(s, g["to"]), g["n"], g["oldest"]
        senders = ", ".join(_name(s, x) for x in g["senders"])
        if g["why"]:
            out.append(_item(f"{n} message{'s' if n != 1 else ''} to {to} that nobody will ever pick up",
                             f"{to} only wakes for certain events and has no listener running, so this channel "
                             f"reaches nothing. Sent by {senders}.",
                             hours=oldest.get("waiting_hours"),
                             at=str(oldest.get("written_at") or ""), source=f"UNREACHABLE {n} to {g['to']}", key=f"unreachable|{g['to']}"))
        else:
            out.append(_item(f"{n} message{'s' if n != 1 else ''} to {to} waiting to be picked up",
                             f"{to} can be reached — it has not acted. Sent by {senders}.",
                             hours=oldest.get("waiting_hours"),
                             at=str(oldest.get("written_at") or ""), source=f"NOT RECEIVED {n} to {g['to']}", key=f"not-received|{g['to']}"))
    ch = s.get("chair") or {}
    for x in ch.get("stale") or []:
        out.append(_item(f"Pull request #{x['number']} needs someone to act",
                         why_pr(x.get("why") or []) +
                         " Nothing wakes the role that opened it for this.",
                         hours=x.get("idle_hours"), at=str(x.get("updated_at") or ""),
                         source=f"NEEDING ACTION #{x['number']}", key=f"pr|{x['number']}"))
    silent = [r for r in (s.get("roles") or []) if not r.get("record_at")]
    stale = sorted((r for r in (s.get("roles") or []) if r.get("record_at")),
                   key=lambda r: -(r.get("age_hours") or 0))
    if len(stale) >= 2:
        # eight rows saying "its last record is older than its own schedule allows" is one fact eight times,
        # and a reader stops reading at about the third (row 118, now in the half a person actually reads)
        who = ", ".join(_name(s, r["role"]) for r in stale)
        out.append(_item(f"{len(stale)} roles have stopped reporting",
                         f"{who}. Each one's last record is older than its own schedule allows — the oldest "
                         f"{ago(stale[0].get('age_hours'))}, the newest {ago(stale[-1].get('age_hours'))}.",
                         hours=stale[0].get("age_hours"), at=str(stale[0].get("record_at") or ""),
                         clause=f"{len(stale)} roles have stopped reporting",
                         source="DEAD " + ", ".join(r["role"] for r in stale), key="dead-roles"))
    else:
        for r in stale:
            out.append(_item(f"{_name(s, r['role'])} has stopped reporting",
                             r.get("history") or "Its last record is older than its own schedule allows.",
                             hours=r.get("age_hours"), at=str(r.get("record_at") or ""),
                             source=f"{r['state'].upper()} {r['role']}", key=f"stopped|{r['role']}"))
    if silent:   # one cause, one fix — the same collapse the instrument makes (row 118)
        who = ", ".join(_name(s, r["role"]) for r in silent)
        hist = {r.get("history") or "" for r in silent}
        out.append(_item(f"{len(silent)} roles have never reported" if len(silent) > 1 else
                         f"{_name(s, silent[0]['role'])} has never reported",
                         (f"{who}. " if len(silent) > 1 else "")
                         + (hist.pop() if len(hist) == 1 and next(iter(hist), "") else
                            "There is no record from any of them — they never ran, or they ran and could not "
                            "write. Nothing here can tell those apart." if len(silent) > 1 else
                            "There is no record from it — it never ran, or it ran and could not write. "
                            "Nothing here can tell those apart."),
                         source="DEAD/ABSENT " + ", ".join(r["role"] for r in silent), key="never-reported"))
    return out


def _machinery(s: dict[str, Any]) -> list[dict[str, Any]]:
    """Plumbing. A person can fix it, but answering it is not the fix — restarting the thing is."""
    out: list[dict[str, Any]] = []
    a = s.get("actuator") or {}
    if a.get("missing"):
        who = ", ".join(_name(s, r) for r in a.get("routed") or [])
        out.append(_item(f"Nothing can start {who}",
                         f"They only run when the scheduler starts them, and the role that would be the scheduler "
                         f"({a.get('role')}) is switched off in this org. They run only if a person starts them.",
                         rank=0, clause=f"nothing can start {who}", source="NO ACTUATOR", key="no-actuator"))
    elif a.get("needed") is False:
        pass    # an org that asks nothing of a scheduler is not missing one (org-core, 2026-09-23)
    elif a.get("read") and not a.get("heartbeat"):
        out.append(_item("The scheduler that wakes the team is not running",
                         "Nothing is being triggered automatically. Every role moves only when its own clock "
                         "fires or a person starts it — which is why work can sit for days with nobody on it."
                         + ("" if a.get("wakes") else " It has never run at all."),
                         rank=0, clause="the scheduler that wakes the team is not running",
                         source="DEAD actuator", key="scheduler-dead"))
    for f in a.get("fired_no_receiver") or []:
        out.append(_item(f"{_name(s, str(f.get('role')))} was woken and never answered",
                         "The scheduler started it and nothing came back.", hours=f.get("age_hours"),
                         source=f"FIRED-NO-RECEIVER {f.get('role')}", key=f"fired-no-receiver|{f.get('role')}"))
    for role in a.get("suppressed") or []:
        out.append(_item(f"{_name(s, str(role))} is no longer being woken",
                         "It lost too many wakes in a row, so the scheduler stopped trying.",
                         source=f"SUPPRESSED {role}", key=f"suppressed|{role}"))
    ls = s.get("listeners") or {}
    never, lapsed = ls.get("never") or [], ls.get("lapsed") or []
    if never:
        out.append(_item(f"{len(never)} role{'s' if len(never) != 1 else ''} can't be reached at all",
                         rank=1,
                         why="They have never checked in, so nothing can be routed to them: "
                             + ", ".join(_name(s, l["role"]) for l in never) + ".",
                         clause=f"{len(never)} role{'s' if len(never) != 1 else ''} cannot be reached at all",
                         source="NEVER REGISTERED " + ", ".join(l["role"] for l in never), key="never-registered"))
    for l in lapsed:
        out.append(_item(f"{_name(s, l['role'])} has gone quiet",
                         "It checked in, but it is not on the roster now — whatever was listening has stopped.",
                         hours=l.get("registered_age_hours"), source=f"NOT LISTENING {l['role']}", key=f"not-listening|{l['role']}"))
    v = s.get("versions") or {}
    if v.get("read") and v.get("behind"):
        n, total = len(v["behind"]), len(v["behind"]) + len(v.get("ok") or [])
        out.append(_item(f"{n} of {total} roles are not running the installed version" if n != 1 else
                         f"1 of {total} roles is not running the installed version",
                         f"The version installed here is {v.get('lock')}. "
                         + "; ".join(
                             (f"{_name(s, b['role'])} is on {b['got']}" if b["cause"] == "behind" else
                              f"{_name(s, b['role'])} never said which version it ran")
                             for b in v["behind"][:6])
                         + ". A role on an older version is following older instructions.",
                         source="BEHIND / NO SUITE", key="behind-version"))
    ci = s.get("ci") or {}
    if ci.get("read"):
        # CI (ci.py, 0.74.0): a job waiting past the bar, and a label nothing online carries. The detail is the Machinery view's
        # own section below these rows; here is the sentence a person reads first
        past = [q for q in ci.get("queue") or [] if q.get("state") == "queued" and q.get("past")]
        if past:
            worst = max(past, key=lambda q: q.get("waited_min") or 0)
            out.append(_item(("A CI job has" if len(past) == 1 else f"{len(past)} CI jobs have")
                             + f" waited more than {ci.get('bar_minutes')} minutes for a runner",
                             f"The longest is {worst.get('workflow')} / {worst.get('job')}, waiting on "
                             f"`{', '.join(worst.get('labels') or []) or 'no label'}`. Whatever needs it to pass — a merge, a "
                             "release — waits with it. The runners and the queue are listed below.",
                             hours=(worst.get("waited_min") or 0) / 60, rank=1,
                             clause=("a CI job has" if len(past) == 1 else f"{len(past)} CI jobs have")
                                    + f" waited more than {ci.get('bar_minutes')} minutes for a runner",
                             source="STUCK IN CI", key="ci-stuck"))
        for g in ci.get("labels") or []:
            if g.get("state") != "no_runner":
                continue
            lab = ", ".join(g.get("labels") or []) or "no label"
            out.append(_item(f"No runner is online for `{lab}`",
                             f"{g.get('queued')} job{'s' if g.get('queued') != 1 else ''} wait on it, and no online runner "
                             "carries those labels — they will wait until one is started or registered with them.",
                             hours=(g.get("oldest_min") or 0) / 60, rank=0, clause=f"no runner is online for {lab}",
                             source=f"NO RUNNER {lab}", key=f"ci-no-runner|{lab}"))
    sp = s.get("spend") or {}
    for r in sp.get("stopped") or []:
        out.append(_item("A session is stopped waiting for permission",
                         f"“{r.get('needs') or 'a permission prompt'}” — nobody unattended can answer it, and it "
                         f"has cost ${r.get('cost', 0):.0f} so far. A person answers it or stops it.",
                         quote=str(r.get("title") or ""), hours=r.get("hours"),
                         source="BLOCKED ON A PROMPT", key="blocked-on-prompt"))
    return out


def _unchecked(st: dict[str, Any], s: dict[str, Any]) -> list[dict[str, Any]]:
    """Every dark tile, said plainly. "Not measured" must read as neither fine nor broken (rows 62, 65)."""
    plain = {
        "spend": ("what the org is costing", "the list of sessions this reading could take does not include "
                                             "this org's, so no figure here would be its spend"),
        "chair": ("whether anything is shipping", "its pull requests could not be read"),
        "versions": ("which version each role is running", "the installed version or the roles' records "
                                                           "could not be read"),
        "people": ("part of what waits on you", "one of the two places it is written could not be read"),
        "handoffs": ("whether messages were picked up", "a message is picked up on its pull request, and those "
                                                        "could not be read"),
        "listeners": ("which roles are reachable", "the roster could not be read"),
        "roles": ("whether each role is reporting on time", "the board could not be read"),
        "blocked": ("what the roles say is blocking them", "the board could not be read"),
        "actuator": ("whether the scheduler is running", "the board could not be read"),
        "chain": ("how fast work moves", "one of its sources could not be read"),
        "ci": ("what CI is running and what waits for a runner", "the repository's Actions runs, or the runners its queued "
                                                                "jobs need, could not be read"),
    }
    sp = s.get("spend") or {}
    if not sp.get("read") and sp.get("why") == "not_read":
        # nothing was read — not an attribution that failed. Say who can feed it, because a terminal never can.
        plain["spend"] = ("what the org is costing", "nobody handed this reading the list of sessions, and a "
                          "reading taken from a terminal cannot fetch it itself. A session that can list sessions — "
                          "the CEO's can — has to pass it in; the reading below names the exact command")
    if sp.get("read") and not sp.get("complete"):
        plain["spend"] = ("what the org is costing, in full", f"only the {sp.get('window_rows')} most recent sessions were "
                          f"read — at least ${sp.get('total', 0):.0f} — and an older session of this org is not counted")
    out = []
    for t in st.get("tiles") or []:
        if t["state"] != DARK:
            continue
        what, why = plain.get(t["id"], (t["title"], "this reading could not read its source"))
        out.append(_item(f"Not checked: {what}", _sentence(why), tone=DARK, source=f"DARK {t['id']}", key=f"dark|{t['id']}"))
    return out


def _numbers(st: dict[str, Any], s: dict[str, Any], sections: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    """Four figures, and only where the figure is the point. Each says what it is, not which key it came from."""
    ch = s.get("chair") or {}
    out = []
    if ch.get("read"):
        h = ch.get("hours_since_last_merge")
        out.append({"label": "Last shipped", "value": ago(h) + " ago" if h is not None else "nothing yet",
                    # nothing merged in the window is not "recent": `(h or 0) < 24` read an unknown age as zero and drew `nothing yet` in the
                    # pass colour, while the fleet's shipping cell (`command.machinery`) called the same fact red
                    "note": f"{ch.get('merged') or 0} merged in this window", "tone": CLEAR if h is not None and h < 24 else RED})
    else:
        out.append({"label": "Last shipped", "value": "not checked", "note": "pull requests were not read", "tone": DARK})
    q = s.get("queue") or []
    # an undated item is age UNKNOWN, not zero: `max(age or 0)` over two undated items printed "oldest 1 minute" for
    # decisions raised two days earlier (org-core 2026-09-24, a checkout too shallow to date them)
    dated = [x["age_days"] for x in q if x.get("age_days") is not None]
    undated = len(q) - len(dated)
    oldest_note = " · ".join(([f"oldest {ago(max(dated) * 24)}"] if dated else [])
                             + ([f"{undated} with no date" if dated else
                                 ("it has no date" if undated == 1 else f"none of the {undated} has a date")] if undated else []))
    partial = len(s.get("queue_halves") or []) < 2   # the queue is written in two places; both, or it is a floor
    if partial and not q:
        # "0" over a source nobody read is the reassuring lie this whole reading is built to refuse
        out.append({"label": "Waiting on you", "value": "not checked",
                    "note": "one of the two places it is written could not be read", "tone": DARK})
    else:
        ck = (s.get("operator_file") or {}).get("checkout")
        stamp = _stamp_note(ck)
        nv = len(s.get("queue_verifying") or [])
        apart = f"{nv} about work being verified, not counted" if nv else ""
        nc = len(s.get("queue_ceo") or [])
        if nc:
            apart = " · ".join(x for x in (apart, f"{nc} wait on the CEO's recommendation first, counted for the CEO") if x)
        na = len(s.get("queue_answered") or [])
        if na:
            apart = " · ".join(x for x in (apart, f"{na} answered, with the CEO now, not counted") if x)
        out.append({"label": "Waiting on you", "value": (f"{len(q)} or more" if partial else str(len(q))),
                    "note": " · ".join(x for x in (("one of the two places it is written could not be read" if partial else
                                                    oldest_note if q else "nothing"), apart, stamp) if x),
                    "commit": (ck or {}).get("read_commit"),
                    "tone": DARK if partial or not (ck or {}).get("read_commit") else (RED if q else CLEAR)})
    out.append({"label": "Stuck in the team", "value": str(len(sections[TEAM])),
                "note": "each has a role that could move it" if sections[TEAM] else "nothing",
                "tone": RED if sections[TEAM] else CLEAR})
    v = s.get("versions") or {}
    if v.get("read"):
        n, total = len(v.get("behind") or []), len(v.get("behind") or []) + len(v.get("ok") or [])
        if not total:
            # `0 of 0` in the pass colour is a check that cannot fail wearing a figure: no role has written a
            # record, so there is nothing to compare, and that is not agreement (org-core's own page, 2026-09-22)
            out.append({"label": "On the installed version", "value": "no records yet",
                        "note": f"version {v.get('lock')} is installed; no role has written a record to read",
                        "tone": DARK})
        else:
            # `ok` holds the roles whose last record was written BEFORE the apply as well: not behind, but not confirmed either
            # — their next run says. Counting them as a pass printed "10 of 10 · 1 not yet run on it" for nine confirmed and
            # one unknown (NumeroTech 2026-10-04, org-core 0.53.1); a check that cannot fail on them is not a check (rule 2)
            pre = len(v.get("predates") or [])
            confirmed = total - n - pre
            out.append({"label": "On the installed version", "value": f"{confirmed} of {total} confirmed",
                        "note": f"version {v.get('lock')}" + (f" · {pre} not yet run since the upgrade — its next run says"
                                                                  if pre else ""),
                        "tone": RED if n else (DARK if pre else CLEAR)})
    else:
        out.append({"label": "On the installed version", "value": "not checked",
                    "note": "the records or the lock were not read", "tone": DARK})
    return out


def _verdict(st: dict[str, Any], s: dict[str, Any], sections: dict[str, list[dict[str, Any]]]) -> str:
    """One sentence a person can act on, built from the worst thing each group holds — never a finding's own
    wording, which is what made the old headline (`DEAD actuator: no heartbeat at coord/tempo/actuator`) useless."""
    if all(t["state"] == DARK for t in st.get("tiles") or [{}]):
        return "This reading could not see the org at all — every source it tried was unreachable."
    ch = s.get("chair") or {}
    h = ch.get("hours_since_last_merge")
    if not ch.get("read"):
        lead = "Whether anything is shipping could not be checked"
    elif h is None:
        lead = "Nothing has shipped in this window"
    elif h < 24:
        lead = f"Work is shipping — the last merge was {ago(h)} ago"
    else:
        lead = f"Nothing has shipped for {ago(h)}"
    # one sentence, not a summary of the whole page: the figures beside it carry the counts, and repeating
    # them here made the reader read the same three numbers twice before reaching anything new.
    worst = (sections[MACHINERY] or sections[YOU] or sections[TEAM] or [None])[0]
    if worst is None:
        return _sentence(lead) + (f" {len(sections[UNCHECKED])} thing(s) could not be checked."
                                  if sections[UNCHECKED] else " Nothing is stopped.")
    tail = worst["clause"]
    if worst in sections[YOU]:
        # counts and an age, never an item's own title: the title is the org's prose and it is on the row below. The
        # headline quoted one whenever the oldest had no date — d14's, naming Lucille's CEO, on org-core's page.
        n = len(sections[YOU])
        ages = [i["hours"] for i in sections[YOU] if i.get("hours") is not None]
        count = "1 thing waits on you" if n == 1 else f"{n} things wait on you"
        held = sorted({r for i in sections[YOU] for r in (i.get("holds") or {}).get("roles", [])})
        who = ", ".join(_name(s, r) for r in held)
        holding = sum(1 for i in sections[YOU] if (i.get("holds") or {}).get("roles"))
        tail = (count + (f" — the oldest for {ago(max(ages))}" if ages else
                         (" and it carries no date" if n == 1 else " and none of them carries a date"))
                + (f"; {who} {'is' if len(held) == 1 else 'are'} stopped on "
                   f"{'it' if n == 1 else 'one of them' if holding == 1 else 'them'}" if held else ""))
    return _sentence(lead) + " " + _sentence(tail[0].upper() + tail[1:])


def brief(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """The reading as a person reads it. Pure over the status dict; reaches nothing and decides nothing."""
    s = st.get("subjects") or {}
    grouped = {YOU: _you(s), TEAM: _team(s), MACHINERY: _machinery(s), UNCHECKED: _unchecked(st, s)}
    answered = _answered(s)
    seen: dict[str, int] = {}
    for items in [*grouped.values(), answered]:
        for i in items:
            i["tz"] = st.get("operator_timezone")        # the focused view dates an item in the operator's zone
            # two items that are truly the same thing (the same bullet twice) must not share an address: the second is `-2`
            seen[i["fid"]] = seen.get(i["fid"], 0) + 1
            if seen[i["fid"]] > 1:
                i["fid"] = f"{i['fid']}-{seen[i['fid']]}"
    for items in grouped.values():
        items.sort(key=lambda i: (i["tone"] != RED, i["rank"], -(i["hours"] or 0)))
    # what it holds up before age (row 128): an item two roles are stopped on outranks an idle older one
    # what only the operator can decide comes first (row 181); then what each holds up. The sort is stable, so age order inside a rank stays
    grouped[YOU].sort(key=lambda i: ((i.get("handoff") or {}).get("decides", "operator") != "operator",
                                     -len((i.get("holds") or {}).get("roles") or []) - len((i.get("holds") or {}).get("sessions") or [])))
    states = [t["state"] for t in st.get("tiles") or []]
    state = RED if RED in states else (DARK if DARK in states else CLEAR)
    sections = []
    for k in (YOU, TEAM, MACHINERY, UNCHECKED):
        items, lead = grouped[k], SECTIONS[k][1]
        whys = {i["why"] for i in items}
        if len(items) > 2 and len(whys) == 1 and whys != {""}:
            # 25 rows each ending "Written in your state-of-the-org file." is eight words of noise 25 times
            lead = lead + " " + whys.pop().replace("Written in", "All of them are written in")
            items = [dict(i, why="") for i in items]
        sections.append({"id": k, "title": SECTIONS[k][0], "lead": lead, "count": len(items),
                         "items": items[:SECTION_ROWS], "more": items[SECTION_ROWS:]})
    return {"kind": "org-brief", "org": st.get("org"), "at": st.get("at"), "state": state,
            "verdict": _verdict(st, s, grouped), "timeline": timeline(st, now),
            "numbers": _numbers(st, s, grouped), "sections": sections, "answered": answered, "roadmap": roadmap(st, now),
            "read": (st.get("coverage") or {}).get("measured"), "of": (st.get("coverage") or {}).get("tiles")}



# --- the roadmap ------------------------------------------------------------------------------------------

#: the order a bar stacks its segments in: finished work first and recessive, then the flow of work. A status keeps
#: its colour whatever the counts are (color follows the entity, never its rank).
ROADMAP_STACK = ("done", "verifying", "claimed", "ready", "blocked", "deferred")
ROADMAP_LABELS = {"done": "done", "verifying": "shipped, being verified", "claimed": "being worked on",
                  "ready": "ready to start", "blocked": "blocked on another item", "deferred": "deferred"}


def roadmap(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """The roadmap as a person reads it: what is being worked on now, and where every item stands, per arc.

    Every percentage is computed here; the page places them and does no arithmetic (the rule `timeline` follows).
    Not read is said as not read, never drawn as an empty roadmap (row 65)."""
    r = (st.get("subjects") or {}).get("roadmap") or {}
    if not r.get("read"):
        return {"read": False, "why": str(r.get("why") or "no roadmap reading in these facts")}
    order = [x for x in ROADMAP_STACK] + [x for x in (r.get("counts") or {}) if x not in ROADMAP_STACK]
    counts = r.get("counts") or {}
    total = sum(counts.values())
    held = []
    for h in sorted(r.get("held") or [], key=lambda h: (not h.get("stale"), -(h.get("days") or 0))):
        hours = h["days"] * 24 if h.get("days") is not None else None
        why = (f"Held by {h['by']} past roadmap-core's {h['limit_days']:g}-day bar for `{h['stored']}`: a session "
               "that ended, or work still in flight. Check its branch before releasing it."
               if h.get("stale") else f"Held by {h['by']} · {ROADMAP_LABELS.get(h['status'], h['status'])}")
        row = _item(f"`{h['key']}` — {h['title']}", why, hours=hours, at=str(h.get("at") or ""),
                    tone=RED if h.get("stale") else OPEN, source="roadmap", key=f"held|{h['key']}")
        # a roadmap item is not a waiting card: its title opens the explorer's page for it (arc, status, holder, evidence), whose
        # address is `explorer._anchor` — imported here, not above, because the explorer imports this module
        from .explorer import _anchor
        row["xid"] = _anchor("item", h["key"])
        held.append(row)
    arcs = []
    for a in r.get("arcs") or []:
        n = a.get("total") or 0
        segs = [{"status": st_, "n": a["counts"][st_], "pct": round(100 * a["counts"][st_] / n, 3)}
                for st_ in order if (a.get("counts") or {}).get(st_)] if n else []
        meta = (r.get("arc_meta") or {}).get(a["arc"]) or {}
        arcs.append({"arc": a["arc"], "total": n, "done": a.get("done", 0), "segs": segs,
                     "priority": meta.get("priority") if meta.get("priority") in PRIORITIES else None,
                     "title": meta.get("title") or "",
                     # what the page's priority pickers list: every open item, dated or not (0.40.0)
                     "open_items": sorted(({"key": i["key"], "title": i.get("title") or i["key"],
                                            "priority": i.get("priority"), "status": i.get("derived"),
                                            "claimed_by": i.get("claimed_by")}
                                           for i in r.get("items") or []
                                           if str(i.get("arc") or "no arc") == a["arc"] and i.get("derived") != "done"),
                                          key=lambda i: (PRIORITY_RANK.get(i["priority"], 2), i["key"])),
                     "gantt": arc_gantt([i for i in r.get("items") or [] if str(i.get("arc") or "no arc") == a["arc"]],
                                        r.get("history") or {}, now or dt.datetime.now(dt.timezone.utc))})
    # the operator's arc priority first (unset between `next` and `later`, as roadmap-core ranks items), then open work
    arcs.sort(key=lambda a: (PRIORITY_RANK.get(a["priority"], 2), -(a["total"] - a["done"]), a["arc"]))
    return {"read": True, "source": r.get("source"), "note": r.get("note"), "total": total,
            "legend": [{"status": x, "label": ROADMAP_LABELS.get(x, x), "n": counts.get(x, 0)} for x in order
                       if counts.get(x)],
            "arcs": arcs, "held": held, "unparsed": list(r.get("unparsed") or [])}


def _day_ticks(t0: dt.datetime, now: dt.datetime, pct: Any) -> list[dict[str, Any]]:
    ticks, day = [], t0.replace(hour=0, minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
    while day < now:
        ticks.append({"at": day.isoformat(), "label": day.strftime("%b %-d"), "left": round(pct(t0, day), 3)})
        day += dt.timedelta(days=1)
    return ticks


#: roadmap-core's rank (`graph._PRIORITY_RANK`), for items and for arcs alike: something pushed down to `later` sorts
#: below what nobody has judged yet, and an unrecognised value ranks with the unjudged
PRIORITY_RANK = {"now": 0, "next": 1, None: 2, "later": 3}
PRIORITIES = ("now", "next", "later")


def arc_gantt(items: list[dict[str, Any]], history: dict[str, Any], now: dt.datetime) -> dict[str, Any]:
    """One arc's items as lifetimes: from the day an item's file landed on the branch to the day it was set `done`
    (or now), split where it was set `verifying` (the operator, 2026-09-24, ruled "item lifetimes").

    What this can and cannot say, measured on org-core's full history the same day: 14 of the 22 items that reached
    `verifying` were filed already `verifying` (the PR that does the work files the item), and 7 of the 16 `done`
    were filed `done` (the roadmap was seeded on 2026-09-20 from work already finished). So a lifetime starts when
    the work was *written down*, which can be the day it shipped — the chart says so, and draws no "asked" date it
    does not have. A status moved on the server alone has no commit; a `done` item whose file never says so ends at
    the last commit that touched it, and the row says the end is undated. Every percentage is computed here."""
    if not history.get("read"):
        return {"read": False, "why": str(history.get("why") or "no item history in this reading"), "rows": []}
    hist = history.get("items") or {}
    rows, undated = [], []
    for i in items:
        h = hist.get(i["key"]) or {}
        opened = tp.parse_ts(h.get("opened_at") or "")
        if not opened:
            undated.append(i["key"])
            continue
        is_open = i.get("derived") != "done"
        done = tp.parse_ts(h.get("done_at") or "")
        end = now if is_open else (done or tp.parse_ts(h.get("last_at") or "") or opened)
        ver = tp.parse_ts(h.get("verifying_at") or "")
        if ver and not (opened <= ver <= end):
            ver = None
        rows.append({"key": i["key"], "title": i.get("title") or i["key"], "status": i.get("derived"),
                     "priority": i.get("priority"), "claimed_by": i.get("claimed_by"),
                     "opened_at": h["opened_at"], "verifying_at": ver.isoformat(timespec="seconds") if ver else None,
                     "end_at": None if is_open else end.isoformat(timespec="seconds"), "open": is_open,
                     "end_undated": (not is_open) and not done, "_o": opened, "_v": ver, "_e": end,
                     "total_hours": round((end - opened).total_seconds() / 3600, 2)})
    if not rows:
        return {"read": False, "why": (f"none of its {len(undated)} item(s) has a dated file" if undated
                                       else "no items"), "rows": [], "undated": undated}
    t0 = min(r["_o"] for r in rows)
    span = max((now - t0).total_seconds() / 3600, 1.0)

    def pct(a: dt.datetime, b: dt.datetime) -> float:
        return max(0.0, (b - a).total_seconds() / 3600) / span * 100

    for r in rows:
        o, v, e = r.pop("_o"), r.pop("_v"), r.pop("_e")
        r["left"] = round(pct(t0, o), 3)
        r["split"] = bool(v and v > o)                       # filed already `verifying` is one segment, not two
        r["first_cls"] = "st-verifying" if (v and v <= o) else "st-ready"
        first = pct(o, v) if r["split"] else pct(o, e)
        r["first_pct"] = round(max(first, MIN_BAR_PCT), 3)
        r["second_pct"] = round(max(pct(v, e), MIN_BAR_PCT), 3) if r["split"] else 0.0
    rows.sort(key=lambda r: (not r["open"], PRIORITY_RANK.get(r["priority"], 2), r["opened_at"], r["key"]))
    return {"read": True, "rows": rows, "undated": undated, "since": t0.isoformat(timespec="seconds"),
            "until": now.isoformat(timespec="seconds"), "span_hours": round(span, 1),
            "ticks": _day_ticks(t0, now, pct), "note": history.get("note"),
            "open_now": sum(1 for r in rows if r["open"]), "filed_verifying": sum(1 for r in rows if r["first_cls"] == "st-verifying")}


# --- where the time went ------------------------------------------------------------------------------

#: how many bars the chart draws. The rest are shorter and are named in a line beneath it, so the chart shows
#: where the time actually went rather than 80 identical slivers (dataviz: emphasis, not categorical flooding).
TIMELINE_ROWS = 24
#: a bar this thin is invisible; a mark that cannot be seen is not a mark. Percent of the window.
MIN_BAR_PCT = 0.45


def timeline(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """Pull requests as spans on one time axis — the only stretch of the chain with real per-item history.

    **Four of the chain's six stages are not drawn, and that is the whole reason this is honest.** A finding
    reaching a dispatcher, and a merge being verified, live on the board, and the board keeps one record per
    key and overwrites it every wake (row 62) — so live there is no `found_at` and no `dispatched_at` to draw
    a bar between. Measured on Lucille 2026-09-22: 59 chain items, 0 with a dispatch timestamp, 18 with a pull
    request. A Gantt of "the chain" that quietly drew only the stages it happened to have would say the work
    starts when a pull request opens, which is the tool's blind spot presented as the org's behaviour.

    Within a pull request the split is drawn only where a verdict exists. On the same reading 10 of 80 carried
    one, so 68 merges are a single unsplit bar — not a missing measurement but the finding of row 96, that the
    chair merged on green. The chart says so in words; it does not paint it red, because 68 of 78 bars in the
    alarm colour is shouting, not reading.

    Every percentage is computed here. The page places what this returns and does no arithmetic of its own.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    s = st.get("subjects") or {}
    if next((c for c in (st.get("could_not_read") or []) if c.startswith("prs:")), ""):
        return {"read": False, "why": "pull requests could not be read, so there is no history to draw", "rows": []}
    prs = [p for p in (s.get("prs") or []) if p.get("opened_at")]
    if not prs:
        return {"read": False, "why": "no pull request in this window", "rows": []}

    t0 = min(tp.parse_ts(p["opened_at"]) for p in prs)
    span = max((now - t0).total_seconds() / 3600, 1.0)

    def pct(a: dt.datetime, b: dt.datetime) -> float:
        return max(0.0, (b - a).total_seconds() / 3600) / span * 100

    rows = []
    for p in prs:
        opened = tp.parse_ts(p["opened_at"])
        ended = tp.parse_ts(p.get("merged_at") or p.get("closed_at") or "") or now
        still_open = not (p.get("merged_at") or p.get("closed_at"))
        verdict = tp.parse_ts(p.get("first_verdict_at") or "")
        if verdict and not (opened <= verdict <= ended):
            verdict = None                 # a verdict outside its own span is not a boundary, it is a defect
        total = (ended - opened).total_seconds() / 3600
        row = {"number": p.get("number"), "role": p.get("author_role") or "unknown", "kind": p.get("kind") or "",
               "opened_at": p["opened_at"], "verdict_at": p.get("first_verdict_at") if verdict else None,
               "end_at": (p.get("merged_at") or p.get("closed_at") or ""), "open": still_open,
               "merged": bool(p.get("merged_at")), "total_hours": round(total, 2),
               "left": round(pct(t0, opened), 3), "split": bool(verdict),
               "review_hours": round((verdict - opened).total_seconds() / 3600, 2) if verdict else None,
               "merge_hours": round((ended - verdict).total_seconds() / 3600, 2) if verdict else None}
        first = pct(opened, verdict) if verdict else pct(opened, ended)
        row["first_pct"] = round(max(first, MIN_BAR_PCT), 3)
        row["second_pct"] = round(max(pct(verdict, ended), MIN_BAR_PCT), 3) if verdict else 0.0
        rows.append(row)

    rows.sort(key=lambda r: -r["total_hours"])
    shown, rest = rows[:TIMELINE_ROWS], rows[TIMELINE_ROWS:]
    ticks = _day_ticks(t0, now, pct)
    no_verdict = sum(1 for r in rows if r["merged"] and not r["split"])
    return {
        "read": True, "rows": shown, "shown": len(shown), "total": len(rows),
        "since": t0.isoformat(timespec="seconds"), "until": now.isoformat(timespec="seconds"),
        "span_hours": round(span, 1), "ticks": ticks,
        "rest": len(rest), "rest_under": round(max((r["total_hours"] for r in rest), default=0), 3),
        # in words: a rest of 2-minute pull requests read "shorter than 0.0h" (org-core, 2026-09-24)
        "rest_under_ago": ago(max((r["total_hours"] for r in rest), default=0)) if rest else "",
        "no_verdict": no_verdict, "merged": sum(1 for r in rows if r["merged"]),
        "open_now": sum(1 for r in rows if r["open"]),
        # "still open" is a state, not a fifth thing to colour: an open request with no verdict is waiting for
        # a review, one with a verdict is waiting to merge, and the arrow says it has not finished. A swatch
        # for it put a second blue beside slot 1 and told the reader nothing.
        "legend": [{"id": "review", "label": "waiting for a review"},
                   {"id": "merge", "label": "reviewed, waiting to merge"},
                   {"id": "none", "label": "merged with no review recorded"},
                   {"id": "open", "label": "still open"}],
    }
