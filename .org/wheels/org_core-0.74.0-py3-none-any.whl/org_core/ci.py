"""The CI an org's work waits on: each self-hosted runner, and the GitHub Actions queue (item
`command-center-shows-ci-runners-and-queue`, 0.74.0).

The operator, 2026-10-27, twice: *"can you give me visibility on the active runners and the queue straight in the org-core
command center?"* and *"get the command center view working"*. Measured on gald33/Lucille that day from the Actions API (the
Lucille infra session, quoted in the item): from 07:20 to 08:00Z the only runner was busy with an 86-minute release and nine PR
runs of about 2 minutes each waited up to 40 minutes; release-train.yml was switched off by hand for 67 minutes; and nothing on
any page showed either. This module is what the pages were missing.

Two halves, kept apart, because they are two different questions:

* **`gather(slug, run, now)`** reaches GitHub and nothing else: the runs queued and in progress
  (`repos/{slug}/actions/runs?status=…`), each run's jobs (`…/runs/{id}/jobs`) up to `RUNS_READ_CAP` runs a reading, the
  repository's self-hosted runners (`…/actions/runners`) and its workflows (`…/actions/workflows`). Every call that fails is
  recorded with why and its HTTP status, never as an empty list: a refused runner list (it needs Administration: read) is
  *not checked*, never "0 runners". It runs on the fast lane (`tempo.refresh_fast`), at most 4 + `RUNS_READ_CAP` calls.
* **`reading(actions, now)`** is pure over what `gather` returned and the clock: how long each job has waited, which label
  each queued job waits on and whether any online runner carries it, and one `signal` — the fleet console's cell and the
  status tile's state, from one function so the two cannot disagree.

**Red** is a queued job that has waited `WAIT_ALARM_MINUTES` or longer, or a label with queued jobs and no online runner
that carries it. Proposed, not measured as a bar: 20 minutes is half the 40-minute wait of 2026-10-27, and a Lucille PR run
takes about a minute. A workflow switched off, and a run queued with no job (GitHub created none, so no runner can take it),
are listed as waiting on a person, never red: the reading cannot tell which workflow a release depends on, and a forgotten
run blocks nothing.

**Broken looks like:** a job queued past the bar while the cell is green; "0 runners" or "no runner" printed over a runner
list that was refused; a GitHub-hosted job (`ubuntu-latest`) counted as having no runner; a count printed as complete when
the cap stopped the read.
"""

from __future__ import annotations

import datetime as dt
import html
import json
import re
from typing import Any, Callable

#: a queued job that has waited this long turns the signal red. Proposed (see the module docstring), not a measured bar
WAIT_ALARM_MINUTES = 20
#: how many runs' jobs one reading reads: one call each. Queued runs first, oldest first, so the run most likely stuck is read
#: before the cap; the page says how many were left unread when it is hit
RUNS_READ_CAP = 12
#: how long the oldest job on a label waits with no online runner carrying it before that is red, not merely young. Proposed:
#: one fast-lane interval on the VM (120 s), so a runner that registers between two readings is never read as missing
NO_RUNNER_GRACE_MINUTES = 2
#: runs listed per status (one page): a longer queue is counted from `total_count` and said to be partial
RUNS_LISTED = 50
#: job statuses that hold a place in the queue. `waiting` is a job held for an environment's approval: a person, not a runner
QUEUED_JOB = ("queued", "requested", "pending")
#: labels GitHub's own runners answer to: a job on these alone never needs a runner of the org's
HOSTED_LABEL_RE = re.compile(r"^(ubuntu|windows|macos)-", re.I)
_HTTP_RE = re.compile(r"HTTP (\d{3})")

Runner = Callable[[list[str], "dict[str, str] | None"], str]


def _iso(t: dt.datetime) -> str:
    return t.isoformat(timespec="seconds")


def _ts(s: Any) -> dt.datetime | None:
    if not s or not isinstance(s, str):
        return None
    try:
        t = dt.datetime.fromisoformat(s.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


def _minutes(a: Any, b: Any) -> float | None:
    ta, tb = (_ts(a) if not isinstance(a, dt.datetime) else a), (_ts(b) if not isinstance(b, dt.datetime) else b)
    if ta is None or tb is None:
        return None
    return round(max(0.0, (tb - ta).total_seconds() / 60), 1)


def http_status(e: BaseException | str) -> int | None:
    """The HTTP status a failed `gh api` call carried: `gh` prints `(HTTP 403)`, the curl fallback `HTTP 403 …`."""
    m = _HTTP_RE.search(str(e))
    return int(m.group(1)) if m else None


def _why(e: BaseException) -> str:
    # a token never reaches here: `gh` and the curl fallback print the API's message, and the token goes in by env or stdin
    # a failed `gh api` is a RuntimeError carrying gh's own words; any other failure names its kind (a reply of the wrong shape)
    return str(e)[:220] if isinstance(e, RuntimeError) else f"{type(e).__name__}: {str(e)[:220]}"


def _get(run: Runner, path: str) -> Any:
    return json.loads(run(["gh", "api", path], None) or "null")


def _labels(raw: Any) -> list[str]:
    """A runner's labels are objects (`{"name": …}`), a job's are strings: both as names."""
    out = []
    for x in raw or []:
        name = x.get("name") if isinstance(x, dict) else x
        if isinstance(name, str) and name:
            out.append(name)
    return out


def hosted(labels: list[str]) -> bool:
    """A job GitHub's own runners take: every label a hosted image name, and no `self-hosted`."""
    return bool(labels) and "self-hosted" not in {x.lower() for x in labels} and all(HOSTED_LABEL_RE.match(x) for x in labels)


def _run_row(r: dict[str, Any]) -> dict[str, Any]:
    return {"id": r.get("id"), "name": r.get("name") or r.get("display_title") or "a run", "status": r.get("status"),
            "branch": r.get("head_branch"), "event": r.get("event"), "created_at": r.get("created_at"),
            "prs": [p.get("number") for p in r.get("pull_requests") or [] if isinstance(p, dict) and p.get("number")],
            "url": r.get("html_url")}


def _job_row(j: dict[str, Any], r: dict[str, Any]) -> dict[str, Any]:
    return {"id": j.get("id"), "run_id": r.get("id"), "workflow": j.get("workflow_name") or r.get("name"), "job": j.get("name"),
            "status": j.get("status"), "labels": _labels(j.get("labels")), "runner": j.get("runner_name") or None,
            "created_at": j.get("created_at"), "started_at": j.get("started_at"), "branch": j.get("head_branch") or r.get("branch"),
            "prs": list(r.get("prs") or []), "event": r.get("event"), "url": j.get("html_url") or r.get("url")}


def gather(slug: str, run: Runner, now: dt.datetime | None = None) -> dict[str, Any]:
    """One reading of the repository's Actions state, as raw rows. Never raises: a call that fails is a `…_why` with its status.

    Broken looks like: a refused call recorded as an empty list (`runners: []` over a 403), or a run past the cap counted as
    read."""
    now = now or dt.datetime.now(dt.timezone.utc)
    out: dict[str, Any] = {"read_at": _iso(now), "repo": slug, "cap": RUNS_READ_CAP, "listed": RUNS_LISTED,
                           "runs": None, "runs_why": None, "runs_http": None, "runs_total": {},
                           "jobs": [], "runners": None, "runners_why": None, "runners_http": None,
                           "workflows": None, "workflows_why": None}
    runs: list[dict[str, Any]] = []
    try:
        for status in ("queued", "in_progress"):
            got = _get(run, f"repos/{slug}/actions/runs?status={status}&per_page={RUNS_LISTED}")
            if not isinstance(got, dict) or not isinstance(got.get("workflow_runs"), list):
                raise ValueError(f"actions/runs?status={status}: not a list of runs")
            rows = [_run_row(r) for r in got["workflow_runs"] if isinstance(r, dict)]
            # a page is partial only when it came back full: GitHub's `total_count` can disagree with the rows it returns (read
            # 2026-10-27 20:49Z on Lucille: a count of 2 over a shorter list, minutes later a list that matched)
            if len(rows) >= RUNS_LISTED and int(got.get("total_count") or 0) > len(rows):
                out["runs_total"][status] = int(got["total_count"])
            seen = {r["id"] for r in runs}
            runs += [r for r in rows if r["id"] not in seen]    # a run that moved between the two calls is read once
        out["runs"] = runs
    except (RuntimeError, ValueError, OSError, TypeError) as e:          # json.JSONDecodeError is a ValueError
        out["runs_why"], out["runs_http"] = _why(e), http_status(e)
    if out["runs"] is not None:
        # queued first, oldest first: the run most likely stuck is read before the cap stops the read
        order = sorted(runs, key=lambda r: (r["status"] != "queued", str(r.get("created_at") or "")))
        for n, r in enumerate(order):
            if n >= RUNS_READ_CAP:
                r["jobs_read"], r["jobs_why"] = False, "cap"
                continue
            try:
                got = _get(run, f"repos/{slug}/actions/runs/{r['id']}/jobs?per_page=100")
                if not isinstance(got, dict) or not isinstance(got.get("jobs"), list):
                    raise ValueError("actions/runs/<id>/jobs: not a list of jobs")
                jobs = [j for j in got["jobs"] if isinstance(j, dict)]
                r["jobs_read"], r["jobs_n"] = True, len(jobs)
                r["jobs_open"] = sum(1 for j in jobs if j.get("status") != "completed")
                out["jobs"] += [_job_row(j, r) for j in jobs if j.get("status") != "completed"]
            except (RuntimeError, ValueError, OSError, TypeError) as e:
                r["jobs_read"], r["jobs_why"] = False, _why(e)
    try:
        got = _get(run, f"repos/{slug}/actions/runners?per_page=100")
        if not isinstance(got, dict) or not isinstance(got.get("runners"), list):
            raise ValueError("actions/runners: not a list of runners")
        out["runners"] = [{"name": x.get("name"), "status": x.get("status"), "busy": bool(x.get("busy")),
                           "labels": _labels(x.get("labels")), "os": x.get("os")}
                          for x in got["runners"] if isinstance(x, dict) and x.get("name")]
        out["runners_total"] = int(got.get("total_count") or len(out["runners"]))
    except (RuntimeError, ValueError, OSError, TypeError) as e:
        out["runners_why"], out["runners_http"] = _why(e), http_status(e)
    try:
        got = _get(run, f"repos/{slug}/actions/workflows?per_page=100")
        if not isinstance(got, dict) or not isinstance(got.get("workflows"), list):
            raise ValueError("actions/workflows: not a list of workflows")
        out["workflows"] = [{"name": w.get("name"), "path": w.get("path"), "state": w.get("state"), "updated_at": w.get("updated_at"),
                             "url": w.get("html_url")} for w in got["workflows"] if isinstance(w, dict)]
    except (RuntimeError, ValueError, OSError, TypeError) as e:
        out["workflows_why"] = _why(e)
    return out


def _covers(runner_labels: list[str], job_labels: list[str]) -> bool:
    have = {x.lower() for x in runner_labels}
    return {x.lower() for x in job_labels} <= have


def _plural(n: int, one: str, many: str | None = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def reading(actions: dict[str, Any] | None, now: dt.datetime | None = None) -> dict[str, Any]:
    """What the page and the cell draw, judged at `now`. Pure.

    `runners` are the repository's own, with the job each busy one is running; when the list was refused they are the runners
    that running jobs name, each `known: "jobs"`. `queue` is every job still open, waiting or running. `labels` groups the
    queued self-hosted jobs by the labels they wait on, with how many online runners carry them: `None` where that cannot be
    told. `signal` is `{state, read}`: RED / CLEAR / DARK, and words that carry no minute-level age (the fleet page repaints
    when a cell's words move, so a cell that counted minutes would repaint every reading).

    Broken looks like: `signal` CLEAR over a job queued past the bar, a label `online: 0` over a refused runner list, or a
    hosted job in `labels`."""
    if not isinstance(actions, dict):
        return {"read": False, "why": "these facts carry no Actions reading — gathered before 0.74.0, or replayed from the store",
                "signal": {"state": "DARK", "read": "not checked"}, "bar_minutes": WAIT_ALARM_MINUTES}
    now = now or dt.datetime.now(dt.timezone.utc)
    base = {"at": actions.get("read_at"), "repo": actions.get("repo"), "bar_minutes": WAIT_ALARM_MINUTES,
            "cap": actions.get("cap") or RUNS_READ_CAP}
    if actions.get("runs") is None:
        why = str(actions.get("runs_why") or "not read")
        return {**base, "read": False, "why": f"the Actions runs could not be read — {why}", "http": actions.get("runs_http"),
                "signal": {"state": "DARK", "read": "not checked" + (f" (HTTP {actions['runs_http']})" if actions.get("runs_http") else "")}}
    runs = list(actions.get("runs") or [])
    jobs = list(actions.get("jobs") or [])
    queue = []
    for j in jobs:
        st = str(j.get("status") or "")
        row = dict(j, hosted=hosted(j.get("labels") or []))
        if st in QUEUED_JOB:
            row["state"] = "queued"
            row["waited_min"] = _minutes(j.get("created_at"), now)
            row["past"] = row["waited_min"] is not None and row["waited_min"] >= WAIT_ALARM_MINUTES
        elif st == "in_progress":
            row["state"] = "running"
            row["running_min"] = _minutes(j.get("started_at"), now)
            row["waited_min"] = _minutes(j.get("created_at"), j.get("started_at"))
            row["past"] = False
        else:                            # `waiting`: held for an environment's approval — a person, not a runner
            row["state"] = "approval"
            row["waited_min"] = _minutes(j.get("created_at"), now)
            row["past"] = False
        queue.append(row)
    # what waits first, longest first; then what runs, longest running first
    queue.sort(key=lambda r: ({"queued": 0, "approval": 1, "running": 2}[r["state"]],
                              -((r.get("running_min") if r["state"] == "running" else r.get("waited_min")) or 0)))
    running = [q for q in queue if q["state"] == "running"]
    queued = [q for q in queue if q["state"] == "queued"]

    # the runners: the repository's list when it was read; else only what running jobs say, and marked so
    rlist = actions.get("runners")
    runners_read = isinstance(rlist, list)
    on_job = {q["runner"]: q for q in running if q.get("runner")}
    runners = []
    if runners_read:
        for r in rlist:
            job = on_job.get(r.get("name"))
            runners.append({"name": r.get("name"), "labels": list(r.get("labels") or []), "online": r.get("status") == "online",
                            "busy": bool(r.get("busy")), "known": "list", "job": _job_ref(job) if job else None})
    # a runner a running job names and the list does not hold — every one when the list was refused; with it read, an
    # organisation's runner (the repository's list holds only its own) or one registered since. It is online and busy, and it
    # carries at least the labels of the job it runs
    listed = {r["name"] for r in runners}
    for name, q in sorted(on_job.items()):
        if q.get("hosted") or name in listed:
            continue
        runners.append({"name": name, "labels": list(q.get("labels") or []), "online": True, "busy": True, "known": "jobs",
                        "job": _job_ref(q)})
    runners.sort(key=lambda r: (not r["online"], not r["busy"], str(r["name"])))

    # which label each queued self-hosted job waits on, and whether anything online carries it
    groups: dict[tuple[str, ...], dict[str, Any]] = {}
    for q in queued:
        if q.get("hosted"):
            continue
        key = tuple(sorted({x.lower() for x in q.get("labels") or []}))
        g = groups.setdefault(key, {"labels": list(key), "queued": 0, "oldest_min": None, "past": 0})
        g["queued"] += 1
        g["past"] += 1 if q["past"] else 0
        if q.get("waited_min") is not None:
            g["oldest_min"] = max(g["oldest_min"] or 0, q["waited_min"])
    labels = []
    for key, g in sorted(groups.items(), key=lambda kv: -(kv[1]["oldest_min"] or 0)):
        if runners_read:
            carry = [r for r in runners if _covers(r["labels"], g["labels"])]
            g["online"] = sum(1 for r in carry if r["online"])
            g["busy"] = sum(1 for r in carry if r["online"] and r["busy"])
            # a job a few seconds old may be waiting on a runner that is still registering (Lucille's autoscaler starts one per
            # burst): red once the oldest has waited the grace, so one reading taken mid-start is not an alarm
            g["state"] = ("ok" if g["online"] else
                          "no_runner" if (g["oldest_min"] or 0) >= NO_RUNNER_GRACE_MINUTES else "no_runner_yet")
        else:
            # a runner running a job carries at least that job's labels: one of those that covers this group is online
            known = [r for r in runners if _covers(r["labels"], g["labels"])]
            g["online"] = len(known) if known else None
            g["busy"] = len(known) if known else None
            g["state"] = "ok" if known else "unknown"
        labels.append(g)

    unread_runs = [r for r in runs if r.get("jobs_read") is False]
    capped = [r for r in unread_runs if r.get("jobs_why") == "cap"]
    # a run queued whose jobs were read and none is open: GitHub created no job for it, so no runner can ever take it
    no_job = [{"name": r.get("name"), "id": r.get("id"), "created_at": r.get("created_at"), "url": r.get("url"),
               "branch": r.get("branch"), "age_min": _minutes(r.get("created_at"), now)}
              for r in runs if r.get("status") == "queued" and r.get("jobs_read") and not r.get("jobs_open")]
    totals = actions.get("runs_total") or {}
    # `runs_total` holds a status only when its page came back full and GitHub counts more (`gather`)
    listed_short = {k: v for k, v in totals.items() if v > (actions.get("listed") or RUNS_LISTED)}
    wf = actions.get("workflows")
    off = [w for w in (wf or []) if str(w.get("state") or "active") != "active"]
    out = {**base, "read": True, "queue": queue, "runners": runners, "runners_read": runners_read,
           "runners_why": None if runners_read else str(actions.get("runners_why") or "not read"),
           "runners_http": None if runners_read else actions.get("runners_http"),
           "labels": labels, "runs": len(runs), "runs_total": totals, "listed_short": listed_short,
           "jobs_read_runs": sum(1 for r in runs if r.get("jobs_read")), "unread_runs": [_run_ref(r) for r in unread_runs],
           "capped": len(capped), "no_job": no_job, "workflows_read": isinstance(wf, list),
           "workflows_why": None if isinstance(wf, list) else actions.get("workflows_why"), "off": off,
           "counts": {"queued": len(queued), "running": len(running), "past": sum(1 for q in queued if q["past"]),
                      "approval": sum(1 for q in queue if q["state"] == "approval")}}
    out["signal"] = signal(out)
    return out


def _job_ref(q: dict[str, Any]) -> dict[str, Any]:
    return {k: q.get(k) for k in ("workflow", "job", "branch", "prs", "running_min", "started_at", "url", "event")}


def _run_ref(r: dict[str, Any]) -> dict[str, Any]:
    return {"name": r.get("name"), "status": r.get("status"), "why": r.get("jobs_why"), "url": r.get("url"),
            "created_at": r.get("created_at")}


def _labels_words(labels: list[str]) -> str:
    return ", ".join(labels) if labels else "no label"


def signal(r: dict[str, Any]) -> dict[str, str]:
    """The cell and the tile's state, in one place. Words, never a minute count (`reading`'s note on repaints).

    Broken looks like: CLEAR with `counts.past` above 0, CLEAR over a label group whose state is `unknown`, or a count of
    queued jobs printed as whole when the cap left runs unread."""
    if not r.get("read"):
        return {"state": "DARK", "read": "not checked"}
    c = r["counts"]
    some = "at least " if (r.get("capped") or r.get("listed_short")) else ""
    no_runner = [g for g in r["labels"] if g["state"] == "no_runner"]
    unknown = [g for g in r["labels"] if g["state"] == "unknown"]
    extra = []
    if r.get("no_job"):
        extra.append(f"{_plural(len(r['no_job']), 'run')} with no job")
    if r.get("off"):
        extra.append(f"{_plural(len(r['off']), 'workflow')} off")
    tail = "".join(" · " + x for x in extra)
    if c["past"] or no_runner:
        bits = ([f"{some}{c['past']} waiting past {r['bar_minutes']} min"] if c["past"] else []) \
            + [f"no runner for {_labels_words(g['labels'])}" for g in no_runner]
        return {"state": "RED", "read": " · ".join(bits) + tail}
    head = (f"{some}{c['queued']} queued" if c["queued"] else ("nothing queued" if not some else "none queued in the runs read"))
    head += f" · {c['running']} running" if c["running"] else ""
    if unknown:
        return {"state": "DARK", "read": head + " · runners not checked" + (f" (HTTP {r['runners_http']})" if r.get("runners_http") else "") + tail}
    return {"state": "CLEAR", "read": head + tail}


# --- the status tile ------------------------------------------------------------------------------------------------

def _job_words(q: dict[str, Any]) -> str:
    where = f" on {q['branch']}" if q.get("branch") else ""
    pr = f" (#{', #'.join(str(n) for n in q['prs'])})" if q.get("prs") else ""
    return f"`{q.get('workflow')} / {q.get('job')}`{where}{pr}"


def tile_lines(r: dict[str, Any]) -> list[str]:
    """The instrument's lines: every finding in the tool's words, each opening with its kind (`status.FINDING`)."""
    if not r.get("read"):
        return [f"not judged — {r.get('why')}"]
    c = r["counts"]
    L = [f"{c['queued']} job(s) queued, {c['running']} running, across {r['runs']} run(s) queued or in progress; the jobs of "
         f"{r['jobs_read_runs']} of {r['runs']} run(s) read (cap {r['cap']} a reading)"
         + (f" — {r['capped']} run(s) past the cap not read" if r.get("capped") else "")
         + ("".join(f"; {v} {k} run(s) exist, one page listed" for k, v in (r.get("listed_short") or {}).items()))]
    for q in [q for q in r["queue"] if q["state"] == "queued" and q["past"]]:
        L.append(f"STUCK IN CI {_job_words(q)} on {_labels_words(q.get('labels') or [])}: queued {q['waited_min']:g} min, past "
                 f"the {r['bar_minutes']} min bar")
    for g in r["labels"]:
        if g["state"] == "no_runner":
            L.append(f"NO RUNNER for {_labels_words(g['labels'])}: {g['queued']} job(s) queued and no online runner carries "
                     f"those labels ({len(r['runners'])} runner(s) read)")
    if r["runners_read"]:
        on = [x for x in r["runners"] if x["online"]]
        L.append(f"runners: {len(on)} online ({sum(1 for x in on if x['busy'])} busy), "
                 f"{len(r['runners']) - len(on)} offline — {', '.join(x['name'] for x in r['runners']) or 'none registered'}")
    else:
        L.append(f"runners: not checked — {r.get('runners_why')}; {len(r['runners'])} named by running jobs")
    for g in r["labels"]:
        if g["state"] == "unknown":
            L.append(f"not judged: {g['queued']} job(s) queued on {_labels_words(g['labels'])} — no running job shows a runner "
                     "that carries those labels, and the runner list was not read")
    for x in r.get("no_job") or []:
        L.append(f"queued with no job: `{x['name']}` since {x['created_at']} — GitHub created no job for it, so no runner can take it")
    for w in r.get("off") or []:
        L.append(f"switched off: `{w.get('name')}` ({w.get('state')}) since {w.get('updated_at')}")
    if not r.get("workflows_read"):
        L.append(f"workflows: not checked — {r.get('workflows_why')}")
    return L


TILE_BROKEN = ("STUCK IN CI `<workflow> / <job>` on <labels>: queued <n> min, past the 20 min bar / NO RUNNER for <labels>: "
               "<n> job(s) queued and no online runner carries those labels — and never `0 runners` over a list that was refused")


# --- the Machinery view's section -----------------------------------------------------------------------------------

def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""), quote=True)


def _mins(m: float | None) -> str:
    if m is None:
        return "—"
    if m < 1:
        return "under a minute"
    if m < 90:
        return f"{round(m)} min"
    h = m / 60
    return f"{h:.1f} h" if h < 36 else f"{round(h / 24)} days"


def _mark(kind: str) -> str:
    """A row's state mark, from `vocab.py` only: the four tones a row already writes, and *in motion* for a busy runner or a
    running job. The state is in the row's words too."""
    if kind == "live":
        return "<i class='sg s-live g-live' aria-hidden='true'></i>"
    return f"<span class='dot {kind}' aria-hidden='true'></span>"


def _job_line(q: dict[str, Any]) -> str:
    bits = []
    if q.get("branch"):
        bits.append(f"branch <code>{_e(q['branch'])}</code>")
    if q.get("prs"):
        bits.append(", ".join(f"PR #{_e(n)}" for n in q["prs"]))
    if q.get("event"):
        bits.append(_e(q["event"]))
    return " · ".join(bits)


def html_section(r: dict[str, Any], tz: str | None = None, clock: Callable[[Any, str | None], str] | None = None) -> str:
    """The runners and the queue, one section of the Machinery view (`dashboard.render_html`, `#ci`). Every row is a mark AND
    its state in words; a list that was not read says *not checked*, with why, and is never drawn empty."""
    when = (lambda at: clock(at, tz)) if clock else (lambda at: _e(at))
    head = ("<section class='sec machinery ci'><div class='sechead'>{ct}<h2>CI — the runners and the queue</h2>"
            "<p>{lead}</p></div>{body}</section>")
    if not r.get("read"):
        return head.format(ct="", lead=_e(f"Not checked — {r.get('why')}. Not read is neither fine nor broken."), body="")
    c = r["counts"]
    sig = r["signal"]
    lead = (f"Read {when(r.get('at'))} from GitHub Actions on {_e(r.get('repo'))}, on the fast lane. A queued job turns this "
            f"red at {r['bar_minutes']} minutes, and so does a label with jobs queued and no online runner. "
            f"Now: <b>{_e(sig['read'])}</b> ({_e({'RED': 'broken', 'CLEAR': 'healthy', 'DARK': 'not checked'}.get(sig['state'], sig['state']))}).")
    rows = []
    # the question first: is anything stuck, and on which label
    rows.append("<h3 class='cih'>Waiting, by label</h3>")
    if not r["labels"]:
        hosted_n = sum(1 for q in r["queue"] if q["state"] == "queued" and q.get("hosted"))
        rows.append(f"<div class='row'>{_mark('CLEAR')}<div class='body'><div class='what'>Nothing is waiting for a runner of "
                    "this org's</div><div class='why'>"
                    + (f"{_plural(hosted_n, 'job')} queued for GitHub's own runners. " if hosted_n else "")
                    + ("" if not r.get("capped") else f"The jobs of {r['capped']} run(s) were not read (the cap), so this is "
                       "what was read, not the whole queue.") + "</div></div></div>")
    for g in r["labels"]:
        tone = "RED" if (g["state"] == "no_runner" or g["past"]) else ("DARK" if g["state"] == "unknown" else "OPEN")
        state_words = ("no online runner carries these labels — broken" if g["state"] == "no_runner" else
                       f"no online runner carries these labels yet — red if none has after {NO_RUNNER_GRACE_MINUTES} minutes"
                       if g["state"] == "no_runner_yet" else
                       "the runner list was not read and no running job shows a runner with these labels — not checked"
                       if g["state"] == "unknown" else
                       f"{g['online']} online runner(s) carry them, {g['busy']} busy"
                       + (" — known from running jobs only" if not r["runners_read"] else ""))
        past = f" · {g['past']} past the {r['bar_minutes']}-minute bar — broken" if g["past"] else ""
        rows.append(f"<div class='row'>{_mark(tone)}<div class='body'><div class='what'>{_plural(g['queued'], 'job')} waiting on "
                    f"<code>{_e(_labels_words(g['labels']))}</code></div><div class='why'>{_e(state_words)}{_e(past)}</div></div>"
                    f"<div class='age'>oldest {_e(_mins(g['oldest_min']))}</div></div>")
    # the runners
    rows.append("<h3 class='cih'>Runners</h3>")
    if not r["runners_read"]:
        why = r.get("runners_why") or "not read"
        status = f"HTTP {r['runners_http']}" if r.get("runners_http") else "no status"
        rows.append(f"<div class='row'>{_mark('DARK')}<div class='body'><div class='what'>Not checked: the runner list "
                    f"({_e(status)})</div><div class='why'>The list needs Administration: read on this repository, and the "
                    f"token this reader holds was refused or could not ask — {_e(why)}. The runners below are the ones running "
                    "jobs name, so an idle or offline runner is not shown.</div></div></div>")
    if not r["runners"]:
        rows.append(f"<div class='row'>{_mark('DARK')}<div class='body'><div class='what'>"
                    + ("No runner is named by a running job" if not r["runners_read"] else
                       "No self-hosted runner is registered on this repository")
                    + "</div></div></div>")
    for x in r["runners"]:
        if x["known"] == "jobs":
            tone, words = "live", ("busy — known only from the job it is running" if not r["runners_read"] else
                                   "busy — not in this repository's runner list (an organisation's runner, or one registered "
                                   "since), known from the job it is running")
        elif not x["online"]:
            tone, words = "RED", "offline"
        elif x["busy"]:
            tone, words = "live", "online, busy"
        else:
            tone, words = "CLEAR", "online, idle"
        job = x.get("job")
        on = (f" — running <b>{_e(job.get('workflow'))} / {_e(job.get('job'))}</b>"
              + (f" · {_job_line(job)}" if _job_line(job) else "")) if job else (
            " — on a job this reading did not read" if x["busy"] and x["known"] == "list" else "")
        rows.append(f"<div class='row'>{_mark(tone)}<div class='body'><div class='what'>{_e(x['name'])}</div>"
                    f"<div class='why'>{_e(words)}{on} · labels <code>{_e(_labels_words(x['labels']))}</code></div></div>"
                    + (f"<div class='age'>for {_e(_mins(job.get('running_min')))}</div>" if job else "") + "</div>")
    # the queue, job by job
    rows.append("<h3 class='cih'>The queue</h3>")
    if not r["queue"]:
        rows.append(f"<div class='row'>{_mark('CLEAR')}<div class='body'><div class='what'>No job is queued or running"
                    "</div></div></div>")
    for q in r["queue"]:
        if q["state"] == "running":
            tone, words = "live", (f"running on {q.get('runner') or 'a runner not named'} for {_mins(q.get('running_min'))}"
                                   f", after waiting {_mins(q.get('waited_min'))}")
        elif q["state"] == "approval":
            tone, words = "OPEN", f"held for an environment's approval for {_mins(q.get('waited_min'))} — a person, not a runner"
        else:
            tone = "RED" if q["past"] else "OPEN"
            words = (f"queued {_mins(q.get('waited_min'))}" + (f", past the {r['bar_minutes']}-minute bar — broken" if q["past"]
                                                               else " — waiting"))
        link = (f"<a href='{_e(q['url'])}' target='_blank' rel='noopener'>{_e(q.get('workflow'))} / {_e(q.get('job'))}</a>"
                if q.get("url") else f"{_e(q.get('workflow'))} / {_e(q.get('job'))}")
        where = _job_line(q)
        rows.append(f"<div class='row'>{_mark(tone)}<div class='body'><div class='what'>{link}</div><div class='why'>"
                    f"{_e(words)} · runs-on <code>{_e(_labels_words(q.get('labels') or []))}</code>"
                    + (" (GitHub's own runners)" if q.get("hosted") else "") + (f" · {where}" if where else "")
                    + "</div></div>"
                    f"<div class='age'>{_e(_mins(q.get('running_min') if q['state'] == 'running' else q.get('waited_min')))}</div></div>")
    for x in r.get("no_job") or []:
        rows.append(f"<div class='row'>{_mark('OPEN')}<div class='body'><div class='what'>"
                    + (f"<a href='{_e(x['url'])}' target='_blank' rel='noopener'>{_e(x['name'])}</a>" if x.get("url") else _e(x["name"]))
                    + f"</div><div class='why'>queued since {when(x.get('created_at'))} with no job — GitHub created none, so no "
                    "runner can take it; cancelling it clears it. Waiting on a person, not red.</div></div>"
                    f"<div class='age'>{_e(_mins(x.get('age_min')))}</div></div>")
    for w in r.get("off") or []:
        rows.append(f"<div class='row'>{_mark('OPEN')}<div class='body'><div class='what'>"
                    + (f"<a href='{_e(w['url'])}' target='_blank' rel='noopener'>{_e(w.get('name'))}</a>" if w.get("url") else _e(w.get("name")))
                    + f" is switched off</div><div class='why'>{_e(w.get('state'))} since {when(w.get('updated_at'))} — "
                    "nothing it runs on will start until a person turns it back on. Waiting on a person.</div></div></div>")
    notes = []
    if r.get("capped"):
        notes.append(f"The cap was hit: the jobs of {r['jobs_read_runs']} of {r['runs']} runs were read this reading "
                     f"(at most {r['cap']}); {r['capped']} run(s) were not, so their jobs are not counted above.")
    for k, v in (r.get("listed_short") or {}).items():
        notes.append(f"{v} runs are {k.replace('_', ' ')}; one page of {r.get('listed') or RUNS_LISTED} was listed.")
    other = [u for u in r.get("unread_runs") or [] if u.get("why") != "cap"]
    if other:
        notes.append(f"The jobs of {len(other)} run(s) could not be read: " + "; ".join(f"{u['name']} ({u['why']})" for u in other[:3]))
    if not r.get("workflows_read"):
        notes.append(f"Whether a workflow is switched off was not checked — {r.get('workflows_why')}.")
    body = "".join(rows) + ("<div class='cinote'>" + "".join(f"<p>{_e(n)}</p>" for n in notes) + "</div>" if notes else "")
    return head.format(ct=f"<span class='ct'>{c['queued']} queued · {c['running']} running</span>", lead=lead, body=body)


#: the section's own layout; its colours are `vocab.py`'s marks and the page's tokens, never a hue of its own
CSS = """
.sec.ci h3.cih{margin:0;padding:9px 18px 5px;font-size:10.5px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;
  color:var(--muted);border-top:1px solid var(--border);background:var(--surface)}
.sec.ci h3.cih+.row{border-top:none}
.sec.ci .row .what{font-size:13.5px}
.sec.ci .row .why{display:block;-webkit-line-clamp:unset;overflow:visible}
.sec.ci .row .why code,.sec.ci .row .what code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px}
.sec.ci .row>.sg{margin-top:4px}
.sec.ci .row .what a{color:var(--accent);text-decoration:none}.sec.ci .row .what a:hover{text-decoration:underline}
.sec.ci .cinote{padding:8px 18px 12px;border-top:1px dashed var(--border);font-size:12px;color:var(--ink-2)}
.sec.ci .cinote p{margin:3px 0}
"""


def digest(r: dict[str, Any]) -> str:
    """What the section says, minus every age: a job joining or leaving the queue, a runner going offline or busy, a state
    crossing the bar. The served reader adds it to its `rev` (`serve.Reader._publish`), so the section repaints on a change
    and not on a clock."""
    import hashlib
    if not r.get("read"):
        key: Any = ["unread", r.get("why")]
    else:
        key = [r["signal"], [(q.get("id"), q["state"], q["past"], q.get("runner")) for q in r["queue"]],
               [(x["name"], x["online"], x["busy"], x["known"], (x.get("job") or {}).get("job")) for x in r["runners"]],
               [(g["labels"], g["queued"], g["state"]) for g in r["labels"]], [x["id"] for x in r.get("no_job") or []],
               [w.get("name") for w in r.get("off") or []], r.get("capped")]
    return hashlib.sha256(json.dumps(key, sort_keys=True, default=str).encode()).hexdigest()[:16]
