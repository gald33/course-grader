"""The claim gate: an outward message reaches the operator approvable only when every claim in it is sourced and fresh (item
`outward-claim-gate-runs-before-a-card-can-be-approved`, SPEC §16 decision 16, §12).

Why. Read 2026-10-11 on Lucille's main 321d76f: the investor reviewer's claim audit of 2026-10-07 found a stale "shipped today"
price, a stale roadmap-core version and an understated check count — and four days later the deck it was written about still
carried all three. A rule and a reviewer existed and the claim still stood. The form was decided by Drew, the org-core planner,
on the operator's delegation ("your call", by 2026-10-13 02:51Z): **the card cannot be approved**. Flagging the claims would make
the operator the gate; a reviewer reading each batch is the practice that left the 10-07 findings unfixed.

What it does. `extract` finds every claim in a message's text — each number (any token with a digit in it: prices, counts,
versions, dates), each relative date ("today", "last week"), each quotation, each comparative ("faster than", "the only"), and each
named customer from the names the caller passes. `check` holds each one against the sources the role filed with the card:

    sources: [{claim: "<the exact words in the text>", source: "<a production read, a file at a commit, a URL>",
               read_at: "<UTC instant the source was read>"}, ...]

A claim is sourced when it lies inside the words a source entry quotes, and that entry names its source and a `read_at`. A source
entry quotes one sentence at most: an entry whose words cross a sentence end or a line break sources nothing, so one fresh read of a
stale deck, quoted whole, cannot source every figure in it (Reed's first probe on #231 — the 2026-10-07 failure the gate is for). It is
fresh when `read_at` is within the freshness window of now (and not in the future). A card with any claim unsourced or stale is
`blocked: unsourced claim` and its `choices` carry no `approve`: the operator sees why, never a message to fact-check.

The role cannot clear the block by rewording a filed card: the gate's reading is bound to the hash of the text it read, and
`outward.approve` re-runs it, so an edited text, or a card whose sources aged past the window while it waited, is read again.
Removing the claim or re-reading its source is a new text, filed as a new card.

What it does not decide (open questions for the operator on the PR that added it): the freshness window's range and default (a
proposal here, `WINDOW_DAYS`), what counts as a comparative claim (the word list below is a proposal), whether a relative date or a
quotation always needs a source, and whether "not checked" — named customers with no list of names given — should block. A
category the gate could not check is said in `not_checked`, never counted as zero claims.

Broken looks like: an approvable card that carries a number with no source or a stale one, or `extract` finding zero claims in a
text that has a digit in it (a gate that cannot fail).
"""
from __future__ import annotations

import datetime as dt
import re
from typing import Any, Iterable

#: the freshness window, in days: a proposal (undated, not ruled). Inside `WINDOW_RANGE` it is the CEO's; outside, `knob_outside_range`
WINDOW_DAYS = 7
WINDOW_RANGE = (1, 30)
#: a source read a little in the future of `now` is clock skew between the role's container and the gate's; beyond it, unreadable
SKEW = dt.timedelta(minutes=5)

BLOCKED = "unsourced claim"
APPROVE = "approve"
KINDS = ("number", "date", "quote", "comparative", "name")

#: a sentence ends at a line break, or at `.`/`!`/`?` (and any closing quote or bracket) followed by space and more text
_SENTENCE_BREAK = re.compile(r"\n|[.!?][\"'”’)\]]*\s+\S")
_EDGE_PUNCT = "\"'“”‘’()[]{}<>.,;:!?"
_NUMBER = re.compile(r"\S*\d\S*")
_RELATIVE_DATE = re.compile(r"\b(?:today|tonight|yesterday|tomorrow|(?:this|last|next)\s+(?:week|month|quarter|year))\b", re.I)
_QUOTE = re.compile(r"\"[^\"\n]+\"|“[^”\n]+”")
#: a proposal, not a ruling: "<word>er than" and "more/less/fewer than", and a short list of superlatives
_COMPARATIVE = re.compile(
    r"\b(?:more|less|fewer|(?!rather\b|other\b)[a-z]+er)\s+than\b"
    r"|\b(?:best|worst|largest|biggest|fastest|cheapest|leading|world's|number one)\b"
    r"|\bthe\s+(?:first|only)\b", re.I)


class GateError(ValueError):
    pass


def window(days: Any = None) -> int:
    """The freshness window in days: `WINDOW_DAYS` when none is set, refused outside `WINDOW_RANGE` — never clamped (a value
    outside the range is the operator's, `knob_outside_range`)."""
    if days is None:
        return WINDOW_DAYS
    if isinstance(days, bool) or not isinstance(days, (int, float)):
        raise GateError(f"the freshness window is a number of days, not {days!r}")
    lo, hi = WINDOW_RANGE
    if not lo <= days <= hi:
        raise GateError(f"freshness window {days:g} d is outside its range {lo}–{hi} d — outside it is the operator's (knob_outside_range)")
    return int(days) if float(days).is_integer() else days


def _claim(kind: str, text: str, start: int, end: int) -> dict[str, Any]:
    return {"kind": kind, "text": text[start:end], "start": start, "end": end}


def extract(text: str, names: Iterable[str] = ()) -> list[dict[str, Any]]:
    """Every claim in `text`, in order, each `{kind, text, start, end}`; a claim inside another one's span is read once, as the
    wider. Any digit in the text yields at least one `number` claim — the extractor's floor."""
    found: list[dict[str, Any]] = []
    for m in _NUMBER.finditer(text):
        s, e = m.start(), m.end()
        while s < e and text[s] in _EDGE_PUNCT and not text[s].isdigit():
            s += 1
        while e > s and text[e - 1] in _EDGE_PUNCT and not text[e - 1].isdigit():
            e -= 1
        found.append(_claim("number", text, s, e))
    for kind, rx in (("date", _RELATIVE_DATE), ("quote", _QUOTE), ("comparative", _COMPARATIVE)):
        found.extend(_claim(kind, text, m.start(), m.end()) for m in rx.finditer(text))
    for n in {str(n).strip() for n in names or () if str(n).strip()}:
        found.extend(_claim("name", text, m.start(), m.end())
                     for m in re.finditer(r"(?<!\w)" + re.escape(n) + r"(?!\w)", text, re.I))
    found.sort(key=lambda c: (c["start"], -(c["end"] - c["start"])))
    out: list[dict[str, Any]] = []
    for c in found:
        if any(o["start"] <= c["start"] and c["end"] <= o["end"] for o in out):
            continue
        out.append(c)
    return out


def _utc(v: Any) -> dt.datetime | None:
    s = str(v or "").strip()
    if not s:
        return None
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo is not None else None      # a read date with no zone is not a UTC instant (rule 7): unreadable


def _sources(raw: Any) -> list[dict[str, Any]]:
    if raw is None:
        return []
    if not isinstance(raw, list) or not all(isinstance(s, dict) for s in raw):
        raise GateError("`sources` is a list of {claim, source, read_at}")
    return [{"claim": str(s.get("claim") or ""), "source": str(s.get("source") or "").strip()[:500],
             "read_at": str(s.get("read_at") or "").strip()[:40]} for s in raw]


def one_sentence(words: str) -> bool:
    """A source entry's quoted words stay inside one sentence: no line break, no sentence end followed by more text."""
    return not _SENTENCE_BREAK.search(str(words or "").strip())


def check(text: str, sources: Any = None, *, now: dt.datetime | None = None, window_days: Any = None,
          names: Iterable[str] | None = None) -> dict[str, Any]:
    """The gate's reading of one text: each claim with the source that covers it and why it fails, if it does; `state`
    `approvable` or `blocked`; and `choices`, with `approve` only when nothing failed."""
    now = now or dt.datetime.now(dt.timezone.utc)
    days = window(window_days)
    srcs = _sources(sources)
    # every place each source's quoted words stand in the text
    spans: list[tuple[int, int, dict[str, Any]]] = []
    for s in srcs:
        if s["claim"].strip():
            spans.extend((m.start(), m.end(), s) for m in re.finditer(re.escape(s["claim"]), text))
    claims = extract(text, names or ())
    for c in claims:
        cover = [s for a, b, s in spans if a <= c["start"] and c["end"] <= b]
        if not cover:
            c["problem"] = "no source names it"
            continue
        reasons = []
        for s in cover:
            read = _utc(s["read_at"])
            if not one_sentence(s["claim"]):
                reasons.append(f"its source {s['source']!r} quotes more than one sentence — a source covers the claims of one sentence at most")
            elif not s["source"]:
                reasons.append("its source entry names no source")
            elif read is None:
                reasons.append(f"its source {s['source']!r} has no UTC read date")
            elif read > now + SKEW:
                reasons.append(f"its source {s['source']!r} reads as read in the future ({s['read_at']})")
            elif now - read > dt.timedelta(days=days):
                reasons.append(f"its source {s['source']!r} was read {s['read_at']}, past the {days} d window")
            else:
                c["source"], c["read_at"] = s["source"], s["read_at"]
                break
        else:
            c["problem"] = "; ".join(reasons)
    failed = [c for c in claims if c.get("problem")]
    not_checked = [] if names is not None else ["named customers: no list of names was given to check against"]
    return {"state": "blocked" if failed else "approvable", "blocked": BLOCKED if failed else None,
            "choices": [] if failed else [APPROVE], "window_days": days, "read_at": now.isoformat(timespec="seconds"),
            "claims": claims, "failed": len(failed), "not_checked": not_checked,
            "why": [f"{c['kind']} {c['text']!r}: {c['problem']}" for c in failed]}
