"""The `org` command."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

from . import __version__
from .apply import ApplyRefused, apply_plan
from .detect import detect, draft_manifest, dump_manifest
from .doctor import Ctx, exit_code, render_text, run, to_json
from .manifest import ManifestError, enabled_roles, flat_vars, layer, read, unfilled, validate
from .plan import make_plan
from .record import from_doctor, validate as validate_record
from .roles import defaults_by_role, discover, runtime_problems
from .routine import render_text as routine_text, spec as routine_spec
from .verify import exit_code as verify_exit, render_text as verify_text, run_verify, summarize as verify_summary
from .vendor import HOOK_SNIPPET, unreleased, vendor, vendored_wheel

NOT_YET = {
    "report": "P4 — SPEC §11, the fleet",
}


def _load(manifest_path: Path):
    packages = discover()
    manifest = layer(read(manifest_path), defaults_by_role(packages))
    bad = runtime_problems(manifest, packages)
    if bad:
        raise ManifestError("manifest invalid:\n  " + "\n  ".join(bad))
    return manifest, packages


def cmd_roles(args) -> int:
    packages = discover()
    for rid, pkg in packages.items():
        c = pkg.contract
        print(f"{rid:<16} {c.get('display','?'):<8} v{pkg.version:<6} runtime={c.get('runtime',{}).get('default','?'):<8} cadence={c.get('cadence',{}).get('default','-'):<14} addenda={','.join(pkg.addenda) or '-'}")
    return 0


def cmd_validate(args) -> int:
    import yaml

    data = yaml.safe_load(Path(args.manifest).read_text())
    problems = validate(data)
    if problems:
        print("\n".join(problems))
        return 1
    packages = discover()
    m = layer(data, defaults_by_role(packages))
    missing = [r for r in enabled_roles(m) if r not in packages]
    if missing:
        print("enabled roles with no package: " + ", ".join(missing))
        return 1
    bad = runtime_problems(m, packages)
    if bad:
        print("\n".join(bad))
        return 1
    from .suite import suite_of
    suite = suite_of(m)
    if suite.problems:
        print("\n".join(suite.problems))
        return 1
    from .plan import empty_project_stops
    repo = Path(args.repo) if args.repo else Path(args.manifest).resolve().parent
    stops = empty_project_stops(repo, m, packages)
    if stops:
        print("\n".join(stops))
        return 1
    from .accounts import check_repo
    fleet = check_repo(repo, data)    # None in a repo that keeps no fleet registry (every installed org)
    if fleet:
        print("\n".join(fleet))
        return 1
    print(f"ok — {len(enabled_roles(m))} roles enabled, manifest_version {m['manifest_version']}; suite: " + ", ".join(f"{n} ({c['policy']})" for n, c in suite.enabled().items()))
    return 0


def cmd_render(args) -> int:
    from .plan import _render_role

    manifest, packages = _load(Path(args.manifest))
    if args.role not in packages:
        print(f"no such role: {args.role}")
        return 1
    if args.role not in manifest.get("roles", {}):
        print(f"{args.role} is not in this manifest's roles — a role the manifest does not name is not installed, so there is nothing to render")
        return 1
    fm, body, _ = _render_role(manifest, args.role, packages[args.role], args.kind, flat_vars(manifest))
    sys.stdout.write(fm + body)
    return 0


def _plan(args):
    manifest_path = Path(args.manifest)
    manifest, packages = _load(manifest_path)
    repo = Path(args.repo).resolve()
    project_from = Path(args.project_from).resolve() if getattr(args, "project_from", None) else None
    plan = make_plan(repo, manifest, packages, manifest_source=manifest_path,
                     adopt_existing=bool(getattr(args, "adopt_existing", False)), project_from=project_from)
    return repo, manifest, packages, plan


def cmd_plan(args) -> int:
    from . import outward_connectors as oc
    from . import prompts as pr
    repo, manifest, packages, plan = _plan(args)
    # the prompts an unattended role will meet, named before anything is written (row 134); `verify` is what refuses
    prompt_rows = pr.read(manifest, packages)
    if args.json:
        print(json.dumps({
            "repo": str(repo), "org": manifest["org"]["id"], "org_core": __version__,
            "worst": plan.worst, "by_status": plan.by_status(),
            "files": [{"path": a.path, "role": a.role, "kind": a.kind, "status": a.status, "detail": a.detail, "diff_lines": a.diff_lines} for a in plan.actions],
            "prompts": prompt_rows,
            "manual_steps": oc.manual_steps(manifest),
        }, indent=2))
        return 0 if not plan.blocking() else 1
    for a in plan.actions:
        extra = f"  ({a.diff_lines} diff lines)" if a.status == "changed" else ""
        print(f"{a.status:<13} {a.path}{extra}{('  ' + a.detail) if a.detail else ''}")
        if args.diff and a.diff:
            print(a.diff)
    print(f"\nworst: {plan.worst}   " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v))
    for ok, text in pr.lines(prompt_rows):
        print(f"{'decided' if ok else 'UNDECIDED':<13} {text}")
    # an outward role's connectors are the operator's manual steps; `verify` passes each only on its recorded read (SPEC §6)
    for line in oc.plan_lines(manifest):
        print(line)
    return 0 if not plan.blocking() else 1


def cmd_apply(args) -> int:
    repo, manifest, packages, plan = _plan(args)
    if args.cmd == "upgrade" and not (repo / ".org/lock.yaml").exists():
        print("upgrade needs an installed repo (.org/lock.yaml missing) — use apply for a first install")
        return 1
    if getattr(args, "diff", False):
        # a preview never writes (measured 2026-09-17: `apply --diff` rewrote every managed file of an installed org)
        for a in plan.actions:
            print(f"{a.status:<13} {a.path}{('  ' + a.detail) if a.detail else ''}")
            if a.diff:
                print(a.diff)
        print(f"\npreview only — nothing written; worst: {plan.worst}   " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v))
        return 0 if not plan.blocking() else 1
    try:
        result = apply_plan(repo, manifest, packages, plan, overwrite_changed=args.overwrite_changed)
    except ApplyRefused as e:
        print(f"apply refused: {e}")
        return 1
    for p in result.written:
        print(f"wrote      {p}")
    for p in result.skipped:
        print(f"unchanged  {p}")
    print(f"lock       {result.lock_path}")
    for line in result.unignored:
        print(f"whitelisted {line}   (git ignored a managed file; a fresh container would not have had it — row 93)")
    w = vendored_wheel(repo)
    if w is not None:
        print(f"vendored   {w.relative_to(repo)}")
        _say_if_unreleased()
    return 0


def _say_if_unreleased() -> None:
    """Print the provenance warning when the wheel just written is on no commit of org-core.

    Only ever a warning: while developing you are legitimately ahead of `main`, and
    refusing would block the release that makes it true. What it must not do is stay
    silent, which is what happened on 2026-09-22.
    """
    msg = unreleased()
    if msg:
        print(f"WARNING    {msg}")


def cmd_vendor(args) -> int:
    """Write the running org-core as a wheel into the repo (SPEC §6, row 54) and print the hook lines that install it."""
    repo = Path(args.repo).resolve()
    w = vendor(repo)
    print(f"vendored   {w.relative_to(repo)}  ({w.stat().st_size} bytes, org-core {__version__})")
    _say_if_unreleased()
    if args.hook:
        print(HOOK_SNIPPET)
    return 0


def cmd_priorities(args) -> int:
    """`org priorities`: exit 0 when every ask is landed or landable, 1 when one names no file, cannot be read, has no
    writer, or (with `--by`) was signed by someone other than the page's owner."""
    from . import priorities as pr
    rows = pr.apply(Path(args.repo), pr.load_asks(Path(args.src), by=args.by, board=args.accept_board), write=args.write)
    if args.json:
        print(json.dumps(rows, indent=2))
    else:
        verb = "set" if args.write else "would set"
        for r in rows:
            what = (f"{r['kind']} {r['key']}: {r.get('was') or 'unset'} -> {r['priority'] or 'unset'} (by {r.get('by')}"
                    + (f"; the row says {r['says']!r} — match it against the relay DM" if r.get("unverified") else "") + ")")
            print({"changed": f"{verb:<10} {what}", "already": f"{'landed':<10} {what}",
                   "unknown": f"{'UNKNOWN':<10} {r['kind']} {r['key']}: no {r.get('file')}",
                   "unverified": f"{'UNVERIFIED':<10} {r['kind']} {r['key']}: {r.get('why')}",
                   "not-owner": f"{'NOT OWNER':<10} {r['kind']} {r['key']}: signed by {r.get('by')}, not {args.by}",
                   "invalid": f"{'INVALID':<10} {r.get('why')}: {r}"}[r["result"]])
        n = sum(1 for r in rows if r["result"] == "changed")
        print(f"{n} to change, {sum(1 for r in rows if r['result'] == 'already')} already landed" +
              ("" if not n else ("; next: roadmap validate --source files && roadmap sync --source files, a PR, "
                                 "and after the merge `roadmap push`" if args.write else "; run again with --write")))
    return 1 if any(r["result"] in ("unknown", "invalid", "not-owner", "unverified") for r in rows) else 0


def cmd_knob(args) -> int:
    """`org knob` (SPEC §10, 0.47.0): the runtime knobs on the org's board. `list` and `get` are what a role reads at wake;
    `set` and `clear` are the operator's (or, inside the declared range, the CEO's). One knob ships:
    `<role>.cadence_multiplier`, which multiplies that role's wake interval and never touches its cron."""
    import yaml as _yaml

    from . import knobs as kn
    from . import tempo as tp
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    try:
        if args.knob_cmd == "set":
            try:
                value = float(args.value)
            except ValueError:
                raise kn.KnobError(f"{args.name} takes a number, not {args.value!r}")
            rec = kn.validate(args.name, value, manifest, ttl=args.ttl, reason=args.reason, by=args.by)
            kn.write(rec, manifest, tp._run)
            print(f"set        {rec['name']} = {rec['value']:g} until {rec['expires_at']} — {rec['reason']}")
            return 0
        if args.knob_cmd == "clear":
            kn.clear(args.name, manifest, tp._run)
            print(f"cleared    {args.name}")
            return 0
        rows = tp.gather_board(manifest["ports"]["coordination"]["workspace"], tp._run, prefixes=(kn.PREFIX,),
                               url=(manifest["ports"]["coordination"] or {}).get("url"))
    except kn.KnobError as e:
        print(f"org knob {args.knob_cmd}: {e}", file=sys.stderr)
        return 1
    except (RuntimeError, OSError, json.JSONDecodeError) as e:
        print(f"org knob {args.knob_cmd}: the board could not be reached ({e})", file=sys.stderr)
        return 2
    knobs = kn.from_board(rows)
    if args.knob_cmd == "get":
        name = args.name
        k = knobs.get(name)
        out = {"name": name, "set": k is not None, "value": k.get("value") if k else 1.0, "effective": kn.multiplier(knobs, kn.role_of(name), manifest),
               "expires_at": k.get("expires_at") if k else None, "reason": k.get("reason") if k else None}
        print(json.dumps(out) if args.json else
              (f"{name} = {out['value']:g} (effective {out['effective']:g}) until {out['expires_at']} — {out['reason']}" if k
               else f"{name} is not set — default 1"))
        return 0
    print(json.dumps(knobs, indent=2) if args.json else kn.render(knobs), end="" if not args.json else "\n")
    return 0


def cmd_pool(args) -> int:
    """`org pool` (item `launcher-role`): the launcher's gates — which account this container is on, whether a spawn
    request, a ledger entry or a listing is well formed, whether this account may claim a request on the headroom it
    read, and the secret names its environment holds against what its pool's orgs declare. Names only, never a value."""
    import yaml as _yaml

    from . import accounts as ac
    from . import pool as pl
    repo = Path(args.repo).resolve()
    a_path = repo / ac.ACCOUNTS_FILE
    a_doc = (_yaml.safe_load(a_path.read_text()) or {}) if a_path.exists() else {}
    label = pl.account_label(a_doc, os.environ.get(ac.ENV_ACCOUNT))
    if args.pool_cmd == "account":
        # `unmapped` keeps the record key a key: a launcher that cannot say which account it is on still writes a record
        print(label or "unmapped")
        return 0 if label else 1
    if args.pool_cmd == "secrets":
        declared: set[str] = set()
        for f in args.manifest or []:
            declared.update(pl.declared_secret_names(_yaml.safe_load(Path(f).read_text()) or {}))
        declared.update(args.declare or [])
        print(json.dumps(pl.secret_names(declared, os.environ.keys())))
        return 0
    doc = json.loads(Path(args.file).read_text())
    if args.pool_cmd == "check":
        bad = {"request": pl.request_problems, "spawned": pl.spawned_problems, "listing": pl.listing_problems}[args.kind](doc)
        for b in bad:
            print(f"INVALID    {b}")
        if not bad:
            print(f"ok         {args.kind}")
        return 1 if bad else 0
    account = ((a_doc.get("accounts") or {}).get(label) if label else None)
    ok, why = pl.may_claim(account, args.headroom, doc)
    print(f"{'claim' if ok else 'no claim'}   {label or 'unmapped'}: {why}")
    return 0 if ok else 1


def cmd_delegations(args) -> int:
    """`org delegations` (0.51.0, SPEC row 180): the operator's standing decisions — who may do which act, where, on
    which conditions — and `use` / `check` for a role to record or dry-run one. `use` refuses (exit 1) when the role,
    the target, the date, the conditions or the evidence is wrong, and then the act is the operator's: ask."""
    import datetime as _dt

    import yaml as _yaml

    from . import delegations as dg
    if not args.repo:
        print("org delegations: --repo is required", file=sys.stderr)
        return 2
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text()) or {}
    bad = dg.problems(manifest)
    if bad:
        for b in bad:
            print(f"INVALID    {b}")
        return 1
    if args.dg_cmd in ("use", "check"):
        checked = [c.strip() for c in (args.checked or "").split(",") if c.strip()]
        try:
            if args.dg_cmd == "use":
                rec = dg.use(repo, manifest, args.id, role=args.role, target=args.target, checked=checked, evidence=args.evidence or "")
                print(f"used       {rec['id']} by {rec['role']} on {rec['target']} at {rec['at']} — {dg.LOG} (commit it with the work)")
            else:
                d = dg.check(manifest, args.id, role=args.role, target=args.target, checked=checked, evidence=args.evidence or "")
                print(f"allowed    {d['id']} for {args.role} on {args.target} — nothing recorded; `use` records")
        except dg.Refused as e:
            print(f"REFUSED    {e}", file=sys.stderr)
            return 1
        return 0
    m = dg.read(repo, manifest, _dt.datetime.now(_dt.timezone.utc))
    if args.json:
        print(json.dumps(m, indent=2, ensure_ascii=False))
        return 0
    if not m["grants"]:
        print("Nothing is delegated: every act in SPEC §12 comes to the operator.")
        return 0
    for g in m["grants"]:
        print(f"{'active ' if g['active'] else 'EXPIRED'}  {g['id']}: `{g['act']}` to {g['to']} in {', '.join(g['orgs'])} — {g['uses']} use(s)")
        print(f"           what: {g['what']}")
        print(f"           when: {'; '.join(c['id'] for c in g['when'])} · granted {g['by']} {g['on']}" + (f" · expires {g['expires']}" if g["expires"] else ""))
        for u in g["last_uses"]:
            print(f"           used {u.get('at')} {u.get('role')} on {u.get('target')} — {u.get('evidence')}")
    if m["bad_lines"] or m["orphans"]:
        print(f"WARNING    the log has {m['bad_lines']} unreadable line(s) and uses of unknown grants {m['orphans']}")
    return 0


def cmd_asks(args) -> int:
    """`org asks` (0.42.0): what the operator asked from the page — on the org's board (a served page) or in a saved
    listing of a published page's `asks` collection (`--from`) — and `done <id>` to answer one on its record."""
    import yaml as _yaml

    from . import asks as ak
    from . import tempo as tp
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    if args.asks_cmd == "done":
        try:
            v = ak.mark_done(args.id, args.note or "", manifest, tp._run)
        except (ak.AskError, RuntimeError, json.JSONDecodeError) as e:
            print(f"org asks done: {e}", file=sys.stderr)
            return 1
        print(f"done       {v['id']} — the page shows it beside the ask")
        return 0
    if args.src:
        from . import priorities as pr
        rows = []
        for d in pr._docs(json.loads(Path(args.src).read_text())):
            try:
                a = ak.validate(d)
            except ak.AskError as e:
                print(f"INVALID    {d.get('id')}: {e}")
                continue
            if not a.get("by"):
                print(f"UNSIGNED   {a['id']}: no writer — nobody can say it is the operator's")
                continue
            if args.by and a["by"] != args.by:
                print(f"NOT OWNER  {a['id']}: signed by {a['by']}")
                continue
            rows.append(a)
        asks = sorted(rows, key=lambda a: a["at"], reverse=True)
    else:
        c = manifest["ports"]["coordination"]
        env = {"SWITCHBOARD_WORKSPACE": c["workspace"], **({"SWITCHBOARD_URL": c["url"]} if c.get("url") else {})}
        try:
            asks = ak.from_board(json.loads(tp._run(["switchboard", "--json", "board", "list"], env) or "[]"))
        except (RuntimeError, json.JSONDecodeError, OSError) as e:
            print(f"org asks: the board could not be read ({e})", file=sys.stderr)
            return 2
    if not args.all:
        asks = [a for a in asks if not a.get("done")]
    print(json.dumps(asks, indent=2, ensure_ascii=False) if args.json else ak.render(asks), end="" if not args.json else "\n")
    return 0


def _item_on_roadmap(repo: Path, manifest: dict, key: str, tp, flag: str = "--item") -> str | None:
    """`org handoffs add --item <key>` refuses a key the org's roadmap does not hold (item `decide-filtered-to-one-arc`, row 2): a card filed
    under a misspelt key would sit under *no arc* with nothing saying why. Read as the page reads it (`tempo._roadmap`: the served store, else
    the committed items). Broken looks like: a card recorded for a key no item carries, or one refused while the item exists."""
    from . import handoffs as hf
    rm = tp._roadmap(repo, manifest)
    if rm is None:
        raise hf.HandoffError(f"`{flag}` names a roadmap item, and this org declares no roadmap-core work store")
    if rm.get("items") is None:
        raise hf.HandoffError(f"the roadmap could not be read to check `{flag}` ({rm.get('why')})")
    held, status = hf.item_now(rm, key)
    if not held:
        raise hf.HandoffError(f"`{flag} {key}` is not an item on this org's roadmap ({rm.get('source')})"
                              + ("" if flag == "--item" else f" — {hf.NO_ITEM}"))
    return status


def cmd_handoffs(args) -> int:
    """`org handoffs` (0.52.0, SPEC row 181): what a role handed the operator — who can decide it, what is recommended, what
    waiting costs, the exact command or text. `add` records one on the board (it sends nothing: the page shows it, and the
    role says so in its own message); `done <id>` answers one. Exit 1 on a handoff that does not validate."""
    import yaml as _yaml

    from . import handoffs as hf
    from . import tempo as tp
    if not args.repo:
        print("org handoffs: --repo is required", file=sys.stderr)
        return 2
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    if args.hf_cmd == "add":
        try:
            h = hf.validate({"org": args.org, "decides": args.decides, "what": args.what, "for": args.for_item, "why": args.why,
                             "recommend": args.recommend, "cost": args.cost, "do": args.do, "delegation": args.delegation,
                             "options": args.option, "recommended_option": args.recommended_option,
                             "close": args.close, "look": args.look, "by": args.by, "item": args.item}, manifest)
            # every card names its roadmap item (the operator, 2026-10-12: "cards must name the items, how else can we track?"; item
            # `every-operator-card-names-its-item`): a close card's `--for` is its item, any other card's is `--item`. No flag skips it
            if not h.get("item"):
                raise hf.HandoffError(hf.NO_ITEM)
            # …and the item's status as the card is written, so Decide can say when it moved since (row 6)
            h["item_status"] = _item_on_roadmap(repo, manifest, h["item"], tp, "--for" if h.get("kind") == "close_item" else "--item")
            kept = _keep_ceo_line(h, manifest, hf, tp) if h.get("kind") == "close_item" else None
            hf.record(h, manifest, tp._run)
        except hf.HandoffError as e:
            print(f"org handoffs add: {e}", file=sys.stderr)
            return 1
        except (RuntimeError, OSError) as e:
            print(f"org handoffs add: the board could not be written ({e})", file=sys.stderr)
            return 2
        print(f"recorded   {h['id']} — decides: {hf.DECIDES[h['decides']]}; the pages show it under what waits on you "
              f"(it expires from the board in 7 days: record it again if it is still true)")
        if h.get("kind") == "close_item":
            print(f"           the close card for {h['item']}: filing it again replaces this one; the answer on it moves the item "
                  f"through `org handoffs settle --apply`")
            print("           the CEO's line is kept: what the card says is unchanged, and it waits on the operator" if kept else
                  f"           held for the CEO: it reaches the operator once the CEO adds its line — `org handoffs ceo {h['id']} "
                  "--recommend \"…\" --close done|reopen`, or `--recommend \"none: <why>\"`")
        return 0
    if args.hf_cmd == "ceo":
        return _handoffs_ceo(args, manifest, hf, tp)
    if args.hf_cmd == "settle":
        return _handoffs_settle(args, manifest, hf, tp)
    if args.hf_cmd == "done":
        try:
            # a card that left the board is closed from its last text in the committed facts (row 4): else it could only be re-recorded
            c = manifest["ports"]["coordination"]
            env = {"SWITCHBOARD_WORKSPACE": c["workspace"], **({"SWITCHBOARD_URL": c["url"]} if c.get("url") else {})}
            try:
                live = json.loads(tp._run(["switchboard", "--json", "board", "list"], env) or "[]")
            except (RuntimeError, OSError, json.JSONDecodeError):
                live = None
            hist = _handoff_history(tp.latest_facts(repo, n=10**6), hf)
            left = hf.expired(hist, live, dt.datetime.now(dt.timezone.utc)) if isinstance(live, list) else []
            # and one closed before whose close has expired too: written back as it was, so a reader whose history lacks it reads it
            v = hf.mark_done(args.id, args.note or "", manifest, tp._run, left=left, history=hist)
        except (hf.HandoffError, RuntimeError, json.JSONDecodeError) as e:
            print(f"org handoffs done: {e}", file=sys.stderr)
            return 1
        if v["done"].get("rewritten_at"):
            print(f"done       {v['id']} — already closed {v['done']['at']}; its close is on the board again, so every reader drops it")
        else:
            print(f"done       {v['id']} — it leaves the list")
        # the operator's answer to it, if they gave one, is acted on now: mark it so the page does not say the CEO has not
        from . import asks as ak
        try:
            c = manifest["ports"]["coordination"]
            env = {"SWITCHBOARD_WORKSPACE": c["workspace"], **({"SWITCHBOARD_URL": c["url"]} if c.get("url") else {})}
            rows = json.loads(tp._run(["switchboard", "--json", "board", "list"], env) or "[]")
            for a in ak.from_board(rows):
                if a.get("kind") == "answer" and (a.get("target") or {}).get("key") == args.id and not a.get("done"):
                    ak.mark_done(a["id"], args.note or "handoff closed", manifest, tp._run)
                    print(f"           and the operator's answer {a['id']}")
        except (RuntimeError, OSError, KeyError, json.JSONDecodeError, ak.AskError) as e:
            print(f"WARNING    the operator's answer was not marked acted on ({e})", file=sys.stderr)
        return 0
    if args.hf_cmd == "missing":
        return _handoffs_missing(args, repo, manifest, hf, tp)
    c = manifest["ports"]["coordination"]
    env = {"SWITCHBOARD_WORKSPACE": c["workspace"], **({"SWITCHBOARD_URL": c["url"]} if c.get("url") else {})}
    try:
        rows = json.loads(tp._run(["switchboard", "--json", "board", "list"], env) or "[]")
        hs, bad = hf.from_board(rows)
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        print(f"org handoffs: the board could not be read ({e})", file=sys.stderr)
        return 2
    now = dt.datetime.now(dt.timezone.utc)
    for h in hs:
        if not h.get("done"):
            h["left_hours"] = hf.left_hours(h, now)
    if not args.all:
        hs = [h for h in hs if not h.get("done")]
    # a card that left the board unanswered is still listed, from the committed facts files (handoffs.expired): never gone for age alone
    hist = tp.latest_facts(repo, n=10**6)
    gone = hf.expired(_handoff_history(hist, hf), rows, now)
    if args.all:
        hs = hs + gone
    print(json.dumps(hs, indent=2, ensure_ascii=False) if args.json else hf.render(hs), end="" if not args.json else "\n")
    unnamed = hf.name_no_item(hs)
    if unnamed:
        print(f"WARNING    {len(unnamed)} open card(s) name no item: {', '.join(unnamed)} — record each again with `--item <key>`, "
              "or close it (`org handoffs done <id>`)", file=sys.stderr)
    if gone and not args.all:
        print(f"WARNING    {len(gone)} card(s) left the board never answered — `org handoffs --all` lists each with its last text",
              file=sys.stderr)
    if hist is None:
        print(f"note       no committed facts under {tp.FACTS_DIR}: a card that left the board cannot be listed (not checked)", file=sys.stderr)
    if bad:
        print(f"WARNING    {bad} row(s) under {hf.BOARD_PREFIX} are not handoffs and were not read", file=sys.stderr)
    return 0


def _handoff_history(hist, hf) -> list:
    """Every handoff row the committed facts hold: the board as each gather read it, and the ledger of cards that had left it
    (`handoffs_left`, carried forward by each gather so it outlives the oldest file — row 5)."""
    return [r for r in ((hist or {}).get("board") or []) + ((hist or {}).get("handoffs_left") or []) + ((hist or {}).get("handoffs_closed") or [])
            if str(r.get("key", "")).startswith(hf.BOARD_PREFIX)]


def _board_handoff(hid: str, manifest, hf, tp) -> dict | None:
    """The handoff recorded under `hid`, or None when there is none (or it could not be read)."""
    try:
        got = json.loads(tp._run(["switchboard", "--json", "board", "get", hf.BOARD_PREFIX + hid], hf._env(manifest)) or "{}")
    except (RuntimeError, OSError, KeyError, json.JSONDecodeError):
        return None
    v = got.get("value") if isinstance(got, dict) else None
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            return None
    return v if isinstance(v, dict) and v.get("id") == hid else None


def _keep_ceo_line(h: dict, manifest, hf, tp) -> bool:
    """A role re-filing a close card keeps the CEO's line only when what the CEO answered is unchanged (`hf.CEO_FIELDS`) — the verifier
    renews its card every six days, and that alone must not send it back to the CEO. A changed measurement or recommendation, or a card
    that could not be read, goes back to the CEO. Sets `h["ceo"]` in place; True when kept."""
    old = _board_handoff(h["id"], manifest, hf, tp)
    if not old or old.get("done") or not old.get("ceo") or any(old.get(k) != h.get(k) for k in hf.CEO_FIELDS):
        return False
    h["ceo"] = old["ceo"]
    return True


def _handoffs_ceo(args, manifest, hf, tp) -> int:
    """`org handoffs ceo <id>`: the CEO's own line on a close card — a recommendation with its pick (`--close`), or `none: <why it cannot
    recommend>` — which is what moves the card from the CEO's queue to *Waiting on you*. The role's recommendation stays as it was filed.
    Exit 1 when the card is not an open close card or the line does not validate; 2 the board could not be written."""
    import datetime as _dt
    v = _board_handoff(args.id, manifest, hf, tp)
    if not v or v.get("kind") != "close_item" or v.get("done"):
        print(f"org handoffs ceo: {args.id} is not an open close card on the board", file=sys.stderr)
        return 1
    try:
        h = hf.validate({**v, "ceo": {"recommend": args.recommend, "close": args.close, "by": args.by,
                                      "at": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")}}, manifest)
        hf.record(h, manifest, tp._run)
    except hf.HandoffError as e:
        print(f"org handoffs ceo: {e}", file=sys.stderr)
        return 1
    except (RuntimeError, OSError) as e:
        print(f"org handoffs ceo: the board could not be written ({e})", file=sys.stderr)
        return 2
    print(f"recorded   the CEO's line on {h['id']} ({h['item']}): {hf.ceo_says(h)} — it now waits on the operator")
    return 0


def cmd_verifying(args) -> int:
    """`org verifying`: the registrar's settle table (`coord/registrar/settle`) read against the verifier's last record — what is
    due, what waits and on what, what is overdue (due more than two days with no verdict and no named wait) and what no state
    places — including every item the work store holds in `verifying` that the table lacks (read 2026-10-15: 37 in the store, 30
    in the table, and the table-only reading printed a pass). `--fold` prints only the table with the verifier's named waits and
    verdicts applied, for the registrar to write back. Exit 0 nothing overdue or unplaced; 1 some; 2 the table or the work
    store could not be read (never read as an empty queue, and never a pass)."""
    import datetime as _dt

    import yaml as _yaml

    from . import verifying as vq
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    if args.table:
        table = json.loads(Path(args.table).read_text())
    else:
        table = _board_get(manifest, "coord/registrar/settle")
    if not isinstance(table, dict):
        print("org verifying: coord/registrar/settle could not be read — not checked, which is not an empty queue", file=sys.stderr)
        return 2
    if args.verifier:
        record = json.loads(Path(args.verifier).read_text())
    else:
        record = _board_get(manifest, "roles/verifier/last-run")
    folded, notes = vq.fold(table, record if isinstance(record, dict) else None)
    if args.fold:
        print(json.dumps(folded, ensure_ascii=False))
        return 0
    today = _dt.date.fromisoformat(args.today) if args.today else _dt.datetime.now(_dt.timezone.utc).date()
    store, store_why = _verifying_in_store(repo, manifest, args.store)
    r = vq.reading(folded, today, store)
    if args.json:
        print(json.dumps({**r, "folded": notes, "verifier_record": "read" if isinstance(record, dict) else "not read",
                          "store_why": store_why}, indent=2, ensure_ascii=False))
    else:
        if not isinstance(record, dict):
            print("the verifier's record could not be read: nothing folded")
        print(vq.render_text(r, notes))
    if store is None:
        print(f"org verifying: the work store's verifying set could not be read ({store_why}) — not checked, which is not a pass",
              file=sys.stderr)
        return 2
    return 1 if r["overdue"] or r["unplaced"] else 0


def _verifying_in_store(repo: Path, manifest: dict, saved: str | None) -> tuple[set[str] | None, str]:
    """The keys the work store holds in `verifying`, and where they were read from — or None and why not. A served store is
    asked through the org's own CLI (`<cli> list --source db --json`, the read `roadmap list` makes) and is never replaced by the
    committed files, whose statuses are not the live ones; a files-mode store is its item files. `saved` is a dump of that
    list (`{key: {status, …}}`) for a reading against a fixed store."""
    from . import tempo as tp
    if saved:
        try:
            got = json.loads(Path(saved).read_text())
        except (OSError, json.JSONDecodeError) as e:
            return None, f"{saved}: {e}"
        rows = [dict(v, key=k) for k, v in got.items() if isinstance(v, dict)] if isinstance(got, dict) else None
        if rows is None:
            return None, f"{saved}: not a {{key: item}} object"
        return {str(r["key"]) for r in rows if r.get("status") == "verifying"}, saved
    ws = (manifest.get("ports") or {}).get("work_store") or {}
    if ws.get("tool") != "roadmap-core":
        return None, "the manifest declares no roadmap-core work store (`ports.work_store`)"
    if str(ws.get("mode") or "files") == "served":
        cmd = [*str(ws.get("cli") or "roadmap").split(), "list", "--source", "db", "--json"]
        try:
            got = json.loads(tp._run_in(repo, cmd, None, manifest) or "{}")
        except (RuntimeError, json.JSONDecodeError, OSError, subprocess.TimeoutExpired) as e:
            return None, f"`{' '.join(cmd)}`: {str(e)[:200]}"
        if not isinstance(got, dict):
            return None, f"`{' '.join(cmd)}` answered no {{key: item}} object"
        return {str(k) for k, v in got.items() if isinstance(v, dict) and v.get("status") == "verifying"}, "the served store"
    files = tp._roadmap_files(repo, str(ws.get("files") or "roadmap/").strip("/"))
    if files is None:
        return None, f"no item files under {ws.get('files') or 'roadmap/'}"
    rows, unparsed = files
    if unparsed:
        return None, f"item files that do not parse: {', '.join(unparsed[:5])}"
    return {r["key"] for r in rows if r.get("status") == "verifying"}, "the item files"


def _handoffs_settle(args, manifest, hf, tp) -> int:
    """`org handoffs settle`: what the operator's answers on close cards move — each item to `done` or back to `ready` — listed, and with
    `--apply` moved on the work store (`<work_store.cli> status <key> <to>`), the card closed and the answer marked acted on, so the page
    stops asking. An answer row on the board is attributed, never signed (`handoffs.answers_for`), so whoever can write the board can
    write one: `--apply` is the CEO's, run after it has read the answers this lists — a role on a clock lists them and never applies
    (Reed, UNSOUND on #170 at 16f624f). An answer that does not say which (words only, or two that disagree) is listed for a person and moves nothing. Exit 0
    listed or moved; 1 a move failed; 2 the board could not be read."""
    import shlex

    from . import asks as ak
    c = manifest["ports"]["coordination"]
    env = {"SWITCHBOARD_WORKSPACE": c["workspace"], **({"SWITCHBOARD_URL": c["url"]} if c.get("url") else {})}
    try:
        rows = json.loads(tp._run(["switchboard", "--json", "board", "list"], env) or "[]")
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        print(f"org handoffs settle: the board could not be read ({e}) — nothing was checked, which is not the same as nothing answered",
              file=sys.stderr)
        return 2
    plan = hf.settle(hf.open_ones(rows), hf.answers_for(ak.from_board(rows)))
    if args.json and not args.apply:
        print(json.dumps(plan, indent=2, ensure_ascii=False))
        return 0
    if not plan:
        print("no close card carries an answer nobody has acted on — nothing to move")
        return 0
    if not args.apply:
        print("listed only: an answer row is attributed, never signed — the CEO reads each one, then applies with --apply")
    cli = shlex.split(str(((manifest.get("ports") or {}).get("work_store") or {}).get("cli") or "roadmap"))
    failed = 0
    for p in plan:
        if not p["to"]:
            print(f"read       {p['item']} (card {p['id']}): {p['why']}" + (f" — the operator said: {p['note']}" if p["note"] else ""))
            continue
        why = f" — the operator's reason: {p['note']}" if p["note"] else ""
        if not args.apply:
            print(f"would move {p['item']} -> {p['to']}   {' '.join(cli)} status {p['item']} {p['to']}{why}  (answer {', '.join(p['answers'])})")
            continue
        try:
            tp._run([*cli, "status", p["item"], p["to"]])
        except (RuntimeError, OSError) as e:
            failed += 1
            print(f"FAILED     {p['item']} -> {p['to']}: {e} — the card stays open", file=sys.stderr)
            continue
        note = f"moved to {p['to']} on the operator's answer{why}"
        try:
            hf.mark_done(p["id"], note, manifest, tp._run)
            for aid in p["answers"]:
                ak.mark_done(aid, note, manifest, tp._run)
        except (hf.HandoffError, ak.AskError, RuntimeError, json.JSONDecodeError) as e:
            print(f"WARNING    {p['item']} moved, but the card or the answer was not marked ({e})", file=sys.stderr)
        print(f"moved      {p['item']} -> {p['to']}{why}")
        if p["to"] == "done":
            print(f"           the file's own `done` is a pull request with its evidence (CLAUDE.md, work tracking)")
    return 1 if failed else 0


def _handoffs_missing(args, repo, manifest, hf, tp) -> int:
    """`org handoffs missing`: the waiting decisions that carry no recommendation and no reason, by address. It writes no recommendation
    (that is the CEO's call, SPEC row 182). `--dm` sends the ones not yet sent as one DM to the CEO through `org tempo dm` and records each
    on the board for seven days, so an item is sent once until it is answered or the record expires. Exit 0 listed; 2 the reading failed."""
    import datetime as _dt

    from . import console as cs
    from . import status as stx
    from .brief import brief
    now = _dt.datetime.now(_dt.timezone.utc)
    try:
        facts = tp.gather(repo, manifest, since=(now - _dt.timedelta(days=7)).strftime("%Y-%m-%dT00:00:00Z"), now=now)
        st = stx.status(facts, now)
        m = cs.org_model(st, brief(st))
    except (RuntimeError, OSError, KeyError, ValueError) as e:
        print(f"org handoffs missing: the board could not be read ({e}) — nothing was checked, which is not the same as none missing", file=sys.stderr)
        return 2
    got = hf.missing(m["cards"])
    # rows held for the CEO's line never reach the cards: they are the CEO's count — a close card by its own id, any other row by the
    # `--for` key its handoff names (handoffs.ceo_owes_row)
    import hashlib as _hl
    got["ceo_owes"] = [({"fid": "close-" + str(q["handoff"]["id"]), "id": q["handoff"]["id"], "item": q["handoff"].get("item"),
                         "what": q.get("head") or "", "ago": ""} if (q.get("handoff") or {}).get("kind") == "close_item" else
                        {"fid": "held-" + _hl.sha1(str(q.get("for_key") or q.get("head")).encode()).hexdigest()[:10], "id": None,
                         "for": str(q.get("for_key") or ""), "what": q.get("head") or "", "ago": ""})
                       for q in (st.get("subjects") or {}).get("queue_ceo") or []]
    org = str(m["scope"]["id"])
    if m["queue_unread"]:
        print(f"not checked: what is waiting on the operator could not be read ({m['queue_note']})")
        return 0
    sent = {k.rsplit("/", 1)[-1] for k in _board_keys(manifest, hf.SENT_PREFIX)} if args.dm else set()
    fresh = {**got, "flagged": [r for r in got["flagged"] if r["fid"] not in sent], "ceo_owes": [r for r in got["ceo_owes"] if r["fid"] not in sent]}
    if args.json:
        print(json.dumps({**got, "unsent": [r["fid"] for r in fresh["flagged"] + fresh["ceo_owes"]]}, indent=2, ensure_ascii=False))
    else:
        print(hf.missing_line(got) or "nothing waits on the operator")
        for r in got["flagged"]:
            print(f"  #f-{r['fid']}  waiting {r['ago'] or 'no date'}  {' '.join(str(r['what']).split())[:100]}")
        for r in got["unread"]:
            print(f"  #f-{r['fid']}  not checked  {' '.join(str(r['what']).split())[:100]}")
        if got["ceo_owes"]:
            print(f"{len(got['ceo_owes'])} held for the CEO's line — not shown to the operator until it is added:")
            for r in got["ceo_owes"]:
                if r["id"]:
                    print(f"  {r['id']}  {r['item']}  `org handoffs ceo {r['id']} --recommend \"…\" --close done|reopen` (or `none: <why>`)")
                else:
                    print(f"  {' '.join(str(r['what']).split())[:90]}\n    `org handoffs add --decides operator --for {json.dumps(r['for'], ensure_ascii=False)} "
                          f"--item \"<key>\" --what \"…\" --recommend \"…\" --cost \"…\"` (or `--recommend \"none: <why>\"`)")
    if not args.dm:
        return 0
    if not fresh["flagged"] and not fresh["ceo_owes"]:
        print("dm         nothing new to send — every flagged item was already sent")
        return 0
    text = hf.dm_text(fresh, org)
    p = subprocess.run(["org", "tempo", "--repo", str(repo), "dm", "--role", "ceo", text], capture_output=True, text=True, timeout=120)
    print("dm         " + (p.stdout or p.stderr).strip()[:300])
    if p.returncode == 0:
        for r in fresh["flagged"] + fresh["ceo_owes"]:
            _board_set(manifest, hf.SENT_PREFIX + r["fid"], json.dumps({"at": now.isoformat(timespec="seconds")}), hf.TTL)
    return 0 if p.returncode == 0 else 1


def _board_keys(manifest, prefix: str) -> list[str]:
    import os as _os
    co = manifest["ports"]["coordination"]
    env = {**_os.environ, "SWITCHBOARD_WORKSPACE": co["workspace"], **({"SWITCHBOARD_URL": co["url"]} if co.get("url") else {})}
    p = subprocess.run(["switchboard", "--json", "board", "list"], capture_output=True, text=True, timeout=60, env=env)
    try:
        return [str(r.get("key")) for r in json.loads(p.stdout or "[]") if str(r.get("key", "")).startswith(prefix)]
    except json.JSONDecodeError:
        return []


def cmd_fleet(args) -> int:
    """`org fleet`: who is behind the package, since when, and whether their upgrade is already open (SPEC §11, row 108)."""
    from . import fleet as fl
    root = Path(args.repo) if args.repo else Path(__file__).resolve().parents[1]
    registry = fl.load_registry(Path(args.registry) if args.registry else root / "fleet" / "orgs.yaml")
    fetch_note = fl.refresh_main(root)
    try:
        history, note = fl.version_history(root)
    except (RuntimeError, OSError) as e:
        history, note = [], f"no git history at {root}: {str(e)[:120]}"
    try:
        shipped, shipped_note = fl.main_wheels(root)
    except (RuntimeError, OSError) as e:
        shipped, shipped_note = None, f"no git history at {root}: {str(e)[:120]}"
    rep = fl.report(registry, history=history, history_note=note, shipped=shipped, shipped_note=shipped_note,
                    fetch_note=fetch_note)
    print(json.dumps(rep, indent=1, ensure_ascii=False) if args.json else fl.render(rep))
    return int(rep["exit"])


def cmd_operator(args) -> int:
    """`org operator render`: the operator file from the board (SPEC §9). Exit 2 when the board cannot be read — a file
    rendered from nothing would say `never ran` for everyone."""
    from . import doctor as dr
    from . import operator_file as of
    repo = Path(args.repo).resolve()
    manifest, packages = _load(Path(args.manifest))
    ctx = dr.Ctx(repo=repo, manifest=manifest)
    def read_record(key: str):
        return dr._record_value(ctx.record(key))
    try:
        rel, new, changes = of.render_repo(repo, manifest, packages, read_record, roles=[r.strip() for r in args.roles.split(",")] if args.roles else None)
    except dr.UnreachablePort as e:
        print(f"operator: {e} — nothing rendered")
        return 2
    for c in changes:
        print(f"{'would render' if args.dry_run else 'rendered'}  {c}")
    if not changes:
        print(f"unchanged  {rel} already says what the board says")
    elif not args.dry_run:
        (repo / rel).write_text(new)
        print(f"wrote      {rel} — commit it on main; the doctor's check 16 reads main")

    # OPT-IN, and it has to be. `operator render` reads the board and nothing else;
    # the page gathers over the network (>2 min against NumeroTech, 2026-09-22).
    # Making it the default put that I/O into a command every chair runs every wake
    # and hung the existing tests, which is how it was caught. The chair's rendered
    # instruction passes --dashboard, so every installed org still gets its page.
    #
    # THE PAGE IS WRITTEN WHEN WHAT IT SAYS CHANGES. Every commit on an installed org's main can deploy (NumeroTech:
    # every one reaches Vercel production, no ignore rule, 2026-09-22), so a wake that only moved the clock must not
    # rewrite it. Until 0.38.0 the page was re-read only when the operator file changed — and a state fixed on the
    # board then stayed red on main for hours (org-core 2026-09-24). Now every `--dashboard` wake takes the reading and
    # writes it when its fingerprint (`dashboard.fingerprint`: tile states, findings, waiting items — never ages)
    # differs from the committed page's, or when the operator file changed, or the page is missing.
    # Broken looks like: a wake with nothing but ages between it and the last writing the page, or a changed tile
    # state leaving it as it was.
    if args.dashboard:
        extra = json.loads(Path(args.extra).read_text()) if getattr(args, "extra", None) else {}
        _render_dashboard(repo, manifest, packages, dry_run=args.dry_run, force=bool(changes), extra=extra)
    return 0


DASHBOARD_DEFAULT = "docs/human/dashboard.html"


def _render_dashboard(repo: Path, manifest: dict, packages: dict, dry_run: bool = False, force: bool = True,
                      extra: dict | None = None) -> bool:
    """The org's own page, written beside its operator file by the chair that already wakes.

    The operator file is the reading as text; this is the same reading as a page.
    It rides `org operator render` rather than a clock of its own for the reason
    rows 65 and 98 record: a surface the operator reads is rendered on `main` by
    the chair, never stamped from a role's PR, or it says `never ran` for roles
    that ran daily.

    BEST EFFORT, and deliberately so. `status` gathers over the network and took
    >2 min against NumeroTech on 2026-09-22; the operator file must not be lost to
    a slow or unreachable reading. A failure here prints and returns False, and
    `operator render` still exits 0 with the file written.

    Broken looks like: this raising out of `cmd_operator`, or the operator file
    going unwritten because the page could not be read.
    """
    rel = (manifest.get("org", {}).get("paths", {}) or {}).get("dashboard", DASHBOARD_DEFAULT)
    out = repo / rel
    if dry_run:
        print(f"would read    {rel}" + ("" if force or not out.exists() else " — written only if what it says changed"))
        return True
    try:
        import datetime as _dt

        from . import dashboard as dash
        from . import status as stx
        from . import tempo as tp

        now = _dt.datetime.now(_dt.timezone.utc)
        since = (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        extra = extra or {}
        facts = tp.gather(repo, manifest, since=since, now=now, triggers=extra.get("triggers"), sessions=extra.get("sessions"))
        st = stx.status(facts, now)
        if not force and out.exists():
            was = dash.page_fingerprint(out.read_text())
            if was == dash.fingerprint(st):
                print(f"unchanged  {rel} — the reading says what the committed page says ({was}); only the clock moved, so no commit")
                return True
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(dash.render_html(st, source="org operator render"))
        cov = st.get("coverage", {})
        print(f"wrote      {rel}  ({cov.get('measured', '?')} of {cov.get('tiles', '?')} tiles read) — commit it on main")
        return True
    except Exception as e:
        print(f"dashboard  not rendered: {type(e).__name__}: {e}")
        print(f"           {rel} is unchanged; the operator file above was written regardless")
        return False


def cmd_setup(args) -> int:
    """`org setup render|status|check` (SPEC §18): the suite install as one generated script, the report a session start
    wrote, and the probe of what this container has against what the tree vendors and pins."""
    from . import suite as su
    from .lock import read as read_lock

    repo = Path(args.repo).resolve()
    manifest, _ = _load(Path(args.manifest))
    if args.setup_cmd == "render":
        text, _ = su.render_setup(manifest)
        print(text, end="")
        return 0
    if args.setup_cmd == "status":
        report = su.read_report(Path(args.report) if args.report else None)
        if args.compact:
            # a reading, never an error: {"report": "absent"} says the setup never ran here, and a record carrying it is
            # distinguishable from one whose capture line failed (`{}`) — the two shapes check 21 tells apart (row 91)
            print(json.dumps(su.compact(report), ensure_ascii=False))
            return 0
        if args.json:
            print(json.dumps(report, indent=2, ensure_ascii=False) if report else "null")
        else:
            print(su.render_status(report))
        return 0 if report else 3
    rows = su.check(repo, manifest, lock=read_lock(repo), runtime=True)
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    else:
        print(su.render_check(rows))
    return 1 if any(r["ok"] is False for r in rows) else 0


def cmd_lessons(args) -> int:
    """`org lessons pull|digest` (SPEC §11): the fleet's inflow, pulled — what a repository wrote into its own ground truth
    since a watermark, with provenance and the section it landed in; and a reading of one or more pulls for the curator."""
    import datetime as _dt
    import yaml as _yaml
    from . import lessons as ls
    if args.lessons_cmd == "pull":
        repo = Path(args.repo).resolve()
        mpath = repo / (args.manifest or "org.yaml")
        manifest = _yaml.safe_load(mpath.read_text()) if mpath.exists() else None
        now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if getattr(args, "now", None) else None
        p = ls.pull(repo, manifest, since=args.since, now=now, max_lines=args.max_lines)
        out = Path(args.out) if args.out else repo / ".org" / "lessons" / f"pull-{p['pulled_at'][:10]}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(p, indent=1, ensure_ascii=False) + "\n")
        c = p["counts"]
        print(f"pulled     {out}  {p['org']}: {c['commits']} commit(s), {c['hunks']} hunk(s), {c['added_lines']} added line(s) since {p['since']}; sections {c['by_section']}")
        return 0
    if args.lessons_cmd == "seed":
        from .render import frame, parse_managed
        repo = Path(args.repo).resolve()
        mpath = repo / (args.manifest or "org.yaml")
        manifest = _yaml.safe_load(mpath.read_text()) if mpath.exists() else {}
        target = repo / ls.LESSONS_REL
        if not target.exists():
            print(f"no {ls.LESSONS_REL} — run `org apply`/`org upgrade` first; it renders the file")
            return 1
        managed = parse_managed(target.read_text())
        if managed is None:
            print(f"{ls.LESSONS_REL} is not a managed file")
            return 1
        names = {str(e.get("name")): r for r, e in (manifest.get("roles") or {}).items() if isinstance(e, dict) and e.get("name")}
        statuses = ls.load_statuses(Path(args.statuses)) if args.statuses else ls.load_statuses()
        rows = ls.rows_from_extraction(Path(args.extraction).read_text(), args.org or manifest.get("org", {}).get("id") or repo.name, args.date, statuses=statuses, names=names)
        project, n = ls.seed(managed.project, rows)
        target.write_text(frame(managed.frontmatter, managed.base, project, managed.role, managed.kind, managed.version))
        print(f"seeded     {target}  {n} new row(s) of {len(rows)} in the extraction; {sum(1 for r in rows if not r['status'].startswith('open'))} carry an answered status")
        return 0
    if args.lessons_cmd == "brief":
        digest_path = Path(args.digest)
        lines = digest_path.read_text().count("\n") if digest_path.exists() else 0
        text = ls.brief(args.org, digest_path=str(digest_path), digest_lines=lines, core_path=args.core, out_path=args.out_path, since=args.since or "the install", head=args.head or "HEAD")
        if args.out:
            Path(args.out).write_text(text)
            print(f"brief      {args.out}")
        else:
            print(text, end="")
        return 0
    if args.lessons_cmd == "ledger":
        pulls = [json.loads(Path(f).read_text()) for f in args.pulls]
        extractions = []
        for spec in args.extractions or []:
            org, _, path = spec.partition("=")
            extractions.append((org, Path(path).read_text()))
        text = ls.ledger_scaffold(pulls, extractions, args.date)
        if args.out:
            Path(args.out).write_text(text)
            print(f"ledger     {args.out}  (scaffold — the judgment is the curator's)")
        else:
            print(text, end="")
        return 0
    if args.lessons_cmd == "status":
        prefixes = {}
        for spec in args.prefix:
            letter, _, prefix = spec.partition("=")
            prefixes[letter] = prefix
        answers = ls.status_from_ledger(Path(args.ledger).read_text(), prefixes)
        out = Path(args.out) if args.out else Path(ls.__file__).with_name("lessons_status.json")
        current = ls.load_statuses(out) if out.exists() else {}
        current.update(answers)
        out.write_text(json.dumps(dict(sorted(current.items())), indent=1, ensure_ascii=False) + "\n")
        by = {}
        for v in answers.values():
            by[v["status"]] = by.get(v["status"], 0) + 1
        print(f"status     {out}  {len(answers)} row(s) answered from the ledger ({', '.join(f'{k} {n}' for k, n in sorted(by.items()))}); {len(current)} in the file")
        return 0
    pulls = [json.loads(Path(f).read_text()) for f in args.facts]
    text = ls.digest(pulls, min_added=args.min_added, skip_tags=tuple(args.skip_tags or ()), skip_sections=tuple(args.skip_sections or ()),
                     max_lines=args.max_lines, subjects_skip=tuple(args.skip_subject_prefix or ()))
    if args.out:
        Path(args.out).write_text(text)
        print(f"digest     {args.out}  {text.count(chr(10))} line(s)")
    else:
        print(text, end="")
    return 0


def cmd_tempo(args) -> int:
    """`org tempo gather|report|wake-now` (SPEC §13): the org's speed, measured from the board, the pull requests and the
    routines — and the roles a port holder should fire before their next cron tick."""
    import datetime as _dt
    import yaml as _yaml
    from . import actuator as ac
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if getattr(args, "now", None) else _dt.datetime.now(_dt.timezone.utc)
    if args.tempo_cmd == "gather":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        facts = tp.gather(repo, manifest, since=args.since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=now)
        out = Path(args.out) if args.out else repo / tp.FACTS_DIR / f"facts-{facts['gathered_at'][:10]}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(tp.for_commit(facts), indent=1, ensure_ascii=False) + "\n")
        print(f"gathered   {out}  board {len(facts['board'])} rows, prs {len(facts['prs'])}, runs {len(facts['runs'])}, triggers {len(facts['triggers'])}"
              + (f"  could not read: {'; '.join(facts['could_not_read'])}" if facts["could_not_read"] else ""))
        return 2 if facts["could_not_read"] else 0
    if args.tempo_cmd == "wake-now":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        since = args.since or (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        facts = tp.gather(repo, manifest, since=since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=now)
        rows = tp.wake_now(facts, now)
        if args.json:
            print(json.dumps({"wake_now": rows, "could_not_read": facts["could_not_read"]}, indent=2, ensure_ascii=False))
        else:
            for w in rows:
                print(f"{'FIRE' if w['fire'] else 'HOLD'} {w['role']:<16} {w['why']}" + (f" — trigger {w['trigger']}" if w.get("trigger") else " — no trigger seen (pass --facts with the triggers list)")
                      + (f" — its record says blocked: {w['blocked']}" if w.get("blocked") else ""))
                for e in w["events"][:5]:
                    print(f"     {e['event']:<16} {e['what']} waiting {e['waiting_hours']}h")
            if not rows:
                print("nothing past target")
            if facts["could_not_read"]:
                print("could not read: " + "; ".join(facts["could_not_read"]))
        return 2 if facts["could_not_read"] else 0
    if args.tempo_cmd == "triggers":
        dump = json.loads(Path(args.facts).read_text())
        # the port's own page is `{"data": [...], "has_more"}` (read 2026-09-25): before 0.44.0 only `{triggers: …}` was
        # unwrapped, so the tool's page published an empty list — every routine read as none
        rows = dump.get("ccr", dump) if isinstance(dump, dict) else dump
        rows = rows.get("triggers", rows) if isinstance(rows, dict) else rows
        if isinstance(rows, dict):
            rows = rows.get("data")
        compact = ac.compact_triggers(rows or [])
        key = ac.org_tempo(manifest)["triggers_key"]
        value = json.dumps({"at": now.isoformat(timespec="seconds"), "triggers": compact}, ensure_ascii=False)
        rc = _board_set(manifest, key, value, 604800)
        print(f"{key}: {len(compact)} triggers" + ("" if rc == 0 else " — WRITE FAILED"))
        return rc
    if args.tempo_cmd == "sessions":
        dump = json.loads(Path(args.facts).read_text())
        # the tool's page as the port returns it (`{"ccr": {"data", "has_more"}}`, read 2026-09-25), the page, or a list
        rows = dump.get("ccr", dump) if isinstance(dump, dict) else dump
        rows = rows.get("sessions") if isinstance(rows, dict) and "sessions" in rows else rows
        complete = tp._sessions_complete(rows)
        compact = ac.compact_sessions(tp._session_rows(rows))
        key = ac.org_tempo(manifest)["sessions_key"]
        value = json.dumps({"at": now.isoformat(timespec="seconds"), "complete": complete, "sessions": compact},
                           ensure_ascii=False)
        rc = _board_set(manifest, key, value, 172800)
        live = [c for c in compact if not str(c.get("session_status") or "").upper().endswith("ARCHIVED")]
        print(f"{key}: {len(live)} live session(s)" + (f", {len(compact) - len(live)} archived (id and status only)" if len(live) != len(compact) else "") + ("" if complete else ", not the whole list (has_more)")
              + ("" if rc == 0 else " — WRITE FAILED"))
        return rc
    if args.tempo_cmd == "wake":
        return _tempo_wake(args, repo, manifest, now, ac, tp)
    if args.tempo_cmd in ("register", "dm", "park-until", "next-fire"):
        return _tempo_listener(args, repo, manifest, now, ac, tp)
    files = [json.loads(Path(f).read_text()) for f in args.facts]
    facts = tp.merge_facts(files) if len(files) > 1 else files[0]
    rep = tp.report(facts, now)
    if args.json:
        print(json.dumps(rep, indent=2, ensure_ascii=False))
    else:
        print(tp.render(rep), end="")
    return 0


def _board_set(manifest, key: str, value: str, ttl: int) -> int:
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    # The value goes on stdin (`-`), never argv: one argument is capped at 131,072 bytes
    # (MAX_ARG_STRLEN) and a day's wake ledger outgrew it 2026-10-08 (switchboard 2.5.0, cmd_board).
    try:
        p = subprocess.run(["switchboard", "--json", "board", "set", key, "-", "--ttl", str(int(ttl))], input=value, capture_output=True, text=True, timeout=60, env=env)
    except subprocess.TimeoutExpired:
        print(f"board set {key} failed: timed out after 60 s")
        return 1
    except OSError as e:   # E2BIG on 0.55.1 (2026-10-14), a missing binary: say so and let the caller's next write run
        print(f"board set {key} failed: {e}")
        return 1
    if p.returncode != 0:
        print(f"board set {key} failed: {(p.stderr or p.stdout).strip()[:200]}")
    return 0 if p.returncode == 0 else 1


def _board_get_rev(manifest, key: str):
    """(value, revision) of a board key: revision 0 when it is absent — what `board set --if-revision 0` expects."""
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    p = subprocess.run(["switchboard", "--json", "board", "get", key], capture_output=True, text=True, timeout=60, env=env)
    text = (p.stdout or "").strip()
    if p.returncode != 0 or not text or text.startswith("no entry"):
        return None, 0
    try:
        got = json.loads(text)
    except json.JSONDecodeError:
        return None, 0
    v = got.get("value")
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            v = None
    return v, int(got.get("revision") or 0)


def _board_set_if(manifest, key: str, value: str, ttl: int, revision: int) -> int:
    """`board set --if-revision`: 0 written, 2 refused because the key moved since `revision` was read, 1 any other failure.
    Measured on switchboard 2.5.0 (2026-10-11): a stale revision exits 1 with `revision mismatch on '<hub key>': expected 1,
    found 2`; `--if-revision 0` writes only when the key is absent."""
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    p = subprocess.run(["switchboard", "--json", "board", "set", key, "-", "--ttl", str(int(ttl)), "--if-revision", str(int(revision))],
                       input=value, capture_output=True, text=True, timeout=60, env=env)
    if p.returncode == 0:
        return 0
    out = (p.stderr or p.stdout).strip()
    if "revision mismatch" in out:
        return 2
    print(f"board set {key} failed: {out[:200]}")
    return 1


def _board_list(manifest, prefix: str) -> list[dict]:
    """Every board row whose key starts with `prefix`, each `{key, value}` with its value parsed: `board list` carries the
    values (switchboard 2.5.0, read 2026-10-11), so this is one call, not one per key."""
    import os as _os
    co = manifest["ports"]["coordination"]
    env = {**_os.environ, "SWITCHBOARD_WORKSPACE": co["workspace"], **({"SWITCHBOARD_URL": co["url"]} if co.get("url") else {})}
    p = subprocess.run(["switchboard", "--json", "board", "list", "--prefix", prefix], capture_output=True, text=True, timeout=60, env=env)
    try:
        rows = json.loads(p.stdout or "[]")
    except json.JSONDecodeError:
        return []
    out = []
    for r in rows if isinstance(rows, list) else []:
        v = r.get("value")
        if isinstance(v, str):
            try:
                v = json.loads(v)
            except json.JSONDecodeError:
                v = None
        if str(r.get("key", "")).startswith(prefix) and isinstance(v, dict):
            out.append({"key": str(r["key"]), "value": v, "updated_at": r.get("updated_at")})
    return out


def _board_get(manifest, key: str):
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    p = subprocess.run(["switchboard", "--json", "board", "get", key], capture_output=True, text=True, timeout=60, env=env)
    text = (p.stdout or "").strip()
    if p.returncode != 0 or not text or text.startswith("no entry"):
        return None
    try:
        got = json.loads(text)
    except json.JSONDecodeError:
        return None
    v = got.get("value")
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            return None
    return v


def _switchboard(manifest, argv: list[str]):
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    return subprocess.run(["switchboard", "--json", *argv], capture_output=True, text=True, timeout=60, env=env)


def _local_cmdline(pid: int) -> str | None:
    """The command line of process `pid` in this container, "" when there is no such process, None when it cannot be read."""
    proc = Path(f"/proc/{pid}/cmdline")
    if Path("/proc/self").exists():
        try:
            return proc.read_bytes().replace(b"\0", b" ").decode(errors="replace").strip()
        except (FileNotFoundError, ProcessLookupError):
            return ""
        except OSError:
            return None
    try:
        p = subprocess.run(["ps", "-p", str(pid), "-o", "args="], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    return p.stdout.strip() if p.returncode == 0 else ""


#: how many predecessors a rotated session's registration names — a DM older than that many rotations is the floor's
ROTATION_LINEAGE_KEPT = 5
#: sessions of one spawned role `coord/tempo/agents` keeps side by side (each until its listen deadline passes)
SPAWNED_SLOTS_KEPT = 12
#: compare-and-set attempts `org tempo register` makes before it reports the registry as not written
REGISTER_CAS_ATTEMPTS = 5


def _rotation_lineage(manifest, role, aid, prev, now) -> list[str]:
    """The agents a persistent role's session took over, newest first: what `orphans` reads to let a rotated session's record
    answer a DM its predecessor was sent. A re-registration of the same agent keeps its lineage. A new agent extends it only
    when the predecessor's listener is still alive on the hub (its `listener/<id>` heartbeat, 90 s TTL, deadline ahead) —
    a session taking over a live one is a rotation; one registering after its predecessor's listener lapsed (the registrar,
    2026-10-08: a cron fire into a new session at 07:11Z, its predecessor unparked since before 02:24Z) is not. A spawned
    role is never a rotation: two builders run side by side and the second does not answer the first's DM."""
    from .tempo import _default, parse_ts
    if not prev or not prev.get("agent_id"):
        return []
    if prev["agent_id"] == aid:
        return list(prev.get("rotated_from") or [])
    runtime = (manifest["roles"].get(role) or {}).get("runtime") or _default(role, "runtime")
    if runtime != "session":
        return []
    beat = _board_get(manifest, f"listener/{prev['agent_id']}")
    until = parse_ts(beat.get("until")) if isinstance(beat, dict) else None
    if not isinstance(beat, dict) or (until is not None and until <= now):
        return []
    return ([prev["agent_id"]] + list(prev.get("rotated_from") or []))[:ROTATION_LINEAGE_KEPT]


def _listener_here(beat, now) -> tuple[bool | None, dict]:
    """(listener_alive, what was read) for `org tempo register`: True only when the `listener/<agent id>` heartbeat names a
    pid that is a running `switchboard listen` in this container and its park deadline is ahead; None when the heartbeat
    says one runs but this container's processes cannot be read (the skill parks one: only `true` stops it)."""
    from .tempo import parse_ts
    if not isinstance(beat, dict):
        return False, {"heartbeat": False, "why": "no listener/<agent id> heartbeat on the hub — nothing is parked"}
    pid, until = beat.get("pid"), beat.get("until")
    read = {"heartbeat": True, "pid": pid, "park_until": until}
    at = parse_ts(until)
    if at is not None and at <= now:
        return False, {**read, "why": f"the heartbeat's park deadline {until} has passed"}
    try:
        cmd = _local_cmdline(int(pid))
    except (TypeError, ValueError):
        return None, {**read, "why": "the heartbeat carries no pid — cannot tell whether its listener runs in this container"}
    if cmd is None:
        return None, {**read, "why": f"cannot read process {pid} in this container — listener unknown"}
    if "switchboard" in cmd and " listen" in cmd:
        return True, {**read, "here": True, "why": f"pid {pid} is `{cmd[:80]}` in this container"}
    return False, {**read, "here": False, "why": f"the heartbeat names pid {pid}, which is not a `switchboard listen` in this container "
                                                   "— a listener from another container (a restarted one, or a session sharing this agent id) "
                                                   "keeps it alive, and its exit wakes nothing here"}


def _tempo_listener(args, repo, manifest, now, ac, tp) -> int:
    """`org tempo register|dm|park-until|next-fire` — the persistent roles' half of tempo (SPEC §5, §13): a role registers
    its agent id so senders can address it, a sender DMs a receiver that is listening, and a role learns how long to park."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    cfg = ac.org_tempo(manifest)
    minutes = float(getattr(args, "listen_minutes", None) or cfg.get("listen_minutes") or tp.DEFAULT_LISTEN_MINUTES)
    if args.tempo_cmd == "park-until":
        if getattr(args, "timeout_ms", False):
            print(tp.listen_timeout_ms(minutes))     # the background `timeout` the listener needs (ruling 7: >= 6,300,000 for 105 min)
            return 0
        print((now + _dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat())
        return 0
    if args.tempo_cmd == "next-fire":
        entry = manifest["roles"].get(args.role) or {}
        cadence = entry.get("cadence") or tp._default(args.role, "cadence")
        nxt = tp.cron_next(str(cadence or ""), now)
        print(nxt.isoformat() if nxt else "none")
        return 0 if nxt else 2
    if args.tempo_cmd == "register":
        who = _switchboard(manifest, ["whoami"])
        try:
            me = json.loads(who.stdout or "{}")
        except json.JSONDecodeError:
            me = {}
        aid = me.get("agent_id")
        if not aid:
            print(f"register: switchboard whoami gave no agent_id: {(who.stderr or who.stdout).strip()[:200]}")
            return 1
        until = (now + _dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat()
        # one listener per session: the hub's `listener/<agent_id>` heartbeat (90 s TTL, refreshed every pass) says a listener
        # runs somewhere under this agent id — not that it runs HERE. Measured five times on the CEO's session after container
        # restarts (2026-09-24…09-28, switchboard 2.5.0): `listener_alive: true` while no `switchboard listen` ran in its
        # container. So the heartbeat's pid must be a live `switchboard listen` in this container, and its deadline ahead.
        alive, listener = _listener_here(_board_get(manifest, f"listener/{aid}"), now)
        # compare-and-set: two sessions registering within one read-write window (about a second) each read the registry
        # before either wrote, and the second write dropped the first's slot (Reed's note 1 on #194). Each write names the
        # revision it read; a refusal re-reads, re-merges this session's slot and tries again.
        runtime = (manifest["roles"].get(args.role) or {}).get("runtime") or tp._default(args.role, "runtime")
        own_slot = _board_get(manifest, tp.spawned_slot_key(args.role, aid)) if runtime == "spawned" else None
        own_slot = own_slot if isinstance(own_slot, dict) else None
        from .accounts import whoami
        me_env = whoami()     # the account and session this registration runs on (arc fleet-accounts-and-pools)
        for _attempt in range(REGISTER_CAS_ATTEMPTS):
            current, revision = _board_get_rev(manifest, tp.AGENTS_KEY)
            current = current or {}
            roles = current.get("roles") if isinstance(current, dict) else None
            roles = dict(roles or {})
            prev = roles.get(args.role) if isinstance(roles.get(args.role), dict) else {}
            roles[args.role] = {"agent_id": aid, "name": (manifest["roles"].get(args.role) or {}).get("name"), "session_id": getattr(args, "session_id", None) or me_env["session_id"] or prev.get("session_id"),
                                "registered_at": now.isoformat(timespec="seconds"), "listen_until": until, "workspace": me.get("workspace"), "listen_minutes": minutes,
                                "org_core": __version__, "claude_account": me_env["claude_account"]}
            lineage = _rotation_lineage(manifest, args.role, aid, prev, now)
            if lineage:
                roles[args.role]["rotated_from"] = lineage
            value = {"at": now.isoformat(timespec="seconds"), "roles": roles}
            spawned = current.get("spawned") if isinstance(current, dict) and isinstance(current.get("spawned"), dict) else {}
            if runtime == "spawned":
                # `roles` holds one slot per role: two builders spawned a second apart overwrote each other there (org-core
                # 2026-10-11, 15:22:23Z replaced at 15:22:29Z). A spawned role also keeps a slot per session, by agent id, with the
                # item and PRs it registered for — a re-registration adds to them — until its listen deadline passes.
                mine = {r: dict(e) for r, e in (spawned.get(args.role) or {}).items() if isinstance(e, dict)
                        and r != aid and (tp.parse_ts(e.get("listen_until")) or now) > now}
                # what this session named before: the map's slot, or its own slot key when an older package's write dropped the map
                was = (spawned.get(args.role) or {}).get(aid) or own_slot or {}
                entry = {k: v for k, v in roles[args.role].items() if k not in ("item", "prs")}
                item = getattr(args, "item", None) or (was.get("item") if isinstance(was, dict) else None)
                prs = sorted({int(n) for n in (was.get("prs") if isinstance(was, dict) else None) or []} | {int(n) for n in getattr(args, "pr", None) or []})
                if item:
                    entry["item"] = roles[args.role]["item"] = item
                if prs:
                    entry["prs"] = roles[args.role]["prs"] = prs
                mine[aid] = entry
                spawned = {**spawned, args.role: dict(sorted(mine.items(), key=lambda kv: str(kv[1].get("registered_at") or ""))[-SPAWNED_SLOTS_KEPT:])}
            if spawned:
                value["spawned"] = spawned
            rc = _board_set_if(manifest, tp.AGENTS_KEY, json.dumps(value, ensure_ascii=False), 604800, revision)
            if rc != 2:
                break
        if rc == 2:
            print(f"register: {tp.AGENTS_KEY} moved under every one of {REGISTER_CAS_ATTEMPTS} writes — not written")
            rc = 1
        slot_written = None
        if runtime == "spawned":
            # the session's own key as well, until its listen deadline: `register` before 0.60.31 rewrites the map's key as
            # `{at, roles}` and drops `spawned` (org-core 2026-10-11 19:39:02Z, a 0.37.1 checkout), and never touches this one
            slot = (value.get("spawned") or {}).get(args.role, {}).get(aid) or {k: v for k, v in roles[args.role].items() if k != "rotated_from"}
            slot_written = _board_set(manifest, tp.spawned_slot_key(args.role, aid), json.dumps(slot, ensure_ascii=False), max(60, int(minutes * 60))) == 0
            if not slot_written:
                rc = rc or 1
        print(json.dumps({"role": args.role, "agent_id": aid, "until": until, "listen_minutes": minutes, "written": rc == 0, "listener_alive": alive,
                          **({"slot_written": slot_written} if slot_written is not None else {}),
                          "listener": listener,
                          # persistent seats only (ruling 7, 2026-10-19/20): a spawned or fresh role is told not to park, whatever is running
                          "park": ("no — a listener is still running; it wakes you when it exits" if alive else
                                   f"yes — park one before you end: background timeout {tp.listen_timeout_ms(minutes)} ms, passed explicitly "
                                   f"(the runner's default {tp.RUNNER_BACKGROUND_DEFAULT_MS} ms kills it at 30 min)") if tp.parks_listener(runtime) else
                                  f"no — a {runtime or 'non-persistent'} role parks no listener (ruling 7): end when your record is written; a DM for it routes to the actuator",
                          **({"listen_timeout_ms": tp.listen_timeout_ms(minutes)} if tp.parks_listener(runtime) else {}),
                          # the gap `switchboard listen` leaves by exiting on the wake (2026-10-07, switchboard 2.5.0): named, with its bound
                          "gap": None if alive or not tp.parks_listener(runtime) else (
                              f"no listener runs while this session works: a DM waits until you re-park; the doctor reads this "
                              f"as mid-turn for {tp.PERSISTENT_MIDTURN_HOURS} h from now, then as not listening")}))
        return rc
    # dm — routed by the receiver's runtime (SPEC §5, rows 75 and 77)
    text = " ".join(args.text)
    how, target = tp.wake_route(args.role, manifest)
    if how == "clock":
        entry = manifest["roles"].get(args.role) or {}
        nxt = tp.cron_next(str(entry.get("cadence") or tp._default(args.role, "cadence") or ""), now)
        print(f"clock-only: {args.role} is woken by nothing on demand (on_demand none — the doctor, or a role this org opted out; "
              f"the CEO listens since 0.15.0, row 86); the board key is the handoff, read at its next fire" + (f" {nxt.isoformat()}" if nxt else " (no cron: a human-driven session)"))
        return 3
    registry = _board_get(manifest, tp.AGENTS_KEY) or {}
    reg = registry.get("roles") or {}
    if how == "route":
        # a spawned role listens after its one item like every role (SPEC row 178): when its own session is parked right now,
        # the DM goes to it. Only a parked one — a busy session reads a DM at its next turn, and a PR waiting behind it is
        # what a fresh spawn is for — otherwise the actuator spawns, as before (rows 75, 77).
        own = reg.get(args.role) or {}
        # addressed by subject (`--item`, `--pr`, or a `#<n>` in the text): the session registered for it, not the newest
        # registration — two builders run side by side, and since 0.60.29 only the session a DM reached answers it
        prs = list(getattr(args, "pr", None) or []) or tp.pr_numbers(text)
        slots = _board_list(manifest, f"{tp.SPAWNED_SLOT_PREFIX}{args.role}/")
        mine = tp.address(tp.spawned_registry([{"key": tp.AGENTS_KEY, "value": registry}, *slots]).get(args.role, []),
                          item=getattr(args, "item", None), prs=prs)
        if mine:
            own = mine
        own_aid = own.get("agent_id")
        if own_aid:
            beat = _board_get(manifest, f"listener/{own_aid}")
            until = tp.parse_ts((beat or {}).get("until")) if isinstance(beat, dict) else None
            if isinstance(beat, dict) and not beat.get("dnd") and (until is None or until > now):
                p = _switchboard(manifest, ["dm", own_aid, text])
                if p.returncode == 0:
                    print(f"delivered: {args.role} is parked as {own_aid} (listener live until {(beat or {}).get('until')}) — DMed directly, no spawn: {(p.stdout or '').strip()[:160]}")
                    return 0
        text = f"wake {args.role}: {text}"
    entry = reg.get(target) or {}
    aid = entry.get("agent_id")
    if not aid:
        print(f"absent: {target} never registered in {tp.AGENTS_KEY} — nothing to address; "
              + (f"{args.role} is spawned by {target}, whose cron is the floor" if how == "route" else "the board key waits for its cron"))
        return 1
    ag = _switchboard(manifest, ["agents"])
    try:
        present = tp.roster_ids(json.loads(ag.stdout or "[]"))
        roster_read = True
    except json.JSONDecodeError:
        present, roster_read = set(), False
    if roster_read and aid not in present:
        print(f"absent: {target} is registered as {aid} but not on the roster (listener parked until {entry.get('listen_until')}, registered {entry.get('registered_at')}) — not sent; "
              + (f"{target}'s cron is the floor for spawning {args.role}" if how == "route" else "the board key waits for its cron"))
        return 2
    p = _switchboard(manifest, ["dm", aid, text])
    if p.returncode != 0:
        print(f"dm to {target} ({aid}) failed: {(p.stderr or p.stdout).strip()[:200]}")
        return 2
    rt = (manifest["roles"].get(args.role) or {}).get("runtime") or tp._default(args.role, "runtime")
    acts = "fires its routine" if rt == "fresh" else "spawns it"     # a fresh role's routine is fired, a spawned role spawned (RUNTIME_ACT)
    head = (f"routed: {args.role} is {rt or 'spawned'} — DM to {target} ({aid}), whose wake {acts}" if how == "route" else f"delivered: {target} ({aid})")
    print(head + ("" if roster_read else " — roster unread, sent on the registry alone") + f": {(p.stdout or '').strip()[:160]}")
    return 0


def _tempo_wake(args, repo, manifest, now, ac, tp) -> int:
    """`org tempo wake plan|record` — the actuator's four-call wake (SPEC §13.1). `plan` gathers live and prints the acts;
    `record` writes the ledger row, the heartbeat and the lease from the plan and the port's answers."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    session = json.loads(Path(args.session_json).read_text()) if getattr(args, "session_json", None) else None
    if args.wake_cmd == "plan":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        triggers = extra.get("triggers") if isinstance(extra, dict) else None
        since = args.since or (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        facts = tp.gather(repo, manifest, since=since, triggers=triggers, sessions=extra.get("sessions") if isinstance(extra, dict) else None, now=now)
        if not triggers:   # the compact key the actuator wrote once a day
            key = ac.org_tempo(manifest)["triggers_key"]
            row = tp._latest_records(facts["board"]).get(key)
            v = tp._value(row) if row else {}
            if v.get("triggers"):
                facts["triggers"] = v["triggers"]
                facts["triggers_key_at"] = v.get("at")
        requests = tp.requests_from_inbox(json.loads(Path(args.inbox).read_text())) if getattr(args, "inbox", None) else []
        holder = json.loads(Path(args.holder_json).read_text()) if getattr(args, "holder_json", None) else None
        p = ac.plan(facts, manifest, now, session=session, requests=requests, holder=holder)
        if facts.get("triggers_key_at") and (tp.hours(facts["triggers_key_at"], now.isoformat()) or 0) > 26:
            p["could_not_read"].append(f"triggers key is {tp.hours(facts['triggers_key_at'], now.isoformat())}h old — refresh it (org tempo triggers)")
        out = Path(args.out) if args.out else repo / ".org" / "tempo" / "plan.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(p, indent=1, ensure_ascii=False) + "\n")
        print(ac.render_plan(p), end="")
        print(f"plan written to {out}")
        return p["exit_code"]
    plan = json.loads(Path(args.plan).read_text())
    results = json.loads(Path(args.results).read_text()) if args.results else []
    if isinstance(results, dict):
        results = results.get("results") or []
    cfg = ac.org_tempo(manifest)
    board = []
    try:
        board = tp.gather_board(manifest["ports"]["coordination"]["workspace"], prefixes=("coord/tempo/",))
    except (RuntimeError, OSError, json.JSONDecodeError) as e:
        print(f"could not read the board: {e}")
    previous = ac.heartbeat(board, cfg)
    rec = ac.record_wake(plan, results, now, session=session, previous=previous, manifest=manifest)
    existing = tp._latest_records(board).get(rec["ledger_key"])
    rows = (tp._value(existing).get("rows") if existing else None) or []
    rows = [r for r in rows if r.get("run_id") != rec["row"]["run_id"]] + [rec["row"]]
    held = ac.operator_queue(board, cfg)
    queue = ac.merge_queue(held, rec["queue_add"], now, current=rec.get("queue_current"))
    lz = ac.lease(board, cfg)
    taken_over = plan.get("lease_taken_over") and lz and ac._sid(lz.get("session_id")) == ac._sid(plan.get("lease_holder"))
    if lz and lz.get("session_id") and rec["lease"].get("session_id") and ac._sid(lz["session_id"]) != ac._sid(rec["lease"]["session_id"]) \
            and (tp.parse_ts(lz.get("until")) or now) > now and not taken_over:
        print(f"LEASE held by {lz['session_id']} until {lz.get('until')} — recording the row, not taking the lease")
        rec["lease"] = None
    if args.dry_run:
        print(json.dumps({k: rec[k] for k in ("row", "heartbeat", "lease", "queue_add")}, indent=1, ensure_ascii=False))
    else:
        # The heartbeat first: a lapsed one reads as "the actuator died", a worse message than "the ledger write failed" (2026-10-14).
        rc = _board_set(manifest, rec["heartbeat_key"], json.dumps(rec["heartbeat"], ensure_ascii=False), rec["ttl_seconds"])
        rc |= _board_set(manifest, rec["ledger_key"], json.dumps({"date": rec["ledger_key"].rsplit("-", 3)[-3:], "rows": rows}, ensure_ascii=False), 604800)
        if rec["lease"]:
            rc |= _board_set(manifest, rec["lease_key"], json.dumps(rec["lease"], ensure_ascii=False), rec["ttl_seconds"])
        if rec["queue_add"] or len(queue) != len(held):
            rc |= _board_set(manifest, rec["operator_queue_key"], json.dumps({"at": now.isoformat(timespec="seconds"), "items": queue[-50:]}, ensure_ascii=False), 604800)
        if rc:
            return 1
    print("fired: " + json.dumps(rec["fired"], ensure_ascii=False))
    for pr in rec["problems"]:
        print(f"problem: {pr}")
    return 2 if rec["problems"] else 0


def cmd_fidelity(args) -> int:
    """Measure and record how far a repo's existing role files are from the packages (SPEC §6, the fidelity test)."""
    repo, manifest, packages, plan = _plan(args)
    try:
        head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        head = None
    record = {
        "at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "org_core": __version__,
        "org": manifest["org"]["id"],
        "repo_head": head,
        "worst": plan.worst,
        "by_status": plan.by_status(),
        "files": [{"path": a.path, "status": a.status, "diff_lines": a.diff_lines, "detail": a.detail} for a in plan.actions],
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(record, indent=2) + "\n")
    print(f"worst={plan.worst}  " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v) + f"  -> {out}")
    for a in plan.actions:
        if a.status not in ("markers-only", "unchanged"):
            print(f"  {a.status:<13} {a.path}  {a.diff_lines} diff lines  {a.detail}")
            if args.diff and a.diff:
                print(a.diff)
    return 0 if not any(a.status in ("changed", "undeclared", "error") for a in plan.actions) else 1


def cmd_init(args) -> int:
    repo = Path(args.repo).resolve()
    d = detect(repo)
    print(json.dumps(d, indent=2))
    if args.write:
        m = draft_manifest(repo, d, defaults_by_role(discover()))
        target = repo / "org.yaml"
        if target.exists() and not args.force:
            print(f"\n{target} exists; not overwriting (use --force)")
            return 1
        target.write_text(dump_manifest(m))
        print(f"\nwrote draft manifest {target} — every <...> is a value the tool would not guess")
    return 0


def cmd_install(args) -> int:
    """One command for a first install. Run it again after each thing it asks for.

    It is the same four commands an operator ran by hand — `init`, `validate`,
    `apply`, `verify` — with the step nobody was doing put back: reading the
    draft's `<...>` values before rendering them into role files.

    Three outcomes, and the exit code says which:
      0  installed, and `verify` is clean enough to hand over
      2  your turn — the manifest is missing or unfinished; it says what to fill
      1  the install itself failed, or `verify` found something broken

    Idempotent: on an installed repo `apply` writes nothing and this re-verifies.
    """
    repo = Path(args.repo).resolve()
    mpath = Path(args.manifest) if args.manifest else repo / "org.yaml"

    # Said here rather than left to a FileNotFoundError three calls down. Measured
    # 2026-09-22: a mistyped --repo ran `detect`, printed the whole detection JSON,
    # then exited 1 with "missing: .../org.yaml" — which names the wrong thing.
    if not repo.is_dir():
        print(f"no such directory: {repo}")
        print("\nNEXT: point --repo at the checkout you want the org installed into.")
        return 1

    if not mpath.exists():
        print(f"no manifest at {mpath} — writing the draft\n")
        rc = cmd_init(argparse.Namespace(repo=str(repo), write=True, force=False))
        if rc:
            return rc
        if not (repo / ".git").exists():
            print(f"\nnote  {repo} is not a git repository. `apply` will still write, but"
                  "\n      `verify`'s `tracked` step reads git to tell a committed install"
                  "\n      from one that exists only in this container.")
        print("\nNEXT: fill every <...> in org.yaml, then run this same command again.")
        return 2

    import yaml as _yaml

    # A syntax error in the file a person was just told to edit is the most likely
    # failure at this point, and a YAML traceback is not an answer to it.
    try:
        data = _yaml.safe_load(mpath.read_text()) or {}
    except _yaml.YAMLError as e:
        print(f"{mpath} is not valid YAML:\n")
        print("  " + str(e).replace("\n", "\n  "))
        print("\nNEXT: fix the syntax, then run this same command again.")
        return 2
    if not isinstance(data, dict):
        print(f"{mpath} is valid YAML but not a mapping — it parsed as {type(data).__name__}.")
        print("\nNEXT: `org init --repo . --write --force` rewrites the draft if you want to start over.")
        return 2
    problems = validate(data)
    if problems:
        print(f"{mpath} is not ready to install:\n")
        for p_ in problems:
            print(f"  {p_}")
        print("\nNEXT: fix those, then run this same command again.")
        return 2

    # Worth saying, never fatal: these are real but nothing renders them, and both
    # shipped orgs carry them (measured 2026-09-22).
    for u in unfilled(data):
        print(f"note  {u}")

    print(f"\n=== apply {repo} ===")
    rc = main(["apply", "--repo", str(repo), "--manifest", str(mpath)])
    if rc:
        return rc

    print("\n=== verify ===")
    manifest_data, packages = _load(mpath)
    steps = run_verify(repo, manifest_data, packages, {}, drill=None)
    print(verify_text(steps))
    rc = verify_exit(steps)

    # A first install CANNOT be verify-clean, and saying "8 bad" without saying why
    # reads as eight things broken. Two of the classes are the install's own next
    # steps rather than faults: `tracked` is red until somebody commits, and
    # `records-ever` is red until each role has run once. Measured 2026-09-22 on a
    # clean rehearsal: 8 bad, and all 8 were those two.
    bad = [s for s in steps if s.status in ("FAIL", "UNREACHABLE")]
    first = ("tracked", "records-ever", "connector")
    expected = [s for s in bad if s.id in first]
    other = [s for s in bad if s.id not in first]

    print("\nThe files are in. What is left has no API and so no command:")
    if any(s.id == "tracked" for s in expected):
        print("  1. commit them — `tracked` is red until git carries the managed files,\n"
              "     because a fresh container gets the install from git, not from here")
    print("  2. attach the repo to each role's routine and start the persistent sessions;\n"
          "     `org routine <role> --manifest org.yaml` prints what each one needs")
    print("  3. re-run this command — `records-ever` goes green as each role fires once.\n"
          "     Every manual step has a verification `org verify` runs; it refuses to pass\n"
          "     one by assertion (SPEC §6).")
    if any(s.id == "connector" for s in expected):
        print("  4. the operator grants each outward role's connector on the operator's own account;\n"
              "     `org plan` lists them, and `connector` is red until a session records each read\n"
              "     (a draft created and deleted for mail — never a message to a person)")

    if other:
        print(f"\n{len(other)} step(s) need looking at beyond those — they are not part of the normal first install:")
        for s in other:
            print(f"  {s.status:<12} {s.id}")
    elif rc:
        print(f"\nverify is {len(expected)} bad, and all of it is the list above — nothing unexpected.")
    return rc


def cmd_doctor(args) -> int:
    manifest, _ = _load(Path(args.manifest))
    facts = json.loads(Path(args.facts).read_text()) if args.facts else {}
    ctx = Ctx(repo=Path(args.repo).resolve(), manifest=manifest, facts=facts)
    if args.drill:
        if args.drill not in manifest["roles"]:
            print(f"no such role: {args.drill}")
            return 1
        ctx.drill_absent = {ctx.report_key(args.drill)}
    only = {int(n) for n in args.only.split(",")} if args.only else None
    results = run(ctx, only)
    if args.json:
        print(json.dumps(to_json(results, ctx), indent=2))
    else:
        print(render_text(results))
    return exit_code(results)


def cmd_record(args) -> int:
    rec = json.loads(Path(args.file).read_text())
    counts_schema = None
    if isinstance(rec, dict) and rec.get("role"):
        pkg = discover().get(rec["role"])
        counts_schema = pkg.record_schema if pkg else None
    problems = validate_record(rec, counts_schema)
    if problems:
        print("\n".join(problems))
        return 1
    print("ok")
    return 0


def cmd_routine(args) -> int:
    manifest, packages = _load(Path(args.manifest))
    try:
        sp = routine_spec(manifest, packages, args.role)
    except (ValueError, KeyError) as e:
        print(str(e))
        return 1
    print(json.dumps(sp, indent=2) if args.json else routine_text(sp))
    return 0


def cmd_verify(args) -> int:
    manifest, packages = _load(Path(args.manifest))
    facts = json.loads(Path(args.facts).read_text()) if args.facts else {}
    steps = run_verify(Path(args.repo).resolve(), manifest, packages, facts, drill=None if args.no_drill else args.drill)
    if args.json:
        print(json.dumps({"summary": verify_summary(steps), "steps": [s.__dict__ for s in steps]}, indent=2))
    else:
        print(verify_text(steps))
    return verify_exit(steps)


def cmd_record_from_doctor(args) -> int:
    import yaml as _yaml
    from .lock import read as read_lock

    report = json.loads(Path(args.report).read_text())
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text())
    lock = read_lock(repo) or {}
    role_version = ((lock.get("files") or {}).get(".claude/skills/doctor/SKILL.md") or {}).get("template_version")
    try:
        sha = subprocess.run(["git", "-C", str(repo), "rev-parse", "--short", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        sha = None
    from . import suite as su
    rec = from_doctor(report, org=manifest["org"]["id"], name=manifest["roles"]["doctor"]["name"], runtime=args.runtime,
                      session_id=args.session_id, manifest_version=manifest.get("manifest_version"), role_version=role_version,
                      git_sha=sha, pr=args.pr, next_due=args.next_due, suite=su.compact(su.read_report()))
    problems = validate_record(rec, discover()["doctor"].record_schema)
    if problems:
        print("\n".join(problems))
        return 1
    print(json.dumps(rec))
    return 0


def _tickets_rows(args, repo: Path, port: dict, manifest: dict | None = None) -> tuple[list[dict], list[dict], bool]:
    """(tickets, items, complete) from the chosen source. `file` is the executor pattern: a role ran the SQL through
    the org's read port and saved the rows; `psql` and `api` read live, never write."""
    from .tickets import adapters as ad

    manifest = manifest or {}

    def _rel(p):   # a role runs from anywhere with --repo: relative paths are the repo's unless they exist here
        q = Path(p)
        return q if q.is_absolute() or q.exists() else repo / q

    items_path = _rel(args.items) if args.items else repo / "roadmap" / "items"
    source = args.source or ("file" if args.tickets else ("api" if args.url else ("psql" if args.dsn_env else "file")))
    if source == "file":
        if not args.tickets:
            raise SystemExit("--tickets <rows.json> is required with --source file (run `org tickets sql` and save what the read port returns)")
        tickets = ad.load_tickets_json(_rel(args.tickets))
        if args.notes:
            ad.attach_notes(tickets, ad.load_notes_json(_rel(args.notes)))
        items = ad.load_items(items_path)
        return tickets, items, bool(args.assume_complete)
    if source == "psql":
        dsn = ad.token_from_env(args.dsn_env or port.get("dsn_env") or "TICKETS_DSN")
        sql = ad.sql_for(args.dialect)
        tickets = ad.psql_rows(dsn, sql["tickets"])
        ad.attach_notes(tickets, ad.psql_rows(dsn, sql["notes"]))
        return tickets, ad.load_items(items_path), True
    if source == "api":
        base = args.url or port.get("api")
        if not base:
            raise SystemExit("--url (or ports.tickets.api) is required with --source api")
        token_file = port.get("token_file") or ((manifest.get("ports") or {}).get("prod_read") or {}).get("jwt_cache")
        token = ad.token_from_env(args.token_env or port.get("token_env") or "LUCILLE_ADMIN_JWT", token_file)
        if getattr(args, "id", None):   # stage: one ticket, with its notes, as the reference script does
            tid = args.id.strip().lower()
            tickets, complete = ad.api_tickets(base, token)
            for t in tickets:
                if str(t.get("id") or "").lower() == tid:
                    try:
                        t["notes"] = ad.api_notes(base, token, tid)
                    except Exception:  # noqa: BLE001 — notes are context, never the answer
                        t["notes"] = []
        else:
            tickets, complete = ad.api_tickets(base, token)
        if args.items:
            items = ad.load_items(items_path)
        else:
            r_url, r_tok, r_tenant = ad.roadmap_store(base, token)
            items = ad.api_items(r_url, r_tok, tenant=r_tenant)
        return tickets, items, complete
    raise SystemExit(f"unknown source {source!r}")


def cmd_tickets(args) -> int:
    """The tickets port (SPEC §17): the lifecycle over an org's own store, plus the github-issues intake helpers."""
    import datetime as _dt

    import yaml as _yaml

    from . import tickets as tk
    from .tickets import adapters as ad
    from .tickets import core as tc

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text()) if (repo / "org.yaml").exists() else {}
    port = (manifest.get("ports") or {}).get("tickets") or {}
    people = port.get("person_sources") or sorted(tc.DEFAULT_PERSON_SOURCES)
    cmd = args.tickets_cmd
    if cmd == "sql":
        sql = ad.sql_for(args.dialect)
        print(f"-- tickets ({args.dialect}); run through the org's read port, save the rows as JSON, pass --tickets\n{sql['tickets']};\n-- notes; pass --notes\n{sql['notes']};")
        return 0
    if cmd in ("stage", "open-loops", "report", "impact"):
        try:
            tickets, items, complete = _tickets_rows(args, repo, port, manifest)
        except (RuntimeError, OSError, ValueError) as e:   # no credential, no rows file, bad JSON: the reason, not a traceback
            print(f"org tickets {cmd}: {e}", file=sys.stderr)
            return 2
        now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)
        index = tc.index_by_ticket(items)
        if cmd == "stage":
            wanted = args.id.strip().lower()
            match = [t for t in tickets if str(t.get("id") or "").lower() == wanted]
            if not match:
                print(f"no ticket {args.id}")
                return 1
            t = tc.normalize_ticket(match[0]); linked = index.get(wanted, []); stage = tc.stage_of(t, linked)
            print(json.dumps({"ticket": t, "items": linked, "stage": stage}, default=str, indent=2) if args.json else tc.render_stage(t, linked, stage, people))
            return 0
        findings = tc.find_open_loops(tickets, index, now=now, person_sources=people)
        if cmd == "open-loops":
            if complete:
                findings += tc.dangling_links(index, [t.get("id") for t in tickets])
            else:
                print("note: read is not known-complete — skipping dangling_link (pass --assume-complete for a full dump)", file=sys.stderr)
            if args.json:
                print(json.dumps(findings, default=str, indent=2))
            else:
                print(tc.render_findings(findings))
                blockers = tc.prune_blockers(index, tickets)
                if blockers:
                    print("Do not prune yet — these done items still carry an open loop:")
                    for key in blockers:
                        print(f"  {key}")
            return 2 if findings else 0
        if cmd == "report":
            today = now.date().isoformat()
            text = tc.report_text(tickets, items, findings, today)
            if args.write:
                out = repo / (port.get("reports_dir") or "docs/operations/ticket-reports") / f"{today}-pipeline.md"
                out.parent.mkdir(parents=True, exist_ok=True); out.write_text(text); print(f"wrote {out.relative_to(repo)}")
            else:
                print(text)
            return 0
        if cmd == "impact":
            by_key = {tc.item_key(i): i for i in items}
            item = by_key.get(args.key)
            if item is None:
                print(f"no item {args.key}")
                return 1
            r = tc.impact(item, tickets)
            if args.json:
                print(json.dumps(r, default=str, indent=2))
            else:
                print(f"{r['item']}: done_at={r['done_at'] or '—'} done_version={r['done_version'] or '—'} — {len(r['tickets'])} linked, {r['recurred']} after, {len(r['missing'])} missing")
                for row in r["tickets"]:
                    print(f"  {row['verdict']:7s} {row['ticket']} [{row['source'] or '?'}] {row['status']} filed {row['created_at']} on {row['deployed_version'] or '—'}")
                for m in r["missing"]:
                    print(f"  missing {m} — linked by the item, not in the rows")
            return 2 if r["recurred"] else 0
    if port.get("tool") != "github-issues":
        print(f"tickets port is `{port.get('tool', 'absent')}` — `org tickets` only serves github-issues orgs")
        return 1
    gh_repo = (manifest.get("org") or {}).get("repo")
    if not gh_repo:
        print("org.repo missing from org.yaml")
        return 1
    wanted = tk.wanted_labels(port)
    tpl = port.get("template")
    try:
        existing = tk.gh_labels(gh_repo)
    except Exception as e:  # noqa: BLE001 — the reason is the output
        print(f"cannot list labels in {gh_repo}: {e}")
        return 2
    missing = tk.label_plan(existing, wanted)
    tpl_state = "not declared" if not tpl else ("present" if (repo / tpl).exists() else "MISSING")
    print(f"labels wanted {len(wanted)}, present {len(wanted) - len(missing)}, missing {len(missing)}" + (": " + ", ".join(missing) if missing else ""))
    print(f"issue form: {tpl_state}" + (f" ({tpl})" if tpl else ""))
    if args.tickets_cmd == "status":
        return 0 if not missing and tpl_state != "MISSING" else 1
    if args.dry_run:
        print("dry run — nothing created")
        return 0
    for line in tk.ensure_labels(gh_repo, wanted):
        print(f"label      {line}")
    if tpl and tk.write_template(repo, tpl, wanted[0]):
        print(f"wrote      {tpl}")
    return 0


def cmd_checks(args) -> int:
    import datetime as _dt

    import yaml as _yaml

    from . import checks as ck

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text()) if (repo / "org.yaml").exists() else {}
    port = (manifest.get("ports") or {}).get("checks") or {}
    registry = repo / (args.registry or port.get("registry") or ck.DEFAULT_REGISTRY)
    ledger_path = repo / (args.ledger or port.get("ledger") or ck.DEFAULT_LEDGER)
    results_path = repo / (args.results or port.get("results") or ck.DEFAULT_RESULTS)
    today = _dt.date.fromisoformat(args.today) if args.today else _dt.datetime.now(_dt.timezone.utc).date()
    try:
        checks = ck.load_registry(registry)
    except ck.RegistryError as e:
        print(str(e))
        return 1

    def _print_results(results):
        for r in results:
            extra = ("  " + ", ".join(f"{k}={v}" for k, v in r.detail.items())) if r.detail else ""
            err = f"  error: {r.error}" if r.error else ""
            esc = "  ESCALATED" if r.escalated else ""
            print(f"{r.state:<13} {r.check.id}{extra}{err}{esc}")
        bad = sum(1 for r in results if r.state in (ck.FAIL, ck.ERROR))
        print(f"\n{len(results)} checks: " + ", ".join(f"{s}={sum(1 for r in results if r.state == s)}" for s in (ck.PASS, ck.FAIL, ck.INCONCLUSIVE, ck.ERROR, ck.PENDING, ck.EXPIRED)))
        return bad

    if args.checks_cmd == "validate":
        try:
            problems = ck.ledger_problems(checks, ck.load_ledger(ledger_path))
        except ck.RegistryError as e:
            problems = [str(e)]
        if problems:
            print("\n".join(problems))
            return 1
        print(f"ok — {len(checks)} checks, ledger consistent")
        return 0
    if args.checks_cmd == "plan":
        rows = ck.plan(checks, today)
        if args.json:
            print(json.dumps(rows, indent=2))
        else:
            for r in rows:
                print(f"{r['state']:<8} {r['id']}  ({r['check_after']} → {r['until']}, {r['severity']})")
            print(f"\n{sum(1 for r in rows if r['state'] == 'due')} due today ({today.isoformat()})")
        return 0
    if args.checks_cmd in ("evaluate", "record", "run"):
        if args.checks_cmd == "run":
            if args.executor != "psql":
                print("run supports --executor psql only; for supabase-mcp or manual, use plan → (run the SQL) → record --rows")
                return 2
            dsn = os.environ.get(args.dsn_env or port.get("dsn_env") or "CHECKS_DSN")
            if not dsn:
                print(f"no DSN: set {args.dsn_env or port.get('dsn_env') or 'CHECKS_DSN'}")
                return 2
            try:
                rows = ck.run_psql(checks, today, dsn)
            except RuntimeError as e:
                print(str(e))
                return 2
        else:
            rows = json.loads(Path(args.rows).read_text())
        results = ck.evaluate_all(checks, rows, today)
        bad = _print_results(results)
        if args.checks_cmd == "evaluate":
            return 1 if bad else 0
        n = ck.append_results(results_path, results, today)
        print(f"appended {n} lines to {results_path.relative_to(repo)}")
        if args.file_issues:
            slug = (manifest.get("org") or {}).get("repo")
            label = ((manifest.get("ports") or {}).get("tickets") or {}).get("label", "ticket")
            if not slug:
                print("--file-issues needs org.repo in org.yaml")
                return 1
            try:
                open_issues = [] if args.dry_run and args.no_gh else ck.gh_open_issues(slug, label)
            except RuntimeError as e:
                print(f"issues: {e}")
                return 1
            actions = ck.issue_actions(results, open_issues, _dt.datetime.now(_dt.timezone.utc), slug, label)
            if args.dry_run:
                for a in actions:
                    print("would " + json.dumps({k: v for k, v in a.items() if k != "body"}))
            else:
                for line in ck.gh_apply(slug, actions):
                    print(line)
        return 1 if bad else 0
    if args.checks_cmd == "report":
        rep = ck.report(checks, ck.read_results(results_path), today, repo / "roadmap" / "items")
        if args.json:
            print(json.dumps(rep, indent=2))
        else:
            c = rep["counts"]
            print(f"{rep['date']}: {rep['checked']} checks — pass {c['pass']}, fail {c['fail']} (high {rep['high']}), inconclusive {c['inconclusive']}, error {c['error']}, pending {c['pending']}, expired {c['expired']}, never run {len(rep['never_run'])}")
            if rep["oldest_failure"]:
                print(f"oldest failure: {rep['oldest_failure']['id']} red {rep['oldest_failure']['days']}d")
            for k in ("failures_without_item", "vacuous_unflagged", "expiring_within_7d", "expired_while_red", "worsening", "never_run"):
                for line in rep[k]:
                    print(f"{k}: {line}")
        return 0
    return 2


def _proxy_secret(args) -> str:
    """`--proxy-secret-env NAME`: the proxy's secret, read from the environment, never from argv (where any local user
    reads it in /proc). A name given with nothing in it is an error, not an open server."""
    name = getattr(args, "proxy_secret_env", None)
    if not name:
        return ""
    val = os.environ.get(name, "")
    if len(val) < 16:
        raise SystemExit(f"org: --proxy-secret-env {name}: the variable is empty or shorter than 16 characters")
    return val


def _agent_token(args) -> str:
    """`--agent-token-env NAME`: the agents' read-only bearer token, from the environment like the proxy secret. A name given with
    nothing (or a short thing) in it is an error, not a server any agent can read; it may not be the proxy's own secret."""
    name = getattr(args, "agent_token_env", None)
    if not name:
        return ""
    val = os.environ.get(name, "")
    if len(val) < 32:
        raise SystemExit(f"org: --agent-token-env {name}: the variable is empty or shorter than 32 characters")
    if val == _proxy_secret(args):
        raise SystemExit(f"org: --agent-token-env {name}: it is the proxy's secret — an agent's token is its own, revocable alone")
    return val


def _agent_rate(args) -> int:
    """`--agent-rate N`: reads a minute the agent token may make (default `serve.AGENT_RATE_PER_MIN`). Never zero or negative:
    there is no way to turn the limit off from the command line."""
    from . import serve as srv
    n = getattr(args, "agent_rate", None)
    n = srv.AGENT_RATE_PER_MIN if n is None else n
    if n < 1:
        raise SystemExit("org: --agent-rate: at least 1 a minute (there is no 'off')")
    return n


def _home(home: str | None):
    """`tempo.store_home` inside a fleet reading (the reader thread's own context), nothing outside one."""
    import contextlib as _cl

    from . import tempo as tp
    return tp.store_home(home) if home is not None else _cl.nullcontext()


def _live_org_reader(repo: Path, manifest: dict, *, days: float, interval: float, fast: float,
                     extra: dict | None = None, source: str = "org status --serve", org_id: str | None = None,
                     home: str | None = None):
    """One org, read live and served (0.42.0): the full read on `interval`, the fast lane on `fast`, and the operator's
    asks recorded on that org's board and relayed to that org's CEO. `org status --serve` serves one; `org command
    --serve` serves one per org in the fleet, each under `/o/<id>/`."""
    import datetime as _dt

    from . import asks as ak
    from . import knobs as kn
    from . import serve as srv
    from . import status as stx
    from . import tempo as tp
    from .clock import for_operator
    extra = extra or {}
    last: dict = {}

    # GH_TOKEN_<ORG ID>, else the process's GH_TOKEN (0.42.2); the id is the fleet registry's when there is one
    token = tp.org_token(org_id or manifest["org"]["id"])

    def read(at) -> dict:
        since = (at - _dt.timedelta(days=float(days))).strftime("%Y-%m-%dT00:00:00Z")
        with tp.gh_token(token), _home(home):
            last["facts"] = tp.gather(repo, manifest, since=since, triggers=extra.get("triggers"),
                                      sessions=extra.get("sessions"), now=at, prior=last.get("facts"))
        st = stx.status(last["facts"], at)
        last["presence"] = (st.get("subjects") or {}).get("presence")
        return st

    def read_fast(at) -> dict:
        if not last.get("facts"):
            raise RuntimeError("no full reading yet to refresh")
        with tp.gh_token(token), _home(home):
            last["facts"] = tp.refresh_fast(repo, manifest, last["facts"], now=at)
        st = stx.status(last["facts"], at)
        last["presence"] = (st.get("subjects") or {}).get("presence")
        return st

    def on_ask(raw) -> dict:
        """Checked, recorded on this org's board, relayed to this org's CEO as a plain DM — a sleeping CEO wakes, a busy
        one reads it at its next look."""
        ask = ak.validate(raw)
        ask["via"] = "the served page"
        knob = kn.apply_ask(ask, manifest, tp._run) if ask["kind"] == "knob" else None
        ak.record(ask, manifest, tp._run)
        local = for_operator(_dt.datetime.now(_dt.timezone.utc), (manifest.get("org", {}).get("operator") or {}).get("timezone"))
        got = ak.relay(ask, manifest, last.get("presence"), tp._run, local=local)
        return {"ask": ask, **got, **({"said": f"{knob}; {got['said']}", "knob": knob} if knob else {})}

    return srv.Reader(read, interval=interval, take_fast=read_fast if fast > 0 else None, on_ask=on_ask,
                      fast_interval=fast, poll_ms=max(1000, int((fast if fast > 0 else interval) * 1000 / 4)),
                      source=f"{source}, re-read every {interval:g}s" + (f", claims and pull requests every {fast:g}s" if fast > 0 else ""))


def cmd_command(args) -> int:
    """`org command` (SPEC §9, §11): the fleet as one console, for the person it waits on. One reading per
    org in the registry; an org that could not be read is a row saying so, never a row left out."""
    import datetime as _dt

    import yaml as _yaml

    from . import command as cm
    from . import fleet as fl
    from . import status as stx
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)
    since = (now - _dt.timedelta(days=float(args.days))).strftime("%Y-%m-%dT00:00:00Z")
    registry = fl.load_registry(Path(args.registry) if args.registry else repo / "fleet" / "orgs.yaml")
    extra = json.loads(Path(args.extra).read_text()) if getattr(args, "extra", None) else {}
    # whose unsuffixed store credential this process holds: the `--repo` org's alone (0.44.2) — "" when it has no
    # manifest, so no org in the fleet gets it
    try:
        home = str(((_yaml.safe_load((repo / "org.yaml").read_text()) or {}).get("org") or {}).get("id") or "")
    except (OSError, ValueError):
        home = ""
    if args.serve:
        # every org the operator commands, served live on one port (0.42.0): `/` the console, `/o/<id>/` each org's
        # own page with its controls. An org this machine has no checkout of is a row saying so, never left out.
        from . import serve as srv
        members = []
        for entry in registry:
            mf = Path(entry.get("checkout") or "") / "org.yaml"
            if not entry.get("checkout") or not mf.is_file():
                members.append({"org": entry, "reader": None,
                                "why": f"no checkout at {entry.get('checkout') or '<none declared>'} — this machine cannot read it"})
                continue
            try:
                manifest = _yaml.safe_load(mf.read_text())
            except (OSError, ValueError) as e:
                members.append({"org": entry, "reader": None, "why": f"its org.yaml does not parse ({e})"})
                continue
            org = {**entry, **(manifest.get("org") or {}), "id": entry["id"]}
            members.append({"org": org, "reader": _live_org_reader(
                Path(entry["checkout"]).resolve(), manifest, days=float(args.days), interval=float(args.interval),
                fast=float(args.fast_interval), extra=extra, source=f"org command --serve ({entry['id']})", org_id=entry["id"],
                home=home)})
        fleet = srv.Fleet(members, poll_ms=max(1000, int(float(args.fast_interval or args.interval) * 1000 / 4)),
                          note=args.sample_note, feedback_to=args.feedback_to or None)
        names = ", ".join(str(m["org"]["id"]) + ("" if m["reader"] else " (not read)") for m in members)
        srv.serve(fleet, host=args.host, port=int(args.port), allow_hosts=tuple(args.allow_host or ()), proxy_secret=_proxy_secret(args), agent_token=_agent_token(args), agent_rate=_agent_rate(args),
                  ready=lambda url: print(f"commanding {url}  — {names}; each org at {url}o/<id>/. Ctrl-C to stop."))
        return 0
    orgs = []
    for entry in registry:
        checkout = Path(entry.get("checkout") or "")
        mf = checkout / "org.yaml"
        if not mf.is_file():
            orgs.append({"org": entry, "status": None,
                         "why": f"no checkout at {checkout or '<none declared>'} — this session cannot read it"})
            continue
        try:
            manifest = _yaml.safe_load(mf.read_text())
            with tp.gh_token(tp.org_token(entry["id"])), tp.store_home(home):
                facts = tp.gather(checkout, manifest, since=since, sessions=extra.get("sessions"),
                                  triggers=extra.get("triggers"), now=now)
            orgs.append({"org": manifest["org"], "status": stx.status(facts, now)})
        except (OSError, ValueError, KeyError) as e:
            orgs.append({"org": entry, "status": None, "why": f"{type(e).__name__}: {e}"})
    d = cm.read(orgs, now)
    if args.json:
        print(json.dumps(d, indent=2))
    if args.html:
        from . import dashboard as dash
        Path(args.html).write_text(dash.render_command_html(d, note=args.sample_note))
        print(f"wrote      {args.html}")
    if not args.json and not args.html:
        print(cm.render(d))
    return 2 if d["state"] == "RED" else (3 if d["state"] == "DARK" else 0)


def cmd_status(args) -> int:
    """`org status` (SPEC §13): what is stopped right now, read at call time. One clock read for the whole
    reading; every tile carries the tier it came from, and the footer says what it could not see."""
    import datetime as _dt

    import yaml as _yaml

    from . import status as stx
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)

    last: dict = {}

    def read(at) -> dict:
        """One reading at `at`. Called once for a render, and once per interval by the reader (`--serve`)."""
        since = args.since or (at - _dt.timedelta(days=float(args.days))).strftime("%Y-%m-%dT00:00:00Z")
        tiers = None
        if args.facts:
            files = [json.loads(Path(f).read_text()) for f in args.facts]
            facts = tp.merge_facts(files) if len(files) > 1 else files[0]
        elif args.store:
            from . import store as sto
            conn = sto.connect(sto.db_path(repo, args.db))
            facts = sto.facts_since(conn, manifest, since=since, now=at, repo=repo)
            tiers = {stx.BOARD: f"replayed from the store — {sto.counts(conn).get('record_snapshot', 0)} record snapshot(s) kept across wakes"}
        else:
            extra = json.loads(Path(args.extra).read_text()) if getattr(args, "extra", None) else {}
            facts = tp.gather(repo, manifest, since=since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=at, prior=last.get("facts"))
            if args.ingest:
                from . import store as sto
                got = sto.ingest(sto.connect(sto.db_path(repo, args.db)), facts)
                print(f"store      +{got['new_snapshots']} record snapshot(s), +{got['new_verdicts']} verdict(s)")
            last["facts"] = facts
        if getattr(args, "refresh", False):
            # the refresh call: fetch the default branch and re-read the repo half of the operator queue now, even over replayed facts
            facts["operator_waiting"] = tp.reread_if_moved(repo, manifest, facts.get("operator_waiting"), at, force=True)
        st = stx.status(facts, at, tiers=tiers)
        last["presence"] = (st.get("subjects") or {}).get("presence")
        return st

    def on_ask(raw) -> dict:
        """An ask from the served page (0.42.0): checked, recorded on the board, relayed to the CEO as a plain DM — a
        sleeping CEO wakes, a busy one reads it at its next look."""
        from . import asks as ak
        from . import knobs as kn
        from .clock import for_operator
        ask = ak.validate(raw)
        ask["via"] = "the served page"
        knob = kn.apply_ask(ask, manifest, tp._run) if ask["kind"] == "knob" else None
        ak.record(ask, manifest, tp._run)
        pres = last.get("presence")
        local = for_operator(_dt.datetime.now(_dt.timezone.utc), (manifest.get("org", {}).get("operator") or {}).get("timezone"))
        got = ak.relay(ask, manifest, pres, tp._run, local=local)
        return {"ask": ask, **got, **({"said": f"{knob}; {got['said']}", "knob": knob} if knob else {})}

    def read_fast(at) -> dict:
        """The fast lane (`--serve`): the last full facts with the roadmap, the tickets and the pull-request index
        re-read (tempo.refresh_fast) — claims and merges reach the page in seconds, the board and reviews on `--interval`."""
        if not last.get("facts"):
            raise RuntimeError("no full reading yet to refresh")
        last["facts"] = tp.refresh_fast(repo, manifest, last["facts"], now=at)
        st = stx.status(last["facts"], at)
        last["presence"] = (st.get("subjects") or {}).get("presence")
        return st

    if args.serve:
        from . import serve as srv
        live_facts = not (args.facts or args.store)      # a replay has no source to re-read fast
        fast = float(args.fast_interval)
        reader = srv.Reader(read, interval=float(args.interval), take_fast=read_fast if live_facts and fast > 0 else None,
                            on_ask=on_ask if live_facts else None,
                            fast_interval=fast, poll_ms=max(1000, int((fast if live_facts and fast > 0 else float(args.interval)) * 1000 / 4)),
                            source=f"org status --serve, re-read every {args.interval:g}s"
                                   + (f", claims and pull requests every {fast:g}s" if live_facts and fast > 0 else ""))
        srv.serve(reader, host=args.host, port=int(args.port), allow_hosts=tuple(args.allow_host or ()), proxy_secret=_proxy_secret(args), agent_token=_agent_token(args), agent_rate=_agent_rate(args),
                  ready=lambda url: print(f"reading    {url}  — a full read at most every {args.interval:g}s"
                                          + (f", the roadmap, tickets and pull requests every {fast:g}s" if live_facts and fast > 0 else "")
                                          + "; the ages on the page are the readings', not the poll's. Ctrl-C to stop."))
        return 0

    st = read(now)
    if args.html:
        from . import dashboard as dash
        out = Path(args.html)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(dash.render_html(st, sample_note=args.sample_note, live=bool(args.live),
                                        source=args.source or "org status"))
        print(f"wrote      {out}  ({st['coverage']['measured']} of {st['coverage']['tiles']} tiles read)")
        if args.reading:
            r = Path(args.reading)
            r.parent.mkdir(parents=True, exist_ok=True)
            r.write_text(json.dumps(dash.reading_doc(st, source=args.source or "org status"), indent=1, ensure_ascii=False) + "\n")
            print(f"reading    {r}  — the document a live page reads; org-core writes files, never a store (rule 6)")
        return stx.exit_code(st)
    if args.json:
        print(json.dumps(st, indent=2, ensure_ascii=False))
    else:
        print(stx.render(st), end="")
    return stx.exit_code(st)


def cmd_store(args) -> int:
    """`org store` (SPEC §9): the derived index. It is not a source — `rebuild` reconstructs it from the
    committed facts files, which is also how check 7's drift question gets an answer."""
    from . import store as sto

    repo = Path(args.repo).resolve()
    conn = sto.connect(sto.db_path(repo, args.db))
    if args.store_cmd == "ingest":
        total = {"new_snapshots": 0, "new_verdicts": 0, "unkeyable_board_rows": 0}
        for f in args.facts:
            got = sto.ingest(conn, json.loads(Path(f).read_text()))
            for k in total:
                total[k] += got[k]
        print(f"ingested   {len(args.facts)} file(s): +{total['new_snapshots']} snapshot(s), +{total['new_verdicts']} verdict(s)"
              + (f", {total['unkeyable_board_rows']} board row(s) with no timestamp to key on" if total["unkeyable_board_rows"] else ""))
        return 0
    if args.store_cmd == "rebuild":
        got = sto.rebuild(conn, repo)
        print(f"rebuilt    from {got['files']} committed facts file(s): +{got['new_snapshots']} snapshot(s), +{got['new_verdicts']} verdict(s)")
        return 0 if got["files"] else 2
    c = sto.counts(conn)
    print(f"store      {sto.db_path(repo, args.db)}")
    for k in ("ingest", "record_snapshot", "pr", "pr_verdict"):
        print(f"  {k:<16} {c[k]}")
    return 0


def cmd_not_yet(args) -> int:
    print(f"`org {args.cmd}` is not implemented in org-core {__version__} ({NOT_YET[args.cmd]}). Exit 2 so nothing reads this as done.")
    return 2


def _repo_args(p: argparse.ArgumentParser, *, parent: bool) -> None:
    """`--repo`/`--manifest` on a command group's parent AND on each subcommand, so both orders parse:
    `org tempo --repo X dm …` and `org tempo dm --repo X …`. Reed's two reads of NumeroTech #210 (2026-09-20, row 91):
    every line the templates rendered put `--repo` after the subcommand — 19 new `setup status` lines and 18 `tempo`
    lines already on both orgs' main — and argparse rejected each with exit 2, so every role's `suite` read `{}` and every
    step-5 escalation failed on its first try. A subcommand's copy uses SUPPRESS so it never clobbers the parent's value."""
    if parent:
        p.add_argument("--repo", default=None)
        p.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml")
    else:
        p.add_argument("--repo", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
        p.add_argument("--manifest", default=argparse.SUPPRESS, help=argparse.SUPPRESS)


REPO_GROUPS = ("setup", "tempo", "checks", "tickets", "operator", "store", "knob")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="org", description="the org builder (see SPEC.md)")
    p.add_argument("--version", action="version", version=f"org-core {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("roles", help="list the role packages this org-core ships")
    s.set_defaults(fn=cmd_roles)

    s = sub.add_parser("validate", help="validate a manifest against the schema")
    s.add_argument("--manifest", default="org.yaml")
    s.add_argument("--repo", default=None, help="the checkout whose role files are read for an empty project section under a base that stops on one (default: the manifest's directory)")
    s.set_defaults(fn=cmd_validate)

    s = sub.add_parser("render", help="render one role file to stdout")
    s.add_argument("role")
    s.add_argument("kind", choices=["agent", "skill"])
    s.add_argument("--manifest", default="org.yaml")
    s.set_defaults(fn=cmd_render)

    for name, fn, help_ in (("plan", cmd_plan, "what apply would do"), ("apply", cmd_apply, "render the manifest into the repo"),
                            ("upgrade", cmd_apply, "re-render an installed repo against a newer org-core; base sections replaced, project sections kept, migrations applied"),
                            ("fidelity", cmd_fidelity, "measure how far the repo's files are from the packages and record it")):
        s = sub.add_parser(name, help=help_)
        s.add_argument("--repo", required=True)
        s.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml")
        s.add_argument("--diff", action="store_true")
        s.add_argument("--adopt-existing", action="store_true", help="keep a pre-existing unmanaged role file verbatim as the project section beneath the package base")
        s.add_argument("--project-from", default=None, help="directory of <role>/agent.md and <role>/SKILL.md to seed project sections of files that do not exist yet")
        if name == "plan":
            s.add_argument("--json", action="store_true")
        if name in ("apply", "upgrade"):
            s.add_argument("--overwrite-changed", action="store_true")
        if name == "fidelity":
            s.add_argument("--out", required=True)
        s.set_defaults(fn=fn)

    s = sub.add_parser("lessons", help="the fleet's inflow, pulled (SPEC §11): what a repository wrote into its own ground truth since a watermark, and a digest for the curator")
    lsub = s.add_subparsers(dest="lessons_cmd", required=True)
    lp = lsub.add_parser("pull", help="every hunk in the ground-truth files since an ISO time or a commit, with provenance and the section it landed in")
    lp.add_argument("--repo", required=True)
    lp.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml; org-core itself has none")
    lp.add_argument("--since", required=True, help="ISO time, or a commit (everything after it)")
    lp.add_argument("--out", default=None, help="defaults to <repo>/.org/lessons/pull-<date>.json")
    lp.add_argument("--max-lines", type=int, default=400)
    lp.add_argument("--now", default=None)
    ld = lsub.add_parser("digest", help="a reading of one or more pulls: per org, per file, every hunk with its tags and added text")
    ld.add_argument("--facts", required=True, nargs="+")
    ld.add_argument("--min-added", type=int, default=1)
    ld.add_argument("--max-lines", type=int, default=60)
    ld.add_argument("--skip-tags", nargs="*", default=["stamp"])
    ld.add_argument("--skip-sections", nargs="*", default=[])
    ld.add_argument("--skip-subject-prefix", nargs="*", default=[], help="drop hunks from commits whose subject starts with any of these (e.g. 'org-core ' for an installer's re-renders)")
    ld.add_argument("--out", default=None)
    sd = lsub.add_parser("seed", help="append a reader's extraction table to the org's docs/ai/lessons.md as rows (ids <org>-<date>-<n>), with the curator's answered statuses")
    sd.add_argument("--repo", required=True)
    sd.add_argument("--manifest", default=None)
    sd.add_argument("--extraction", required=True, help="the reader's table (fleet/lessons/<date>-<org>-extraction.md)")
    sd.add_argument("--date", required=True, help="the pull date the ids carry")
    sd.add_argument("--org", default=None, help="defaults to the manifest's org id")
    sd.add_argument("--statuses", default=None, help="a lessons_status.json; defaults to the one shipped with org-core")
    br = lsub.add_parser("brief", help="the standard reader brief for one org's digest — the same instructions every time")
    br.add_argument("--org", required=True)
    br.add_argument("--digest", required=True)
    br.add_argument("--core", default="/home/user/org-core", help="where the reader checks what org-core already ships")
    br.add_argument("--out-path", required=True, help="where the reader writes its table")
    br.add_argument("--since", default=None)
    br.add_argument("--head", default=None)
    br.add_argument("--out", default=None, help="write the brief here instead of stdout")
    lg = lsub.add_parser("ledger", help="scaffold the curated ledger: watermarks and counts filled in, the judgment left blank")
    lg.add_argument("--pulls", required=True, nargs="+")
    lg.add_argument("--extractions", nargs="*", default=[], help="<org>=<path> per reader table")
    lg.add_argument("--date", required=True)
    lg.add_argument("--out", default=None)
    st = lsub.add_parser("status", help="read the curator's answers out of a ledger into org_core/lessons_status.json, which `org upgrade` writes into each org's rows")
    st.add_argument("--ledger", required=True)
    st.add_argument("--prefix", required=True, nargs="+", help="<letter>=<org>-<date>, e.g. N=numerotech-2026-09-19")
    st.add_argument("--out", default=None, help="defaults to the package's lessons_status.json")
    s.set_defaults(fn=cmd_lessons)
    s = sub.add_parser("setup", help="the suite install (SPEC §18): render the setup script, read the report a session start wrote, or probe what this container has")
    _repo_args(s, parent=True)
    ssub = s.add_subparsers(dest="setup_cmd", required=True)
    sr = ssub.add_parser("render", help="the generated .claude/hooks/org-setup.sh to stdout (apply writes it)")
    _repo_args(sr, parent=False)
    st = ssub.add_parser("status", help="the report the last session start wrote ($TMPDIR/org-setup-report.json); exit 3 when none — the script never ran here (a usage error is exit 2, kept distinct on purpose); --compact always exits 0 and prints {\"report\": \"absent\"} for none")
    _repo_args(st, parent=False)
    st.add_argument("--report", default=None, help="read this report file instead")
    st.add_argument("--compact", action="store_true", help="the versions alone, one JSON line, for a role's record")
    st.add_argument("--json", action="store_true")
    ck = ssub.add_parser("check", help="probe every module and the wiring now; exit 1 on any row that is not what the tree says")
    _repo_args(ck, parent=False)
    ck.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_setup)
    s = sub.add_parser("operator", help="the operator file (SPEC §9): render every role's three lines from the board — the chair runs it each wake and commits the file on main (rows 65, 98)")
    _repo_args(s, parent=True)
    osub = s.add_subparsers(dest="operator_cmd", required=True)
    orr = osub.add_parser("render", help="rewrite each role's `last run` / `outcome` / `blocked` from roles/<role>/last-run; everything else in the file is kept")
    _repo_args(orr, parent=False)
    orr.add_argument("--dry-run", action="store_true", help="print the changes, write nothing")
    orr.add_argument("--roles", default=None, help="comma-separated role ids (default: every enabled role with a section contract)")
    orr.add_argument("--extra", default=None, help="with --dashboard: a JSON file carrying `sessions`/`triggers` from a session holding the sessions port (`list_sessions`), so the page's cost tile is read rather than dark")
    orr.add_argument("--dashboard", action="store_true", help="also write the org's own page (org.paths.dashboard, default docs/human/dashboard.html) from a live reading — this gathers over the network; the operator file does not")
    s.set_defaults(fn=cmd_operator)
    s = sub.add_parser("fleet", help="every installed org's default branch against this package (SPEC §11): installed version, since when it is behind, and the open upgrade PR if any — exit 1 when an org is behind with no upgrade open, 2 when one could not be read")
    s.add_argument("--repo", default=None, help="the org-core checkout (default: the one this package runs from) — its git log dates when the package moved past each org")
    s.add_argument("--registry", default=None, help="defaults to <repo>/fleet/orgs.yaml")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_fleet)
    s = sub.add_parser("priorities", help="land the priorities the operator set on the org page: edit the item and arc files from a saved `priority_asks` listing (checkout only; the PR, merge and `roadmap push` stay the chair's)")
    s.add_argument("--repo", required=True)
    s.add_argument("--from", dest="src", required=True, help="the page's `priority_asks` collection, saved as JSON (an ArtifactData list)")
    s.add_argument("--by", default=None, help="the page owner's id: an ask signed by anyone else is refused (NOT OWNER)")
    s.add_argument("--accept-board", action="store_true", help="also land `prioritize` asks read from the board (`switchboard board list`). A board row is attributed, never signed — anyone holding the workspace key can write one — so each is printed UNVERIFIED: match it against the relay DM first")
    s.add_argument("--write", action="store_true", help="edit the files; without it, say what would change")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_priorities)
    s = sub.add_parser("knob", help="runtime knobs on the org's board (SPEC §10): `<role>.cadence_multiplier` multiplies a role's wake interval, 0.5–4, for at most 7 days (0.47.0)")
    ks = s.add_subparsers(dest="knob_cmd", required=True)
    for nm, hp in (("list", "every knob set now"), ("get", "one knob: its value, what is in effect, and when it expires"),
                   ("set", "set a knob (refused outside its declared range or past the 7 d ceiling)"), ("clear", "delete a knob: the role is back on its own cadence")):
        k = ks.add_parser(nm, help=hp)
        k.add_argument("--repo", default=None)
        k.add_argument("--manifest", default=None)
        k.add_argument("--json", action="store_true")
        if nm != "list":
            k.add_argument("name", help="<role>.cadence_multiplier")
        if nm == "set":
            k.add_argument("value", help="a number inside the range, e.g. 2 = woken half as often")
            k.add_argument("--reason", default="", help="why — the record carries it, and check 12 prints it")
            k.add_argument("--ttl", default="24h", help="90m, 24h, 7d (default 24h, at most 7d)")
            k.add_argument("--by", default="", help="who sets it")
        k.set_defaults(fn=cmd_knob)
    s = sub.add_parser("asks", help="what the operator asked from the org page — rulings, start/stop work, notes — on the board or in a published page's saved `asks` listing; `done <id>` answers one (0.42.0)")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--from", dest="src", default=None, help="a published page's `asks` collection saved as JSON (an ArtifactData list)")
    s.add_argument("--by", default=None, help="with --from: the page owner's id; an ask signed by anyone else is refused")
    s.add_argument("--all", action="store_true", help="include asks already answered")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_asks, asks_cmd="list")
    asub = s.add_subparsers(dest="asks_cmd")
    d = asub.add_parser("done", help="answer an ask on its board record: what you did")
    d.add_argument("id")
    d.add_argument("--repo", required=True)
    d.add_argument("--manifest", default=None)
    d.add_argument("--note", default="")
    d.set_defaults(fn=cmd_asks, asks_cmd="done", src=None, by=None, all=False, json=False)
    s = sub.add_parser("handoffs", help="what a role handed the operator — who can decide it, what is recommended, what waiting costs, the exact command or text — on the board; `add` records one, `done <id>` answers it (0.52.0, SPEC row 181)")
    s.add_argument("--repo", default=None)
    s.add_argument("--manifest", default=None)
    s.add_argument("--all", action="store_true", help="include handoffs already answered, and the ones that left the board never answered "
                   "(read from the committed .org/tempo facts files, with their last text)")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_handoffs, hf_cmd="list")
    hsub = s.add_subparsers(dest="hf_cmd")
    a = hsub.add_parser("add", help="record a handoff: refused (exit 1) unless it says who decides it, what you recommend and what waiting costs")
    a.add_argument("--repo", required=True)
    a.add_argument("--manifest", default=None)
    a.add_argument("--org", default="", help="the org it concerns")
    a.add_argument("--decides", required=True, help="operator | org_ceo | org_core_ceo (the last only under a delegation)")
    a.add_argument("--what", required=True)
    a.add_argument("--for", dest="for_item", default="", help="the heading in the operator file (or the item's id) this is the recommendation for, "
                   "as the page names it when the operator asks: the card they asked from gains it and keeps its address, instead of a second card appearing")
    a.add_argument("--item", default="", help="the roadmap item this card concerns — required (a close card's `--for` is its item): checked "
                   "against the roadmap, stored as the key only — Decide files the card under that item's arc as the roadmap holds it when the "
                   "page is drawn. No item yet: file one first")
    a.add_argument("--why", default="")
    a.add_argument("--recommend", default="")
    a.add_argument("--cost", default="", help="what waiting costs, or `nothing known`")
    a.add_argument("--do", default="", help="the exact command or text to act with; on an `org_ceo` card, the DM the org-core CEO session "
                   "handed it over with (row 7: it messages that CEO as itself, never as them)")
    a.add_argument("--option", action="append", default=[], help="a choice the operator may pick (repeat for several, at most 6)")
    a.add_argument("--recommended-option", default="", help="which --option you recommend (exactly as written)")
    a.add_argument("--delegation", default="", help="with org_core_ceo: the standing decision it falls under")
    a.add_argument("--close", default="", choices=["", "done", "reopen"],
                   help="a close card for the item `--for` names, whose done-line needs the operator: what you recommend — `done` (close it) "
                        "or `reopen` (back to ready, the reason in --recommend); `--why` is what was measured, `--look` what to look at and "
                        "where. One card per item: filing it again replaces it")
    a.add_argument("--look", default="", help="with --close: what the operator is asked to look at, and where")
    a.add_argument("--by", default="", help="who writes it")
    a.set_defaults(fn=cmd_handoffs, hf_cmd="add", all=False, json=False)
    ce = hsub.add_parser("ceo", help="the CEO's own line on a close card: a recommendation with its pick, or `none: <why it cannot "
                                     "recommend>` — only then does the card reach the operator; the role's recommendation stays beside it")
    ce.add_argument("id", help="the close card's id (`org handoffs`, or `org handoffs missing`)")
    ce.add_argument("--repo", required=True)
    ce.add_argument("--manifest", default=None)
    ce.add_argument("--recommend", required=True, help="what the CEO recommends and why, or `none: <why it cannot recommend>`")
    ce.add_argument("--close", default="", choices=["", "done", "reopen"], help="the CEO's pick; required unless --recommend is `none: …`")
    ce.add_argument("--by", default="", help="who writes it")
    ce.set_defaults(fn=cmd_handoffs, hf_cmd="ceo", all=False, json=False)
    st = hsub.add_parser("settle", help="what the operator's answers on close cards move — each item to done or back to ready; `--apply` "
                                        "moves them on the work store, closes the card and marks the answer acted on. An answer row is "
                                        "attributed, never signed: `--apply` is the CEO's, after reading the answers, never a role's on a clock")
    st.add_argument("--repo", required=True)
    st.add_argument("--manifest", default=None)
    st.add_argument("--apply", action="store_true")
    st.add_argument("--json", action="store_true")
    st.set_defaults(fn=cmd_handoffs, hf_cmd="settle", all=False)
    d = hsub.add_parser("done", help="answer a handoff on its record: what was done")
    d.add_argument("id")
    d.add_argument("--repo", required=True)
    d.add_argument("--manifest", default=None)
    d.add_argument("--note", default="")
    d.set_defaults(fn=cmd_handoffs, hf_cmd="done", all=False, json=False)
    mi = hsub.add_parser("missing", help="the waiting decisions with no recommendation and no reason, by address; `--dm` sends the ones not yet sent to the CEO as one DM (never writes a recommendation)")
    mi.add_argument("--repo", required=True)
    mi.add_argument("--manifest", default=None)
    mi.add_argument("--dm", action="store_true")
    mi.add_argument("--json", action="store_true")
    mi.set_defaults(fn=cmd_handoffs, hf_cmd="missing", all=False)
    s = sub.add_parser("verifying", help="the verifying queue: the registrar's settle table read against the verifier's last record — due, "
                                         "waiting (on what), overdue (due > 2 days, nothing named), unplaced; `--fold` prints the table with the "
                                         "verifier's named waits and verdicts applied, for the registrar to write back. Exit 1 when any is overdue or unplaced")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--table", default=None, help="a saved settle table (JSON) instead of the board key")
    s.add_argument("--verifier", default=None, help="a saved verifier record (JSON) instead of roles/verifier/last-run")
    s.add_argument("--store", default=None, help="a saved `roadmap list --json` (JSON) instead of reading the work store")
    s.add_argument("--today", default=None, help="YYYY-MM-DD (default: today, UTC)")
    s.add_argument("--fold", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_verifying)
    s = sub.add_parser("pool", help="the launcher's gates (item launcher-role): this container's account label, a spawn request / ledger / listing checked before it is served or written, may-claim on the headroom read, and secret names held against declared — names only")
    psub = s.add_subparsers(dest="pool_cmd", required=True)
    pp = psub.add_parser("account", help="the fleet/accounts.yaml label of CLAUDE_CODE_ACCOUNT_UUID; prints `unmapped` and exits 1 when none")
    pp.add_argument("--repo", required=True)
    pp.set_defaults(fn=cmd_pool)
    pp = psub.add_parser("check", help="validate a JSON document before it is served or written; exit 1 with each problem")
    pp.add_argument("--repo", required=True)
    pp.add_argument("--kind", required=True, choices=["request", "spawned", "listing"])
    pp.add_argument("file")
    pp.set_defaults(fn=cmd_pool)
    pp = psub.add_parser("may-claim", help="whether this account may claim a spawn request on the headroom status it read this wake; exit 1 = no claim, with why")
    pp.add_argument("--repo", required=True)
    pp.add_argument("--headroom", default=None, help="the rate_limit_info status read from list_sessions this wake; omitted = no reading")
    pp.add_argument("file")
    pp.set_defaults(fn=cmd_pool)
    pp = psub.add_parser("secrets", help="{declared, held, missing}: the names the given manifests declare, against the names in this environment — never a value")
    pp.add_argument("--repo", required=True)
    pp.add_argument("--manifest", action="append", help="an org.yaml of the pool (repeatable)")
    pp.add_argument("--declare", action="append", help="a further declared name (repeatable)")
    pp.set_defaults(fn=cmd_pool)
    s = sub.add_parser("delegations", help="the operator's standing decisions (org.yaml `delegations:`) and every recorded use; `use`/`check` are for the role that holds one — it refuses unless the role, org, date, conditions and evidence are right (0.51.0, SPEC row 180)")
    s.add_argument("--repo", default=None)
    s.add_argument("--manifest", default=None)
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_delegations, dg_cmd="list")
    dsub = s.add_subparsers(dest="dg_cmd")
    for name, hlp in (("use", "record a use: refuses and exits 1 if the grant does not allow it"), ("check", "the same test, recording nothing")):
        d = dsub.add_parser(name, help=hlp)
        d.add_argument("id")
        d.add_argument("--repo", required=True)
        d.add_argument("--manifest", default=None)
        d.add_argument("--role", required=True, help="the role exercising it")
        d.add_argument("--target", required=True, help="`<org>#<number>`, e.g. lucille#1914")
        d.add_argument("--checked", default="", help="comma-separated conditions you checked")
        d.add_argument("--evidence", default="", help="where you saw them hold")
        d.set_defaults(fn=cmd_delegations, dg_cmd=name, json=False)
    s = sub.add_parser("vendor", help="write the running org-core as a wheel under .org/wheels/ so a cold session installs it with no credential (SPEC §6)")
    s.add_argument("--repo", required=True)
    s.add_argument("--hook", action="store_true", help="also print the session-start hook lines that install from the wheel")
    s.set_defaults(fn=cmd_vendor)
    s = sub.add_parser("tempo", help="the org's speed, measured — and the roles to wake before their cron tick (SPEC §13)")
    _repo_args(s, parent=True)
    tsub = s.add_subparsers(dest="tempo_cmd", required=True)
    g = tsub.add_parser("gather", help="read the board, the pull requests and the run ledgers into one facts file (read-only)")
    _repo_args(g, parent=False)
    g.add_argument("--since", required=True, help="ISO time; pull requests updated before it are ignored")
    g.add_argument("--facts", default=None, help="JSON with `triggers`/`sessions` from a session holding the sessions port, folded in")
    g.add_argument("--out", default=None, help="defaults to .org/tempo/facts-<date>.json")
    g.add_argument("--now", default=None, help="pin the reading's clock: one instant stamps the facts and ages everything read from them")
    r = tsub.add_parser("report", help="edge latencies vs targets, the PR cycle, handoffs, blocked fields, wakes and wake-now, from one or more facts files")
    _repo_args(r, parent=False)
    r.add_argument("--facts", required=True, nargs="+", help="facts files; several are merged (a week from a day's files)")
    r.add_argument("--now", default=None)
    r.add_argument("--json", action="store_true")
    w = tsub.add_parser("wake-now", help="gather live and list the roles whose events are past target — the read-only view of the plan")
    _repo_args(w, parent=False)
    w.add_argument("--facts", default=None, help="JSON with `triggers` from the session holding the sessions port (trigger ids and last fires)")
    w.add_argument("--since", default=None, help="ISO time; defaults to three days ago")
    w.add_argument("--now", default=None)
    w.add_argument("--json", action="store_true")
    t = tsub.add_parser("triggers", help="write the compact coord/tempo/triggers key from a list_triggers dump — each wake of the port holder since 0.44.0, so the page shows each role's routine (next run, last result)")
    _repo_args(t, parent=False)
    t.add_argument("--facts", required=True, help="the list_triggers JSON (or {triggers: [...]})")
    t.add_argument("--now", default=None)
    ss = tsub.add_parser("sessions", help="write the compact coord/tempo/sessions key from a list_sessions dump — every "
                         "wake of the port holder, so the page shows each role's session (0.44.0)")
    _repo_args(ss, parent=False)
    ss.add_argument("--facts", required=True, help="the list_sessions JSON: the tool's own page ({ccr: {data, has_more}} or {data, has_more}) or a list")
    ss.add_argument("--now", default=None)
    rg = tsub.add_parser("register", help="a role's first act every wake: its agent id into coord/tempo/agents, and — a persistent seat only — the deadline to park its listener until")
    _repo_args(rg, parent=False)
    rg.add_argument("--role", required=True)
    rg.add_argument("--session-id", default=None)
    rg.add_argument("--item", default=None, help="a spawned role: the item it was spawned for — a DM addressed to it (`dm --item`) reaches this session")
    rg.add_argument("--pr", type=int, action="append", default=None, help="a spawned role: a PR it holds (repeatable; re-registering adds) — `dm --pr`, or a `#<n>` in the text, reaches this session")
    rg.add_argument("--listen-minutes", type=float, default=None, help="defaults to tempo.listen_minutes (105 — re-armed on every expiry, ruling 7)")
    rg.add_argument("--now", default=None)
    dm = tsub.add_parser("dm", help="wake a receiver: a listening persistent role is DMed; a spawned/fresh role's DM is routed to the actuator (`wake <role>: …`), whose wake spawns it; a clock-only role (`on_demand: none` — the doctor, or a role the org opted out) is not woken — exit 0 delivered/routed, 1 unregistered, 2 absent (not sent), 3 clock-only")
    _repo_args(dm, parent=False)
    dm.add_argument("--role", required=True, help="the receiving role")
    dm.add_argument("text", nargs="+", help="the message — usually the handoff key")
    dm.add_argument("--item", default=None, help="a spawned receiver: the session registered for this item")
    dm.add_argument("--pr", type=int, action="append", default=None, help="a spawned receiver: the session registered for this PR (default: the text's `#<n>`)")
    dm.add_argument("--now", default=None)
    pu = tsub.add_parser("park-until", help="the ISO time a persistent seat's listener parks until: now + tempo.listen_minutes (default 105 min); `--timeout-ms` prints the background timeout to start it with")
    _repo_args(pu, parent=False)
    pu.add_argument("--listen-minutes", type=float, default=None)
    pu.add_argument("--timeout-ms", action="store_true", help="print the background timeout (ms) the listener must be started with, not the deadline")
    pu.add_argument("--now", default=None)
    nf = tsub.add_parser("next-fire", help="the next cron fire of a role, ISO; exit 2 when it has no cron")
    _repo_args(nf, parent=False)
    nf.add_argument("--role", required=True)
    nf.add_argument("--now", default=None)
    wk = tsub.add_parser("wake", help="the actuator's four-call wake: plan (gather live, print the acts and the one-shot prompts) and record (ledger, heartbeat, lease)")
    wsub = wk.add_subparsers(dest="wake_cmd", required=True)
    wp = wsub.add_parser("plan")
    _repo_args(wp, parent=False)
    wp.add_argument("--facts", default=None, help="JSON with `triggers`; else the compact board key is read")
    wp.add_argument("--session-json", default=None, help="this session's get_session JSON (context tokens, cost) — needed for the rotate rule and the cost series")
    wp.add_argument("--holder-json", default=None, help="the lease holder's get_session JSON, fetched by the id in coord/tempo/lease when "
                    "that id is not this session: an archived holder's lease is taken over without coord/tempo/sessions carrying it")
    wp.add_argument("--inbox", default=None, help="this wake's `switchboard --json inbox` saved to a file: the routed `wake <role>: <event> <what>` DMs are acted on now, target or not")
    wp.add_argument("--since", default=None)
    wp.add_argument("--now", default=None)
    wp.add_argument("--out", default=None, help="defaults to .org/tempo/plan.json")
    wr = wsub.add_parser("record")
    _repo_args(wr, parent=False)
    wr.add_argument("--plan", required=True)
    wr.add_argument("--results", default=None, help="[{i, ok, id, readback, could_not, peer_parked}] per action index the session performed")
    wr.add_argument("--session-json", default=None)
    wr.add_argument("--now", default=None)
    wr.add_argument("--dry-run", action="store_true", help="print the row, heartbeat and lease; write nothing")
    s.set_defaults(fn=cmd_tempo)
    s = sub.add_parser("command", help="the fleet as one console, for the person it waits on: every org's "
                                       "operator queue, what each item is holding up, and the signal matrix (SPEC §9, §11)")
    s.add_argument("--repo", default=".")
    s.add_argument("--registry", help="defaults to <repo>/fleet/orgs.yaml")
    s.add_argument("--days", default=3, help="how far back each org's reading looks")
    s.add_argument("--extra", help="a JSON file carrying `sessions` from a session holding the sessions port")
    s.add_argument("--html", help="write the console as one self-contained page")
    s.add_argument("--sample-note", help="a banner naming the reading")
    s.add_argument("--now")
    s.add_argument("--json", action="store_true")
    s.add_argument("--serve", action="store_true", help="serve every org live on one port: the console at /, each org's own "
                                                        "page, controls and all, at /o/<id>/")
    s.add_argument("--host", default="127.0.0.1", help="bind address (default local only: the reader holds every org's credentials)")
    s.add_argument("--port", default=8798)
    s.add_argument("--allow-host", action="append", metavar="NAME",
                   help="with --serve: a Host a proxy in front serves the pages under (repeatable); every other Host but "
                        "127.0.0.1/localhost at this port is refused")
    s.add_argument("--proxy-secret-env", metavar="VAR",
                   help="with --serve: refuse every request whose X-Org-Proxy header is not the value of this environment "
                        "variable — the proxy in front adds it, so nothing that bypasses the proxy (and its login) is served")
    s.add_argument("--agent-token-env", metavar="VAR",
                   help="with --serve: a read-only bearer token (the value of this environment variable, 32+ characters) that "
                        "opens GET /command.json and GET /o/<id>/status.json and nothing else; never a write, never /ask")
    s.add_argument("--agent-rate", type=int, metavar="N",
                   help="with --agent-token-env: reads a minute that token may make before a 429 with Retry-After (default 60: five times "
                        "a page's own 5 s poll; proposed, 0.58.0)")
    s.add_argument("--interval", default=300.0, type=float, help="with --serve: seconds between each org's full reads")
    s.add_argument("--fast-interval", default=20.0, type=float, help="with --serve: seconds between each org's fast-lane reads (0: off)")
    s.add_argument("--feedback-to", default="org-core", metavar="ORG",
                   help="with --serve: the org that takes a bug or feature request about the dashboard, posted from any org's page "
                        "(default org-core; an org this fleet does not serve means each page's own org takes its own; '' turns it off)")
    s.set_defaults(fn=cmd_command)

    s = sub.add_parser("status", help="what is stopped right now, read at call time — the chain, the chair, the roles, the wake chain (SPEC §13)")
    s.add_argument("--repo", default="."); s.add_argument("--manifest")
    s.add_argument("--facts", nargs="*", help="read committed facts files instead of gathering live")
    s.add_argument("--store", action="store_true", help="replay from the store, so board edges keep the history the board overwrites")
    s.add_argument("--db", help="store path (default <repo>/.org/status.db)")
    s.add_argument("--extra", help="a JSON file carrying `triggers`/`sessions` from a session holding the sessions port")
    s.add_argument("--since"); s.add_argument("--days", default=3, help="how far back to read when --since is absent")
    s.add_argument("--ingest", action="store_true", help="fold what this live reading saw into the store — the board is overwritten every wake (row 62)")
    s.add_argument("--html", help="write the same reading as one self-contained page")
    s.add_argument("--sample-note", help="a banner naming the reading as a replay or sample, never passed off as live")
    s.add_argument("--live", action="store_true", help="the page redraws when a newer reading reaches the store it watches; it still renders this one at rest")
    s.add_argument("--reading", help="also write the reading as one JSON document — what a live page reads")
    s.add_argument("--serve", action="store_true", help="serve the page and re-take the reading on an interval, the way switchboard's own viewer does")
    s.add_argument("--host", default="127.0.0.1", help="bind address (default local only: the reader holds the org's credentials)")
    s.add_argument("--port", default=8799)
    s.add_argument("--allow-host", action="append", metavar="NAME",
                   help="with --serve: a Host a proxy in front serves the page under (repeatable). Every other Host but "
                        "127.0.0.1/localhost at this port is refused, on every request: the page carries its ask token")
    s.add_argument("--proxy-secret-env", metavar="VAR",
                   help="with --serve: refuse every request whose X-Org-Proxy header is not the value of this environment "
                        "variable — the proxy in front adds it, so nothing that bypasses the proxy (and its login) is served")
    s.add_argument("--agent-token-env", metavar="VAR",
                   help="with --serve: a read-only bearer token (the value of this environment variable, 32+ characters) that "
                        "opens GET /command.json and GET /o/<id>/status.json and nothing else; never a write, never /ask")
    s.add_argument("--agent-rate", type=int, metavar="N",
                   help="with --agent-token-env: reads a minute that token may make before a 429 with Retry-After (default 60: five times "
                        "a page's own 5 s poll; proposed, 0.58.0)")
    s.add_argument("--interval", default=300.0, type=float, help="seconds between FULL reads — the board, and 1 + 3N gh calls for the pull requests; a floor, not a refresh rate (30 until 0.41.0: ~91 gh calls a read on org-core, measured 2026-09-24, which at that floor projects to ~10,900/h against the 15,000/h the API reported — bucket unverified)")
    s.add_argument("--refresh", action="store_true", help="fetch the default branch and re-read the operator file now, so a count over a stale checkout is forced fresh (it shows the commit and time it was read at)")
    s.add_argument("--fast-interval", default=20.0, type=float, help="with --serve: seconds between re-reads of the cheap sources — the roadmap's claims and statuses, the ticket queue, the pull-request index (0 turns the fast lane off)")
    s.add_argument("--source", help="where this reading came from, shown in the page footer")
    s.add_argument("--now"); s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("store", help="the derived index over the sources (SPEC §9) — not a source: rebuild reconstructs it from the committed facts files")
    _repo_args(s, parent=True)
    s.add_argument("--db", default=None, help="store path (default <repo>/.org/status.db)")

    def _store_sub(sp):                       # --repo/--manifest/--db read the same either side (row 91)
        _repo_args(sp, parent=False)
        sp.add_argument("--db", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
        return sp

    st_ = s.add_subparsers(dest="store_cmd", required=True)
    i = _store_sub(st_.add_parser("ingest", help="fold one or more facts files into the store (idempotent)"))
    i.add_argument("--facts", nargs="+", required=True)
    _store_sub(st_.add_parser("rebuild", help="reconstruct from every committed .org/tempo/facts-*.json, oldest first"))
    _store_sub(st_.add_parser("counts", help="how many rows the store holds, per table"))
    s.set_defaults(fn=cmd_store)

    s = sub.add_parser("install", help="ONE COMMAND for a first install: init -> check the draft is filled -> apply -> verify. Run it again after each thing it asks for.")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.set_defaults(fn=cmd_install)

    s = sub.add_parser("init", help="detect what a repo has; --write a draft manifest")
    s.add_argument("--repo", required=True)
    s.add_argument("--write", action="store_true")
    s.add_argument("--force", action="store_true")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("doctor", help="run the health checks (SPEC §8)")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--facts", default=None, help="JSON with `triggers` and/or `sessions` gathered by a session holding the sessions port")
    s.add_argument("--only", default=None, help="comma-separated check numbers")
    s.add_argument("--drill", default=None, help="read this role's record as absent (the dead-role drill)")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("routine", help="the trigger spec a clock role needs (SPEC §5/§6) — create it on the org account")
    s.add_argument("role")
    s.add_argument("--manifest", default="org.yaml")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_routine)

    s = sub.add_parser("verify", help="prove an install works, including the dead-role drill (SPEC §7)")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--facts", default=None)
    s.add_argument("--drill", default="random", help="role to kill at the read layer; default random")
    s.add_argument("--no-drill", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_verify)

    s = sub.add_parser("record", help="validate a run record JSON file")
    s.add_argument("file")
    s.set_defaults(fn=cmd_record)

    s = sub.add_parser("record-from-doctor", help="build the doctor's run record from `org doctor --json` output (one JSON line, validated)")
    s.add_argument("report")
    s.add_argument("--repo", required=True)
    s.add_argument("--runtime", default="fresh", choices=["fresh", "session", "spawned"])
    s.add_argument("--session-id", default=None)
    s.add_argument("--pr", default=None)
    s.add_argument("--next-due", default=None)
    s.set_defaults(fn=cmd_record_from_doctor)

    s = sub.add_parser("tickets", help="the tickets port for a github-issues org: labels + issue form (SPEC §16 decision 4)")
    _repo_args(s, parent=True)
    ts = s.add_subparsers(dest="tickets_cmd", required=True)
    _repo_args(ts.add_parser("status", help="github-issues intake: which declared labels exist, and whether the issue form is in the tree"), parent=False)
    t = ts.add_parser("init", help="github-issues intake: create every missing label (idempotent) and write the issue form if absent")
    _repo_args(t, parent=False)
    t.add_argument("--dry-run", action="store_true")
    t = ts.add_parser("sql", help="the read-only SELECTs a role runs through the read port to get the rows")
    _repo_args(t, parent=False)
    t.add_argument("--dialect", choices=["generic", "lucille"], default="generic")

    def _rows_opts(p):
        p.add_argument("--tickets", default=None, help="rows JSON saved from the read port (a list, or {tickets: [...]})")
        p.add_argument("--notes", default=None, help="notes rows JSON (optional)")
        p.add_argument("--items", default=None, help="roadmap items: a directory of YAML (files mode) or a JSON dump; default <repo>/roadmap/items")
        p.add_argument("--source", choices=["file", "psql", "api"], default=None, help="default: file when --tickets is given, api when --url, psql when --dsn-env")
        p.add_argument("--dsn-env", default=None); p.add_argument("--url", default=None); p.add_argument("--token-env", default=None)
        p.add_argument("--dialect", choices=["generic", "lucille"], default="generic")
        p.add_argument("--now", default=None, help="ISO-8601, for reproducible runs")
        p.add_argument("--assume-complete", action="store_true", help="the rows file is the whole table (enables dangling_link)")
        p.add_argument("--json", action="store_true")

    t = ts.add_parser("stage", help="one ticket, across every layer"); t.add_argument("--id", required=True); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("open-loops", help="every place the pipeline stopped without finishing (exit 2 on any finding)"); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("report", help="the pipeline digest: stages, open loops"); t.add_argument("--write", action="store_true"); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("impact", help="an item's linked tickets, before/after it was called done (exit 2 on any after)"); t.add_argument("key"); _rows_opts(t)
    _repo_args(t, parent=False)
    s.set_defaults(fn=cmd_tickets)

    s = sub.add_parser("checks", help="checks-core: a production checks registry (SPEC §4 checks port)")
    _repo_args(s, parent=True)
    s.add_argument("--registry", default=None)
    s.add_argument("--ledger", default=None)
    s.add_argument("--results", default=None)
    s.add_argument("--today", default=None, help="YYYY-MM-DD; defaults to today UTC")
    cs = s.add_subparsers(dest="checks_cmd", required=True)
    _repo_args(cs.add_parser("validate", help="registry well-formed, queries read-only, ledger consistent (a LOST check is a finding)"), parent=False)
    c = cs.add_parser("plan", help="which checks are due today, with their SQL")
    _repo_args(c, parent=False)
    c.add_argument("--json", action="store_true")
    c = cs.add_parser("evaluate", help="verdicts from a rows file {check_id: row | {error}}; nothing recorded")
    _repo_args(c, parent=False)
    c.add_argument("--rows", required=True)
    c = cs.add_parser("record", help="evaluate a rows file, append the results log, optionally file/retire GitHub issues")
    _repo_args(c, parent=False)
    c.add_argument("--rows", required=True)
    c.add_argument("--file-issues", action="store_true")
    c.add_argument("--dry-run", action="store_true")
    c.add_argument("--no-gh", action="store_true", help="with --dry-run: do not call gh at all")
    c = cs.add_parser("run", help="plan → execute through psql (read-only, time-bounded) → record")
    _repo_args(c, parent=False)
    c.add_argument("--executor", default="psql")
    c.add_argument("--dsn-env", default=None)
    c.add_argument("--file-issues", action="store_true")
    c.add_argument("--dry-run", action="store_true")
    c.add_argument("--no-gh", action="store_true")
    c = cs.add_parser("report", help="what the checks-watch role reads: counts, oldest failure, unowned failures, vacuous passes, expiries, worsening")
    _repo_args(c, parent=False)
    c.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_checks)

    for name in NOT_YET:
        s = sub.add_parser(name, help=f"not implemented: {NOT_YET[name]}")
        s.add_argument("rest", nargs="*")
        s.set_defaults(fn=cmd_not_yet)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "cmd", None) in REPO_GROUPS and getattr(args, "repo", None) is None:
        parser.error(f"org {args.cmd}: --repo is required (before or after the subcommand)")
    if getattr(args, "repo", None) is not None and getattr(args, "manifest", "org.yaml") is None:
        args.manifest = str(Path(args.repo) / "org.yaml")
    try:
        return args.fn(args)
    except ManifestError as e:
        print(str(e))
        return 1
    except FileNotFoundError as e:
        print(f"missing: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
