"""Two clocks: the record's and the operator's (the operator's ruling, 2026-09-24).

Everything a role keeps — board records, facts, commits, SPEC's dated sentences — is UTC and stays UTC: it is
compared across orgs and sessions, and a zone in a record is a second thing to get wrong. Everything a role *says to
the operator* is in the operator's own zone, `org.operator.timezone` (IANA), with the UTC instant beside it so a time
the operator quotes back can be found in a record without arithmetic.

Broken looks like: a time addressed to the operator in `Z` when the manifest names a zone, or a record written in local
time. An unknown zone name is a manifest error (`org validate`), never a silent fall back to UTC.
"""

from __future__ import annotations

import datetime as dt
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

UTC = dt.timezone.utc


def zone_name(manifest: dict[str, Any] | None) -> str:
    """The operator's IANA zone from the manifest; `UTC` when it names none."""
    return (((manifest or {}).get("org") or {}).get("operator") or {}).get("timezone") or "UTC"


def zone(name: str | None) -> dt.tzinfo:
    if not name or name.upper() in ("UTC", "Z", "GMT"):
        return UTC
    return ZoneInfo(name)


def valid(name: str) -> bool:
    try:
        zone(name)
        return True
    except (ZoneInfoNotFoundError, ValueError):
        return False


def for_operator(at: dt.datetime, name: str | None) -> str:
    """`2026-09-24 14:02 IDT (2026-09-24 11:02Z)` — local first, the record's instant after it.

    With no zone (or UTC) it is the record's form alone, `2026-09-24 11:02Z`, byte for byte what org-core wrote before
    the operator had a zone. The UTC half is a full timestamp so `doctor.parse_ts` reads it, not the local half.
    """
    if at.tzinfo is None:
        at = at.replace(tzinfo=UTC)
    utc = at.astimezone(UTC).strftime("%Y-%m-%d %H:%MZ")
    tz = zone(name)
    if tz is UTC:
        return utc
    local = at.astimezone(tz)
    return f"{local.strftime('%Y-%m-%d %H:%M')} {local.tzname()} ({utc})"
