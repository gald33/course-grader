"""`org command` — the fleet, for the person the fleet waits on (SPEC §9, §11).

Every page before this one had the org as its subject and the operator as its reader. That is a report. A
command centre inverts it: **the operator is the subject**, because in this fleet they are the scarce
resource — measured on Lucille 2026-09-22, 25 items waiting on a person, the oldest 7 days, while every
role that named one of them sat blocked behind it.

So this reading answers three questions in order, and nothing else above the fold:

1. **What needs me?** Every org's operator queue, the sessions stopped on a permission prompt nobody
   unattended can answer, and the pull requests whose merge is the operator's — in one list, across the
   fleet, oldest first.
2. **What does it cost to keep not deciding?** Each item names the roles and sessions that are *stopped
   naming the same thing*. That is the number that makes a decision cheap, and no page here has shown it.
3. **Is the machinery running?** One row per org, one cell per signal. Dense, and read only when it is red.

**The cost link is evidence, not a causal claim.** An operator item and a role's blocker are matched when
they share a distinctive token — `LUCILLE_ADMIN_JWT`, `#1471`, a path — and the page prints the token it
matched on, so the reader judges the link rather than taking it. A heuristic that hid its evidence would be
the confident-window failure of rows 115 and 124 in a new costume.

An org that could not be read is a dark cell naming the reason. The fleet has three orgs and this session
can reach two of them; a command centre that quietly showed the two it had would be the worst lie available.
"""

from __future__ import annotations

import hashlib
import datetime as dt
from typing import Any

from .brief import SECTION_ROWS, TOKEN_RE, _sentence, ago, costs, fallback_words, tokens  # noqa: F401 — TOKEN_RE/tokens/costs re-exported
from .status import CLEAR, DARK, RED, item_arc

def _action(kind: str, org: dict[str, Any], **kw: Any) -> dict[str, Any]:
    repo, branch = org.get("repo"), org.get("default_branch") or "main"
    if kind == "file":
        return {"label": "open the item" if str(kw["path"]).endswith(".yaml") else "open the file",
                "href": f"https://github.com/{repo}/blob/{branch}/{kw['path']}"}
    if kind == "pr":
        return {"label": f"open #{kw['number']}", "href": f"https://github.com/{repo}/pull/{kw['number']}"}
    if kind == "session":
        return {"label": "answer it in that session", "href": ""}
    if kind == "roadmap":
        return {"label": f"roadmap show {kw['id']}", "href": ""}
    return {"label": "", "href": ""}


def needs_you(st: dict[str, Any], org: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Everything in one org that only a person can clear, with what each one is holding up."""
    s = st.get("subjects") or {}
    rm = s.get("roadmap") or {}
    road = {"items": rm.get("items") if rm.get("read") else None}
    out = [_queue_row(q, st, org) for q in s.get("queue") or []]
    for r in (s.get("spend") or {}).get("stopped") or []:
        out.append({"org": org["id"], "what": "A session is stopped waiting for permission",
                    "why": f"“{r.get('needs') or 'a permission prompt'}” in {r.get('title')} — nobody "
                           f"unattended can answer it, and it has cost ${r.get('cost', 0):.0f} so far.",
                    "hours": r.get("hours"), "ago": ago(r.get("hours")), "at": "",
                    "kind": "permission", "cost": {"roles": [], "sessions": [], "on": []},
                    "fid": hashlib.sha1(f"{org['id']}|prompt|{r.get('title')}".encode()).hexdigest()[:10],
                    "action": _action("session", org), "source": "BLOCKED ON A PROMPT",
                    # a session's claim is recorded by a role's name, not the session, so which item it is on cannot be read: no arc
                    "item": None, "arc": None})
    ch = s.get("chair") or {}
    for x in ch.get("stale") or []:
        out.append({"org": org["id"], "what": f"Pull request #{x['number']} has been waiting on an act",
                    "why": "; ".join(x.get("why") or []) + ".", "hours": x.get("idle_hours"),
                    "ago": ago(x.get("idle_hours")), "at": x.get("updated_at") or "", "kind": "pr",
                    "cost": {"roles": [], "sessions": [], "on": []},
                    "fid": hashlib.sha1(f"{org['id']}|pr|{x['number']}".encode()).hexdigest()[:10],
                    "action": _action("pr", org, number=x["number"]), "source": f"NEEDING ACTION #{x['number']}",
                    **item_arc([(k, True) for k in x.get("builds") or []], road)})
    return out


def _queue_row(q: dict[str, Any], st: dict[str, Any], org: dict[str, Any]) -> dict[str, Any]:
    """One row of an org's operator queue as the fleet reads it: waiting (`needs_you`) or answered (`answered`) alike, so a card keeps
    its address when it moves from one to the other."""
    s = st.get("subjects") or {}
    head = str(q.get("head") or "").strip()
    days = q.get("age_days")
    tok = tokens(head) | tokens(q.get("body", ""))
    hid = (q.get("handoff") or {}).get("id")
    return {"org": org["id"], "what": _sentence(head), "why": str(q.get("body_full") or q.get("body") or "").strip(),
            # a handoff recorded for a heading in the operator file is that heading's own card (SPEC row 189): its address stays
            "fid": f"h{hid}" if hid and not q.get("attached") else hashlib.sha1(f"{org['id']}|{q.get('source')}|{head}".encode()).hexdigest()[:10],
            "hours": (days or 0) * 24 if days is not None else None,
            "ago": ago((days or 0) * 24) if days is not None else "", "at": q.get("since") or "",
            "kind": "decision", "cost": costs(tok, st), "handoff": q.get("handoff"), "counts": bool(q.get("counts", True)),
            "hread": bool((s.get("operator_handoffs") or {}).get("read")),
            # a queue item from the repo links to the file it lives in: the operator file, or the roadmap
            # item that carries the operator's arc; a board row has no page to open
            "action": _action("file", org, path=q["source"]) if str(q.get("source", "")).endswith((".md", ".yaml"))
                      else _action("", org),
            # with the board unread a file row says so, and how old the file's reading is (status `fallback`); the fid above never carries it
            "source": f"{q.get('source')}" + (f" — {fallback_words(q['fallback'])}" if q.get("fallback") else ""),
            # the item it concerns and that item's arc, as the reading took them (status.item_arc): Decide's arc filter
            "item": q.get("item"), "arc": q.get("arc"),
            # its item moved, or left the roadmap, since the card was written (handoffs.item_moved, read with the arc)
            "item_moved": q.get("item_moved")}


def answered(st: dict[str, Any], org: dict[str, Any]) -> list[dict[str, Any]]:
    """What the operator already answered in one org and its CEO has not yet closed (`status.answered_apart`): listed apart from
    `needs_you`, never counted with it, each with what the board says was said and whether the CEO acted on it."""
    return [{**_queue_row(q, st, org), "said": q.get("said") or [], "acted": bool(q.get("acted")), "answered_at": q.get("answered_at")}
            for q in (st.get("subjects") or {}).get("queue_answered") or []]


#: one cell per signal, in the order a person triages: is it moving, is anyone home, is the plumbing up,
#: is it current. A cell is a state and a short reading, never a number alone. `ci` (0.74.0) is plumbing: the runners and
#: the Actions queue, judged once in `ci.reading`; its detail is the org page's Machinery view, which the cell links to.
SIGNALS = ("shipping", "roles", "scheduler", "ci", "reachable", "version", "spend")


def machinery(st: dict[str, Any], fleet_row: dict[str, Any] | None) -> dict[str, dict[str, str]]:
    s = st.get("subjects") or {}
    ch, ac, ls = s.get("chair") or {}, s.get("actuator") or {}, s.get("listeners") or {}
    v, sp = s.get("versions") or {}, s.get("spend") or {}
    h = ch.get("hours_since_last_merge")
    cells = {
        "shipping": ({"state": DARK, "read": "not checked"} if not ch.get("read") else
                     {"state": CLEAR, "read": f"{ago(h)} ago"} if h is not None and h < 24 else
                     {"state": RED, "read": f"{ago(h)} ago" if h is not None else "nothing in the window"}),
        "roles": ({"state": DARK, "read": "not checked — board not read" if s.get("roles_why") else "not checked",
                   "why": s.get("roles_why") or ""} if s.get("roles") is None else
                  {"state": RED, "read": f"{len(s['roles'])} not reporting"} if s.get("roles") else
                  {"state": CLEAR, "read": f"all {s.get('roles_total', 0)} reporting"
                                           + (f" · {len(s['roles_idle'])} idle" if s.get("roles_idle") else "")}),
        "scheduler": ({"state": CLEAR, "read": "none needed"} if ac.get("needed") is False else
                      {"state": RED, "read": "switched off"} if ac.get("missing") else
                      {"state": DARK, "read": "not checked"} if not ac.get("read") else
                      {"state": CLEAR, "read": f"woke {ago(ac.get('age_hours'))} ago"} if ac.get("heartbeat") else
                      {"state": RED, "read": "not running"}),
        "reachable": ({"state": DARK, "read": "not checked"} if not ls.get("read") else
                      {"state": RED, "read": f"{len(ls.get('never') or []) + len(ls.get('lapsed') or [])} of "
                                             f"{ls.get('total', 0)} unreachable"}
                      if (ls.get("never") or ls.get("lapsed")) else
                      {"state": CLEAR, "read": f"all {ls.get('total', 0)} on the roster"}),
        "version": ({"state": DARK, "read": (fleet_row or {}).get("installed") and "records not read" or "not checked"}
                    if not v.get("read") else
                    {"state": RED, "read": f"{len(v['behind'])} of {len(v['behind']) + len(v['ok'])} behind"}
                    if v.get("behind") else
                    {"state": DARK, "read": f"{len(v['ok']) - len(v['predates'])} of {len(v['ok'])} confirmed on {v.get('lock')}, "
                                            f"{len(v['predates'])} not run since the upgrade"} if v.get("predates") else
                    {"state": CLEAR, "read": f"all on {v.get('lock')}"}),
        # red when a queued job waited past the bar or a label with queued jobs has no online runner; not checked when the runs
        # were not read, or when jobs wait on a label the refused runner list would have to answer for (ci.signal)
        "ci": dict((s.get("ci") or {}).get("signal") or {"state": DARK, "read": "not checked"}, view="machinery"),
        "spend": ({"state": DARK, "read": "not checked"} if not sp.get("read") else
                  {"state": RED, "read": f"${sp.get('total', 0):.0f}, one stopped"} if sp.get("stopped") else
                  {"state": CLEAR, "read": f"${sp.get('total', 0):.0f} cumulative"} if sp.get("complete") else
                  {"state": DARK, "read": f"at least ${sp.get('total', 0):.0f}, partial"}),
    }
    return cells


def motion(st: dict[str, Any]) -> int | None:
    """How many roadmap items are in motion — held by someone, or shipped and being verified — and `None` when the roadmap was
    not read: the Brief's *items in motion* says *not checked* then, never `0` (row 65).

    Broken looks like: a roadmap nobody read counted as nothing in motion, or a done item counted as in motion."""
    r = (st.get("subjects") or {}).get("roadmap") or {}
    if not r.get("read"):
        return None
    c = r.get("counts") or {}
    return int(c.get("claimed") or 0) + int(c.get("verifying") or 0)


WINDOW_DAY, WINDOW_MONTH = dt.timedelta(hours=24), dt.timedelta(days=30)


def _when(v: Any) -> dt.datetime | None:
    try:
        t = dt.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


def throughput(st: dict[str, Any], now: dt.datetime) -> dict[str, Any]:
    """Pull requests merged and items built, in the last 24 hours and the last 30 days, from one org's reading.

    Two sources, each read for how far back it reaches (measured 2026-10-08 on 0.60.5, org-core: `pr_index` is ONE page of the
    100 pull requests most recently updated, and reached back to 2026-09-24, 14 days). A merged pull request was last updated no
    earlier than its merge, so the index holds every merge in a window it reaches back past; a full page whose oldest row is
    newer than the window's start does not, and its figure is `partial` with the date it reaches back to: a shorter window
    is never printed as a month. Items are dated by `tempo._item_history`: built = the first of `verifying_at` / `done_at`;
    a truncated (shallow) history is `partial`. A source nobody read is `{"read": False}`: not checked, never `0`.

    Broken looks like: a 14-day figure presented as 30 days, a source that failed counted as 0, or an item counted twice."""
    sub = st.get("subjects") or {}
    d1, d30 = now - WINDOW_DAY, now - WINDOW_MONTH

    def tally(stamps: list[dt.datetime]) -> dict[str, int]:
        return {"d1": sum(1 for t in stamps if t >= d1), "d30": sum(1 for t in stamps if t >= d30)}

    idx = sub.get("pr_index")
    if not isinstance(idx, list):
        prs: dict[str, Any] = {"read": False, "why": str(sub.get("pr_index_why") or "the pull-request index was not read")}
    else:
        from .tempo import PR_INDEX_KEPT
        seen = [t for t in (_when(p.get("updated_at")) for p in idx) if t]
        reach = min(seen) if seen else None
        partial = len(idx) >= PR_INDEX_KEPT and (reach is None or reach > d30)
        prs = {"read": True, **tally([t for t in (_when(p.get("merged_at")) for p in idx) if t]),
               "partial": partial, "since": reach.isoformat(timespec="seconds") if partial and reach else None}
    hist = (sub.get("roadmap") or {}).get("history") or {}
    if not hist.get("read"):
        items: dict[str, Any] = {"read": False, "why": str(hist.get("why") or "the item history was not read")}
    else:
        built = []
        for h in (hist.get("items") or {}).values():
            ts = [t for t in (_when(h.get("verifying_at")), _when(h.get("done_at"))) if t]
            if ts:
                built.append(min(ts))
        items = {"read": True, **tally(built), "partial": bool(hist.get("shallow")), "since": None}
    return {"prs": prs, "items": items, "at": now.isoformat(timespec="seconds")}


WINDOW_WEEK = dt.timedelta(days=7)
ACCOMPLISHED_SHOWN = 8       # rows listed per window; the rest are counted, never silently dropped


def queue(st: dict[str, Any], now: dt.datetime) -> dict[str, Any]:
    """What left the queue, and what is left, from one org's reading (the operator, 2026-10-08: finished work "doesn't show on
    the command center").

    `accomplished` lists, newest first, the items that reached `verifying` or `done` (dated by `tempo._item_history`, the first
    of the two) and the pull requests merged (`pr_index.merged_at`), in the last 24 hours and the last 7 days, each by name, with
    when and, where the reading knows it, by whom and a link. Handoffs answered are not listed: the reading dates no answer.
    `counts` are items ready and being built (`roadmap.counts`, which holds the served store's claims), pull requests open (not draft) with
    no verdict yet (joined from the full read; `None` when it was not read), and pull requests open with a SOUND verdict waiting to merge (`chair.open_sound`; CI is not read, so "green"
    is not claimed). `trend` is seven points, one per day, each day ending 23:59:59 UTC, the last at the reading: items opened and not yet `verifying`/`done`, plus pull
    requests opened and not yet closed or merged, rebuilt from `opened_at` / `verifying_at` / `done_at` / `merged_at` /
    `closed_at`; the four-way split is not dated anywhere, so it is not drawn. `empty` is true only when the roadmap and the pull
    requests were both read and nothing is ready, built or waiting; then `last` is the latest thing that left.

    Broken looks like: a source nobody read drawn as `0` (each part says `read: False` with why), a verifying item counted twice
    in the window, an item or pull request dated by a `created_at` the index does not carry, `empty` true over an unread source,
    or the trend's last point disagreeing with the day's open pull requests."""
    sub = st.get("subjects") or {}
    d1, d7 = now - WINDOW_DAY, now - WINDOW_WEEK
    links = sub.get("links") or {}
    repo = links.get("repo")
    idx = sub.get("pr_index")
    prs_read = isinstance(idx, list)
    rm = sub.get("roadmap") or {}
    hist = rm.get("history") or {}
    items_read = bool(rm.get("read"))
    hist_read = bool(hist.get("read"))
    titles = {i.get("key"): i for i in rm.get("items") or []}
    far = now + WINDOW_MONTH
    done: list[dict[str, Any]] = []
    lives: list[tuple[dt.datetime, dt.datetime]] = []      # (opened, left the queue or far in the future) per item
    if hist_read:
        for key, h in (hist.get("items") or {}).items():
            if h.get("deleted"):
                continue
            ts = [t for t in (_when(h.get("verifying_at")), _when(h.get("done_at"))) if t]
            opened = _when(h.get("opened_at"))
            if opened:
                lives.append((opened, min(ts) if ts else far))
            if not ts:
                continue
            row = titles.get(key) or {}
            done.append({"kind": "item", "what": str(row.get("title") or key), "key": key, "at": min(ts).isoformat(timespec="seconds"),
                         "by": row.get("claimed_by"),
                         "url": (f"https://github.com/{repo}/blob/{links.get('branch') or 'main'}/"
                                 f"{links.get('items_dir') or 'roadmap/items'}/{key}.yaml" if repo else None)})
    if prs_read:
        for p in idx:
            t = _when(p.get("merged_at"))
            if t:
                done.append({"kind": "pr", "what": f"#{p.get('number')} {p.get('title') or ''}".strip(), "number": p.get("number"),
                             "at": t.isoformat(timespec="seconds"), "by": p.get("author_role") or p.get("role"),
                             "url": p.get("url") or (f"https://github.com/{repo}/pull/{p.get('number')}"
                                                     if repo and p.get("number") else None)})
    done.sort(key=lambda r: r["at"], reverse=True)
    win1 = [r for r in done if _when(r["at"]) >= d1]
    win7 = [r for r in done if _when(r["at"]) >= d7]
    why = [w for w in ((None if hist_read else str(hist.get("why") or "the item history was not read")),
                       (None if prs_read else str(sub.get("pr_index_why") or "the pull-request index was not read"))) if w]
    out: dict[str, Any] = {
        "at": now.isoformat(timespec="seconds"),
        "accomplished": {"d1": win1[:ACCOMPLISHED_SHOWN], "d1_n": len(win1), "d7": win7[:ACCOMPLISHED_SHOWN], "d7_n": len(win7),
                         "items_read": hist_read, "prs_read": prs_read, "partial": bool(hist.get("shallow")), "why": why}}
    # the index carries no verdict (`gather_pr_index`: "no review and no check"); verdicts come from the full read, `subjects.prs`, joined
    # on number. Drafts are dropped there too, so they are dropped here: the two lists must agree on what is open.
    full = sub.get("prs")
    full_read = not sub.get("prs_why") and isinstance(full, list)
    verdict_at = {p.get("number"): p.get("first_verdict_at") for p in full} if full_read else {}
    open_prs = [p for p in idx if p.get("opened_at") and not p.get("draft")
                and not (p.get("merged_at") or p.get("closed_at"))] if prs_read else []
    c = rm.get("counts") or {}
    chair = sub.get("chair") or {}
    counts: dict[str, Any] = {"read": items_read and prs_read}
    if items_read:
        counts["ready"], counts["building"] = int(c.get("ready") or 0), int(c.get("claimed") or 0)
    if prs_read:
        counts["pr_open"] = len(open_prs)
        counts["pr_no_verdict"] = (sum(1 for p in open_prs if not verdict_at.get(p.get("number"))) if full_read else None)
        counts["pr_sound"] = int(chair.get("open_sound") or 0) if chair.get("read") else None
    out["counts"] = counts
    if hist_read and prs_read:
        spans = [(_when(p.get("opened_at")), _when(p.get("merged_at") or p.get("closed_at"))) for p in idx if p.get("opened_at") and not p.get("draft")]
        points = []
        for back in range(6, -1, -1):
            end = now if back == 0 else (now - dt.timedelta(days=back)).replace(hour=23, minute=59, second=59, microsecond=0)
            n_items = sum(1 for a, b in lives if a <= end < b)
            n_prs = sum(1 for a, b in spans if a and a <= end and (b is None or b > end))
            points.append({"day": end.date().isoformat(), "items": n_items, "prs": n_prs, "total": n_items + n_prs})
        out["trend"] = {"read": True, "points": points, "partial": bool(hist.get("shallow")) or len(idx) >= _pr_kept()}
    else:
        out["trend"] = {"read": False, "why": "; ".join(why)}
    if counts["read"]:
        waiting = counts["ready"] + counts["building"] + len(open_prs)
        out["empty"] = waiting == 0
        out["last"] = done[0] if (waiting == 0 and done) else None
    else:
        out["empty"], out["last"] = None, None
    return out


def _pr_kept() -> int:
    from .tempo import PR_INDEX_KEPT
    return PR_INDEX_KEPT


def read(orgs: list[dict[str, Any]], now: dt.datetime | None = None) -> dict[str, Any]:
    """The fleet as one document. `orgs` is a list of `{org, status|None, why, fleet}`."""
    now = now or dt.datetime.now(dt.timezone.utc)
    rows, strip, dark, said = [], [], [], []
    for o in orgs:
        org, st = o["org"], o.get("status")
        if st is None:
            strip.append({"id": org["id"], "repo": org.get("repo"), "state": DARK,
                          "read": o.get("why") or "not read"})
            dark.append({"id": org["id"], "why": o.get("why") or "not read"})
            continue
        rows += needs_you(st, org, now)
        said += answered(st, org)
        cells = machinery(st, o.get("fleet"))
        bad = [k for k, c in cells.items() if c["state"] == RED]
        strip.append({"id": org["id"], "repo": org.get("repo"), "cells": cells, "signals": list(SIGNALS),
                      "state": RED if bad else (DARK if any(c["state"] == DARK for c in cells.values()) else CLEAR),
                      "read": (", ".join(bad) if bad else "all clear"), "motion": motion(st),
                      "throughput": throughput(st, now), "queue": queue(st, now),
                      "pr_daily": (st.get("subjects") or {}).get("pr_daily"),
                      "item_daily": (st.get("subjects") or {}).get("item_daily")})
    # what only the operator can decide comes first: a handoff another CEO can decide is waiting on them, not on you
    seen: dict[str, int] = {}
    for r in rows + said:               # two items that are truly the same thing must not share an address: the second is `-2`
        seen[r["fid"]] = seen.get(r["fid"], 0) + 1
        if seen[r["fid"]] > 1:
            r["fid"] = f"{r['fid']}-{seen[r['fid']]}"
    rows.sort(key=lambda r: ((r.get("handoff") or {}).get("decides", "operator") != "operator",
                             -(len(r["cost"]["roles"]) + len(r["cost"]["sessions"])), -(r["hours"] or 0)))
    blocking = [r for r in rows if r["cost"]["roles"] or r["cost"]["sessions"]]
    # the operator, 2026-10-04: the CEO leaves a recommendation or a choice in the item whenever possible. What is counted is
    # what the CEO was asked for — a decision item — and "carries one" means a handoff that states one, not merely exists
    asked = [r for r in rows if r.get("kind") == "decision" or r.get("handoff")]
    carry = [r for r in asked if r.get("handoff") and not r["handoff"].get("no_recommendation")]
    live = [s for s in strip if s.get("cells")]
    zones = {((o.get("org") or {}).get("operator") or {}).get("timezone") for o in orgs if isinstance(o.get("org"), dict)} - {None}
    return {"kind": "org-command", "at": now.isoformat(timespec="seconds"), "orgs": strip, "dark": dark,
            "operator_timezone": zones.pop() if len(zones) == 1 else "UTC",   # one operator, one zone; disagreeing orgs read UTC
            "state": RED if any(s["state"] == RED for s in live) or rows else (DARK if dark else CLEAR),
            "needs_you": rows, "shown": rows[:SECTION_ROWS * 2], "more": rows[SECTION_ROWS * 2:],
            # what the operator already answered, newest answer first, apart from `needs_you` and never counted with it (0.63.1)
            "answered": sorted(said, key=lambda r: str(r.get("answered_at") or ""), reverse=True),
            "blocking": len(blocking), "signals": list(SIGNALS),
            "recommended": {"n": len(carry), "of": len(asked)},
            "verdict": _verdict(rows, blocking, strip, dark)}


def tempo(presence: dict[str, Any] | None) -> dict[str, Any]:
    """One org's tempo knobs for the fleet page (SPEC §10): each role with its cadence, the edges it owns as last
    measured, the knob in effect, and the range the operator may set. Speed is read per edge before it is set."""
    return {"roles": [{"role": r.get("role"), "name": r.get("name"), "cadence": r.get("cadence"), "knob": r.get("knob"),
                       "range": r.get("knob_range"), "owns": r.get("owns") or [], "wake_on": r.get("wake_on") or []}
                      for r in (presence or {}).get("roles") or []]}


def _plural(n: int, one: str, many: str | None = None) -> str:
    """`1 org`, `2 orgs`. A verdict is the one sentence a person reads; `1 org(s)` reads as a machine's."""
    return f"{n} {one if n == 1 else (many or one + 's')}"


def _verdict(rows, blocking, strip, dark) -> str:
    live = [s for s in strip if s.get("cells")]
    red = [s for s in live if s["state"] == RED]
    if not rows:
        head = "Nothing is waiting on you"
    else:
        dated = [r for r in rows if r["hours"] is not None and r.get("ago")]
        # across the orgs that are actually waiting, not the orgs that could be read — those differ the
        # moment one org is clear, and the reader is counting the places they have to go.
        spread = _plural(len({r["org"] for r in rows}), "org")
        head = (f"{_plural(len(rows), 'thing')} {'is' if len(rows) == 1 else 'are'} waiting on you across {spread}"
                # an item with no date has no age: "the oldest for ." was a served fleet of undated items (0.42.0)
                + (f", the oldest for {max(dated, key=lambda r: r['hours'])['ago']}" if dated else ""))
        if blocking:
            head += (f", and {len(blocking)} of them {'names' if len(blocking) == 1 else 'name'} "
                     "something a role is stopped on")
    tail = (f" {len(red)} of {_plural(len(live), 'org')} {'has' if len(red) == 1 else 'have'} something red in the machinery." if red else
            " The machinery is clear everywhere it could be read.")
    return _sentence(head) + tail + (
        f" {_plural(len(dark), 'org')} could not be read at all." if dark else "")


def render(d: dict[str, Any]) -> str:
    """The console in a terminal. Same reading, same order: the verdict, the matrix, then the work."""
    L = [f"command — the fleet at {d['at']}", f"  {d['verdict']}", ""]
    w = max((len(o["id"]) for o in d["orgs"]), default=8)
    L.append("  " + "org".ljust(w + 2) + "  ".join(s.ljust(22) for s in d["signals"]))
    for o in d["orgs"]:
        if not o.get("cells"):
            L.append("  " + o["id"].ljust(w + 2) + f"not read — {o['read']}")
            continue
        L.append("  " + o["id"].ljust(w + 2)
                 + "  ".join(f"{'●' if o['cells'][k]['state'] == 'RED' else ('○' if o['cells'][k]['state'] == 'CLEAR' else '—')} "
                             f"{o['cells'][k]['read']}".ljust(22) for k in d["signals"]))
    L.append("")
    L.append(f"waiting on you: {len(d['needs_you'])}" + (f", {d['blocking']} naming something a role is stopped on"
                                                         if d["blocking"] else ""))
    for r in d["needs_you"]:
        L.append(f"  [{r['org']}] {r['what']}  ({r['ago']})")
        c = r["cost"]
        if c["roles"] or c["sessions"]:
            L.append(f"      blocks {', '.join(c['roles'] + c['sessions'])} — both name {', '.join(c['on'])}")
    if d.get("answered"):
        L += ["", f"answered on the board, with the CEO: {len(d['answered'])} (not counted above)"]
        for r in d["answered"]:
            L.append(f"  [{r['org']}] {r['what']}  ({'the CEO acted' if r['acted'] else 'not acted on yet'})")
    return "\n".join(L) + "\n"
