"""The shell both pages are read through, and its first two views: Brief and Decide (SPEC row 186).

The operator, 2026-10-04, handing over a design for the dashboard: *"new UI for the dashboard"* — one shell for the org page
and the fleet console, a scope bar and six views, of which the first two are the operator's channel to the CEO (rows 181–182):
**Brief**, what needs them and how the fleet is, and **Decide**, the decisions themselves, one at a time, with the CEO's
recommendation beside each. Asked how to roll it out and what to build first, the operator ruled: *replace the current pages in
place*, and *shell + Brief + Decide* first. So the other four views (Team, Work, Machinery, Standing rules) carry today's
sections unchanged, in the new shell, until each is redone in its own change. **Team** is the first of those (0.59.0, item
`command-center-v2-remaining-views`): `team_model` groups the roster by what a message would do — stopped on you, unreachable, never
registered, in motion, listening, between turns — and links each stopped role to the decision that names it; its controls are the
ones `controls.JS` already hangs on a row. Work and Machinery are still today's sections.

What this module is, and is not:

- **One model, two renderers.** `org_model` and `fleet_model` turn a reading into the same shape (numbers, the most urgent card,
  every card, the lines), so the org page and the fleet console cannot say different things about the same queue. The server
  renders the model at rest; the served org page swaps that same HTML in on a newer reading (`dashboard.reading_doc` fragments)
  and the fleet console reloads on a new `rev`, as before. A published page paints the model with `JS`'s painter.
- **Nothing here sends.** A card's answer is the ask the page already sends (`HANDOFF_JS` for a handoff, `controls.JS` for a
  ruling): recorded on the org's board and relayed to its CEO (rule 6). A page that cannot send says so beside the card and
  offers the same words to copy.
- **A thing the reading cannot say is said as not read** — never `0`, never the all-clear (row 65): a queue whose second half
  could not be read says *not checked*, a roster nobody read says *not read*.
- **Colour is a state, a shape is a thing** (rule 8): every mark here is `vocab`'s, in `vocab`'s five states; the shell defines no
  hue of its own.

Not built, and said (SPEC row 186): *Since you last looked* (no feed of changes exists to read it from), *Sent* (the asks are on
the Team view until it is redone), the design's *Make this a standing rule* (the draft-and-approve flow it opens does not exist),
an *Undo* on a recorded ask (a recorded ask cannot be taken back, only answered), and the in-page scope switch (each scope is
its own document; the chips are links).
"""

from __future__ import annotations

import datetime as dt
import html
import json
import re
from typing import Any

#: the six views, in the order the keys 1–6 and the tabs take them
VIEWS = (("brief", "Brief"), ("decide", "Decide"), ("team", "Team"), ("work", "Work"), ("machinery", "Machinery"),
         ("rules", "Standing rules"))

#: the status words the pages already write (`RED`, `CLEAR`, `DARK`, `OPEN`) as the five states of `vocab`
STATE = {"RED": "crit", "CLEAR": "ok", "DARK": "idle", "OPEN": "wait"}

KIND_WORDS = {"decision": "decision", "pr": "pull request", "permission": "permission prompt"}


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""))


def mark(state: str, extra: str = "") -> str:
    """A state's shape, in its colour: `vocab`'s glyph over `currentColor`, and never alone — every place that draws one also
    writes the state in words."""
    return f"<i class='sg s-{_e(state)} g-{_e(state)}{(' ' + extra) if extra else ''}' aria-hidden='true'></i>"


def icon(entity: str) -> str:
    """An entity's icon, in ink (`vocab.ICONS`): what the thing *is*, never how it is."""
    return f"<i class='ic ic-{_e(entity)}' aria-hidden='true'></i>"


# --- the model -----------------------------------------------------------------------------------------------------

def team_counts(p: dict[str, Any] | None) -> dict[str, int] | None:
    """What the roster says about the people the operator would wait on: roles stopped on a prompt or a question, roles nothing is
    listening for, roles listening. `None` when the roster was not read — *not read* is neither 0 nor all well (row 65).

    Broken looks like: an unread roster counted as no role stopped, or a role registered and gone counted as listening."""
    if not p or not p.get("read"):
        return None
    roles = p.get("roles") or []

    def bucket(r: dict[str, Any]) -> str:
        return str((r.get("session") or {}).get("bucket") or "").lower().replace("session_status_bucket_", "")
    # unreachable is what the fleet's *reachable* signal calls it (`command.machinery`): registered and gone, or never registered —
    # nothing can be sent to either, so neither is a role that is well
    return {"stopped": sum(1 for r in roles if bucket(r) == "blocked"),
            "gone": sum(1 for r in roles if r.get("state") in ("gone", "unregistered")),
            "listening": sum(1 for r in roles if r.get("state") == "parked"), "total": len(roles)}


def _team_number(c: dict[str, int] | None) -> dict[str, Any]:
    if c is None:
        return {"k": "roles stopped or unreachable", "v": "not read", "mark": "idle", "view": "team",
                "note": "the roster was not read"}
    if not c["total"]:                       # a roster that lists no role has nobody to be well: not a pass
        return {"k": "roles stopped or unreachable", "v": "none", "mark": "idle", "view": "team", "note": "no role is on the roster"}
    n = c["stopped"] + c["gone"]
    return {"k": "roles stopped or unreachable", "v": str(n), "view": "team",
            "mark": "crit" if c["gone"] else ("wait" if c["stopped"] else "ok"),
            "note": f"{c['stopped']} stopped on you · {c['gone']} unreachable"}


def _red_number(cells: list[dict[str, str]], unread_orgs: int = 0) -> dict[str, Any]:
    """Red signals in the machinery, counted from the fleet console's own cells so the org page and the fleet say the same
    number. `0` is green only when every cell was measured: a grey cell is *not checked*, and zero beside it is not a pass."""
    red = sum(1 for c in cells if c["state"] == "RED")
    dark = sum(1 for c in cells if c["state"] == "DARK")
    note = ", ".join(x for x in (f"{dark} not checked" if dark else "", f"{unread_orgs} org not read" if unread_orgs == 1 else
                                 f"{unread_orgs} orgs not read" if unread_orgs else "") if x)
    return {"k": "red in the machinery", "v": str(red), "view": "machinery", "note": note,
            "mark": "crit" if red else ("idle" if dark or unread_orgs or not cells else "ok")}


def _motion_number(n: int | None, unread: int = 0) -> dict[str, Any]:
    if n is None:
        return {"k": "items in motion", "v": "not checked", "mark": "idle", "view": "work", "note": "the roadmap was not read"}
    return {"k": "items in motion", "v": str(n), "mark": "live", "view": "work",
            "note": f"{unread} org not read" if unread == 1 else (f"{unread} orgs not read" if unread else "")}


#: the lead of a recommendation the CEO could not form (`--recommend "none yet: needs …"`), as `handoffs.lines` strips it
_NONE_YET = re.compile(r"^none(\s+yet)?\s*[:\-—]*\s*", re.I)


def _prompt(c: dict[str, Any], read_at: str) -> str:
    """A copied prompt is a brief, not a verdict (`explorer`'s rule): what this reading saw and when, and a session that is told to
    read the source before it advises — a page is a reading, and a reading ages (SPEC Appendix A, row 40)."""
    h = c.get("handoff") or {}
    plain = lambda t: str(t).replace("`", "")   # noqa: E731 — the roles write markdown; a prompt is plain words
    c = {**c, "what": plain(c["what"]), "why": plain(c.get("why") or ""), "where": plain(c.get("where") or "")}
    h = {**h, "recommend": plain(h.get("recommend") or ""), "cost": plain(h.get("cost") or ""),
         "options": [plain(o) for o in h.get("options") or []]}
    out = [f"I'm deciding something in {c.get('repo') or c['org']} and want help thinking it through.", "", f"What: {c['what']}"]
    if c.get("why"):
        out.append(f"Why it is on me: {c['why']}")
    from . import handoffs as hf
    if h.get("recommend") and hf.no_recommendation(h):
        need = _NONE_YET.sub("", str(h["recommend"]).strip())
        out.append("The CEO has left no recommendation yet" + (f" ({need})" if need else "") + ".")
    elif h.get("kind") == "close_item":
        out.append(f"The CEO's recommendation: {plain(hf.ceo_says(h))}")
        out.append(f"{h.get('by') or 'The role that filed it'} recommends: {h.get('recommended_option') or ''}: {h['recommend']}")
    elif h.get("recommend"):
        out.append(f"The CEO's recommendation: {h['recommend']}")
    for o in h.get("options") or []:
        out.append(f"Option: {o}")
    if h.get("cost"):
        out.append(f"What waiting costs: {h['cost']}")
    if c.get("holding"):
        out.append("Stopped on it: " + ", ".join(x["name"] for x in c["holding"]))
    out += ["", f"Read {c.get('where') or c.get('source') or 'the item'} in the repository's default branch first — this is a "
                f"reading from {read_at} and may be old — then tell me what you would do and why."]
    return "\n".join(out)


def carries_recommendation(h: dict[str, Any] | None) -> bool:
    """A handoff that states a recommendation: `recommended_option` or a `recommend` that is not the CEO's "none yet: …". The one test the
    Decide view's default, its counts and `rec_line` share, so the view and the figure beside it cannot disagree."""
    from . import handoffs as hf
    return bool(h) and (bool(h.get("recommended_option")) or (bool(str(h.get("recommend") or "").strip()) and not hf.no_recommendation(h)))


def rec_state(h: dict[str, Any] | None, handoffs_read: bool | None) -> str:
    """`rec` (a recommendation is recorded), `none` (the record was read and holds none), or `unread` (the board's handoffs were not read, so
    whether this item carries one is unknown — counted as *not checked*, never as none: CLAUDE.md rule 9)."""
    if carries_recommendation(h):
        return "rec"
    return "none" if h or handoffs_read else "unread"


def rec_counts(cards: list[dict[str, Any]]) -> dict[str, int]:
    return {k: sum(1 for c in cards if c.get("recstate") == k) for k in ("rec", "none", "unread")}


def card_from_item(i: dict[str, Any], *, org: str, ceo: str, repo: str | None, tz: str | None, read_at: str,
                   names: dict[str, str] | None = None, page: str = "") -> dict[str, Any]:
    """One waiting item from an org's brief (`brief._you`) as a Decide card."""
    from .dashboard import _clock
    holds = i.get("holds") or {}
    holding = ([{"role": r, "name": (names or {}).get(r) or r} for r in holds.get("roles") or []]
               + [{"role": "", "name": s} for s in holds.get("sessions") or []])
    c = {"fid": i["fid"], "org": org, "kind": "decision", "kind_label": KIND_WORDS["decision"], "what": i["what"],
         "why": i.get("why") or "", "quote": i.get("quote") or "", "ago": i.get("ago") or "", "hours": i.get("hours"),
         "at": i.get("at") or "", "written": _clock(i["at"], tz) if i.get("at") else "",
         "where": i.get("where") or i.get("source") or "", "mark": "crit" if holding else "wait", "holding": holding,
         "on": list(holds.get("on") or []), "handoff": i.get("handoff"), "norec": bool(i.get("norec")), "counts": bool(i.get("counts", True)),
         "recstate": rec_state(i.get("handoff"), i.get("hread")),
         "ask_key": i.get("ask_key") or "", "ceo": ceo, "repo": repo, "page": page,
         "item": i.get("item"), "arc": i.get("arc"), "item_moved": i.get("item_moved"), "action": {"label": "", "href": ""},
         **_said(i, tz)}
    c["prompt"] = _prompt(c, read_at)
    return c


def card_from_row(r: dict[str, Any], *, ceo: str, repo: str | None, tz: str | None, read_at: str, names: dict[str, str],
                  page: str) -> dict[str, Any]:
    """One waiting row from the fleet reading (`command.needs_you`) as a Decide card."""
    from .dashboard import _clock
    cost = r.get("cost") or {"roles": [], "sessions": [], "on": []}
    # a stopped role is an agent (a link and a card) only where its org's roster was read and names it
    holding = ([{"role": k if k in names else "", "name": names.get(k) or k} for k in cost.get("roles") or []]
               + [{"role": "", "name": s} for s in cost.get("sessions") or []])
    c = {"fid": r["fid"], "org": r["org"], "kind": r.get("kind") or "decision",
         "kind_label": KIND_WORDS.get(r.get("kind") or "decision", str(r.get("kind"))), "what": r["what"],
         "why": r.get("why") or "", "quote": "", "ago": r.get("ago") or "", "hours": r.get("hours"), "at": r.get("at") or "",
         "written": _clock(r["at"], tz) if r.get("at") else "", "where": r.get("source") or "",
         "mark": "crit" if holding else "wait", "holding": holding, "on": list(cost.get("on") or []),
         "handoff": r.get("handoff"), "norec": r.get("kind") == "decision" and not r.get("handoff"), "ask_key": "",
         "counts": bool(r.get("counts", True)),
         "recstate": rec_state(r.get("handoff"), r.get("hread")),
         "ceo": ceo, "repo": repo, "page": page, "item": r.get("item"), "arc": r.get("arc"), "item_moved": r.get("item_moved"),
         "action": r.get("action") or {"label": "", "href": ""}, **_said(r, tz)}
    c["prompt"] = _prompt(c, read_at)
    return c


def _said(i: dict[str, Any], tz: str | None) -> dict[str, Any]:
    """What the operator already said on an answered item (`status.answered_apart`), each answer dated in the operator's zone with the
    UTC instant beside it (rule 7); nothing for a waiting one."""
    from .dashboard import _clock
    if "said" not in i:
        return {}
    return {"said": [{**a, "when": _clock(a["at"], tz) if a.get("at") else ""} for a in i.get("said") or []],
            "acted": bool(i.get("acted")), "answered_at": i.get("answered_at"),
            "answered_when": _clock(i["answered_at"], tz) if i.get("answered_at") else ""}


def _ceo_of(presence: dict[str, Any] | None) -> str:
    for r in (presence or {}).get("roles") or []:
        if r.get("role") == "ceo" and r.get("name"):
            return str(r["name"])
    return "the CEO"


def rec_line(cards: list[dict[str, Any]]) -> str:
    """How many of what waits on the operator arrive with the CEO's recommendation — the measure of the operator's load the CEO is asked
    to lower (row 182), counted as `command.read` counts it: a decision, or anything a handoff was written for, and "carries one" means
    a handoff that states one, not merely exists."""
    from .dashboard import _rec_line
    asked = [c for c in cards if c["kind"] == "decision" or c.get("handoff")]
    carry = [c for c in asked if carries_recommendation(c.get("handoff"))]
    from . import handoffs as hf
    base = _rec_line({"n": len(carry), "of": len(asked)}) if asked else ""
    miss = hf.missing_line(hf.missing(cards))
    return f"{base} {miss}".strip()


def _lines_org(b: dict[str, Any], team: dict[str, int] | None) -> list[dict[str, Any]]:
    nums = {n["label"]: n for n in b.get("numbers") or []}
    out = []
    n = nums.get("Last shipped")
    if n:
        out.append({"k": "Shipping", "v": f"{n['value']} · {n['note']}", "mark": STATE.get(n["tone"], "idle"), "view": "work"})
    if team is None:
        out.append({"k": "Team", "v": "not read — the roster was not read", "mark": "idle", "view": "team"})
    elif not team["total"]:
        out.append({"k": "Team", "v": "no role is on the roster", "mark": "idle", "view": "team"})
    else:
        out.append({"k": "Team", "v": f"{team['stopped']} stopped on you · {team['gone']} unreachable · {team['listening']} listening",
                    "mark": "crit" if team["gone"] else ("wait" if team["stopped"] else "ok"), "view": "team"})
    n = nums.get("On the installed version")
    if n:
        out.append({"k": "Version", "v": f"{n['value']} · {n['note']}", "mark": STATE.get(n["tone"], "idle"), "view": "machinery"})
    return out


def _tabs(decide: int, team: dict[str, int] | None, red: int, work: int | None, rules: int | None) -> dict[str, dict[str, Any]]:
    return {"decide": {"n": str(decide) if decide else "", "tone": "wait"},
            "team": {"n": (f"{team['stopped'] + team['gone']} stopped" if team and (team['stopped'] + team['gone']) else ""),
                     "tone": "crit"},
            "work": {"n": str(work) if work else "", "tone": ""},
            "machinery": {"n": f"{red} red" if red else "", "tone": "crit"},
            "rules": {"n": str(rules) if rules else "", "tone": ""}}


ACC_SHOWN = 8


def _throughput_numbers(parts: list[dict[str, Any]], tz: str | None, unread: int = 0) -> list[dict[str, Any]]:
    """Two tiles, pull requests merged and items built: the last 24 hours beside the last 30 days and its per-day average.
    `parts` is one `command.throughput` per org read. A source none of them read says *not checked*, never `0`; a figure any of
    them could only partly see says *at least* and the date it reaches back to (SPEC row 191)."""
    from .clock import for_operator
    out = []
    total = len(parts) + unread
    for key, label in (("prs", "pull requests merged"), ("items", "items built")):
        got = [p[key] for p in parts if p[key].get("read")]
        if not got:
            why = parts[0][key]["why"] if len(parts) == 1 else "no org's source was read"
            out.append({"k": f"{label} · 24 h", "v": "not checked", "mark": "idle", "view": "work", "note": why})
            continue
        d1, d30 = sum(g["d1"] for g in got), sum(g["d30"] for g in got)
        part = [g for g in got if g["partial"]]
        since = sorted(g["since"] for g in part if g.get("since"))
        note = f"30 d: {'at least ' if part else ''}{d30} · {d30 / 30:.1f}/day"
        if since:
            note += f" · read back only to {for_operator(dt.datetime.fromisoformat(since[-1]), tz)}"
        elif part:
            note += " · history truncated"
        if total > 1 or len(got) < total:
            note += f" · {len(got)} of {total} orgs read"
        trunc = any(g["partial"] and not g.get("since") for g in got)     # a truncated history undercounts the day too
        out.append({"k": f"{label} · 24 h", "v": f"at least {d1}" if trunc else str(d1), "mark": "live", "view": "work", "note": note})
    return out


def queue_view(parts: list[dict[str, Any]], tz: str | None, unread: int = 0, scoped: bool = False) -> dict[str, Any]:
    """The Brief's *Accomplished* section, as text the page and its live painter both print: what left the queue in the last 24 hours
    and 7 days by name and time, the explicit *Queue empty*, the four counts, and the seven-day line of the total. `parts` is one
    `command.queue` per org read (`scoped` names the org on each row). A part nobody read says *not checked* and why, never `0`.

    Broken looks like: `Queue empty` over an org whose roadmap or pull requests were not read, a zero where a source failed, a row
    with no time, or a fleet total that hides how many orgs were read."""
    from .clock import for_operator
    total = len(parts) + unread

    def when(iso: str) -> str:
        return for_operator(dt.datetime.fromisoformat(iso), tz)
    if not parts:
        return {"read": False, "why": "no org's reading could be taken", "empty": None, "counts": [], "trend": None, "windows": [], "notes": []}
    out: dict[str, Any] = {"read": True, "why": "", "notes": []}
    if total > 1 or unread:
        out["notes"].append(f"{len(parts)} of {total} orgs read")
    windows = []
    for key, label in (("d1", "Last 24 hours"), ("d7", "Last 7 days")):
        if not any(p["accomplished"]["items_read"] or p["accomplished"]["prs_read"] for p in parts):
            windows.append({"h": label, "n": None, "rows": [], "more": 0, "why": "; ".join(p["accomplished"]["why"][0] for p in parts if p["accomplished"]["why"])})
            continue
        rows = sorted((dict(r, org=p.get("org")) for p in parts for r in p["accomplished"][key]), key=lambda r: r["at"], reverse=True)
        n = sum(p["accomplished"][f"{key}_n"] for p in parts)
        shown = rows[:ACC_SHOWN]
        windows.append({"h": label, "n": n, "more": n - len(shown), "why": "",
                        "rows": [{"t": (f"{r['org']} · " if scoped and r.get("org") else "") + f"{r['what']} · {'merged' if r['kind'] == 'pr' else 'reached verifying/done'}"
                                      + (f" · {r['by']}" if r.get("by") else "") + f" · {when(r['at'])}", "u": r.get("url") or ""} for r in shown]})
    out["windows"] = windows
    miss = [p["accomplished"] for p in parts if not (p["accomplished"]["items_read"] and p["accomplished"]["prs_read"])]
    if miss:
        out["notes"].append("not fully checked: " + "; ".join(w for m in miss for w in m["why"]))
    if any(p["accomplished"]["partial"] for p in parts):
        out["notes"].append("the item history is shallow in a shallow clone, so older items are undated")
    cs = [p["counts"] for p in parts]
    got = [c for c in cs if c["read"]]
    if got:
        sound = [c["pr_sound"] for c in got]
        out["counts"] = [
            {"k": "ready", "v": str(sum(c["ready"] for c in got))},
            {"k": "being built", "v": str(sum(c["building"] for c in got))},
            {"k": "pull requests without a verdict",
             "v": "not checked" if any(c["pr_no_verdict"] is None for c in got) else str(sum(c["pr_no_verdict"] for c in got))},
            {"k": "pull requests with a SOUND verdict, waiting to merge",
             "v": "not checked" if any(x is None for x in sound) else str(sum(sound))}]
    else:
        out["counts"] = [{"k": "queue counts", "v": "not checked"}]
    empties = [p["empty"] for p in parts]
    out["empty"] = None if any(e is None for e in empties) or unread else all(empties)
    if out["empty"]:
        lasts = sorted((p["last"] for p in parts if p.get("last")), key=lambda r: r["at"], reverse=True)
        out["last"] = (f"Last to leave: {lasts[0]['what']} · {when(lasts[0]['at'])}" if lasts else "Nothing in the reading has left it yet.")
    tr = [p["trend"] for p in parts]
    if all(t["read"] for t in tr) and tr:
        pts = [sum(t["points"][i]["total"] for t in tr) for i in range(7)]
        days = [tr[0]["points"][i]["day"][5:] for i in range(7)]
        out["trend"] = {"read": True, "points": pts, "days": days,
                        "text": "Open work, 7 days to today (days end 23:59 UTC): " + " → ".join(str(x) for x in pts)
                                + " (items opened and not yet verifying or done, plus pull requests opened and not yet closed)"
                                + (" · at least — the pull-request index or item history is partial" if any(t["partial"] for t in tr) else "")}
    else:
        out["trend"] = {"read": False, "text": "Seven-day line: not checked — " + "; ".join(t.get("why") or "unread" for t in tr if not t["read"])}
    return out


def org_model(st: dict[str, Any], b: dict[str, Any], explorer_model: dict[str, Any] | None = None) -> dict[str, Any]:
    """The model for one org's own page, from its reading (`st`) and its brief (`b`)."""
    from . import command as cm
    from .dashboard import _clock
    s = st.get("subjects") or {}
    tz = st.get("operator_timezone")
    org = str(st.get("org") or "")
    repo = (s.get("links") or {}).get("repo")
    ceo = str((s.get("names") or {}).get("ceo") or "the CEO")
    names = {r: (f"{n} ({r})" if n and n.lower() != r.lower() else r) for r, n in (s.get("names") or {}).items()}
    read_at = _clock(st.get("at"), tz)
    you = next((x for x in b.get("sections") or [] if x["id"] == "you"), {"items": [], "more": []})
    cards = [card_from_item(i, org=org, ceo=ceo, repo=repo, tz=tz, read_at=read_at, names=names)
             for i in (you["items"] + you["more"])]
    answered = [card_from_item(i, org=org, ceo=ceo, repo=repo, tz=tz, read_at=read_at, names=names) for i in b.get("answered") or []]
    waiting = next((n for n in b.get("numbers") or [] if n["label"] == "Waiting on you"), None) or {}
    unread_q = waiting.get("value") == "not checked"
    team = team_counts(s.get("presence"))
    cells = list(cm.machinery(st, None).values())
    red = sum(1 for c in cells if c["state"] == "RED")
    rm = b.get("roadmap") or {}
    work = (rm.get("total", 0) - next((x["n"] for x in rm.get("legend") or [] if x["status"] == "done"), 0)) if rm.get("read") else None
    dg = s.get("delegations") or {}
    numbers = [{"k": "waiting on you", "v": waiting.get("value", str(len(cards))), "view": "decide", "note": waiting.get("note", ""),
                "mark": "idle" if unread_q else ("wait" if cards else "ok")},
               _team_number(team), _motion_number(cm.motion(st)), _red_number(cells),
               *_throughput_numbers([cm.throughput(st, dt.datetime.fromisoformat(str(st.get("at")).replace("Z", "+00:00")))], tz)]
    return {"scope": {"kind": "org", "id": org, "title": org, "eyebrow": repo or org, "read": read_at},
            "ceo": ceo, "verdict": b.get("verdict") or "", "state": b.get("state") or "DARK", "numbers": numbers,
            "queue": queue_view([cm.queue(st, dt.datetime.fromisoformat(str(st.get("at")).replace("Z", "+00:00")))], tz),
            "cards": cards, "answered": answered, "top": cards[0] if cards else None, "orgs": [], "lines": _lines_org(b, team),
            "rec": rec_line(cards), "recs": rec_counts(cards), "queue_unread": unread_q, "queue_note": waiting.get("note", ""),
            "tabs": _tabs(len(cards), team, red, work, len(dg.get("grants") or []) if dg.get("read") else None),
            "index": _index_org(org, cards, s, explorer_model, answered)}


def fleet_model(d: dict[str, Any]) -> dict[str, Any]:
    """The model for the fleet console, from `command.read` plus the served fleet's team and pages."""
    from .dashboard import _clock
    tz = d.get("operator_timezone")
    pages = d.get("pages") or {}
    team = d.get("team") or {}
    read_at = _clock(d.get("at"), tz)
    repos = {o["id"]: o.get("repo") for o in d.get("orgs") or []}
    cards = []
    for r in d.get("needs_you") or []:
        p = team.get(r["org"])
        names = {x["role"]: (f"{x['name']} ({x['role']})" if x.get("name") and x["name"].lower() != x["role"].lower() else x["role"])
                 for x in ((p or {}).get("roles") or []) if x.get("role")} if (p or {}).get("read") else {}
        cards.append(card_from_row(r, ceo=_ceo_of(p), repo=repos.get(r["org"]), tz=tz, read_at=read_at, names=names,
                                   page=pages.get(r["org"], "")))
    answered = [card_from_row(r, ceo=_ceo_of(team.get(r["org"])), repo=repos.get(r["org"]), tz=tz, read_at=read_at, names={},
                              page=pages.get(r["org"], "")) for r in d.get("answered") or []]
    live = [o for o in d.get("orgs") or [] if o.get("cells")]
    unread = [o for o in d.get("orgs") or [] if not o.get("cells")]
    counts = [team_counts(p) for oid, p in team.items() if p]
    got = [c for c in counts if c is not None]
    agg = ({k: sum(c[k] for c in got) for k in ("stopped", "gone", "listening", "total")} if got else None)
    motions = [o.get("motion") for o in live if o.get("motion") is not None]
    cells = [c for o in live for c in o["cells"].values()]
    numbers = [{"k": "waiting on you", "v": str(len(cards)), "view": "decide", "mark": "wait" if cards else "ok",
                "note": " · ".join(x for x in (f"across {len({c['org'] for c in cards})} org(s)" if cards else "",
                                               f"{len(answered)} answered, with the CEOs now, not counted" if answered else "") if x)},
               _team_number(agg), _motion_number(sum(motions) if motions else None, len([o for o in live if o.get("motion") is None])),
               _red_number(cells, len(unread)),
               *_throughput_numbers([o["throughput"] for o in live if o.get("throughput")], tz, len(unread))]
    orgs = []
    for o in d.get("orgs") or []:
        if not o.get("cells"):
            orgs.append({"id": o["id"], "mark": "idle", "ceo": "", "href": pages.get(o["id"], ""), "unread": True,
                         "line": f"not read — {o.get('read')}", "sig": []})
            continue
        n = sum(1 for c in cards if c["org"] == o["id"])
        red_k = [k for k in d.get("signals") or [] if o["cells"][k]["state"] == "RED"]
        orgs.append({"id": o["id"], "mark": STATE.get(o["state"], "idle"), "href": pages.get(o["id"], ""), "unread": False,
                     "ceo": f"{_ceo_of(team.get(o['id']))} (ceo)" if _ceo_of(team.get(o["id"])) != "the CEO" else "",
                     "sig": [{"k": k, "state": o["cells"][k]["state"], "read": o["cells"][k]["read"]} for k in d.get("signals") or []],
                     "line": f"{n} waiting on you · " + (", ".join(red_k) + " red" if red_k else "all clear")})
    reads = {k: [(o["id"], o["cells"][k]) for o in live] for k in ("shipping", "version")}

    def line(k: str, label: str, view: str) -> dict[str, Any] | None:
        if not reads[k]:
            return None
        sts = [c["state"] for _, c in reads[k]]
        # red if any org is; grey if any signal went unmeasured (a read nobody could take is not a pass); green only when all were
        return {"k": label, "v": " · ".join(f"{oid} {c['read']}" for oid, c in reads[k]), "view": view,
                "mark": "crit" if "RED" in sts else ("idle" if "DARK" in sts else "ok")}
    lines = [x for x in (line("shipping", "Shipping", "work"),) if x]
    lines.append({"k": "Team", "v": ("not read — no org's roster was read" if agg is None else
                                      "no role is on any roster" if not agg["total"] else
                                      f"{agg['stopped']} stopped on you · {agg['gone']} unreachable · {agg['listening']} listening"),
                  "mark": "idle" if agg is None or not agg["total"] else ("crit" if agg["gone"] else ("wait" if agg["stopped"] else "ok")),
                  "view": "team"})
    lines += [x for x in (line("version", "Version", "machinery"),) if x]
    return {"scope": {"kind": "fleet", "id": "fleet", "title": "The fleet", "eyebrow": "the fleet", "read": read_at},
            "ceo": "the CEO", "verdict": d.get("verdict") or "", "state": d.get("state") or "DARK", "numbers": numbers,
            "queue": queue_view([dict(o["queue"], org=o["id"]) for o in live if o.get("queue")], tz, len(unread), scoped=True),
            "cards": cards, "answered": answered, "top": cards[0] if cards else None, "orgs": orgs, "lines": lines, "rec": rec_line(cards),
            "recs": rec_counts(cards),
            "queue_unread": False, "queue_note": "",
            "tabs": _tabs(len(cards), agg, sum(1 for c in cells if c["state"] == "RED"), None, None),
            "index": _index_fleet(cards, d, answered)}


#: the roster's groups, in the order a message's effect is worst-first: (key, mark, title, what a message does to the role)
TEAM_GROUPS = (
    ("stopped", "wait", "Stopped on you", "waiting on a permission prompt or a question — a message does not help, an answer does"),
    ("unreachable", "crit", "Unreachable", "registered and not on the roster — nothing is listening; a message waits on the board"),
    ("never", "idle", "Never registered", "no agent registered for the role — nothing can be sent to it"),
    ("motion", "live", "In motion", "running a turn or on do-not-disturb — a message waits for its next look"),
    ("listening", "ok", "Listening", "a listener is parked — a message wakes it in seconds"),
    ("between", "idle", "Between turns or away", "on the roster with no listener parked — it reads a message on its next turn"),
)


def _role_group(r: dict[str, Any]) -> str:
    """The one group a role is in, by what a message would do to it. Order matters: a role whose session waits on a person is
    stopped on them whatever its listener says (the Brief counts it so, `team_counts`)."""
    bucket = str((r.get("session") or {}).get("bucket") or "").lower().replace("session_status_bucket_", "")
    if bucket == "blocked":
        return "stopped"
    state = r.get("state")
    if state == "gone":
        return "unreachable"
    if state == "unregistered":
        return "never"
    if bucket == "working" or state == "busy":
        return "motion"
    return "listening" if state == "parked" else "between"


def team_model(s: dict[str, Any], cards: list[dict[str, Any]], tz: str | None) -> dict[str, Any]:
    """The Team view's model: the roster in groups by what a message would do, each role with the decision it is stopped on (the
    Decide card that names it, by its address `#f-<fid>`), then the roles the manifest leaves off and agents no role names.
    `read` is false when the roster was not read — then there are no groups, never an empty list that reads as no one stopped (row 65).

    Broken looks like: a role in two groups or none (the groups' sizes must sum to the roles), a stopped role with no link to what
    it waits on while a card names it, or an unread roster drawn as a team with nobody on it."""
    from . import controls
    p = controls.with_cards(s.get("presence") or {}, tz)
    if not p.get("read"):
        return {"read": False, "groups": [], "others": [], "off": [], "presence": p, "total": 0}
    held: dict[str, list[dict[str, Any]]] = {}
    for c in cards:
        for h in c.get("holding") or []:
            if h.get("role"):
                held.setdefault(h["role"], []).append(c)
    by_key: dict[str, list[dict[str, Any]]] = {k: [] for k, *_ in TEAM_GROUPS}
    for r in p.get("roles") or []:
        by_key[_role_group(r)].append({**r, "stopped_on": [{"fid": c["fid"], "what": c["what"]} for c in held.get(r["role"], [])]})
    groups = [{"key": k, "mark": m, "title": t, "means": means, "roles": by_key[k]} for k, m, t, means in TEAM_GROUPS if by_key[k]]
    return {"read": True, "groups": groups, "others": p.get("others") or [], "off": p.get("off") or [], "presence": p,
            "total": len(p.get("roles") or [])}


def team_groups_html(m: dict[str, Any], tz: str | None) -> str:
    """The roster as the team model groups it. Each role is the row the page's controls hang on (`controls.role_row`)."""
    from . import controls
    p = m["presence"]
    out = []
    for g in m["groups"]:
        rows = "".join(controls.role_row(r, p, tz, ", ".join(f"<a href='#f-{_e(x['fid'])}'>{_e(_plain(x['what']))}</a>" for x in r["stopped_on"]))
                       for r in g["roles"])
        out.append(f"<section class='tgroup' data-group='{_e(g['key'])}'><div class='tghead'>{mark(g['mark'])}<h3>{_e(g['title'])}</h3>"
                   f"<span class='tgn'>{len(g['roles'])}</span><span class='tgmeans'>{_e(g['means'])}</span></div>{rows}</section>")
    if m["off"]:
        out.append("<section class='tgroup' data-group='off'><div class='tghead'>" + mark("idle") + "<h3>Not in this org</h3>"
                   f"<span class='tgn'>{len(m['off'])}</span><span class='tgmeans'>in the package's cast; this org's manifest leaves it off — "
                   "a role can be set up from its row</span></div>" + "".join(controls.off_row(o) for o in m["off"]) + "</section>")
    if m["others"]:
        out.append("<section class='tgroup' data-group='others'><div class='tghead'>" + mark("idle") + "<h3>On the roster, no role</h3>"
                   f"<span class='tgn'>{len(m['others'])}</span></div>" + "".join(controls.other_row(o) for o in m["others"]) + "</section>")
    return "".join(out) + controls.as_of_html(p, tz)


def _plain(t: Any) -> str:
    """Words for a place that prints no markdown (the palette): the roles write backticks, and a list of results is not where they render."""
    return str(t or "").replace("`", "")


#: ⌘K finds the feedback dialog too (`a` is an act the script runs; every other entry is an address)
FEEDBACK_ENTRY = {"t": "do", "l": "Send feedback — a bug or a feature request", "o": "the page attaches what you were looking at", "a": "fb", "m": "idle"}


def _answered_index(answered: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """⌘K finds what the operator answered too, labelled as answered: searching for a decision they made must not come back empty."""
    return [{"t": "answered", "l": _plain(c["what"]), "o": c["org"], "h": f"f-{c['fid']}", "m": answered_state(c)} for c in answered or []]


def _index_org(org: str, cards: list[dict[str, Any]], s: dict[str, Any], xm: dict[str, Any] | None,
               answered: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """What ⌘K searches on an org's page: what waits, what was answered, the roles, the items and arcs the explorer holds."""
    out = [{"t": "ask", "l": _plain(c["what"]), "o": org, "h": f"f-{c['fid']}", "m": c["mark"]} for c in cards] + _answered_index(answered)
    for r in (s.get("presence") or {}).get("roles") or []:
        out.append({"t": "role", "l": f"{r.get('name') or r['role']} · {r['role']}", "o": org, "h": f"team-{r['role']}", "m": "idle"})
    for i in (xm or {}).get("items") or []:
        out.append({"t": "item", "l": _plain(f"{i.get('key')} — {i.get('title')}"), "o": org, "h": i.get("id"), "m": "idle"})
    for a in (xm or {}).get("arcs") or []:
        out.append({"t": "arc", "l": a.get("arc") or a.get("name") or "", "o": org, "h": a.get("id"), "m": "idle"})
    return [x for x in out if x.get("h") and x.get("l")] + [FEEDBACK_ENTRY]


def _index_fleet(cards: list[dict[str, Any]], d: dict[str, Any], answered: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    pages = d.get("pages") or {}
    out = [{"t": "ask", "l": _plain(c["what"]), "o": c["org"], "h": f"f-{c['fid']}", "m": c["mark"]} for c in cards] + _answered_index(answered)
    for o in d.get("orgs") or []:
        out.append({"t": "org", "l": o["id"], "o": o.get("repo") or "", "u": pages.get(o["id"], ""), "m": STATE.get(o.get("state"), "idle")})
    for oid, p in (d.get("team") or {}).items():
        for r in (p or {}).get("roles") or []:
            if pages.get(oid):
                out.append({"t": "role", "l": f"{r.get('name') or r['role']} · {r['role']}", "o": oid,
                            "u": f"{pages[oid]}#team-{r['role']}", "m": "idle"})
    return [x for x in out if x.get("h") or x.get("u")] + [FEEDBACK_ENTRY]


def reading_part(m: dict[str, Any]) -> dict[str, Any]:
    """What a published page's painter needs on top of the reading's `brief` (which already holds every waiting item whole): the
    figures, the lines, the tab badges, and each card's *written* line — composed here, in the operator's zone with the UTC instant
    beside it, because the painter cannot know the zone's name (rule 7). The cards themselves are not repeated: a store document
    is capped, and a waiting item twice is the largest thing in it."""
    return {"scope": m["scope"], "ceo": m["ceo"], "state": m["state"], "verdict": m["verdict"], "numbers": m["numbers"],
            "lines": m["lines"], "tabs": m["tabs"], "rec": m["rec"], "queue": m["queue"], "queue_unread": m["queue_unread"],
            "queue_note": m["queue_note"], "written": {c["fid"]: c["written"] for c in m["cards"] if c["written"]},
            "answered": [answered_part(c) for c in m.get("answered") or []], "digest": digest(m)}


#: what moves with the clock alone and so must not repaint the page: a card's age, and its prompt, which prints when it was read
_MOVING = ("ago", "hours", "prompt")


def digest(m: dict[str, Any]) -> str:
    """The Brief and Decide as 16 hex characters, with the clock taken out: every card, figure and line, but not how long anything
    has waited. The served reader adds it to its `rev`, so a recommendation the CEO writes, an option it adds or an answer that
    lands repaints the page — the fingerprint alone covers only what an item is called (a recommendation left at 10:05 stayed
    unpainted until the hour turned).

    Broken looks like: a handoff's recommendation or an answer changing without the digest moving, or two readings an hour apart
    with only ages between them digesting differently."""
    import hashlib

    def strip(o: Any) -> Any:
        if isinstance(o, dict):
            return {k: strip(v) for k, v in o.items() if k not in _MOVING}
        if isinstance(o, list):
            return [strip(v) for v in o]
        return o
    body = {k: m.get(k) for k in ("numbers", "cards", "answered", "lines", "orgs", "tabs", "verdict", "rec", "queue")}
    return hashlib.sha256(json.dumps(strip(body), sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:16]


# --- the shell ------------------------------------------------------------------------------------------------------

HEAD_SCRIPT = ("<script>(function(){var H=document.documentElement;H.className+=' js';"
               "try{var t=localStorage.getItem('org-theme');if(t==='dark'||t==='light')H.setAttribute('data-theme',t)}catch(e){}})()</script>")


def shell_html(m: dict[str, Any], scopes: list[dict[str, Any]], fresh_html: str, *, tell: bool = True) -> str:
    """The bar every view sits under: where you are (the scope), whether it is live, the one thing you can always do (tell the
    CEO), the palette, the theme — and the tabs. Scripts off, the tabs are anchors to the views, which then all show."""
    chips = "".join(
        (f"<a class='scope{' on' if s.get('on') else ''}' href='{_e(s['href'])}'>" if s.get("href") else
         f"<span class='scope{' on' if s.get('on') else ''}'>")
        + (icon("org") if s.get("org") else "") + mark(s.get("mark") or "idle") + _e(s["label"])
        + ("</a>" if s.get("href") else "</span>") for s in scopes)
    tabs = "".join(
        f"<a class='tab' role='tab' href='#v-{k}' data-tab='{k}' title='{_e(label)} · press {n}'>{_e(label)}"
        f"<span class='badge {_e((m['tabs'].get(k) or {}).get('tone', ''))}'{'' if (m['tabs'].get(k) or {}).get('n') else ' hidden'}>"
        f"{_e((m['tabs'].get(k) or {}).get('n', ''))}</span></a>" for n, (k, label) in enumerate(VIEWS, 1))
    return ("<header class='shell'><div class='shell-in'><div class='shell-row'><b class='shell-t'>Command</b>"
            f"<nav class='scopes' id='scopes' aria-label='Scope'>{chips}</nav><span class='shell-sp'></span>"
            f"<span class='fresh' id='fresh'>{fresh_html}</span>"
            + ("<button type='button' class='sbtn tellbtn' id='tell-open'><span class='lg'>Tell the CEO</span><span class='sm'>Tell</span></button>"
               if tell else "")
            + "<button type='button' class='sbtn fbbtn' id='fb-open' title='Report a bug or ask for a feature — the page attaches what you were looking at'>Feedback</button>"
            "<button type='button' class='sbtn kbd' id='pal-open' title='Find anything · Ctrl/⌘ K'>⌘K</button>"
            "<button type='button' class='sbtn kbd' id='theme-btn' title='Light or dark'>◐ dark</button></div>"
            f"<nav class='tabs' role='tablist' aria-label='Views'>{tabs}</nav></div></header>")


def pane(name: str, inner: str) -> str:
    return f"<section class='pane' data-pane='{name}' id='v-{name}'>{inner}</section>"


def _ago_words(c: dict[str, Any]) -> str:
    return f"waiting {c['ago']}" if c.get("ago") else "no date — its age is unknown"


def brief_html(m: dict[str, Any]) -> str:
    """The Brief below its header: four figures, the most urgent card, the orgs (on the fleet), the lines. Each is a link to the view
    it summarises. This is the fragment a live repaint swaps (`#bbody`)."""
    from .dashboard import _md
    nums = "".join(
        f"<a class='bnum' href='#v-{_e(n['view'])}'><span class='bv'>{_e(n['v'])}</span>"
        f"<span class='bk'>{mark(n['mark'])}{_e(n['k'])}</span>"
        + (f"<span class='bn'>{_e(n['note'])}</span>" if n.get("note") else "") + "</a>" for n in m["numbers"])
    top = m.get("top")
    top_html = ""
    if top:
        stop = (f"<div class='btopstop'>Stopping {_e(' and '.join(x['name'] for x in top['holding']))}</div>" if top["holding"] else "")
        top_html = (f"<section class='bsec'><div class='bh'>Most urgent</div><div class='btop'><div class='btopb'>"
                    f"<div class='btopm'>{mark(top['mark'])}{_e(top['org'])} · {_e(top['kind_label'])} · {_e(_ago_words(top))}</div>"
                    f"<div class='btopw'>{_md(top['what'])}</div>{stop}</div>"
                    f"<a class='bgo' href='#f-{_e(top['fid'])}'>Decide →</a></div></section>")
    elif m.get("queue_unread"):
        top_html = (f"<div class='bnone'>What is waiting on you could not be checked — {_e(m['queue_note'])}. "
                    "Not read is neither clear nor waiting.</div>")
    orgs = ""
    if m["orgs"]:
        cards = "".join(
            (f"<a class='borg{' unread' if o['unread'] else ''}' href='{_e(o['href'])}'>" if o.get("href") else
             f"<div class='borg{' unread' if o['unread'] else ''}'>")
            + f"<div class='borgh'>{icon('org')}{mark(o['mark'])}{_e(o['id'])}<span class='shell-sp'></span>"
              f"<span class='borgc'>{_e(o['ceo'])}</span></div>"
            + ("<div class='bsig'>" + "".join(
                f"<span class='sig {_e(x['state'])}' title='{_e(x['k'])}: {_e(x['read'])}'></span>" for x in o["sig"]) + "</div>"
               if o["sig"] else "")
            + f"<div class='borgl'>{_e(o['line'])}</div>" + ("</a>" if o.get("href") else "</div>") for o in m["orgs"])
        orgs = f"<section class='bsec'><div class='bh'>{icon('org')}Orgs</div><div class='borgs'>{cards}</div></section>"
    lines = "".join(
        f"<a class='bline' href='#v-{_e(l['view'])}'><span class='blk'>{_e(l['k'])}</span>"
        f"<span class='blv'>{mark(l['mark'])}{_e(l['v'])}</span><span class='blgo'>→</span></a>" for l in m["lines"])
    return (f"<div class='bnums' id='bnums'>{nums}</div>{top_html}{_queue_html(m.get('queue'))}{orgs}<section class='blines'>{lines}</section>")


def _windows_html(q: dict[str, Any]) -> str:
    """The Accomplished windows (last 24 hours, last 7 days) as the Brief prints them; the Work view's plots print the same list."""
    body = ""
    for w in q["windows"]:
        head = f"{_e(w['h'])} · " + ("not checked — " + _e(w['why']) if w["n"] is None else f"{w['n']} finished")
        rows = "".join(f"<li>{_a(r['u'], r['t'])}</li>" for r in w["rows"])
        more = f"<li class='qmore'>and {w['more']} more</li>" if w["more"] else ""
        body += f"<div class='qwin'><div class='qwh'>{head}</div><ul>{rows}{more}</ul></div>"
    return body


def _queue_html(q: dict[str, Any] | None) -> str:
    """The Accomplished section: the same text `queue_view` composed, which the painter prints too (one reading, two printers)."""
    if not q:
        return ""
    body = ""
    if not q["read"]:
        body = f"<div class='bnone'>Not checked — {_e(q['why'])}.</div>"
    else:
        if q.get("empty"):
            body += f"<div class='qempty'><b>Queue empty</b> — nothing is ready, being built or waiting. {_e(q.get('last') or '')}</div>"
        elif q.get("empty") is None:
            body += "<div class='qempty'>Whether the queue is empty is not checked — a source was not read.</div>"
        body += "<div class='qcounts'>" + "".join(f"<span><b>{_e(c['v'])}</b> {_e(c['k'])}</span>" for c in q["counts"]) + "</div>"
        body += f"<div class='qtrend' title='{_e(' '.join(map(str, (q['trend'].get('days') or []))))}'>{_e(q['trend']['text'])}</div>"
        body += _windows_html(q)
        body += "".join(f"<div class='qnote'>{_e(n)}</div>" for n in q["notes"])
    return f"<section class='bsec' id='bqueue'><div class='bh'>Accomplished</div>{body}</section>"


def _a(url: str, text: str) -> str:
    return f"<a href='{_e(url)}'>{_e(text)}</a>" if url.startswith("https://") else _e(text)


def _holding_html(c: dict[str, Any]) -> str:
    from .controls import agent_link
    names = []
    for x in c["holding"]:
        inner = f"{mark('crit')}{_e(x['name'])}"
        names.append(agent_link(c["org"], x["role"], c.get("page") or None, inner) if x["role"] else f"<span class='cstop'>{inner}</span>")
    # the token the match was made on is printed, so the link is the reader's to judge rather than to trust (row 128)
    on = (f" — {'they and this item both' if len(c['holding']) > 1 else 'it and this item both'} name "
          f"<code>{_e(', '.join(c['on']))}</code>") if c.get("on") else ""
    return (f"<div class='cblocks'>While this waits, {' '.join(names)} {'are' if len(c['holding']) > 1 else 'is'} stopped{on}.</div>")


def _card_ho(c: dict[str, Any]) -> str:
    """The handoff's own controls, in the markup `HANDOFF_JS` already drives (a `.ho` box with `data-hid`, `button[data-choice]`,
    a textarea, `.hosend`, `.hosaidnow`): its transport, its token check and its words, restyled as the design's tiles. The
    controls are in the markup always and shown only on a page that can send (`[data-ask]` on the document)."""
    from . import handoffs as hf
    from .dashboard import _e as de, _handoff_said, _md
    h = c["handoff"]
    opts = h.get("options") or []
    pick = hf.marked_pick(h)
    answers = h.get("answered") or []
    norec = hf.no_recommendation(h)
    # a card drawn here waits on the operator (`status.answered_apart` sets every answered one apart): an answer it still carries was acted on
    # before the card was asked again, so it is history, printed below, and the card is answered afresh
    can = not h.get("orphan")
    ordered = ([pick] if pick in opts else []) + [o for o in opts if o != pick]
    tiles = ""
    if can:
        tiles = "".join(
            f"<button type='button' class='hoans otile{' prim' if o == pick else ''}' data-choice='{de(o)}'>"
            f"<b>{_md(o)}</b>{'<small>recommended</small>' if o == pick else ''}</button>" for o in ordered)
        if not opts and not norec:
            tiles = ("<button type='button' class='hoans otile prim' data-choice='Do as recommended'><b>Do as recommended</b>"
                     "<small>the CEO's recommendation, as written</small></button>")
        if not tiles:
            # nothing to pick from and nothing recommended: the card still has a button, and says in words why
            tiles = ("<button type='button' class='hoans otile prim' data-choice='Seen — nothing decided'><b>Seen</b>"
                     "<small>no options and no recommendation were left — records that you saw it; this is not an answer and approves nothing</small></button>")
        if opts and norec:
            note = "Choose one — no recommendation was left."
        elif opts and pick not in opts:
            note = "The recommendation names none of the options, so none is marked as the main one — choose one."
        else:
            note = ""
        tiles = (f"<div class='cchoose'>{note}</div>" if note else "") + f"<div class='otiles'>{tiles}</div>"
    else:
        # an orphan: the state is in words above; the button takes it off the operator's list here
        tiles = ("<div class='cchoose'>Nothing left to answer here.</div><button type='button' class='cbtn cclear'>"
                 "Clear from this view</button>")
    reply = ("<div class='hoans hoask creply'><textarea rows='2' maxlength='2000' aria-label='Reply to the CEO' "
             f"placeholder='or answer in your own words, or ask {de(c['ceo'])} something'></textarea>"
             "<button type='button' class='hosend cprim'>Send</button></div>") if can else ""
    nosend = (f"<div class='cnosend'>This copy of the page cannot send an answer. Copy it as a prompt below and paste it to "
              f"{_e(c['ceo'])}{', or run the command above' if h.get('do') else ''}.</div>") if can else ""
    return (f"<div class='ho cho' data-hid='{de(h.get('id') or '')}' data-org='{de(c['org'])}' data-title='{de((h.get('what') or '')[:120])}'>"
            f"{tiles}{reply}<span class='hosaidnow' role='status'></span>{_handoff_said(answers)}{nosend}</div>")


def card_html(c: dict[str, Any]) -> str:
    """One decision, whole. The id is `f-<fid>` — the address SPEC row 184 gave every waiting item, unchanged: the card is that
    item's focused view, so it carries everything the list used to hide (its full text, when it was written in the operator's zone
    with the UTC instant beside it, where it lives) and its controls.

    Broken looks like: an item's text cut short, a card with no way to answer and no word saying why, a recommendation the CEO
    never left drawn as though it had, or an id that moves as the item ages."""
    from . import handoffs as hf
    from .dashboard import _e as de, _md
    h = c.get("handoff")
    fid = c["fid"]
    facts: list[tuple[str, str]] = []
    if c.get("why"):
        facts.append(("Why", _md(c["why"])))
    mv = c.get("item_moved")
    if mv:
        # its item moved, or left the roadmap, since the card was written: a shape and the words, never a close or a hide (row 6)
        facts.append(("Its item", f"<span class='cmoved' data-moved='{_e(mv['state'])}'>{mark(mv['mark'])}{_e(mv['words'])}</span>"))
    if h:
        lines = dict(hf.lines(h))
        facts.append(("Decides", _md(lines.get("decides", ""))))
        if h.get("look"):
            facts.append(("Look at", _md(h["look"])))
        if h.get("cost"):
            facts.append(("Waiting costs", _md(h["cost"])))
        if h.get("do"):
            facts.append(("Do", f"<span class='hodo'><pre>{de(h['do'])}</pre><button type='button' class='hocopy' "
                                f"data-do='{de(h['do'])}'>copy</button></span>"))
        if h.get("by"):
            facts.append(("From", _e(h["by"])))
        if h.get("left_hours") is not None:
            facts.append(("Leaves the board", _md(hf.left_words(h["left_hours"]))))
        if h.get("expired"):
            facts.append(("Left the board", _md(hf.left_board_words(h))))
        if h.get("note"):
            facts.append((f"Send to {h.get('org') or 'the org'}'s CEO", _e(hf.NOTE_WORDS)))
    facts.append(("Written", _e(c["written"]) if c.get("written") else
                  "no date — nothing in this reading can say when it was written, so its age is unknown"))
    if c.get("where"):
        facts.append(("Where it lives", _e(c["where"])))
    frows = "".join(f"<div class='fk'>{_e(k)}</div><div class='fv'>{v}</div>" for k, v in facts)
    quote = f"<blockquote class='cquote'>{_md(c['quote'])}</blockquote>" if c.get("quote") else ""
    ceo = _e(c["ceo"])
    if h and h.get("kind") == "close_item":
        # the role that filed the card and the CEO, each under its own name: the role's recommendation never stands in for the CEO's
        rec = (f"<div class='crec{' none' if hf.ceo_owes(h) else ''}'><b>{ceo} recommends</b> — {_md(hf.ceo_says(h))}</div>"
               f"<div class='crec role'><b>{_e(h.get('by') or 'the role that filed it')} recommends</b> — "
               f"{_md(h.get('recommended_option') or '')}: {_md(h.get('recommend') or '')}</div>")
    elif h and not hf.no_recommendation(h):
        rec = f"<div class='crec'><b>{ceo} recommends</b> — {_md(h.get('recommend') or '')}</div>"
    elif h:
        lines = dict(hf.lines(h))
        rec = f"<div class='crec none'><b>Recommendation</b> — {_md(lines.get('CEO recommends', ''))}</div>"
    elif c["kind"] == "decision" and re.search(r"\brecommend", c.get("why") or "", re.I):
        # the item's own words (its Why, from the operator file) already say one: "nothing recorded" under them read as a
        # contradiction (measured 2026-10-04 on Lucille: 5 of 21 cards). Said as what it is — text in the item, not a record.
        rec = ("<div class='crec none'><b>Recommendation</b> — the item's own text mentions one (see Why above); none was recorded "
               "with it (<code>org handoffs add</code>)</div>")
    elif c["kind"] == "decision":
        rec = ("<div class='crec none'><b>Recommendation</b> — nothing recorded — the CEO owes a recommendation, or the reason it has none "
               "(<code>org handoffs add</code>)</div>")
    else:
        rec = ""
    # what *Review recommendations at once* would answer with: the recommended option, or — where the CEO left a recommendation and
    # no options — "Do as recommended". Never a guess: options with no recommended one are the operator's to choose from.
    can_rec = bool(h and not hf.no_recommendation(h) and h.get("decides") == "operator" and not h.get("orphan")
                   and not (h.get("answered") and h["answered"]))
    rec_choice = ""
    if can_rec and h.get("kind") == "close_item":
        # *Review recommendations at once* takes the CEO's pick, never the role's; a CEO line of `none: <why>` picks nothing
        rec_choice = hf.CLOSE_OPTIONS.get(str((h.get("ceo") or {}).get("close") or ""), "")
    elif can_rec:
        if h.get("recommended_option") in (h.get("options") or []):
            rec_choice = h["recommended_option"]
        elif not h.get("options"):
            rec_choice = "Do as recommended"
    ask = ""
    if not h:
        # a ruling on a heading from the operator file: `controls.JS` puts Approve / Reject / Defer in `.cbody`; the fleet console
        # has no such script, so it sends the operator to the org's own page, where the ruling is made
        ask = ("<div class='cbody'></div>" + (f"<a class='cprim go' href='{_e(c['page'])}'>Rule on it in {_e(c['org'])}’s page →</a>"
                                              if c.get("page") else ""))
    needrec = (f"<button type='button' class='cbtn cask' data-org='{_e(c['org'])}' data-ceo='{_e(c['ceo'])}' "
               f"data-key='{_e(c.get('ask_key') or '')}'>Ask {ceo} for a recommendation</button>"
               if (not h or hf.no_recommendation(h)) and c["kind"] == "decision" else "")
    act = c.get("action") or {}
    link = (f"<a class='cbtn' href='{_e(act['href'])}' target='_blank' rel='noopener'>{_e(act['label'])} ↗</a>" if act.get("href") else
            (f"<span class='cbtn quiet'>{_e(act['label'])}</span>" if act.get("label") else ""))
    attrs = (f" data-ask-key='{_e(c['ask_key'])}' data-ask-title='{_e(c['what'])}'" if c.get("ask_key") and not h else "")
    attrs += " data-blocks='1'" if c["holding"] else ""
    attrs += f" data-hid='{de(h['id'])}'" if h and h.get("id") else ""
    attrs += f" data-rec='{de(rec_choice)}'" if rec_choice else ""
    attrs += f" data-waiting='{de(c['ago'])}'" if c.get("ago") else ""
    rs = c.get("recstate") or "none"
    attrs += f" data-recstate='{rs}' data-arc='{_e(arc_value(c))}'"
    note = (f"<button type='button' class='cbtn cc cnote' data-cc='note' data-text='{_e(h['note'])}'>Copy the note for "
            f"{_e(h.get('org') or 'the org')}'s CEO</button>") if h and h.get("note") else ""
    said = {"rec": "", "none": " · no recommendation yet", "unread": " · recommendation not checked"}[rs]
    return (f"<article class='card' id='f-{_e(fid)}' data-fid='{_e(fid)}' data-org='{_e(c['org'])}'{attrs}>"
            f"<div class='chead'>{icon('ask')}{mark(c['mark'])}<span class='cpos'></span>"
            f"<span>{_e(c['org'])} · {_e(c['kind_label'])} · {_e(arc_words(c))} · {_e(_ago_words(c))}{said}</span></div>"
            f"<h3 class='cwhat'><a class='fl' href='#f-{_e(fid)}'>{_md(c['what'])}</a></h3><div class='cfacts'>{frows}</div>{quote}"
            f"{_holding_html(c) if c['holding'] else ''}{rec}{_card_ho(c) if h else ''}{ask}"
            f"<div class='cdone' hidden></div>"
            f"<div class='cfoot'><button type='button' class='cbtn clater'>Later</button>{needrec}<span class='shell-sp'></span>"
            f"{note}<button type='button' class='cbtn cc' data-cc='prompt' data-text='{_e(c['prompt'])}'>Copy as prompt</button>"
            f"<button type='button' class='cbtn cc' data-cc='link'>Copy link</button>{link}</div></article>")


def arc_value(c: dict[str, Any]) -> str:
    """A card's arc as the filter names it: `<org>/<arc>`, or "" for a card whose item, or its item's arc, could not be known (*no arc*).
    The URL carries the same value (`#arc=<org>/<arc>`, `#arc=none`), so a filtered view can be linked and reloaded."""
    return f"{c['org']}/{c['arc']}" if c.get("arc") else ""


def arc_words(c: dict[str, Any]) -> str:
    return f"arc {c['arc']}" if c.get("arc") else "no arc"


def arc_choices(cards: list[dict[str, Any]], fleet: bool) -> list[dict[str, Any]]:
    """The arc selector's choices (item `decide-filtered-to-one-arc`, row 3): *all*, then every arc a card carries, by its count and then its
    name, then *no arc* when a card has none. On the fleet page an arc is named with its org. The live script rebuilds the same list from the
    cards (`arcPick`), so a repainted Decide offers what it holds. Broken looks like: an arc with a waiting card missing from the list, or
    *no arc* missing while a card carries none."""
    n: dict[str, int] = {}
    for c in cards:
        n[arc_value(c)] = n.get(arc_value(c), 0) + 1
    out = [{"v": "", "l": f"All arcs ({len(cards)})"}]
    for v in sorted((v for v in n if v), key=lambda v: (-n[v], v)):
        org, arc = v.split("/", 1)
        out.append({"v": v, "l": f"{org} · {arc} ({n[v]})" if fleet else f"{arc} ({n[v]})"})
    if n.get(""):
        out.append({"v": "none", "l": f"No arc ({n['']})"})
    return out


def arc_html(m: dict[str, Any]) -> str:
    """Decide's arc selector and the count beside it, hidden until the script runs (without it every card is in the page, as with the
    recommendation filter). The count reads "N of M waiting on you — arc <name>", so what the filter leaves out is never silently gone."""
    if not m["cards"]:
        return ""
    fleet = m["scope"]["kind"] == "fleet"
    opts = "".join(f"<option value='{_e(o['v'])}'>{_e(o['l'])}</option>" for o in arc_choices(m["cards"], fleet))
    return (f"<div class='carc' id='carc' hidden><label class='pmono' for='arc-pick'>Arc</label>"
            f"<select id='arc-pick' data-fleet='{1 if fleet else 0}'>{opts}</select>"
            f"<span class='pmono' id='arc-count' role='status'></span></div>")


def rest_words(n: dict[str, int]) -> str:
    """What the control says about the cards the default view leaves out. The same words are written by the live script (`restWords`)."""
    out = [f"{n['rec']} with a recommendation"]
    if n["none"]:
        out.append(f"{n['none']} more waiting without a recommendation")
    if n["unread"]:
        out.append(f"{n['unread']} not checked — the board's handoffs were not read, so whether they carry one is unknown")
    return " · ".join(out)


def rest_html(n: dict[str, int]) -> str:
    """The Decide view's control: by default only the cards that carry a recommendation, and the rest — counted, never dropped — one click
    away. Hidden until the script runs, because without it every card is already in the page (a printed page holds every decision).

    Broken looks like: a waiting item with no way to reach it, a card whose record was not read counted as having none (or the control
    reading `0` over it), or the default holding a card that carries no recommendation."""
    if not sum(n.values()):
        return ""
    extra = n["none"] or n["unread"]
    return (f"<div class='crest' id='crest'{'' if extra else ' hidden'}>"
            f"<span class='crestw' id='rest-words'>{_e(rest_words(n))}</span>"
            f"<button type='button' class='cbtn' id='rest-open' aria-pressed='false'>Show them</button></div>"
            f"<div class='cleared' id='norecs' hidden><div class='clh'>None of what is waiting carries a recommendation yet.</div>"
            f"<div class='cln'>Nothing was dropped: “Show them” opens every waiting item, each labelled.</div></div>")


def decide_html(m: dict[str, Any]) -> str:
    """Every card, and what the empty state says. The cards are all in the markup — one after another with no script, the current
    one alone with it (`.js .card:not(.cur)` is hidden) — so a printed or archived page still holds every decision whole. This is the
    fragment a live repaint swaps (`#decide`)."""
    # recommended first, so the default view is a prefix of the list; stable, so the model's own order holds within each group
    ordered = sorted(m["cards"], key=lambda c: c.get("recstate") != "rec")
    cards = "".join(card_html(c) for c in ordered)
    rest = rest_html(rec_counts(m["cards"]))
    if m["cards"]:
        empty = ""
    elif m.get("queue_unread"):
        empty = (f"<div class='cleared' id='cleared'>{mark('idle', 'lg')}<div class='clh'>What is waiting on you could not be checked."
                 f"</div><div class='cln'>{_e(m['queue_note'])}. Not read is neither clear nor waiting.</div></div>")
    else:
        empty = (f"<div class='cleared' id='cleared'>{mark('ok', 'lg')}<div class='clh'>Nothing is waiting on you here.</div></div>")
    # named, so the list below it (`answered_html`) reads as the other half: what waits on the operator, and what was already answered
    ctl = ((f"<h3 class='wh'>{icon('ask')}Waiting on you</h3>" if m.get("answered") else "")
           + "<div class='cdots' id='cdots'></div>" if m["cards"] else "")
    nav = ("<div class='cnav'><button type='button' class='cbtn' id='c-prev'>← Previous</button>"
           "<button type='button' class='cbtn' id='c-next'>Next →</button></div>" if m["cards"] else "")
    return (f"{arc_html(m)}{ctl}{rest}<div class='cards' id='cards'>{cards}</div><div class='cleared done' id='cleared-done' hidden></div>"
            f"{empty}{nav}{answered_html(m)}")


# --- what the operator already answered -------------------------------------------------------------------------------------------
# The operator, in chat on 2026-10-22: *"separate in the dashboard between what's actually waiting for my decision and what I already
# answered."* An answered card leaves the cards above (and every count of what waits) for this list, where it stays, whole, until its
# CEO closes it (`status.answered_apart`). Broken looks like: an answered card among the cards or in the badge, one missing from this
# list, an answer drawn without the warning that the board is unsigned, or a state told by its colour alone.

#: an answered card's state: in motion while the CEO has an answer to act on, healthy once it acted (closing it is all that is left)
ANSWERED_STATE = {False: "live", True: "ok"}


def answered_state(c: dict[str, Any]) -> str:
    return ANSWERED_STATE[bool(c.get("acted"))]


def answered_words(c: dict[str, Any]) -> str:
    """The card's state in words, beside its mark (rule 8): what it waits on now."""
    return (f"{c['ceo']} acted on the answer — not yet closed" if c.get("acted") else f"waiting on {c['ceo']} to act on the answer")


def said_words(a: dict[str, Any]) -> str:
    """One answer as the board holds it: the choice and the note, or the note alone."""
    return " — ".join(x for x in (str(a.get("choice") or "").strip(), str(a.get("note") or "").strip()) if x) or "(no words)"


def answered_part(c: dict[str, Any]) -> dict[str, Any]:
    """An answered card as a published page's painter draws it: the words composed here, in the operator's zone (rule 7)."""
    return {"fid": c["fid"], "org": c["org"], "what": c["what"], "kind": c["kind_label"], "arc": arc_words(c), "state": answered_state(c),
            "words": answered_words(c), "when": c.get("answered_when") or "", "why": c.get("why") or "", "where": c.get("where") or "",
            "said": [{"text": said_words(a), "when": a.get("when") or "", "by": a.get("by") or "",
                      "acted": bool(a.get("acted")), "done": a.get("done") or "", "how": a.get("how") or ""} for a in c.get("said") or []]}


def _said_html(c: dict[str, Any]) -> str:
    rows = ""
    for a in c.get("said") or []:
        what = "ruling on the board" if a.get("how") == "ruling" else "answer on the board"
        who = f" · claims to be from {_e(a['by'])}" if a.get("by") else ""
        state = (f"{mark('ok')}{_e(c['ceo'])} acted: {_e(a.get('done') or 'done')}" if a.get("acted")
                 else f"{mark('live')}not marked acted on yet")
        rows += (f"<li><span class='answ'>{_e(what)}</span> <b>{_e(said_words(a))}</b>"
                 f"<span class='answhen'>{_e(a.get('when') or 'no date')}{who}</span><span class='anst'>{state}</span></li>")
    return f"<ul class='ansaid'>{rows}</ul>"


def answered_card_html(c: dict[str, Any]) -> str:
    """One answered card: what was asked, what the board says you said and when, and whether its CEO has acted — the whole card one
    click down. Its id is the card's own `f-<fid>`, so a link to a decision still opens it once it is answered. A handoff that is not yet
    acted on keeps a reply box, to add to an answer or change it; the option tiles are not offered again."""
    from . import handoffs as hf
    from .dashboard import _e as de, _md
    h = c.get("handoff")
    st = answered_state(c)
    facts: list[tuple[str, str]] = []
    if c.get("why"):
        facts.append(("Why", _md(c["why"])))
    if h and not hf.no_recommendation(h):
        facts.append((f"{c['ceo']} recommended", _md(h.get("recommend") or "")))
    if h and h.get("options"):
        facts.append(("Options", " · ".join(_md(o) for o in h["options"])))
    facts.append(("Asked", _e(c["written"]) if c.get("written") else "no date — its age is unknown"))
    if c.get("where"):
        facts.append(("Where it lives", _e(c["where"])))
    frows = "".join(f"<div class='fk'>{_e(k)}</div><div class='fv'>{v}</div>" for k, v in facts)
    reply = ""
    if h and h.get("id") and not c.get("acted") and h.get("decides") == "operator":
        reply = (f"<div class='ho cho' data-hid='{de(h['id'])}' data-org='{de(c['org'])}' data-title='{de((h.get('what') or '')[:120])}'>"
                 "<div class='hoans hoask creply'><textarea rows='2' maxlength='2000' aria-label='Add to the answer' "
                 f"placeholder='add to the answer, change it, or ask {de(c['ceo'])} something'></textarea>"
                 "<button type='button' class='hosend cprim'>Send</button></div><span class='hosaidnow' role='status'></span></div>")
    return (f"<details class='acard' id='f-{_e(c['fid'])}' data-fid='{_e(c['fid'])}' data-org='{_e(c['org'])}' data-state='{st}'>"
            f"<summary><span class='amark'>{mark(st)}</span><span class='abody'><span class='awhat'>{_md(c['what'])}</span>"
            f"<span class='ameta'>{_e(c['org'])} · {_e(c['kind_label'])} · {_e(arc_words(c))} · {_e(answered_words(c))}"
            + (f" · answered {_e(c['answered_when'])}" if c.get("answered_when") else "") + "</span></span></summary>"
            f"<div class='abox'>{_said_html(c)}<div class='cfacts'>{frows}</div>"
            "<div class='anote'>The board is shared and unsigned, so an answer listed here is not proof it was you. "
            "If you did not send it, say so in a reply.</div>"
            f"{reply}<a class='fl' href='#f-{_e(c['fid'])}'>Link to this card</a></div></details>")


def answered_html(m: dict[str, Any]) -> str:
    """The Decide view's second list: what the operator already answered, apart from what waits on them. Shown whole with or
    without the script; it is not part of the cards stepped through above."""
    a = m.get("answered") or []
    if not a:
        return ""
    open_n = sum(1 for c in a if not c.get("acted"))
    head = " · ".join(x for x in (f"{open_n} waiting on the CEO to act" if open_n else "",
                                  f"{len(a) - open_n} acted on, not yet closed" if len(a) - open_n else "") if x)
    return (f"<section class='answered' id='answered'><div class='anh'><h3>{icon('ask')}Answered "
            f"<span class='ann' id='answered-n'>{len(a)}</span></h3><span class='pmono'>{_e(head)}</span></div>"
            "<div class='anl'>The board holds an answer to each, so none is waiting on you or counted as waiting: each waits on its "
            "CEO to act on the answer and close it, and leaves this list when it is closed.</div>"
            f"<div class='anrows' id='anrows'>{''.join(answered_card_html(c) for c in a)}</div></section>")


def decide_pane(m: dict[str, Any]) -> str:
    batch = ("<button type='button' class='sbtn batch' id='batch-open' hidden>Review recommendations at once</button>"
             if m["cards"] else "")
    only = (f"<button type='button' class='sbtn only' id='only-blocking'>{mark('crit')}Only what stops a role</button>"
            if any(c["holding"] for c in m["cards"]) else "")
    return pane("decide", f"<div class='phead'><h2>Decide</h2><span class='pmono' id='recline'>{_e(m['rec'])}</span>"
                          f"<span class='shell-sp'></span>{batch}{only}</div><div id='decide'>{decide_html(m)}</div>")


def brief_pane(m: dict[str, Any]) -> str:
    """The Brief, with its header. The header keeps the ids the live script writes (`org`, `readat`, `age`, `verdict`) and the
    body is the fragment that repaints."""
    from .dashboard import _e as de
    sc = m["scope"]
    return pane("brief", f"<header class='bhead'><div class='beyebrow'>{_e(sc['eyebrow'])} · "
                         f"<span id='readat'>{'read' if sc['kind'] == 'fleet' else 'read at'} {_e(sc['read'])}</span><span id='age'></span></div>"
                         f"<h1 class='bh1' id='org'>{de(sc['title'])}</h1>"
                         f"<div class='verdict {de(m['state'])}' id='verdict'>{de(m['verdict'])}</div></header>"
                         f"<div id='bbody'>{brief_html(m)}</div>")


def overlays_html(m: dict[str, Any], tell_orgs: list[str]) -> str:
    """The three dialogs, closed: the palette (⌘K), *Tell the CEO*, and *Review recommendations at once*. `hidden` until opened;
    Esc closes the open one."""
    # on the fleet a note names the org it is for; on an org's own page the page is its one destination and there is nothing to choose
    chips = "".join(f"<button type='button' class='chip{' on' if n == 0 else ''}' data-org='{_e(o)}'>{_e(o)}</button>"
                    for n, o in enumerate(tell_orgs)) if m["scope"]["kind"] == "fleet" and tell_orgs and tell_orgs != [""] else ""
    idx = json.dumps(m["index"], ensure_ascii=False).replace("<", "\\u003c")
    return (f"<script type='application/json' id='console-index'>{idx}</script>"
            "<div class='ov' id='ov-pal' hidden><div class='dlg pal'><input id='pal-q' type='text' autocomplete='off' "
            "placeholder='Find a decision, role, item, arc or org…' aria-label='Find'><div class='pal-r' id='pal-r'></div></div></div>"
            "<div class='ov' id='ov-tell' hidden><div class='dlg'><div class='dh'>Tell the CEO</div>"
            f"<div class='chips' id='tell-orgs'>{chips}</div>"
            "<textarea id='tell-q' rows='4' placeholder='Anything — it is recorded on the board and relayed as a plain message.' "
            "aria-label='Message to the CEO'></textarea><div class='dn' id='tell-n'></div>"
            "<div class='dfoot'><button type='button' class='cbtn' data-close='1'>Cancel</button>"
            "<button type='button' class='cprim' id='tell-send'>Send</button></div></div></div>"
            f"<div class='ov' id='ov-fb' data-scope='{_e(m['scope']['id'])}' data-kind='{_e(m['scope']['kind'])}' hidden><div class='dlg'>"
            "<div class='dh'>Send feedback</div>"
            "<div class='chips' id='fb-kind'><button type='button' class='chip on' data-kind='bug'>Bug</button>"
            "<button type='button' class='chip' data-kind='feature_request'>Feature request</button></div>"
            "<input id='fb-title' type='text' maxlength='120' autocomplete='off' placeholder='One line: what is it?' aria-label='Title'>"
            "<textarea id='fb-q' rows='5' maxlength='1900' placeholder='What happened, and what did you expect instead?' aria-label='Details'></textarea>"
            "<details class='fbctx'><summary>What the page attaches</summary>"
            "<div class='dn'>Measured by the page, not typed. Nothing you type elsewhere, and no card text beyond the one you are on.</div>"
            "<pre id='fb-ctx'></pre></details>"
            "<div class='dn'>It becomes a ticket in org-core’s own queue (label <code>ticket</code>): the page records it on the board and tells the "
            "CEO that maintains the dashboard, who files it and says where.</div><div class='dn fbn' id='fb-n' role='status'></div>"
            "<div class='dfoot'><button type='button' class='cbtn' data-close='1'>Cancel</button>"
            "<button type='button' class='cprim' id='fb-send'>Send</button></div></div></div>"
            "<div class='ov' id='ov-batch' hidden><div class='dlg wide'><div class='dh'>Accept the CEO’s recommendations</div>"
            "<div class='dn'>Each goes to its own org’s CEO as a ruling, exactly as if you had chosen it on its card. "
            "Untick any you want to look at on its own.</div><div id='batch-l'></div>"
            "<div class='dfoot'><button type='button' class='cbtn' data-close='1'>Cancel</button>"
            "<button type='button' class='cprim' id='batch-go'>Accept</button></div></div></div>"
            "<div class='toast' id='toast' role='status' hidden></div>")


# --- the page's own ink -----------------------------------------------------------------------------------------------

CSS = r"""
/* --- the shell (org_core/console.py): tokens are the page's own; no hue is defined here -------------------------------- */
:root{--surface-3:#eceef2;--on-accent:#fff;--live-wash:#eef4fc}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--surface-3:#2a2d35;--on-accent:#0f1216;--live-wash:#17202d}}
:root[data-theme="dark"]{--surface-3:#2a2d35;--on-accent:#0f1216;--live-wash:#17202d}
.wrap{max-width:1080px;padding-inline:28px}
.shell{position:sticky;top:0;z-index:30;background:var(--bg);border-bottom:1px solid var(--border)}
.shell-in{max-width:1080px;margin:0 auto;padding:12px 28px 0;display:flex;flex-direction:column;gap:10px}
.shell-row{display:flex;align-items:center;gap:4px;white-space:nowrap;overflow-x:auto;scrollbar-width:none}
.shell-t{font-size:14px;margin-right:14px;letter-spacing:-.01em}
.shell-sp{flex:1}
.scopes{display:flex;align-items:center;gap:4px}
.scope{display:inline-flex;align-items:center;gap:7px;padding:5px 11px;border-radius:99px;font-size:13px;color:var(--ink-2);
  text-decoration:none;border:none;cursor:pointer}
a.scope:hover{background:var(--surface-2);text-decoration:none}
.scope .sg{width:10px;height:10px}.scope .ic{margin:0 -2px 0 0;color:inherit}
.scope.on{background:var(--ink);color:var(--bg)}.scope.on .ic{color:var(--bg)}
.fresh{font:400 11.5px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted);margin-right:6px;cursor:default}
.sbtn{font:inherit;font-size:12.5px;padding:6px 10px;border:1px solid transparent;border-radius:8px;background:none;color:var(--muted);cursor:pointer;
  white-space:nowrap}
.sbtn.kbd{font:400 12px "IBM Plex Mono",ui-monospace,monospace}
.sbtn:hover{color:var(--ink)}
.sbtn.tellbtn,.sbtn.batch,.sbtn.only{border-color:var(--border);background:var(--surface);color:var(--ink);font-weight:600}
.sbtn.batch{border-color:var(--accent);background:var(--live-wash);color:var(--accent);border-radius:99px}
.sbtn.only{border-radius:99px;font-weight:400;display:inline-flex;align-items:center;gap:7px}
.sbtn.only.on{border-color:var(--c-crit);background:var(--red-wash)}
.sbtn:focus-visible,.tab:focus-visible,.scope:focus-visible,.cbtn:focus-visible,.cprim:focus-visible,.bnum:focus-visible,.bline:focus-visible,
.borg:focus-visible,.bgo:focus-visible,.otile:focus-visible,.cdot:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.tabs{display:flex;gap:2px;overflow-x:auto;margin-bottom:-1px;scrollbar-width:none}
.tab{display:inline-flex;align-items:center;gap:7px;padding:9px 12px 11px;border-bottom:2px solid transparent;font-size:13.5px;
  white-space:nowrap;color:var(--ink-2);text-decoration:none}
.tab:hover{color:var(--ink);text-decoration:none}
.tab.on{border-bottom-color:var(--ink);color:var(--ink);font-weight:600}
.badge{font:500 10.5px "IBM Plex Mono",ui-monospace,monospace;padding:1px 7px;border-radius:99px;background:var(--surface-3);color:var(--ink-2)}
.badge.wait{background:var(--c-wait);color:#1a1405}.badge.crit{background:var(--red-wash);color:var(--red)}
.badge[hidden]{display:none}
.shell .live{font:400 11.5px "IBM Plex Mono",ui-monospace,monospace;text-transform:none;letter-spacing:0;border:none;padding:0;max-width:300px;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
/* the views: with scripts, one at a time; without, all of them in order */
html.js .pane{display:none}html.js .pane.on{display:block}
.pane{scroll-margin-top:110px}
.pane>.sec:first-child,.pane>.sec.team{margin-top:0}
.phead{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.phead h2{margin:0;font-size:22px;font-weight:500;letter-spacing:-.02em}
.pmono{font:400 12px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted)}
.pane>.stub{color:var(--ink-2);font-size:13px;margin:0 0 14px;max-width:70ch}
/* the focused view of a row in the machinery view: the page's rules name `#secs`; this view's container is its own */
#secs-machinery:has(.frow:is(:target,.is-focus))>.sec:not(:has(.frow:is(:target,.is-focus))){display:none}
/* Brief */
.bhead{display:flex;flex-direction:column;gap:14px;margin-bottom:24px}
.beyebrow{font:500 11px "IBM Plex Mono",ui-monospace,monospace;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}
.bh1{margin:0;font-size:40px;line-height:1.1;font-weight:500;letter-spacing:-.03em}
.bhead .verdict{margin:0;padding:2px 0 2px 14px;border:none;border-left:3px solid var(--border);border-radius:0;background:none;font-size:16.5px;
  line-height:1.5;max-width:70ch}
.bhead .verdict.RED{border-left-color:var(--red)}.bhead .verdict.CLEAR{border-left-color:var(--green)}
.bhead .verdict.DARK{border-left-color:var(--dark-mark);border-left-style:dashed}
.bnums{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.bnum{display:flex;flex-direction:column;align-items:flex-start;gap:6px;padding:16px 18px;border:1px solid var(--border);border-radius:14px;
  background:var(--surface);color:inherit;text-decoration:none}
.bnum:hover{border-color:var(--accent);text-decoration:none}
.bv{font:600 30px/1 "IBM Plex Mono",ui-monospace,monospace;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.bk{font-size:12.5px;color:var(--ink-2);display:flex;align-items:center;gap:6px}
.bn{font-size:11.5px;color:var(--muted)}
.bsec{display:flex;flex-direction:column;gap:10px;margin-top:28px}
.bh{font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.bh .ic{margin-right:6px}
.btop{border:1px solid var(--border);border-radius:16px;background:var(--surface);padding:22px 24px;display:flex;gap:20px;align-items:center;flex-wrap:wrap}
.btopb{flex:1;min-width:260px;display:flex;flex-direction:column;gap:6px}
.btopm{font:500 11px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted);display:flex;gap:8px;align-items:center}
.btopw{font-size:19px;font-weight:500;line-height:1.35;letter-spacing:-.01em;text-wrap:pretty}
.btopstop{font-size:13px;color:var(--c-crit)}
.bgo,.cprim{display:inline-block;padding:11px 18px;border-radius:10px;border:none;background:var(--accent);color:var(--on-accent);font:inherit;
  font-weight:600;font-size:14px;cursor:pointer;text-decoration:none;white-space:nowrap}
.bgo:hover,.cprim:hover{text-decoration:none;filter:brightness(1.08)}
.bnone,.cleared{border:1px dashed var(--border);border-radius:14px;padding:24px;color:var(--ink-2);margin-top:28px}
.borgs{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px}
.borg{display:flex;flex-direction:column;gap:10px;padding:14px 16px;border-radius:14px;border:1px solid var(--border);background:var(--surface);
  color:inherit;text-decoration:none;text-align:left}
a.borg:hover{border-color:var(--accent);text-decoration:none}
.borg.unread{border-style:dashed}
.borgh{display:flex;align-items:center;gap:8px;font-weight:600;font-size:14px}.borgh .ic{margin:0 -2px 0 0}
.borgc{font:400 11px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted);font-weight:400}
.bsig{display:flex;gap:3px}
.sig{flex:1;height:6px;border-radius:3px}
.sig.RED{background:var(--c-crit)}.sig.CLEAR{background:var(--c-ok)}.sig.DARK{box-shadow:inset 0 0 0 1px var(--c-idle)}
.borgl{font-size:12.5px;color:var(--ink-2)}
.qempty{border:1px dashed var(--border);border-radius:14px;padding:16px 20px;color:var(--ink-2)}
.qcounts{display:flex;flex-wrap:wrap;gap:6px 22px;font-size:13px;color:var(--ink-2)}.qcounts b{font:600 15px "IBM Plex Mono",ui-monospace,monospace;color:var(--ink)}
.qtrend,.qnote{font-size:12px;color:var(--muted)}
.qwh{font-size:12.5px;font-weight:600;margin-bottom:4px}.qwin ul{margin:0;padding-left:18px;font-size:13px;color:var(--ink-2)}.qmore{list-style:none;color:var(--muted)}
.blines{display:flex;flex-direction:column;margin-top:28px}
.bline{display:grid;grid-template-columns:120px minmax(0,1fr) auto;gap:16px;align-items:center;padding:14px 4px;border-top:1px solid var(--border);
  color:inherit;text-decoration:none}
.bline:hover{background:var(--surface);text-decoration:none}
.blk{font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.blv{display:flex;align-items:center;gap:8px;font-size:14px;min-width:0}
.blgo{color:var(--muted)}
/* Decide */
.cdots{display:none;align-items:center;gap:5px;margin-bottom:10px}
.js .cdots{display:flex}
.cdot{width:10px;height:6px;border-radius:3px;border:none;padding:0;cursor:pointer;background:var(--surface-3)}
.cdot.crit{background:var(--c-crit)}.cdot.cur{width:28px;background:var(--ink)}
.cdots .keys{margin-left:auto;font:400 11.5px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted)}
.card{border:1px solid var(--border);border-radius:16px;background:var(--surface);padding:28px 30px;display:flex;flex-direction:column;gap:16px;
  box-shadow:0 18px 40px -28px rgba(0,0,0,.4);margin-bottom:14px;scroll-margin-top:110px}
.js .card:not(.cur){display:none}
.crest{display:none;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:10px;font-size:13px;color:var(--muted)}
.js .crest{display:flex}.crest[hidden]{display:none!important}.crest .cbtn.on{border-color:var(--accent)}
.card.done{opacity:.6}
.carc{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px;font-size:13px;color:var(--muted)}.carc[hidden]{display:none!important}
.carc select{font:inherit;font-size:12.5px;padding:5px 8px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2);color:var(--ink);max-width:100%}
.chead{display:flex;align-items:center;gap:10px;font:500 11px "IBM Plex Mono",ui-monospace,monospace;letter-spacing:.05em;text-transform:uppercase;color:var(--muted)}
.chead .ic{margin:0 -4px 0 0}
.cwhat{margin:0;font-size:26px;line-height:1.3;font-weight:500;letter-spacing:-.015em;text-wrap:pretty}
.cfacts{display:grid;grid-template-columns:110px minmax(0,1fr);gap:8px 16px;font-size:13.5px;line-height:1.5;padding:14px 0;
  border-top:1px solid var(--border);border-bottom:1px solid var(--border)}
.fk{font-size:10.5px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);padding-top:3px}
.fv{min-width:0;overflow-wrap:anywhere}
.cquote{margin:0;padding:2px 0 2px 16px;border-left:2px solid var(--accent);font-size:15px;line-height:1.55;font-style:italic}
.cblocks{font-size:14px;line-height:1.6;padding:12px 16px;border-radius:10px;background:var(--red-wash)}
.cblocks .ag,.cblocks .cstop{display:inline-flex;align-items:center;gap:5px;margin-right:6px;font-weight:600;color:inherit;text-decoration:none}
.cblocks code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px}
.crec{font-size:14px}.crec b{color:var(--accent);font-weight:600}
.crec.none{color:var(--ink-2)}.crec.none b{color:var(--ink-2)}
.cchoose{font-size:12.5px;color:var(--ink-2);margin-bottom:8px}
.cho{display:flex;flex-direction:column;gap:12px;margin:0;padding:0;background:none;border-radius:0}
.otiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px}
/* the controls keep `HANDOFF_JS`'s class names (`hoans`, `hosend`) and the old row's rules for them, which are more specific than a bare
   class: the design's tiles are written against the card, so they win by naming it */
.card button.otile{display:none;flex-direction:column;align-items:flex-start;gap:3px;padding:14px 16px;border-radius:12px;border:1px solid var(--border);
  background:var(--surface-2);color:var(--ink);font:inherit;font-size:14px;cursor:pointer;text-align:left}
[data-ask] .card button.otile{display:flex}
.card button.otile.prim{border-color:var(--accent);background:var(--accent);color:var(--on-accent)}
.card button.otile:hover{border-color:var(--accent)}
.otile small{font-size:11.5px;opacity:.75}
.card button.otile:disabled,.card .cprim:disabled{opacity:.55;cursor:default}
.creply{gap:8px;align-items:flex-start;flex-wrap:wrap}
[data-ask] .card div.hoans.creply{display:flex}
.creply textarea{flex:1;min-width:220px;font:inherit;font-size:14px;border:1px solid var(--border);border-radius:10px;padding:10px 12px;
  background:var(--surface-2);color:var(--ink);resize:vertical}
.card .cprim{font:inherit;font-size:14px;font-weight:600;padding:11px 18px;border:none;border-radius:10px;background:var(--accent);color:var(--on-accent);cursor:pointer}
.card .cprim.go{align-self:flex-start;text-decoration:none}
.cnosend{display:block;font-size:12.5px;color:var(--ink-2)}
[data-ask] .cnosend{display:none}
.card .hosaid,.card .hosaidnow{font-size:12.5px}
.card .hol s{width:96px}
.cfoot{display:flex;align-items:center;gap:6px;flex-wrap:wrap;border-top:1px solid var(--border);padding-top:14px;font-size:12.5px}
.cbtn{font:inherit;font-size:12.5px;padding:6px 12px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2);color:var(--ink);cursor:pointer;
  text-decoration:none;display:inline-block}
.cbtn.cc,.cbtn.quiet{border-color:transparent;background:none;color:var(--ink-2)}
.cbtn:hover{text-decoration:none;border-color:var(--accent)}
.cbtn.cask{display:none}[data-ask] .cbtn.cask{display:inline-block}
.cbody:empty{display:none}
.card .ctlopen{font:inherit;font-size:12.5px;padding:6px 12px;border:1px solid var(--border);border-radius:8px;background:var(--surface-2);color:var(--ink);cursor:pointer;text-decoration:none}
/* a ruling on a heading from the operator file (`controls.JS` `ruling`): the question restated beside the buttons, what each button
   means, and an answer in words. Not gated on `[data-ask]` — the script that builds it runs only where there is something to do */
.crule{display:flex;flex-direction:column;gap:10px}
.crq{font-size:13px;color:var(--ink-2);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.crq b{color:var(--ink);font-weight:600}
.crtiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px}
.crtiles.one{grid-template-columns:minmax(150px,220px)}
.card button.crtile{display:flex;flex-direction:column;align-items:flex-start;gap:3px;padding:12px 14px;border-radius:12px;border:1px solid var(--border);
  background:var(--surface-2);color:var(--ink);font:inherit;font-size:14px;cursor:pointer;text-align:left}
.card button.crtile small{font-size:11.5px;opacity:.75}
.card button.crtile:hover{border-color:var(--accent)}
.crtile:focus-visible,.crsend:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.crlegend{font-size:12.5px;color:var(--ink-2)}
.crans{display:flex;gap:8px;align-items:flex-start;flex-wrap:wrap}
.crans textarea{flex:1;min-width:220px;font:inherit;font-size:14px;border:1px solid var(--border);border-radius:10px;padding:10px 12px;
  background:var(--surface-2);color:var(--ink);resize:vertical}
.cdone{padding:12px 14px;border-radius:10px;background:var(--green-wash);font-size:13.5px}
.cdone[hidden]{display:none}
.cnav{display:none;gap:8px}.js .cnav{display:flex}
.cleared{display:flex;flex-direction:column;align-items:center;gap:14px;text-align:center;padding:40px;margin-top:0}
/* what the operator already answered: apart from the cards above, one row each, the whole card one click down. Its marks are vocab's
   (in motion while the CEO has an answer to act on, healthy once it acted), each beside its state in words */
.answered{margin-top:36px;border-top:1px solid var(--border);padding-top:20px}
.wh{margin:0 0 10px;font-size:15px;font-weight:600;display:flex;align-items:center;gap:8px}
.anh{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}
.anh h3{margin:0;font-size:15px;font-weight:600;display:flex;align-items:center;gap:8px}
.ann{font:500 12px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted)}
.anl{font-size:13px;color:var(--ink-2);margin:6px 0 12px}
.anrows{display:flex;flex-direction:column;gap:8px}
.acard{border:1px solid var(--border);border-radius:12px;background:var(--surface)}
.acard>summary{display:flex;gap:10px;align-items:flex-start;padding:12px 16px;cursor:pointer;list-style:none}
.acard>summary::-webkit-details-marker{display:none}
.acard .amark{padding-top:3px}.acard .abody{display:flex;flex-direction:column;gap:3px;min-width:0}
.acard .awhat{font-size:14px;overflow-wrap:anywhere}
.acard .ameta{font:500 11px "IBM Plex Mono",ui-monospace,monospace;letter-spacing:.04em;color:var(--muted)}
.acard .abox{display:flex;flex-direction:column;gap:12px;padding:0 16px 16px 40px;font-size:13.5px}
.ansaid{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
.ansaid li{display:flex;gap:8px;flex-wrap:wrap;align-items:baseline}
.answ,.answhen{font-size:12px;color:var(--muted)}.anst{display:inline-flex;gap:6px;align-items:center;font-size:12.5px;color:var(--ink-2)}
.anote{font-size:12px;color:var(--ink-2)}
.acard .creply{display:none}[data-ask] .acard div.hoans.creply{display:flex}
.acard .cprim{font:inherit;font-size:13px;font-weight:600;padding:9px 14px;border:none;border-radius:10px;background:var(--accent);color:var(--on-accent);cursor:pointer}
.acard .hosaidnow{font-size:12.5px}
.cleared[hidden]{display:none}
.cleared .sg.lg{width:28px;height:28px}
.clh{font-size:20px;color:var(--ink)}.cln{font-size:13px;color:var(--ink-2);max-width:60ch}
/* dialogs */
.ov{position:fixed;inset:0;background:rgba(8,9,12,.5);z-index:50;display:flex;justify-content:center;align-items:flex-start;padding-top:12vh}
.ov[hidden]{display:none}
.dlg{width:min(540px,92vw);max-height:80vh;overflow:auto;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px;
  display:flex;flex-direction:column;gap:12px;box-shadow:0 30px 80px -20px rgba(0,0,0,.5)}
.dlg input#fb-title{font:inherit;font-size:14px;border:1px solid var(--border);border-radius:10px;padding:10px 12px;background:var(--surface-2);color:var(--ink)}
.fbctx summary{cursor:pointer;font-size:12.5px;color:var(--ink-2)}.fbctx pre{margin:8px 0 0;max-height:180px;overflow:auto;font:400 11.5px/1.5 "IBM Plex Mono",ui-monospace,monospace;
  white-space:pre-wrap;word-break:break-word;background:var(--surface-2);border:1px solid var(--border);border-radius:10px;padding:10px 12px}
.fbn:empty{display:none}
.dlg.wide{width:min(640px,94vw)}.dlg.pal{width:min(620px,92vw);padding:0;gap:0;overflow:hidden}
.dh{font-size:16px;font-weight:600}.dn{font-size:12.5px;color:var(--ink-2)}
.dfoot{display:flex;gap:8px;justify-content:flex-end}
.dlg textarea,.dlg input{flex:none}
.dlg textarea{font:inherit;font-size:14px;border:1px solid var(--border);border-radius:10px;padding:12px;background:var(--surface-2);color:var(--ink);resize:vertical}
.chips{display:flex;gap:6px}.chip{font:inherit;font-size:12.5px;padding:5px 11px;border-radius:99px;border:1px solid var(--border);background:transparent;
  color:var(--ink);cursor:pointer}.chip.on{border-color:var(--ink);background:var(--surface-3)}
.pal input{width:100%;border:none;border-bottom:1px solid var(--border);background:transparent;color:var(--ink);padding:16px 18px;font:inherit;font-size:16px;outline:none}
.pal-r{max-height:52vh;overflow:auto;padding:6px}
.pr{display:grid;grid-template-columns:56px 14px minmax(0,1fr) auto;gap:10px;align-items:center;width:100%;padding:9px 12px;border:none;border-radius:8px;
  background:transparent;color:inherit;font:inherit;cursor:pointer;text-align:left}
.pr.act,.pr:hover{background:var(--surface-2)}
.pr .t{font:500 10px "IBM Plex Mono",ui-monospace,monospace;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}
.pr .l{font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pr .o{font:400 11px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted)}
.bl{display:grid;grid-template-columns:20px minmax(0,1fr);gap:10px;padding:12px 0;border-top:1px solid var(--border);cursor:pointer}
.bl input{margin-top:3px;accent-color:var(--accent)}
.bl .m{font:500 11px "IBM Plex Mono",ui-monospace,monospace;color:var(--muted)}.bl .w{font-size:13.5px;font-weight:600;line-height:1.35}
.bl .r{font-size:13px}.bl .r b{color:var(--accent);font-weight:600}
.toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:60;background:var(--ink);color:var(--bg);padding:11px 16px;border-radius:10px;
  font-size:13px;max-width:min(600px,92vw);box-shadow:0 12px 30px -10px rgba(0,0,0,.5)}
.toast[hidden]{display:none}
@media (max-width:640px){
  .wrap{padding-inline:16px}.shell-in{padding-inline:16px}.bh1{font-size:30px}.card{padding:20px 18px}.cwhat{font-size:22px}
  .cfacts{grid-template-columns:1fr;gap:2px 0}.fk{padding-top:8px}.bline{grid-template-columns:90px minmax(0,1fr) auto;gap:10px}
  .tellbtn .lg,.fresh,#pal-open{display:none}}
@media (min-width:641px){.tellbtn .sm{display:none}}
@media print{.shell,.cnav,.cdots,.ov,.toast{display:none}html.js .pane{display:block}.js .card:not(.cur){display:block}.crest{display:none}}
""" + __import__("org_core.prplots", fromlist=["CSS"]).CSS + __import__("org_core.itemplots", fromlist=["CSS"]).CSS


#: the shell's behaviour, in one delegated script: views by the URL's fragment (so a link names a view, an item or a role),
#: the cards one at a time, ⌘K, the theme, the dialogs, and the two ways a card is answered that `HANDOFF_JS` does not do — a
#: batch of recommendations, and a request for one. Every send goes through `post`, which is the page's own transport and
#: nothing else: a page that cannot send says so, and copies the words.
JS = r"""
<script>
(function () {
  "use strict";
  var D = document, H = D.documentElement;
  function $(s, r) { return (r || D).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || D).querySelectorAll(s)); }
  function E(t, c, x) { var e = D.createElement(t); if (c) e.className = c; if (x !== undefined && x !== null) e.textContent = String(x); return e; }
  var PANES = ["brief", "decide", "team", "work", "machinery", "rules"], cur = "brief", ci = 0, only = false, tt = null;
  // what a bug report needs and an operator cannot be asked to remember: the last errors this page threw and the last things done on it,
  // kept from load (labels only — never what was typed). Installed first, so an error in anything below is seen (0.56.0, SPEC row 190)
  var ERR = [], CRUMBS = [];
  function keep(a, v, n) { a.push(v); if (a.length > n) a.shift(); }
  window.addEventListener("error", function (e) { keep(ERR, String(e.message || "error") + (e.filename ? " (" + String(e.filename).split("/").pop() + ":" + (e.lineno || 0) + ")" : ""), 5); });
  window.addEventListener("unhandledrejection", function (e) { keep(ERR, "unhandled rejection: " + String((e.reason && e.reason.message) || e.reason || ""), 5); });
  D.addEventListener("click", function (e) {
    var b = e.target && e.target.closest ? e.target.closest("button, a, [role=tab]") : null; if (!b) return;
    var l = String(b.getAttribute("aria-label") || b.textContent || b.id || "").replace(/\s+/g, " ").trim().slice(0, 40); if (l) keep(CRUMBS, l, 8);
  }, true);
  function store(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) {} return null; }
  function setHash(h) { try { history.replaceState(null, "", location.pathname + location.search + "#" + h); } catch (e) {} }

  // --- views ---------------------------------------------------------------------------------------------------------
  function pane(name) {
    if (PANES.indexOf(name) < 0) name = "brief";
    if (name !== cur) keep(CRUMBS, "view " + name, 8);
    cur = name;
    $$(".pane").forEach(function (p) { p.classList.toggle("on", p.getAttribute("data-pane") === name); });
    $$(".tab").forEach(function (t) { var on = t.getAttribute("data-tab") === name; t.classList.toggle("on", on); t.setAttribute("aria-selected", on ? "true" : "false"); });
    if (name === "decide") paintCards();
  }
  // `hashchange` is not the only way an address moves: the explorer follows every in-page link with `history.pushState`, which fires none, and
  // assigning the hash it already has fires none either. So `nav` routes itself when the event will not come, and the explorer calls `route`.
  function nav(h) { var was = location.hash; location.hash = h; if (location.hash === was) route(); }
  function route() {
    var h = location.hash.replace(/^#/, "");
    if (!h) { pane(cur); return; }
    if (h === "all") { setHash("v-" + cur); pane(cur); return; }
    if (h.indexOf("v-") === 0) { pane(h.slice(2)); window.scrollTo(0, 0); return; }
    var el = D.getElementById(h);
    if (h.indexOf("arc=") === 0) { arcSel = decodeURIComponent(h.slice(4)); pin = null; ci = -1; pane("decide"); return; }
    if (h === "v-decide" && arcSel) setHash(arcHash());
    if (el && el.classList.contains("card")) { collect(); pin = el; ci = cards.indexOf(el); store("org-card", el.getAttribute("data-fid")); pane("decide"); setHash(arcSel ? arcHash() : "v-decide"); return; }
    if (el && el.classList.contains("acard")) el.open = true;     // an answered card, under *Answered*: opened where it stands
    var p = el && el.closest ? el.closest(".pane") : null;
    if (p) pane(p.getAttribute("data-pane")); else if (/^x-/.test(h)) pane("work");
    if (el && el.scrollIntoView) setTimeout(function () { el.scrollIntoView(); }, 30);
  }

  // --- the cards ---------------------------------------------------------------------------------------------------
  var cards = [], pin = null, rest = false;
  // Decide filtered to one arc (item decide-filtered-to-one-arc): "" all, "none" the cards whose item or arc is not known, else "<org>/<arc>".
  // It lives in the address (#arc=<org>/<arc>), so a filtered view can be linked and reloaded; nothing is stored on a server
  var arcSel = "";
  function arcHash() { return "arc=" + encodeURIComponent(arcSel).replace(/%2F/g, "/"); }
  function inArc(c) { if (!arcSel) return true; var a = c.getAttribute("data-arc") || ""; return arcSel === "none" ? !a : a === arcSel; }
  function arcName(v, fleet) { var k = v.indexOf("/"); return fleet ? v.slice(0, k) + " · " + v.slice(k + 1) : v.slice(k + 1); }
  // the choices are rebuilt from the cards on every paint (a repaint swaps the cards in), as `console.arc_choices` draws them; the chosen arc
  // stays offered at 0 once its last card is answered, so the count says "0 of M" rather than the choice vanishing
  function arcPaint() {
    var box = $("#carc"), sel = $("#arc-pick"), cnt = $("#arc-count"); if (!box || !sel) return;
    box.hidden = false;
    var live = cards.filter(function (c) { return !c.classList.contains("done"); }), n = {}, fleet = sel.getAttribute("data-fleet") === "1";
    live.forEach(function (c) { var a = c.getAttribute("data-arc") || ""; n[a] = (n[a] || 0) + 1; });
    var named = Object.keys(n).filter(function (a) { return a; });
    if (arcSel && arcSel !== "none" && !n[arcSel]) named.push(arcSel);
    named.sort(function (x, y) { return ((n[y] || 0) - (n[x] || 0)) || (x < y ? -1 : x > y ? 1 : 0); });
    sel.textContent = "";
    function opt(v, l) { var o = E("option", null, l); o.value = v; sel.appendChild(o); }
    opt("", "All arcs (" + live.length + ")");
    named.forEach(function (a) { opt(a, arcName(a, fleet) + " (" + (n[a] || 0) + ")"); });
    if (n[""] || arcSel === "none") opt("none", "No arc (" + (n[""] || 0) + ")");
    sel.value = arcSel;
    if (cnt) cnt.textContent = arcSel ? live.filter(inArc).length + " of " + live.length + " waiting on you — " +
      (arcSel === "none" ? "no arc" : "arc " + arcName(arcSel, fleet)) : "";
  }
  function setArc(v) { arcSel = v || ""; pin = null; ci = -1; keep(CRUMBS, "arc " + (arcSel || "all"), 8); setHash(arcSel ? arcHash() : "v-decide"); paintCards(); }
  D.addEventListener("change", function (e) { if (e.target && e.target.id === "arc-pick") setArc(e.target.value); });
  // by default only the cards that carry a recommendation; the rest are counted and one click away (never dropped)
  function recd(c) { return (c.getAttribute("data-recstate") || "rec") === "rec"; }
  function restWords() {
    var live = cards.filter(function (c) { return !c.classList.contains("done") && inArc(c); }), n = { rec: 0, none: 0, unread: 0 };
    live.forEach(function (c) { n[c.getAttribute("data-recstate") || "rec"]++; });
    var out = [n.rec + " with a recommendation"];
    if (n.none) out.push(n.none + " more waiting without a recommendation");
    if (n.unread) out.push(n.unread + " not checked — the board's handoffs were not read, so whether they carry one is unknown");
    return { text: out.join(" · "), extra: n.none + n.unread };
  }
  function collect() { cards = $$("#cards .card"); }
  // a card the operator was sent to (an address, the palette) is shown even if it is answered or filtered out; stepping lets go of it.
  // "Only what stops a role" shows every card a role is stopped on whatever its recommendation: the card the CEO has not yet written one for is
  // the one the operator most needs (item only-what-blocks-filter-shows-blocking-cards-without-a-recommendation)
  function shown(c) { return c === pin || (inArc(c) && !c.classList.contains("done") && !(only && !c.hasAttribute("data-blocks")) && (rest || only || recd(c))); }
  function badge() {
    var b = $(".tab[data-tab=decide] .badge"); if (!b) return;
    var n = cards.filter(function (c) { return !c.classList.contains("done"); }).length;
    b.textContent = n || ""; b.hidden = !n;
  }
  function step(d) {
    collect(); var vis = cards.filter(shown); if (!vis.length) return;
    pin = null; vis = cards.filter(shown);
    var i = vis.indexOf(cards[ci]); ci = cards.indexOf(vis[(i + d + vis.length * 2) % vis.length]); paintCards();
  }
  function paintCards() {
    collect(); badge(); arcPaint();
    var vis = cards.filter(shown), none = $("#cleared"), done = $("#cleared-done");
    if (ci < 0 || ci >= cards.length || !cards[ci] || !shown(cards[ci])) {
      var want = store("org-card"), k = cards.filter(function (c) { return c.getAttribute("data-fid") === want && shown(c); })[0];
      ci = cards.indexOf(k || vis[0] || cards[0]);
    }
    cards.forEach(function (c) { c.classList.remove("cur"); });
    var c = cards[ci];
    if (c && shown(c)) { c.classList.add("cur"); store("org-card", c.getAttribute("data-fid")); }
    var pos = c && shown(c) ? (vis.indexOf(c) + 1) + " of " + vis.length : "";
    cards.forEach(function (x) { var p = $(".cpos", x); if (p) p.textContent = x === c ? pos : ""; });
    var dots = $("#cdots");
    if (dots) {
      dots.textContent = "";
      vis.forEach(function (x) {
        var b = E("button", "cdot" + (x === c ? " cur" : "") + (x.hasAttribute("data-blocks") ? " crit" : "")); b.type = "button";
        b.setAttribute("aria-label", "Decision " + (vis.indexOf(x) + 1)); b.onclick = function () { pin = null; ci = cards.indexOf(x); paintCards(); };
        dots.appendChild(b);
      });
      if (vis.length) dots.appendChild(E("span", "keys", "← → to move"));
    }
    var nav = $(".cnav"); if (nav) nav.style.display = vis.length > 1 ? "" : "none";
    var cleared = cards.length - cards.filter(function (x) { return !x.classList.contains("done"); }).length;
    if (done) {
      done.hidden = !(cards.length && !vis.length && !only && !arcSel && !rw0());
      done.textContent = "";
      if (!done.hidden) {
        done.appendChild(E("div", "clh", "You cleared " + cleared + (cleared === 1 ? " thing" : " things") + " — nothing else is waiting on you here."));
        done.appendChild(E("div", "cln", "Each is recorded on its org's board and relayed to its CEO, and moves to Answered below with the next reading — apart from what waits on you, until its CEO closes it."));
      }
    }
    var ob = $("#only-blocking"); if (ob) ob.classList.toggle("on", only);
    var rw = restWords(), cr = $("#crest"), rb = $("#rest-open"), rt = $("#rest-words");
    if (cr) { cr.hidden = !rw.extra; if (rt) rt.textContent = rw.text; }
    if (rb) { rb.textContent = rest ? "Only those with a recommendation" : "Show them"; rb.setAttribute("aria-pressed", rest ? "true" : "false"); rb.classList.toggle("on", rest); }
    var nr = $("#norecs");
    if (nr) nr.hidden = !(cards.length && !vis.length && !only && rw.extra && !rest);
    var bo = $("#batch-open"); if (bo) bo.hidden = !recs().length;
  }
  function rw0() { return restWords().extra; }
  function recs() { collect(); return cards.filter(function (c) { return c.hasAttribute("data-rec") && !c.classList.contains("done"); }); }
  function later(c) { var box = $("#cards"); if (box && c) { box.appendChild(c); ci = 0; paintCards(); } }
  function markDone(c, text) {
    c.classList.add("done"); var d = $(".cdone", c); if (d) { d.hidden = false; d.textContent = text; }
    // after the confirmation has been read, the next waiting card after the one answered (wrapping past the end), not the first: the operator
    // clears the queue in order without hunting for where they were (item decide-view-advances-after-an-answer). Only a recorded answer
    // reaches here — `org-answered` and the batch's `.then` — so a send that failed leaves the card where it is.
    setTimeout(function () {
      collect(); var vis = cards.filter(shown), at = cards.indexOf(c), nxt = null;
      for (var k = 1; k <= cards.length && !nxt; k++) { var x = cards[(at + k) % cards.length]; if (vis.indexOf(x) >= 0) nxt = x; }
      ci = nxt ? cards.indexOf(nxt) : 0; pin = null; paintCards();
    }, 1100);
    badge();
  }

  // --- the page's one transport ----------------------------------------------------------------------------------
  var CFG = null;
  function cfg(org) {
    if (CFG === null) {
      CFG = {}; var el = $("#org-ask-cfg"); try { if (el) CFG = JSON.parse(el.textContent) || {}; } catch (e) {}
      var m = $("meta[name='org-ask']"); if (m && !CFG._) CFG._ = { ask: "ask", token: m.getAttribute("content") };
    }
    return CFG[org] || CFG._ || null;
  }
  function words(a) {
    var t = a.target || {};
    return "The operator asks, from the dashboard: " + a.kind + (a.choice ? " — " + a.choice : "") + ", on " + t.type + (t.key ? " `" + t.key + "`" : "") +
      (t.title ? " (" + t.title + ")" : "") + "." + (a.note ? "\n\nThe operator's note:\n" + String(a.note).split("\n").map(function (l) { return "> " + l; }).join("\n") : "") +
      (a.kind === "feedback" && a.context ? "\n\nContext the page attached:\n" + Object.keys(a.context).map(function (k) { return "> " + k + ": " + a.context[k]; }).join("\n") : "");
  }
  function copy(t) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(t);
    return new Promise(function (ok, no) {
      var a = E("textarea"); a.value = t; a.style.cssText = "position:fixed;opacity:0"; D.body.appendChild(a); a.select();
      var done = false; try { done = D.execCommand("copy"); } catch (e) {} a.remove(); done ? ok() : no(new Error("the browser blocked the clipboard"));
    });
  }
  function post(org, ask, got) {                   // `got`, when given, is the caller's own: the server's ask id lands in `got.id`
    ask.at = new Date().toISOString();
    var c = cfg(org);
    if (c) {
      return fetch(c.ask, { method: "POST", headers: { "Content-Type": "application/json", "X-Org-Ask": c.token }, body: JSON.stringify(ask) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var er = new Error(j.error || ("HTTP " + r.status)); er.status = r.status; throw er; } if (got) got.id = (j.ask && j.ask.id) || ""; return j.said || "recorded"; }); });
    }
    if (window.orgAsk && window.orgAsk.send) {            // a published page: the controls' own transport (its store, its relay)
      var sp = E("span"); return Promise.resolve(window.orgAsk.send(ask, sp)).then(function () { if (/bad/.test(sp.className)) throw new Error(sp.textContent); return sp.textContent; });
    }
    return copy(words(ask)).then(function () { return "this copy of the page cannot send — the words are copied; paste them to the CEO"; });
  }
  function toast(msg) {
    var t = $("#toast"); if (!t) return; t.textContent = msg; t.hidden = false; clearTimeout(tt); tt = setTimeout(function () { t.hidden = true; }, 5500);
  }

  // --- dialogs -------------------------------------------------------------------------------------------------------
  function open(id, focus) { closeAll(); var o = D.getElementById(id); if (!o) return; o.hidden = false; var f = focus && $(focus, o); if (f) f.focus(); }
  function closeAll() { $$(".ov").forEach(function (o) { o.hidden = true; }); }
  function anyOpen() { return $$(".ov").some(function (o) { return !o.hidden; }); }

  var pi = 0;
  function pal() {
    // read on every search, not once at load: the served fleet page swaps the index in with a new reading (`dashboard.COMMAND_LIVE_JS`)
    var IDX = []; try { IDX = JSON.parse($("#console-index").textContent) || []; } catch (e) {}
    var q = ($("#pal-q").value || "").toLowerCase(), box = $("#pal-r"); box.textContent = "";
    var hits = IDX.filter(function (r) { return !q || (r.l + " " + r.o + " " + r.t).toLowerCase().indexOf(q) >= 0; }).slice(0, 40);
    pi = Math.min(pi, Math.max(0, hits.length - 1));
    hits.forEach(function (r, n) {
      var b = E("button", "pr" + (n === pi ? " act" : "")); b.type = "button";
      b.appendChild(E("span", "t", r.t)); b.appendChild(E("i", "sg s-" + (r.m || "idle") + " g-" + (r.m || "idle")));
      b.appendChild(E("span", "l", r.l)); b.appendChild(E("span", "o", r.o));
      b.onclick = function () { go(r); }; box.appendChild(b);
    });
    box._hits = hits;
  }
  function go(r) { closeAll(); if (r.a === "fb") { openFb(); return; } if (r.u) location.href = r.u; else nav(r.h); }

  // --- feedback: a bug or a feature request about the dashboard, with what the page measured about where the operator was --------------
  // Where it goes: the org-core entry when this console holds one (it maintains the dashboard), else this page's own org. From an org's own page the
  // fleet server routes it to org-core (serve.Fleet.feedback_reader) and stamps which page posted it; a copy that cannot send copies it.
  function fbOrg() { cfg("_"); var ks = Object.keys(CFG || {}).filter(function (k) { return k !== "_"; }); return CFG && CFG["org-core"] ? "org-core" : (CFG && CFG._ ? "_" : (ks[0] || "_")); }
  function fbContext() {
    var c = {}, sc = $("#ov-fb"), live = $$("#cards .card"), card = cur === "decide" ? (live.filter(function (x) { return x.classList.contains("cur"); })[0] || null) : null;
    var rd = $("#readat"), ag = $("#age"), meta = $("meta[name='org-core']");
    c.org = sc ? sc.getAttribute("data-scope") : "";
    c.page = sc && sc.getAttribute("data-kind") === "fleet" ? "fleet console" : "org page";
    c.view = cur;
    if (card) c.card = ("f-" + card.getAttribute("data-fid") + " — " + (($(".cwhat", card) || {}).textContent || "")).slice(0, 200);
    c.cards_waiting = String(live.filter(function (x) { return !x.classList.contains("done"); }).length);
    c.url = location.origin + location.pathname + location.hash;
    c.org_core = meta ? meta.getAttribute("content") : "unknown";
    c.sends = cfg(fbOrg()) ? "served" : (window.orgAsk && window.orgAsk.send ? "published" : "copy");
    c.reading = ((rd ? rd.textContent : "") + (ag ? ag.textContent : "")).replace(/\s+/g, " ").trim();
    c.viewport = innerWidth + "x" + innerHeight + " @" + (window.devicePixelRatio || 1) + "x";
    c.theme = H.getAttribute("data-theme") || (window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark (system)" : "light (system)");
    c.browser = navigator.userAgent; c.language = navigator.language || "";
    c.at = new Date().toISOString(); try { c.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (e) {}
    c.errors = ERR.length ? ERR.join(" | ") : "none since this page loaded";
    c.last_clicks = CRUMBS.join(" → ") || "none";
    return c;
  }
  var fbSent = false;     // a send landed and the text has not changed since: Send stays off, so a second click cannot file it twice
  function fbKind() { var c = $("#fb-kind .chip.on"); return c ? c.getAttribute("data-kind") : "bug"; }
  function openFb() {
    var pre = $("#fb-ctx"), c = fbContext();
    pre.textContent = Object.keys(c).map(function (k) { return k + ": " + c[k]; }).join("\n");
    if (fbSent) { $("#fb-title").value = ""; $("#fb-q").value = ""; fbSent = false; $("#fb-send").disabled = false; }
    $("#fb-n").textContent = ""; open("ov-fb", "#fb-title");
  }
  function sendFb() {
    var title = ($("#fb-title").value || "").trim(), n = $("#fb-n"), b = $("#fb-send");
    if (b.disabled) return;                       // in flight, or already sent: ⌘↵ in the details box reaches here too
    if (!title) { n.textContent = "Not sent: give it a title — one line saying what it is."; $("#fb-title").focus(); return; }
    b.disabled = true; n.textContent = "sending…"; var got = {};
    post(fbOrg(), { kind: "feedback", choice: fbKind(), target: { type: "org", key: "", title: title }, note: ($("#fb-q").value || "").trim(), context: fbContext() }, got).then(function (said) {
      fbSent = true; n.textContent = "Sent" + (got.id ? " as ask " + got.id : "") + " — " + said + ". Change the text to send another.";
      toast("Feedback sent" + (got.id ? " (ask " + got.id + ")" : "") + ": " + said);
    }, function (e) {
      b.disabled = false; var why = e && e.message ? e.message : e;
      // only a refusal (4xx) proves nothing was recorded; a 5xx or no answer at all may have come after the board took it
      n.textContent = e && e.status >= 400 && e.status < 500 ? "Not sent: " + why : "Not confirmed: " + why + " — check the Team tab, which lists what you asked, before sending again.";
    });
  }
  function fbEdited() { var b = $("#fb-send"); if (fbSent) { fbSent = false; b.disabled = false; $("#fb-n").textContent = ""; } }

  function tellOrg() { var c = $("#tell-orgs .chip.on"); return c ? c.getAttribute("data-org") : "_"; }
  function sendTell() {
    var q = $("#tell-q"), t = (q.value || "").trim(); if (!t) return;
    var org = tellOrg(), n = $("#tell-n"); n.textContent = "sending…";
    post(org, { kind: "note", target: { type: "org", key: "", title: "" }, note: t }).then(function (said) {
      q.value = ""; closeAll(); toast("Told the CEO: " + said);
    }, function (e) { n.textContent = "not sent: " + (e && e.message ? e.message : e); });
  }
  function openBatch() {
    var l = $("#batch-l"); l.textContent = "";
    recs().forEach(function (c) {
      var lab = E("label", "bl"), cb = E("input"); cb.type = "checkbox"; cb.checked = true; cb.setAttribute("data-fid", c.getAttribute("data-fid"));
      var s = E("span"); s.style.cssText = "display:flex;flex-direction:column;gap:3px";
      s.appendChild(E("span", "m", c.getAttribute("data-org") + " · waiting " + (c.getAttribute("data-waiting") || "—")));
      s.appendChild(E("span", "w", ($(".cwhat", c) || {}).textContent));
      var r = E("span", "r"), b = E("b", null, "→ " + c.getAttribute("data-rec")); r.appendChild(b);
      var rec = $(".crec", c); if (rec) r.appendChild(D.createTextNode(" " + rec.textContent.replace(/^.*?recommends\s*—\s*/, "")));
      s.appendChild(r); lab.appendChild(cb); lab.appendChild(s); l.appendChild(lab);
    });
    var go = $("#batch-go"); go.textContent = "Accept " + recs().length; open("ov-batch");
    l.onchange = function () { var n = $$("input:checked", l).length; go.textContent = "Accept " + (n === 1 ? "1 ruling" : n + " rulings"); go.disabled = !n; };
    l.onchange();
  }
  function acceptBatch() {
    var picked = $$("#batch-l input:checked").map(function (i) { return i.getAttribute("data-fid"); });
    var go = $("#batch-go"); go.disabled = true; var ok = 0, bad = 0;
    (function next(i) {
      if (i >= picked.length) { closeAll(); toast(ok + " ruling" + (ok === 1 ? "" : "s") + " recorded, each on its own org's board" + (bad ? "; " + bad + " not sent — they stay on the page" : "") + "."); return; }
      var c = D.getElementById("f-" + picked[i]);
      post(c.getAttribute("data-org"), { kind: "answer", target: { type: "handoff", key: c.getAttribute("data-hid"), title: ($(".cwhat", c) || {}).textContent.slice(0, 120) },
        choice: c.getAttribute("data-rec"), note: "" }).then(function (said) { ok++; markDone(c, "✓ " + c.getAttribute("data-rec") + " — " + said); },
        function () { bad++; }).then(function () { next(i + 1); });
    })(0);
  }

  // --- one delegated listener ----------------------------------------------------------------------------------
  D.addEventListener("click", function (e) {
    var t = e.target, b = t.closest ? t.closest("button, a") : null; if (!b) return;
    var card = b.closest(".card");
    if (b.id === "tell-open") { open("ov-tell", "#tell-q"); return; }
    if (b.id === "fb-open") { openFb(); return; }
    if (b.id === "fb-send") { sendFb(); return; }
    if (b.classList.contains("chip") && b.parentNode.id === "fb-kind") {
      $$(".chip", b.parentNode).forEach(function (x) { x.classList.toggle("on", x === b); });
      $("#fb-q").placeholder = b.getAttribute("data-kind") === "bug" ? "What happened, and what did you expect instead?" : "What would you like to be able to do, and why?";
      return;
    }
    if (b.id === "pal-open") { $("#pal-q").value = ""; pi = 0; pal(); open("ov-pal", "#pal-q"); return; }
    if (b.id === "theme-btn") { var d = (H.getAttribute("data-theme") || (matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")) === "dark" ? "light" : "dark"; theme(d); return; }
    if (b.id === "tell-send") { sendTell(); return; }
    if (b.id === "batch-open") { openBatch(); return; }
    if (b.id === "batch-go") { acceptBatch(); return; }
    if (b.id === "c-prev") { step(-1); return; }
    if (b.id === "c-next") { step(1); return; }
    if (b.id === "rest-open") { rest = !rest; pin = null; ci = -1; paintCards(); return; }
    if (b.id === "only-blocking") { only = !only; pin = null; ci = 0; paintCards(); return; }
    if (b.hasAttribute("data-close")) { closeAll(); return; }
    if (b.classList.contains("chip") && b.parentNode.id === "tell-orgs") { $$(".chip", b.parentNode).forEach(function (x) { x.classList.toggle("on", x === b); }); return; }
    if (b.classList.contains("clater") && card) { later(card); return; }
    if (b.classList.contains("cclear") && card) { markDone(card, "Cleared from this view — it comes back on reload while the board still lists it."); return; }
    if (b.classList.contains("cc") && card) {
      var text = b.getAttribute("data-cc") === "link" ? location.href.split("#")[0] + "#f-" + card.getAttribute("data-fid") : b.getAttribute("data-text");
      copy(text).then(function () { toast(({link: "Link", note: "Note"}[b.getAttribute("data-cc")] || "Prompt") + " copied."); }, function (x) { toast("Not copied: " + x.message); });
      return;
    }
    if (b.classList.contains("cask") && card) {
      var key = b.getAttribute("data-key"), what = (($(".cwhat", card) || {}).textContent || "").slice(0, 200);
      // the card shows only what is on the board, so an answer in chat never reaches it (the operator, 2026-10-05, on Lucille: the CEO
      // recommended in the chat and "nothing is recorded on the dashboard"): the ask carries the exact command, and `--for` names the card.
      // The heading is the operator file's text, which roles and the operator write, and the note is written to be pasted: it is quoted for
      // the SHELL (single quotes — nothing inside expands), never for JSON, whose double quotes still expand `$VAR`, `$(…)` and backticks
      // (Reed, UNSOUND on e73f028, 2026-10-05: `$(id)` in a heading ran in the CEO's shell and `$DEPLOY_TOKEN` was written into the record)
      var sq = function (t) { return "'" + String(t).replace(/'/g, "'\\''") + "'"; };
      var how = "org handoffs --repo . add --decides operator" + (key ? " --for " + sq(key) : "") + " --what " + sq(what) +
        " --item \"<its roadmap item; none yet: file one first>\" --recommend \"<what you would do, and why>\" --cost \"<what waiting costs, or: nothing known>\"";
      var ask = "Please leave a recommendation — or the reason there is none — on", gist = "\n\nRecord it on the board, not only in chat: the card shows only what is recorded, and says \"nothing recorded\" until it is.\n",
          alt = "\n(Real alternatives: `--option \"…\"` for each and `--recommended-option` for yours. When you cannot form one: `--recommend \"none yet: <what you need>\"`.)",
          tail = "\nThe card keeps its address and gains your recommendation.";
      var note = ask + ": " + what + gist + how + alt + tail;
      // quoting grows a heading full of apostrophes (each becomes four characters); the command already carries it, so the first line yields
      // before anything is cut: a command cut mid-quote would be worse than none, and the server refuses a note over its limit
      if (note.length > 1990) note = ask + "." + gist + how + tail;
      post(b.getAttribute("data-org"), { kind: "note", target: key ? { type: "queue", key: key, title: what.slice(0, 160) } : { type: "org", key: "", title: "" },
        note: note }).then(
        function (said) { toast("Asked " + b.getAttribute("data-ceo") + " for a recommendation: " + said); }, function (x) { toast("Not sent: " + x.message); });
      return;
    }
    if (b.classList.contains("tab")) { e.preventDefault(); nav(b.getAttribute("href")); return; }
  });
  D.addEventListener("org-answered", function (e) {
    var c = e.target.closest ? e.target.closest(".card") : null; if (!c) return;
    markDone(c, "✓ " + ((e.detail || {}).choice || "Answered") + " — " + ((e.detail || {}).said || "recorded"));
    toast("Recorded on " + c.getAttribute("data-org") + "'s board. " + ((e.detail || {}).said || ""));
  });
  D.addEventListener("keydown", function (e) {
    if ((e.metaKey || e.ctrlKey) && String(e.key).toLowerCase() === "k") { e.preventDefault(); $("#pal-q").value = ""; pi = 0; pal(); open("ov-pal", "#pal-q"); return; }
    if (e.defaultPrevented) return;
    if (e.key === "Escape") { if (anyOpen()) closeAll(); return; }
    var tg = (e.target || {}).tagName || "";
    if (e.target && e.target.id === "fb-q" && (e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); sendFb(); return; }
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(tg)) {
      if (e.target.id === "pal-q") {
        var box = $("#pal-r"), hits = box._hits || [];
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); pi = (pi + (e.key === "ArrowDown" ? 1 : hits.length - 1)) % Math.max(1, hits.length); pal(); }
        else if (e.key === "Enter" && hits[pi]) go(hits[pi]);
      }
      return;
    }
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (/^[1-6]$/.test(e.key)) { nav("v-" + PANES[+e.key - 1]); return; }
    if (cur === "decide" && (e.key === "ArrowRight" || e.key === "ArrowLeft")) step(e.key === "ArrowRight" ? 1 : -1);
  });
  D.addEventListener("input", function (e) { if (e.target.id === "pal-q") { pi = 0; pal(); } if (e.target.id === "fb-title" || e.target.id === "fb-q") fbEdited(); });
  D.addEventListener("click", function (e) { if (e.target.classList && e.target.classList.contains("ov")) closeAll(); });

  // --- the theme -----------------------------------------------------------------------------------------------
  function theme(t) {
    H.setAttribute("data-theme", t); try { localStorage.setItem("org-theme", t); } catch (e) {}
    var b = $("#theme-btn"); if (b) b.textContent = t === "dark" ? "◐ dark" : "◑ light";
  }
  theme(H.getAttribute("data-theme") || (matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));

  // --- an org's page, served under a fleet: the fleet and its siblings join the scope bar ------------------------------
  (function () {
    var m = location.pathname.match(/^(.*\/)o\/([^\/]+)\/$/), bar = $("#scopes"); if (!m || !bar) return;
    fetch(m[1] + "command.json", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
      if (!d || !d.orgs) return; bar.textContent = "";
      var S = { RED: "crit", CLEAR: "ok", DARK: "idle" };
      function chip(label, href, on, st, org) {
        var a = E(href && !on ? "a" : "span", "scope" + (on ? " on" : "")); if (href && !on) a.href = href;
        if (org) a.appendChild(E("i", "ic ic-org"));
        a.appendChild(E("i", "sg s-" + st + " g-" + st)); a.appendChild(D.createTextNode(label)); bar.appendChild(a);
      }
      chip("The fleet", m[1], false, (d.needs_you || []).length ? "wait" : "ok", false);
      d.orgs.forEach(function (o) { chip(o.id, (d.pages || {})[o.id] ? m[1] + d.pages[o.id] : "", o.id === decodeURIComponent(m[2]), S[o.state] || "idle", true); });
    }).catch(function () {});
  })();

  // --- a repaint -------------------------------------------------------------------------------------------------------
  // Served: the reader's own HTML was swapped into #bbody and #decide, and `refresh` re-selects the card the operator was on by its id (a
  // position would land on another decision when one arrives or leaves). Published: a store document is never trusted as markup, so
  // `paint` builds the same views from the reading's own fields, as text.
  var DECIDES = { operator: "you", org_ceo: "the org's CEO", org_core_ceo: "the org-core CEO session, under a standing decision" };
  var CLOSE = { done: "Close as done", reopen: "Reopen: back to ready" };   // handoffs.CLOSE_OPTIONS
  function mk(st, x) { return E("i", "sg s-" + st + " g-" + st + (x ? " " + x : "")); }
  function badges(c) {
    Object.keys(c.tabs || {}).forEach(function (k) {
      var b = $(".tab[data-tab=" + k + "] .badge"); if (!b) return;
      var t = c.tabs[k] || {}; b.textContent = t.n || ""; b.hidden = !t.n; b.className = "badge " + (t.tone || "");
    });
    var r = $("#recline"); if (r) r.textContent = c.rec || "";
  }
  function paintBrief(c, items) {
    var box = $("#bbody"); if (!box) return; box.textContent = "";
    var nums = E("div", "bnums"); nums.id = "bnums";
    (c.numbers || []).forEach(function (n) {
      var a = E("a", "bnum"), k = E("span", "bk"); a.href = "#v-" + n.view; a.appendChild(E("span", "bv", n.v));
      k.appendChild(mk(n.mark)); k.appendChild(D.createTextNode(n.k)); a.appendChild(k); if (n.note) a.appendChild(E("span", "bn", n.note)); nums.appendChild(a);
    });
    box.appendChild(nums);
    var top = items[0];
    if (top) {
      var sec = E("section", "bsec"), w = E("div", "btop"), b = E("div", "btopb"), m = E("div", "btopm");
      sec.appendChild(E("div", "bh", "Most urgent")); m.appendChild(mk(top.holding ? "crit" : "wait"));
      m.appendChild(D.createTextNode(c.scope.id + " · decision · " + (top.ago ? "waiting " + top.ago : "no date — its age is unknown")));
      b.appendChild(m); b.appendChild(E("div", "btopw", top.what)); if (top.holding) b.appendChild(E("div", "btopstop", "Stopping " + top.holding));
      var go = E("a", "bgo", "Decide →"); go.href = "#f-" + top.fid; w.appendChild(b); w.appendChild(go); sec.appendChild(w); box.appendChild(sec);
    } else if (c.queue_unread) {
      box.appendChild(E("div", "bnone", "What is waiting on you could not be checked — " + c.queue_note + ". Not read is neither clear nor waiting."));
    }
    var q = c.queue;
    if (q) {
      var qs = E("section", "bsec"); qs.id = "bqueue"; qs.appendChild(E("div", "bh", "Accomplished"));
      if (!q.read) qs.appendChild(E("div", "bnone", "Not checked \u2014 " + q.why + "."));
      else {
        if (q.empty) { var qe = E("div", "qempty"); qe.appendChild(E("b", null, "Queue empty")); qe.appendChild(D.createTextNode(" \u2014 nothing is ready, being built or waiting. " + (q.last || ""))); qs.appendChild(qe); }
        else if (q.empty === null) qs.appendChild(E("div", "qempty", "Whether the queue is empty is not checked \u2014 a source was not read."));
        var qc = E("div", "qcounts");
        (q.counts || []).forEach(function (x) { var sp = E("span"); sp.appendChild(E("b", null, x.v)); sp.appendChild(D.createTextNode(" " + x.k)); qc.appendChild(sp); });
        qs.appendChild(qc);
        var qt = E("div", "qtrend", q.trend.text); qt.title = (q.trend.days || []).join(" "); qs.appendChild(qt);
        (q.windows || []).forEach(function (w) {
          var wb = E("div", "qwin"), ul = E("ul");
          wb.appendChild(E("div", "qwh", w.h + " \u00b7 " + (w.n === null ? "not checked \u2014 " + w.why : w.n + " finished")));
          (w.rows || []).forEach(function (r) {
            var li = E("li");
            if (/^https:/.test(r.u)) { var la = E("a", null, r.t); la.href = r.u; li.appendChild(la); } else li.textContent = r.t;
            ul.appendChild(li);
          });
          if (w.more) ul.appendChild(E("li", "qmore", "and " + w.more + " more"));
          wb.appendChild(ul); qs.appendChild(wb);
        });
        (q.notes || []).forEach(function (n) { qs.appendChild(E("div", "qnote", n)); });
      }
      box.appendChild(qs);
    }
    var ls = E("section", "blines");
    (c.lines || []).forEach(function (l) {
      var a = E("a", "bline"), v = E("span", "blv"); a.href = "#v-" + l.view; a.appendChild(E("span", "blk", l.k));
      v.appendChild(mk(l.mark)); v.appendChild(D.createTextNode(l.v)); a.appendChild(v); a.appendChild(E("span", "blgo", "→")); ls.appendChild(a);
    });
    box.appendChild(ls);
  }
  function fact(box, k, v) { box.appendChild(E("div", "fk", k)); box.appendChild(E("div", "fv", v)); }
  function cardEl(i, c) {
    var a = E("article", "card"), h = i.handoff, ceo = c.ceo || "the CEO", facts = E("div", "cfacts"), head = E("div", "chead");
    a.id = "f-" + i.fid; a.setAttribute("data-fid", i.fid); a.setAttribute("data-org", c.scope.id); if (i.holding) a.setAttribute("data-blocks", "1");
    var rs = h && ((h.recommended_option) || (h.recommend && !/^none/i.test(String(h.recommend).trim()))) ? "rec" : (h || i.hread ? "none" : "unread");
    a.setAttribute("data-recstate", rs); a.setAttribute("data-arc", i.arc ? c.scope.id + "/" + i.arc : "");
    head.appendChild(E("i", "ic ic-ask")); head.appendChild(mk(i.holding ? "crit" : "wait")); head.appendChild(E("span", "cpos"));
    head.appendChild(E("span", null, c.scope.id + " · decision · " + (i.arc ? "arc " + i.arc : "no arc") + " · " + (i.ago ? "waiting " + i.ago : "no date — its age is unknown") + (rs === "none" ? " · no recommendation yet" : rs === "unread" ? " · recommendation not checked" : "")));
    var t3 = E("h3", "cwhat"), tl = E("a", "fl", i.what); tl.href = "#f-" + i.fid; t3.appendChild(tl); a.appendChild(head); a.appendChild(t3);
    if (i.why) fact(facts, "Why", i.why);
    if (i.item_moved) { var mv = i.item_moved, mvv = E("div", "fv"), mvs = E("span", "cmoved"); mvs.setAttribute("data-moved", mv.state);
      mvs.appendChild(mk(mv.mark)); mvs.appendChild(D.createTextNode(mv.words)); mvv.appendChild(mvs); facts.appendChild(E("div", "fk", "Its item")); facts.appendChild(mvv); }
    if (h) { fact(facts, "Decides", DECIDES[h.decides] || h.decides); if (h.cost) fact(facts, "Waiting costs", h.cost); if (h.do) fact(facts, "Do", h.do);
      if (h.left_hours != null) fact(facts, "Leaves the board", (h.left_hours ? "in " + h.left_hours + " h" : "within the hour") + " \u2014 unless it is recorded again (org handoffs add); an unanswered card that leaves is still listed by org handoffs --all");
      if (h.expired) fact(facts, "Left the board", (h.left_board ? "expired " + h.left_board : "left before its expiry (deleted?)") + ", never answered \u2014 this is its last text. Record it again if it is still true (org handoffs add), or close it (org handoffs done " + h.id + ")");
      if (h.note) fact(facts, "Send to " + (h.org || "the org") + "'s CEO", "the org-core CEO session hands this to that CEO by DM, as itself \u2014 the Do line names the DM. If that CEO is unreachable, copy the note below and paste it to that session yourself"); }
    fact(facts, "Written", (c.written || {})[i.fid] || "no date — nothing in this reading can say when it was written, so its age is unknown");
    if (i.where) fact(facts, "Where it lives", i.where);
    a.appendChild(facts);
    if (i.quote) a.appendChild(E("blockquote", "cquote", i.quote));
    if (i.holding) a.appendChild(E("div", "cblocks", "While this waits, " + i.holding + " stopped" + (((i.holds || {}).on || []).length ? " — they and this item both name " + i.holds.on.join(", ") : "") + "."));
    var rec = E("div", "crec" + (h && !h.no_recommendation && !(h.kind === "close_item" && !h.ceo) ? "" : " none"));
    var says = "";
    if (h && h.kind === "close_item") {
      var cl = h.ceo || {}; says = !h.ceo ? "not yet — the CEO owes its line before this reaches the operator" :
        (!cl.close ? "none — " + String(cl.recommend || "").replace(/^none(\s+yet)?\s*[:\-—]*\s*/i, "").trim() : (CLOSE[cl.close] || cl.close) + " — " + (cl.recommend || ""));
      rec.appendChild(E("b", null, ceo + " recommends")); rec.appendChild(D.createTextNode(" — " + says)); a.appendChild(rec);
      rec = E("div", "crec role"); rec.appendChild(E("b", null, (h.by || "the role that filed it") + " recommends"));
      rec.appendChild(D.createTextNode(" — " + (h.recommended_option || "") + ": " + (h.recommend || "")));
    } else if (h && !h.no_recommendation) { rec.appendChild(E("b", null, ceo + " recommends")); rec.appendChild(D.createTextNode(" — " + (h.recommend || ""))); }
    else { rec.appendChild(E("b", null, "Recommendation")); rec.appendChild(D.createTextNode(" — " + (h ? "none yet — the CEO owes one" : "nothing recorded — the CEO owes a recommendation, or the reason it has none"))); }
    a.appendChild(rec);
    a.appendChild(E("div", "cnosend", "This copy of the page cannot send an answer: copy it as a prompt and paste it to " + ceo + "."));
    var foot = E("div", "cfoot"), l = E("button", "cbtn clater", "Later"), sp = E("span", "shell-sp"), cp = E("button", "cbtn cc", "Copy as prompt"), lk = E("button", "cbtn cc", "Copy link");
    l.type = cp.type = lk.type = "button"; cp.setAttribute("data-cc", "prompt"); lk.setAttribute("data-cc", "link");
    cp.setAttribute("data-text", "I'm deciding something in " + c.scope.id + " and want help thinking it through.\n\nWhat: " + i.what + (i.why ? "\nWhy it is on me: " + i.why : "") +
      (h && h.kind === "close_item" ? "\nThe CEO's recommendation: " + says + "\n" + (h.by || "The role that filed it") + " recommends: " + (h.recommended_option || "") + ": " + (h.recommend || "") :
       h && h.recommend ? "\nThe CEO's recommendation: " + h.recommend : "") + "\n\nRead " + (i.where || "the item") + " in the repository first — this is a reading and may be old — then tell me what you would do and why.");
    var nb = null;
    if (h && h.note) { nb = E("button", "cbtn cc cnote", "Copy the note for " + (h.org || "the org") + "'s CEO"); nb.type = "button"; nb.setAttribute("data-cc", "note"); nb.setAttribute("data-text", h.note); }
    [l, sp, nb, cp, lk].forEach(function (x) { if (x) foot.appendChild(x); }); a.appendChild(foot); return a;
  }
  function paintDecide(c, items) {
    var box = $("#cards"); if (!box) return; box.textContent = "";
    items.map(function (i, k) { return { i: i, k: k, r: cardEl(i, c) }; })
      .sort(function (a, b) { return ((a.r.getAttribute("data-recstate") !== "rec") - (b.r.getAttribute("data-recstate") !== "rec")) || a.k - b.k; })
      .forEach(function (x) { box.appendChild(x.r); });
    var ph = $("#cleared"); if (ph) ph.hidden = items.length > 0;
  }
  // what the operator already answered (`console.answered_html`), from the reading's own words (`answered_part`), as text
  function paintAnswered(c) {
    var host = $("#decide"), old = $("#answered"), a = c.answered || []; if (!host) return;
    if (old) old.remove(); if (!a.length) return;
    var sec = E("section", "answered"), hd = E("div", "anh"), h3 = E("h3"), rows = E("div", "anrows"), open = a.filter(function (x) { return x.state !== "ok"; }).length;
    sec.id = "answered"; rows.id = "anrows";
    h3.appendChild(E("i", "ic ic-ask")); h3.appendChild(D.createTextNode("Answered ")); var n = E("span", "ann", a.length); n.id = "answered-n"; h3.appendChild(n);
    hd.appendChild(h3); hd.appendChild(E("span", "pmono", [open ? open + " waiting on the CEO to act" : "", a.length - open ? (a.length - open) + " acted on, not yet closed" : ""].filter(Boolean).join(" · ")));
    sec.appendChild(hd);
    sec.appendChild(E("div", "anl", "The board holds an answer to each, so none is waiting on you or counted as waiting: each waits on its CEO to act on the answer and close it, and leaves this list when it is closed."));
    a.forEach(function (x) {
      var d = E("details", "acard"), sm = E("summary"), am = E("span", "amark"), bd = E("span", "abody"), box = E("div", "abox"), ul = E("ul", "ansaid"), f = E("div", "cfacts");
      d.id = "f-" + x.fid; d.setAttribute("data-fid", x.fid); d.setAttribute("data-org", x.org); d.setAttribute("data-state", x.state);
      am.appendChild(mk(x.state)); bd.appendChild(E("span", "awhat", x.what));
      bd.appendChild(E("span", "ameta", x.org + " · " + x.kind + " · " + x.arc + " · " + x.words + (x.when ? " · answered " + x.when : "")));
      sm.appendChild(am); sm.appendChild(bd); d.appendChild(sm);
      (x.said || []).forEach(function (y) {
        var li = E("li"), st = E("span", "anst"); li.appendChild(E("span", "answ", y.how === "ruling" ? "ruling on the board" : "answer on the board"));
        li.appendChild(D.createTextNode(" ")); li.appendChild(E("b", null, y.text));
        li.appendChild(E("span", "answhen", (y.when || "no date") + (y.by ? " · claims to be from " + y.by : "")));
        st.appendChild(mk(y.acted ? "ok" : "live")); st.appendChild(D.createTextNode(y.acted ? (c.ceo || "the CEO") + " acted: " + (y.done || "done") : "not marked acted on yet"));
        li.appendChild(st); ul.appendChild(li);
      });
      box.appendChild(ul);
      if (x.why) fact(f, "Why", x.why); if (x.where) fact(f, "Where it lives", x.where); box.appendChild(f);
      box.appendChild(E("div", "anote", "The board is shared and unsigned, so an answer listed here is not proof it was you. If you did not send it, say so in a reply."));
      d.appendChild(box); rows.appendChild(d);
    });
    sec.appendChild(rows); host.appendChild(sec);
  }
  window.orgConsole = {
    refresh: function () { collect(); ci = -1; paintCards(); if (window.orgRefocus) window.orgRefocus(); },
    pane: pane, route: route,
    paint: function (d, build) {
      var c = d.console || {}; badges(c);
      if (!build) return;
      var you = ((d.brief || {}).sections || []).filter(function (s) { return s.id === "you"; })[0] || { items: [], more: [] };
      var items = you.items.concat(you.more || []);
      var typing = $$("#decide textarea").some(function (t) { return t.value; });
      paintBrief(c, items); if (!typing) { paintDecide(c, items); paintAnswered(c); collect(); ci = -1; paintCards(); }
    }
  };

  collect(); route(); paintCards();
  window.addEventListener("hashchange", route);
})();
</script>
"""
