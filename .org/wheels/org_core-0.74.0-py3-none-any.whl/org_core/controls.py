"""The operator's controls on the org page, and the team's listening marks (0.42.0).

The page never acts (rule 6): every control makes an **ask** (`asks.py`) — recorded, and relayed to the CEO as a plain
switchboard DM that wakes a sleeping CEO and leaves a busy one to read it at its next look. Which way an ask travels
depends on where the page is open, and the page says which before anything is pressed:

- **served** (`org status --serve`): posted to the reader that rendered the page, which records it on the org's board
  and relays it — the loop closed end to end, on the machine that holds the org's credentials;
- **published** (a claude.ai artifact granted `asks.ASK_CAPABILITIES`): written to the page's own `asks` collection as
  its owner, signed, and relayed through the operator's own switchboard on their device (`host:switchboard`, the Claude
  app) where there is one — else it waits for the CEO's next wake, and the page says so;
- **anywhere else** (the committed page, a file in a viewer): a control copies the instruction, for the operator to
  paste to the CEO themselves. Nothing pretends to have been sent.

Beside every agent the page names, a mark says whether it is listening — parked (a message wakes it), busy
(do-not-disturb: only urgent wakes it), between turns, away, gone — from the heartbeats the reading carries, and the team
section links the org's room in switchboard's viewer with nothing secret in the link (`asks.viewer_link`).
"""

from __future__ import annotations

import html
import json
from typing import Any

from .tempo import PRESENCE_STATES

STATE_WORDS = {"parked": "listening", "busy": "busy", "between turns": "between turns", "away": "away",
               "gone": "not listening", "unregistered": "not registered"}


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""))


#: a session's `status_bucket` (Claude Code Remote), as the page says it
BUCKET_WORDS = {"working": "running a turn", "blocked": "waiting on a person — a permission prompt or a question",
                "review_ready": "idle, with work ready for review", "completed": "idle", "failed": "idle — its last turn failed"}


def report_of(row: dict[str, Any]) -> dict[str, Any]:
    """A role's last run record, cut to what the page says (0.48.0): when it ended, how it ended, its own headline, what
    it counted, what stopped it, when it is next due. Bounded — a record is the role's words, shown, never obeyed."""
    from .tempo import _value
    v = _value(row)
    counts = v.get("counts") if isinstance(v.get("counts"), dict) else {}
    return {"at": v.get("ended_at") or v.get("at") or row.get("updated_at"), "outcome": str(v.get("outcome") or "")[:20],
            "headline": str(v.get("headline") or "")[:240], "blocked": str(v.get("blocked") or "")[:200],
            "counts": {str(k)[:30]: (n if isinstance(n, (int, float)) else str(n)[:20]) for k, n in list(counts.items())[:6]},
            "next_due": v.get("next_due"), "woken_by": str(v.get("woken_by") or "")[:80]}


def report_line(rep: dict[str, Any] | None, tz: str | None, *, read: bool = True) -> str:
    """"Last report: 14:02 IDT · ran — headline · 3 prs · blocked: … · next due …". A board that was not read says so —
    never the empty line that reads as "this role has reported nothing" (row 65)."""
    from .dashboard import _clock
    if not rep:
        return "Last report: none on the board" if read else "Last report: not read — the board was not read"
    bits = [(_clock(rep["at"], tz) if rep.get("at") else "undated") + (f" · {rep['outcome']}" if rep.get("outcome") else "")]
    if rep.get("headline"):
        bits[0] += f" — {rep['headline']}"
    if rep.get("counts"):
        bits.append(", ".join(f"{k} {v}" for k, v in rep["counts"].items()))
    if rep.get("blocked"):
        bits.append("blocked: " + rep["blocked"])
    if rep.get("next_due"):
        bits.append("next due " + _clock(rep["next_due"], tz))
    return "Last report: " + " · ".join(bits)


def work_line(r: dict[str, Any], team: dict[str, Any] | None, tz: str | None) -> dict[str, str]:
    """What a role is doing, from the CEO's snapshots (0.44.0): its session (running, idle, waiting on a prompt; cost and
    context) and its routine (on or off, next run, last result) — each with how old the snapshot is, and "not read" when
    no snapshot is on the board, never an empty line that reads as "nothing running" (row 65)."""
    from .dashboard import _clock
    team = team or {}
    out = {}
    snap = team.get("sessions")
    s = r.get("session")
    if s:
        bucket = str(s.get("bucket") or "").lower().replace("session_status_bucket_", "")
        state = str(s.get("status") or "").lower().replace("session_status_", "")
        bits = [BUCKET_WORDS.get(bucket, state or bucket or "state unknown")]
        if s.get("doing"):
            bits.append("“" + str(s["doing"])[:120] + "”")
        if s.get("needs"):
            bits.append("needs: " + str(s["needs"])[:120])
        if s.get("cost") is not None:
            bits.append(f"${float(s['cost']):.2f}")
        if s.get("tokens") is not None:
            bits.append(f"{int(s['tokens']) // 1000}k context")
        if s.get("updated_at"):
            bits.append("last active " + _clock(s["updated_at"], tz))
        out["session"] = "Session: " + " · ".join(bits)
    elif snap:
        out["session"] = ("Session: none live" if r.get("runtime") == "session" else "Session: none live (spawned per task)")
    else:
        out["session"] = "Session: not read — the CEO has published no sessions snapshot"
    snap_t = team.get("triggers")
    t = r.get("routine")
    if t:
        bits = ["on" if t.get("enabled") else "off"]
        if t.get("cron"):
            bits.append(f"`{t['cron']}`")
        if t.get("enabled") and t.get("next_run_at"):
            bits.append("next " + _clock(t["next_run_at"], tz))
        if t.get("last_fired_at"):
            bits.append("last ran " + _clock(t["last_fired_at"], tz) + (f" ({str(t['last_status']).lower()})" if t.get("last_status") else ""))
        out["routine"] = "Routine: " + " · ".join(bits)
    elif snap_t:
        out["routine"] = "Routine: none"
    else:
        out["routine"] = "Routine: not read — the CEO has published no routines snapshot"
    ages = [f"{w} {_clock(x['at'], tz)}" for w, x in (("sessions as of", snap), ("routines as of", snap_t)) if x and x.get("at")]
    out["as_of"] = "; ".join(ages)
    return out


def card_lines(r: dict[str, Any], team: dict[str, Any] | None, tz: str | None) -> list[str]:
    """What the card beside an agent says (0.47.1): its listening state and what that means, then its session and its
    routine (`work_line`'s words, each as old as the CEO's snapshot), then how old the snapshots are. Composed here,
    in the operator's zone, so every page that names the agent — the fleet console, an org's own page — reads the same."""
    from .dashboard import _clock
    st = str(r.get("state") or "")
    w = r.get("work") or work_line(r, team, tz)
    first = (STATE_WORDS.get(st, st) or "state not read") + (f" · until {_clock(r['until'], tz)}" if r.get("until") else "")
    if r.get("means"):
        first += f" — {r['means']}"
    return [first, w["session"], w["routine"]] + ([w["report"]] if w.get("report") else []) + ([w["as_of"]] if w.get("as_of") else [])


def with_cards(p: dict[str, Any] | None, tz: str | None) -> dict[str, Any]:
    """A copy of a presence reading whose every role carries its `card` — a reading taken before 0.47.1 has none."""
    if not p or not p.get("roles"):
        return dict(p or {})
    return {**p, "roles": [{**r, "card": r.get("card") or card_lines(r, p.get("team"), tz)} for r in p["roles"]]}


def agent_link(org: str, role: str, page: str | None, inner: str, cls: str = "", title: str = "") -> str:
    """One agent, named on a page, as the element `AGENTS_JS` hangs a card on: a link to its row on its org's page when
    that page is served, else the same element as a span (the card, no link). `inner` is HTML the caller escaped; `title`
    is the card's words for a page with scripts off, which the script removes when it draws the card."""
    c = ("ag " + cls).strip()
    attrs = f"class='{c}' data-org='{_e(org)}' data-role='{_e(role)}'" + (f" title='{_e(title)}'" if title else "")
    if page:
        return f"<a {attrs} href='{_e(page)}#team-{_e(role)}'>{inner}</a>"
    return f"<span {attrs}>{inner}</span>"


def role_row(r: dict[str, Any], p: dict[str, Any], tz: str | None, stopped_on: str = "") -> str:
    """One role of the roster as the row `JS` hangs its controls on (`#team .trow[data-role]`). `stopped_on` is HTML the caller
    escaped — a link to the decision the role is stopped on."""
    from .dashboard import _clock
    state = r.get("state") or "unknown"
    w = r.get("work") or work_line(r, p.get("team"), tz)
    return (
        f"<div class='trow' id='team-{_e(r['role'])}' data-role='{_e(r['role'])}' data-agent='{_e(r.get('agent_id') or '')}'"
        f" data-session='{_e((r.get('session') or {}).get('bucket') or '')}'"
        f" data-routine='{_e('' if not r.get('routine') else ('on' if r['routine'].get('enabled') else 'off'))}'"
        f" data-runtime='{_e(r.get('runtime') or '')}'>"
        f"<span class='pdot ps-{_e(state.replace(' ', '-'))}' aria-hidden='true'></span>"
        f"<span class='tname2'><b>{_e(r['name'])}</b> <span class='trole'>{_e(r['role'])}</span></span>"
        f"<span class='tstate'>{_e(STATE_WORDS.get(state, state))}"
        + (f" · until {_e(_clock(r['until'], tz))}" if r.get("until") else "") + "</span>"
        f"<span class='tmeans'>{_e(r.get('means'))}"
        + (" (the listeners were not read: these facts predate 0.42.0)" if not p.get("beats_read") else "")
        + "</span><span class='tctl'></span>"
        + (f"<span class='tstop'>Stopped on: {stopped_on}</span>" if stopped_on else "")
        + f"<span class='twork'><span class='tsess'>{_e(w['session'])}</span>"
        f"<span class='trout'>{_e(w['routine'])}</span>"
        + (f"<span class='trep'>{_e(w['report'])}</span>" if w.get("report") else "") + "</span></div>")


def off_row(o: dict[str, Any]) -> str:
    return (f"<div class='trow toff' data-role='{_e(o['role'])}' data-off='1'>"
            "<span class='pdot ps-unregistered' aria-hidden='true'></span>"
            f"<span class='tname2'>{_e(o['name'])} <span class='trole'>{_e(o['role'])}</span></span>"
            "<span class='tstate'>not set up</span>"
            f"<span class='tmeans'>in the package's cast, and this org's manifest leaves it off"
            f"{(' (runs as a ' + _e(o['runtime']) + ')') if o.get('runtime') else ''}</span>"
            "<span class='tctl'></span></div>")


def other_row(o: dict[str, Any]) -> str:
    state = o.get("state") or "unknown"
    return (f"<div class='trow'><span class='pdot ps-{_e(state.replace(' ', '-'))}' aria-hidden='true'></span>"
            f"<span class='tname2'>{_e(o.get('name') or o.get('agent_id'))} <span class='trole'>no role</span>"
            f"</span><span class='tstate'>{_e(STATE_WORDS.get(state, state))}</span>"
            f"<span class='tmeans'>on the roster, and no role in the manifest names it</span></div>")


def as_of_html(p: dict[str, Any], tz: str | None) -> str:
    ages = work_line({}, p.get("team"), tz)["as_of"]
    return f"<div class='tasof' id='team-asof'>{_e(ages or 'No sessions or routines snapshot on the board: the CEO publishes one each wake (0.44.0).')}</div>"


def team_html(st: dict[str, Any], *, ask_token: str | None = None, groups: str | None = None) -> str:
    """The team, right now — every role's mark and what a message does to it, the room's viewer link, anyone else on the
    roster, and the operator's asks with where each stands. Scripts off, this is the whole section; scripts on,
    `JS` adds the controls to it and to the rest of the page. `groups` is the roster already drawn in groups
    (`console.team_groups_html`); without it the roles are one list."""
    s = st.get("subjects") or {}
    tz = st.get("operator_timezone")
    p = with_cards(s.get("presence") or {}, tz)
    asks = s.get("asks") or []
    from .dashboard import _clock
    if not p.get("read"):
        body = "<div class='rmnone'>The roster was not read, so nobody's listening state is known.</div>"
    elif groups is not None:
        body = groups
    else:
        body = "".join([role_row(r, p, tz) for r in p.get("roles") or []] + [off_row(o) for o in p.get("off") or []]
                       + [other_row(o) for o in p.get("others") or []]) + as_of_html(p, tz)
    room = p.get("room") or {}
    viewer = (f"<a href='{_e(room['viewer'])}' target='_blank' rel='noopener'>Open the room in switchboard's viewer ↗</a>"
              f" <span class='tmeans'>— {_e(room.get('workspace'))}; the link carries no key, so the viewer asks for "
              "the room's key once</span>") if room.get("viewer") else ""
    asked = "".join(
        f"<div class='arow2' data-ask='{_e(a.get('id'))}'><span class='pdot {'ps-done' if a.get('done') else 'ps-asking'}' "
        f"aria-hidden='true'></span><span><b>{_e(a.get('kind'))}{(' ' + _e(a['choice'])) if a.get('choice') else ''}</b> "
        f"{_e((a.get('target') or {}).get('type'))} <code>{_e((a.get('target') or {}).get('key'))}</code>"
        + (f" — “{_e(str(a.get('note'))[:140])}”" if a.get("note") else "")
        + f"</span><span class='tmeans'>asked {_e(_clock(a.get('at'), tz))} · "
        + (f"done {_e(_clock(a['done'].get('at'), tz))}: {_e(a['done'].get('note'))}" if a.get("done") else "waiting on the CEO")
        + "</span></div>" for a in asks[:30])
    return (f"<section class='sec team' id='team'><div class='sechead'>"
            f"<span class='ct'>{len(p.get('roles') or [])}</span><h2>The team, right now</h2>"
            "<p>Who is listening, and what a message does to each. An ask from this page is recorded and relayed to "
            "the CEO as a plain message: a CEO that is asleep with a listener parked wakes on it; one that is busy reads "
            "it at its next look, without being interrupted. <b>Wake</b> sends that same plain message to the role's own agent "
            "instead; <b>Run now</b>, <b>Set up</b> and <b>Shut down</b> act on sessions and routines, which only the CEO "
            "can, so they are asks to it.</p>"
            f"<p class='xlanes' id='ask-route'></p></div>"
            f"<div class='tbody' id='teamgroups'>{body}</div>"
            + (f"<div class='troom'>{viewer}</div>" if viewer else "")
            + "<div class='tell' id='tell'></div>"
            + f"<div class='asked' id='asked'>{asked or ''}</div></section>"
            + (f"<meta name='org-ask' content='{_e(ask_token)}'>" if ask_token else "")
            + f"<script type='application/json' id='org-controls'>"
            + json.dumps({"org": st.get("org"), "presence": p, "asks": asks[:30], "tz": tz},
                         ensure_ascii=False).replace("<", "\\u003c") + "</script>")


CSS = """
.team .tbody{padding:4px 0}
.trow{display:grid;grid-template-columns:14px minmax(120px,190px) minmax(90px,150px) minmax(0,1fr) auto;gap:4px 12px;
  align-items:baseline;padding:9px 18px;border-top:1px solid var(--border)}
.trow:first-child{border-top:none}
.trow{scroll-margin-top:16px}
.trow:target{background:var(--surface-2);box-shadow:inset 3px 0 0 var(--accent)}
.tname2 b{font-weight:600}
.trole{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--muted)}
.tstate{font-size:12.5px;font-weight:600}
.tmeans{font-size:12px;color:var(--ink-2)}
.tstop{grid-column:2 / -1;font-size:12px}.tstop a{color:var(--accent)}
.tgroup>.tghead{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:12px 18px 4px;border-top:1px solid var(--border)}
.tgroup:first-child>.tghead{border-top:none}
.tghead h3{margin:0;font-size:13px}.tghead .tgn{font-size:12px;color:var(--muted)}.tghead .tgmeans{flex-basis:100%;font-size:12px;color:var(--ink-2)}
.twork{grid-column:2 / -1;display:flex;flex-wrap:wrap;gap:2px 18px;font-size:12px;color:var(--ink-2)}
.trep{flex-basis:100%;color:var(--ink)}
.toff{opacity:.8}
.tasof{padding:6px 18px 10px;font-size:11.5px;color:var(--muted)}
.troom{padding:10px 18px;border-top:1px solid var(--border);font-size:12.5px}
.troom a,.asked a{color:var(--accent)}
.pdot{margin-right:4px;vertical-align:-2px;color:var(--c-ring);--m:var(--g-idle)}
.trow>.pdot{margin:0;align-self:center}
/* a role's or a session's presence, in the page's five states (org_core/vocab.py); the words beside it say it too */
.ps-parked{color:var(--c-ok);--m:var(--g-ok)}
.ps-busy,.ps-live{color:var(--c-live);--m:var(--g-live)}
.ps-between-turns{color:var(--c-live2);--m:var(--g-claimed)}
.ps-away{color:var(--c-idle);--m:var(--g-idle)}
.ps-gone{color:var(--c-crit);--m:var(--g-crit)}
.ps-unregistered{color:var(--c-idle);--m:var(--g-parked)}
.ps-asking{color:var(--c-wait);--m:var(--g-wait)}
.ps-done{color:var(--c-idle);--m:var(--g-done)}
.pmark{margin:0 3px 0 0}
.ag{color:inherit;text-decoration:none;border-radius:4px}
a.ag{cursor:pointer}a.ag:hover,a.ag:focus-visible{text-decoration:underline dotted;text-underline-offset:3px}
a.ag:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.trow.flash{background:var(--surface-2);box-shadow:inset 3px 0 0 var(--accent)}
.tipbox{position:fixed;z-index:60;max-width:min(360px,calc(100vw - 16px));padding:10px 12px;border:1px solid var(--border);
  border-radius:8px;background:var(--surface);color:var(--ink);box-shadow:0 6px 22px rgba(0,0,0,.16);font-size:12px;
  line-height:1.45;pointer-events:none;white-space:normal;font-weight:400;text-align:left}
.tipbox[hidden]{display:none}.tipbox b{font-weight:600;font-size:13px}
.tipbox i{font-style:normal;color:var(--muted);font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11px}
.tipbox span{display:block;color:var(--ink-2);margin-top:3px}.tipbox .tipf{color:var(--ink);font-weight:600}
.tell,.asked{padding:0 18px}
.tell:empty,.asked:empty{display:none}
.tell{padding-block:12px;border-top:1px solid var(--border)}
.asked{padding-block:6px 12px;border-top:1px solid var(--border)}
.arow2{display:grid;grid-template-columns:14px minmax(0,1fr);gap:2px 10px;padding:6px 0;font-size:13px}
.arow2 .tmeans{grid-column:2}
.arow2 code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px}
.ctl{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:8px}
.ctl textarea,.ctl input{font:inherit;font-size:13px;flex:1 1 220px;min-height:34px;padding:6px 9px;border:1px solid var(--border);
  border-radius:7px;background:var(--surface);color:var(--ink);resize:vertical}
.ctl textarea:focus-visible,.ctl input:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.ctlsaid{flex-basis:100%;font-size:12px;color:var(--ink-2)}
.ctlsaid.ok{color:var(--green)}
.ctlsaid.bad{color:var(--red)}
.ctlopen{font:inherit;font-size:12px;color:var(--accent);background:none;border:0;padding:0;cursor:pointer;text-decoration:underline}
@media (max-width:620px){.trow{grid-template-columns:14px minmax(0,1fr);padding-inline:16px}
  .trow .tstate,.trow .tmeans,.trow .tctl,.trow .twork{grid-column:2}}
"""


#: the agent cards (0.47.1), one script for every page that names an agent — the fleet console and an org's own page. An
#: element with class `ag`, `data-org` and `data-role` gets a card on hover or keyboard focus (the agent's listening
#: state, session and routine, from the registry the page carries: words composed on the server, only arranged here);
#: `mark` finds the agents a page names in running text and makes each one such an element, linking to its row on the
#: org's page. Every node is built with textContent. A role's key is a common word ("the reviewer said…"), so it is
#: marked only where the page uses it as a name: after `(` or `▸ `, after `held by `, after an upper-case status word
#: (`DEAD verifier`), or alone in its cell. A name is marked wherever it stands as a whole word.
AGENTS_JS = r"""
<script>
(function () {
  "use strict";
  if (window.orgAgents) return;
  var REG = {}, box = null, on = null, tid = null;
  var WORDS = { parked: "listening", busy: "busy", "between turns": "between turns", away: "away", gone: "not listening", unregistered: "not registered" };
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x !== undefined && x !== null) e.textContent = String(x); return e; }
  function cls(state) { return "ps-" + String(state || "unknown").replace(/ /g, "-"); }
  function roster(org) { return (REG[org || ""] || {}).roles || []; }
  function find(org, role) { return roster(org).filter(function (r) { return r.role === role; })[0] || null; }
  function lines(r) {
    if (r.card && r.card.length) return r.card;
    var w = r.work || {}, out = [(WORDS[r.state] || "state not read") + (r.means ? " — " + r.means : "")];
    if (w.session) out.push(w.session); if (w.routine) out.push(w.routine); if (w.as_of) out.push(w.as_of);
    return out;
  }
  function hide() { if (on) on.removeAttribute("aria-describedby"); on = null; if (box) box.hidden = true; }
  function show(el) {
    var r = find(el.getAttribute("data-org"), el.getAttribute("data-role")); if (!r) return;
    if (!box) { box = E("div", "tipbox"); box.id = "tipbox"; box.setAttribute("role", "tooltip"); box.hidden = true; document.body.appendChild(box); }
    on = el; box.textContent = "";
    var h = E("div"); h.appendChild(E("b", null, r.name || r.role)); h.appendChild(document.createTextNode(" ")); h.appendChild(E("i", null, r.role));
    box.appendChild(h);
    lines(r).forEach(function (x, n) { box.appendChild(E("span", n ? null : "tipf", x)); });
    box.hidden = false;
    var b = el.getBoundingClientRect(), w = box.offsetWidth, ht = box.offsetHeight;
    box.style.left = Math.max(8, Math.min(b.left, window.innerWidth - w - 8)) + "px";
    box.style.top = (b.bottom + 6 + ht > window.innerHeight - 8 ? Math.max(8, b.top - ht - 6) : b.bottom + 6) + "px";
    el.setAttribute("aria-describedby", "tipbox");
  }
  function agent(t) { return t && t.closest ? t.closest(".ag") : null; }
  document.addEventListener("mouseover", function (e) { var a = agent(e.target); if (a && a !== on) { a.removeAttribute("title"); show(a); } });
  document.addEventListener("mouseout", function (e) { var a = agent(e.target); if (a && !(e.relatedTarget && a.contains(e.relatedTarget))) hide(); });
  document.addEventListener("focusin", function (e) { var a = agent(e.target); if (a) { a.removeAttribute("title"); show(a); } });
  document.addEventListener("focusout", function (e) { if (agent(e.target)) hide(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") hide(); });
  window.addEventListener("scroll", hide, true);
  // an in-page landing moves the address with pushState, which does not move :target — so the row it lands on is flashed
  document.addEventListener("click", function (e) {
    var a = agent(e.target), href = a && a.getAttribute("href"); if (!href || href.charAt(0) !== "#") return;
    hide(); var id = href.slice(1);
    setTimeout(function () {
      var row = document.getElementById(id); if (!row) return;
      row.classList.add("flash"); clearTimeout(tid); tid = setTimeout(function () { row.classList.remove("flash"); }, 2200);
    }, 0);
  });

  // --- the agents a page names in running text ------------------------------------------------------------------
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
  var SKIP = /^(SCRIPT|STYLE|TEXTAREA|INPUT|SELECT|BUTTON|CODE|PRE)$/;
  var AFTER = /(\(|▸ |held by |\b[A-Z]{3,} )$/;
  function mark(root, org) {
    var list = [];
    roster(org).forEach(function (r) {
      if (!r.state) return;                                   // an unread roster marks nobody (row 65)
      if (r.name && r.name.length >= 3) list.push({ k: r.name, r: r });
      if (r.role && r.role !== r.name) list.push({ k: r.role, r: r, strict: true });
    });
    if (!root || !list.length) return;
    list.sort(function (a, b) { return b.k.length - a.k.length; });
    var by = {}; list.forEach(function (n) { by[n.k] = n; });
    var re = new RegExp("\\b(" + list.map(function (n) { return escRe(n.k); }).join("|") + ")\\b");
    var reG = new RegExp(re.source, "g"), page = (REG[org || ""] || {}).page || "";
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: function (n) {
      var p = n.parentNode; if (!p || SKIP.test(p.nodeName) || (p.closest && p.closest(".ctl, .ag, .pmark, .tipbox, [contenteditable]"))) return NodeFilter.FILTER_REJECT;
      return re.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP; } });
    var hits = []; while (w.nextNode()) hits.push(w.currentNode);
    hits.forEach(function (n) {
      var ms = [], m; reG.lastIndex = 0;
      while ((m = reG.exec(n.nodeValue))) ms.push({ i: m.index, k: m[1] });
      var text = n.nodeValue;
      ms.reverse().forEach(function (x) {            // from the last name back, so the earlier offsets still hold
        var hit = by[x.k], before = text.slice(0, x.i);
        if (hit.strict && !AFTER.test(before) && text.trim() !== x.k) return;
        if (hit.strict && hit.r.name && before.slice(-(hit.r.name.length + 2)) === hit.r.name + " (") return;   // "Vera (verifier)": one mark, on the name
        var pv = n.previousSibling;                     // ...and on a second pass, when that name is already its own element
        if (hit.strict && before === " (" && pv && pv.classList && pv.classList.contains("ag") && pv.getAttribute("data-role") === hit.r.role) return;
        var mid = n.splitText(x.i); mid.splitText(x.k.length);
        var inLink = !!(mid.parentNode.closest && mid.parentNode.closest("a"));           // a link inside a link is not one: the card only
        var el = E(inLink ? "span" : "a", "ag"); el.setAttribute("data-org", org || ""); el.setAttribute("data-role", hit.r.role); el.setAttribute("data-m", "1");
        if (!inLink) el.setAttribute("href", page + "#team-" + hit.r.role);
        var dot = E("span", "pmark " + cls(hit.r.state)); dot.setAttribute("role", "img"); dot.setAttribute("aria-label", WORDS[hit.r.state] || hit.r.state || "state not read");
        mid.parentNode.insertBefore(el, mid); el.appendChild(dot); el.appendChild(mid);
      });
    });
  }
  function unmark(root) {
    Array.prototype.forEach.call((root || document).querySelectorAll(".ag[data-m]"), function (el) {
      var p = el.parentNode; if (!p) return;
      while (el.lastChild) { if (el.lastChild.classList && el.lastChild.classList.contains("pmark")) el.removeChild(el.lastChild); else p.insertBefore(el.lastChild, el.nextSibling); }
      p.removeChild(el); p.normalize();
    });
  }
  window.orgAgents = { set: function (reg) { REG = reg || {}; }, mark: mark, unmark: unmark, find: find };
})();
</script>
"""


#: the controls, scripts on. Every node is built with textContent; an ask is plain JSON; the only text composed here is
#: the short instruction a published or copied ask carries, which quotes the operator's note line by line.
JS = r"""
<script>
(function () {
  "use strict";
  var dataEl = document.getElementById("org-controls"); if (!dataEl) return;
  var D; try { D = JSON.parse(dataEl.textContent); } catch (e) { return; }
  var tokenEl = document.querySelector("meta[name='org-ask']"), TOKEN = tokenEl ? tokenEl.getAttribute("content") : null;
  var MODE = TOKEN ? "served" : "copy", db = null, mcp = null, me = null, busy = false;
  var WORDS = { parked: "listening", busy: "busy", "between turns": "between turns", away: "away", gone: "not listening", unregistered: "not registered" };
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x !== undefined && x !== null) e.textContent = String(x); return e; }
  function cls(state) { return "ps-" + String(state || "unknown").replace(/ /g, "-"); }
  function ceo() { return ((D.presence || {}).roles || []).filter(function (r) { return r.role === "ceo"; })[0] || null; }
  function newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

  // --- where an ask goes ------------------------------------------------------------------------------------------
  function routeLine() {
    var el = document.getElementById("ask-route"); if (!el) return;
    var c = ceo(), st = c && c.state ? (WORDS[c.state] || c.state) : "unknown";
    // what a relay does to the CEO as the reading last saw it — "relayed now (it is not listening)" read as a contradiction
    var does = !c || !c.state ? "the CEO's state was not read" : c.state === "parked" ? "it is listening, so it wakes on the ask"
      : c.state === "busy" ? "it is busy, so it reads the ask at its next look, uninterrupted"
      : c.state === "unregistered" ? "no CEO agent is registered, so it reads the ask on the board at its next wake"
      : "it is " + st + ", so the ask waits for it on the board and in its inbox";
    el.textContent = MODE === "served" ? "Asks from this page are recorded on the org's board and relayed to the CEO: " + does + "."
      : MODE === "store" ? "Asks from this page are recorded in it, as its owner" + (mcp ? ", and relayed to the CEO through your switchboard (it is " + st + ")." : "; the CEO reads them at its next wake — open this page in the Claude app with switchboard to relay them now.")
      : "This copy of the page cannot send: a control copies the instruction, for you to paste to the CEO.";
  }
  function quote(t) { return String(t || "").split("\n").map(function (l) { return "> " + l; }).join("\n"); }
  function textOf(a) {                  // the instruction a published or copied ask carries (the served reader writes its own)
    var t = a.target || {};
    return "The operator asks, from " + (D.org || "the org") + "'s dashboard: " + a.kind + (a.choice ? " — " + a.choice : "") +
      ", on " + t.type + (t.key ? " `" + t.key + "`" : "") + (t.title ? " (" + t.title + ")" : "") + "." +
      (a.kind === "prioritize" ? "\n\nWhat it asks of you: set the " + t.type + "'s priority to " + a.choice + " (`clear` removes it) by landing it as a file edit — `org priorities` — then a PR, as every roadmap change goes." : "") +
      (a.kind === "speed" ? "\n\nWhat it asks of you: speed this arc up — put builders on its ready items now, up to the dispatcher's cap, or say what is holding it back." : "") +
      (a.note ? "\n\nThe operator's note (quoted):\n" + quote(a.note) : "") +
      (a.kind === "feedback" && a.context ? "\n\nContext the page attached (measured by the page, not typed; quoted):\n" + quote(Object.keys(a.context).map(function (k) { return k + ": " + a.context[k]; }).join("\n")) : "") +
      (MODE === "store" ? "\n\nRecorded in the page's `asks` collection as `" + a.id + "`: read it with `org asks --from <listing>` and act." : "");
  }
  async function send(a, said) {
    if (busy) return; busy = true;
    a.at = new Date().toISOString(); a.id = newId();
    said.className = "ctlsaid"; said.textContent = "sending…";
    try {
      if (MODE === "served") {
        var r = await fetch("ask", { method: "POST", headers: { "Content-Type": "application/json", "X-Org-Ask": TOKEN }, body: JSON.stringify(a) });
        var j = await r.json().catch(function () { return {}; });
        if (!r.ok) throw new Error(j.error || ("HTTP " + r.status));
        said.className = "ctlsaid ok"; said.textContent = j.said || "recorded";
        listAsk(j.ask || a, j.said);
      } else if (MODE === "store") {
        a.by = me; a.via = "the published page";
        await db.doc("asks/" + a.id).set(a);
        var msg = "recorded in this page";
        var c = ceo(), rw = a.kind === "wake" ? roleOf((a.target || {}).key) : null;
        if (rw && rw.agent_id) c = rw;          // a wake goes to the role's own agent, as the served page sends it
        if (mcp && c && c.agent_id) {
          try { await mcp.callTool("host:switchboard", "dm", { to: c.agent_id, message: textOf(a) });
                msg += " and relayed to " + (c === rw ? (rw.name || rw.role) : "the CEO") + " — " + (c.state === "parked" ? "it was asleep, so it wakes on this now" : c.state === "busy" ? "it is busy, so it reads this at its next look" : "it reads this on its next turn"); }
          catch (e) { msg += "; the relay did not go (" + ((e && e.code) || "error") + "), so the CEO reads it at its next wake"; }
        } else msg += "; the CEO reads it at its next wake";
        said.className = "ctlsaid ok"; said.textContent = msg; listAsk(a, msg);
      } else {
        await copyText(textOf(a));
        said.className = "ctlsaid ok"; said.textContent = "copied — paste it to the CEO; this copy of the page cannot send";
      }
    } catch (e) { said.className = "ctlsaid bad"; said.textContent = "not sent: " + (e && e.message ? e.message : e); }
    busy = false;
  }
  function copyText(t) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(t);
    return new Promise(function (ok, no) {
      var ta = E("textarea"); ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select();
      var done = false; try { done = document.execCommand("copy"); } catch (e) {} document.body.removeChild(ta); done ? ok() : no(new Error("the browser blocked the clipboard"));
    });
  }
  function listAsk(a, said) {
    var box = document.getElementById("asked"); if (!box) return;
    var row = E("div", "arow2"), t = a.target || {};
    row.appendChild(E("span", "pdot ps-asking")); var s = E("span"); s.appendChild(E("b", null, a.kind + (a.choice ? " " + a.choice : "")));
    s.appendChild(document.createTextNode(" " + t.type + " ")); s.appendChild(E("code", null, t.key || ""));
    if (a.note) s.appendChild(document.createTextNode(" — “" + String(a.note).slice(0, 140) + "”"));
    row.appendChild(s); row.appendChild(E("span", "tmeans", "just now · " + (said || "recorded")));
    box.insertBefore(row, box.firstChild);
  }

  // --- the controls -------------------------------------------------------------------------------------------------
  function btn(t, fn) { var b = E("button", "xbtn", t); b.type = "button"; b.onclick = fn; return b; }
  function panel(target, choices, kind, label) {
    var box = E("div", "ctl"), note = E("textarea"), said = E("span", "ctlsaid");
    note.rows = 1; note.placeholder = "a note for the CEO (optional)"; note.maxLength = 2000; note.setAttribute("aria-label", "Note for the CEO");
    choices.forEach(function (c) {
      box.appendChild(btn(c[1], function () { send({ kind: c[0].kind || kind, choice: c[0].choice || null, target: target, note: note.value }, said); }));
    });
    box.appendChild(note); box.appendChild(said);
    if (!label) return box;
    var wrap = E("div"), open = E("button", "ctlopen", label); open.type = "button";
    open.onclick = function () { wrap.removeChild(open); wrap.appendChild(box); var f = box.querySelector("button"); if (f) f.focus(); };
    // an open panel holds the page's repaint off its row (`swapFragments`); a way to close it is how the row follows the reading again
    var close = btn("Close", function () { wrap.removeChild(box); wrap.appendChild(open); open.focus(); if (window.orgTeamApply) window.orgTeamApply(); }); close.className += " ctlclose";
    box.appendChild(close);
    wrap.appendChild(open); return wrap;
  }
  // a ruling on a heading from the operator file, on the Decide view's card (`console.card_html`). The heading is the question, so the
  // controls name it, say what each button does, and take the answer in words: Approve and Reject cannot answer "which scheme?" or
  // "how should…?", so a question of that kind is answered as a `rule` whose choice is `answer`, and Defer is the one button left (0.55.2)
  function rulingKind(what) {
    var w = String(what || "").replace(/^[\s“"'`*_]+/, "");
    if (/^yes\s*(or|\/)\s*no\b/i.test(w) || /^(does|do|is|are|should|can|will|would|may)\b/i.test(w)) return "yn";
    if (/^(which|how|what|where|when|who|why|say|tell|name|pick|choose|decide)\b/i.test(w)) return "open";
    return "go";
  }
  var RULING = {
    go: { tiles: [["approve", "Approve", "go ahead"], ["reject", "Reject", "don’t"], ["defer", "Defer", "ask me again later"]],
          legend: "Approve — the CEO goes ahead as the item proposes. Reject — it does not. Defer — it asks you again later. Or answer in your own words (“done”, or what you decided).",
          hint: "Add a note, or answer in your own words", send: "Send answer" },
    yn: { tiles: [["approve", "Yes", "go ahead"], ["reject", "No", "don’t"], ["defer", "Defer", "ask me again later"]],
          legend: "Yes — the CEO goes ahead. No — it does not. Defer — it asks you again later. Words you add go with your choice, or answer in them alone.",
          hint: "Add a note, or answer in your own words", send: "Send answer" },
    open: { tiles: [["defer", "Defer", "ask me again later"]],
          legend: "This asks which, or how — Approve and Reject cannot answer it. Write your answer and the CEO records it as written, or defer it and the CEO asks you again later.",
          hint: "Your answer — the CEO records it as written", send: "Send answer" } };
  function ruling(card, body) {
    var what = card.getAttribute("data-ask-title") || "", kind = rulingKind(what), mode = RULING[kind];
    var target = { type: "queue", key: card.getAttribute("data-ask-key"), title: what };
    var box = E("div", "crule ctlhost"), q = E("div", "crq"), tiles = E("div", "crtiles" + (mode.tiles.length === 1 ? " one" : "")), ans = E("div", "crans");
    var area = E("textarea"), said = E("span", "ctlsaid"), go = E("button", "cprim crsend", mode.send), legend = E("div", "crlegend", mode.legend);
    // the heading as the operator file wrote it keeps its markdown code spans; the card's title renders them, this line only quotes
    q.appendChild(E("b", null, "Your ruling on ")); q.appendChild(document.createTextNode("“" + what.replace(/`/g, "") + "”"));
    mode.tiles.forEach(function (t) {
      var b = E("button", "crtile"); b.type = "button"; b.appendChild(E("b", null, t[1])); b.appendChild(E("small", null, t[2]));
      b.onclick = function () { send({ kind: "rule", choice: t[0], target: target, note: area.value }, said); };
      tiles.appendChild(b);
    });
    area.rows = 2; area.maxLength = 2000; area.placeholder = mode.hint; area.setAttribute("aria-label", "Your answer, in your own words");
    go.type = "button";
    function sendWords() {
      if (!area.value.trim()) { said.className = "ctlsaid bad"; said.textContent = "write your answer first — Approve, Reject and Defer need no words, this does"; area.focus(); return; }
      send({ kind: "rule", choice: "answer", target: target, note: area.value }, said);
    }
    go.onclick = sendWords;
    area.addEventListener("keydown", function (e) { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sendWords(); } });
    ans.appendChild(area); ans.appendChild(go);
    // a question that wants words leads with the box to write them in; the buttons that need none come first on every other
    (kind === "open" ? [q, legend, ans, tiles, said] : [q, tiles, legend, ans, said]).forEach(function (n) { box.appendChild(n); });
    body.appendChild(box);
  }
  function waitingRows() {
    Array.prototype.forEach.call(document.querySelectorAll("#cards .card[data-ask-key]"), function (card) {
      var body = card.querySelector(".cbody"); if (body && !body.querySelector(".crule")) ruling(card, body);
    });
    // a ruling on a heading from the operator file, on a row of the page's own list
    Array.prototype.forEach.call(document.querySelectorAll("#secs .sec.you .row[data-ask-key]"), function (row) {
      var body = row.querySelector(".body"); if (!body || body.querySelector(".ctlhost")) return;
      var host = E("div", "ctlhost");
      host.appendChild(panel({ type: "queue", key: row.getAttribute("data-ask-key"), title: row.getAttribute("data-ask-title") || "" },
        [[{ choice: "approve" }, "Approve"], [{ choice: "reject" }, "Reject"], [{ choice: "defer" }, "Defer"]], "rule", "Rule on this"));
      body.appendChild(host);
    });
  }
  // what a role's controls offer, from its row as last read (0.44.0): Wake goes to its own agent, the rest to the CEO
  function roleChoices(r, off) {
    if (off) return [[{ kind: "setup" }, "Set up"], [{ kind: "note" }, "Message"]];
    var ss = (r && r.session) || null, rt = (r && r.routine) || null, team = (D.presence || {}).team || {};
    var known = !!(team.sessions || team.triggers), c = [[{ kind: "wake" }, r && r.agent_id ? "Wake" : "Wake (via the CEO)"]];
    if (rt) c.push([{ kind: "run" }, "Run now"]);
    if (known && !rt && !ss) c.push([{ kind: "setup" }, "Set up"]);
    if (!known || ss || (rt && rt.enabled)) c.push([{ kind: "shutdown" }, "Shut down"]);
    c.push([{ kind: "pause" }, "Pause"], [{ kind: "resume" }, "Resume"], [{ kind: "note" }, "Message"]);
    return c;
  }
  function roleOf(role) { return ((D.presence || {}).roles || []).filter(function (x) { return x.role === role; })[0] || null; }
  // the arc board's controls (arcs.py): set an arc's priority, or ask for it to be sped up — asks, never acts
  function arcRows() {
    Array.prototype.forEach.call(document.querySelectorAll("#arcs .arcctl[data-arc]"), function (slot) {
      if (slot.firstChild) return;
      var arc = slot.getAttribute("data-arc"), have = slot.getAttribute("data-priority");
      var t = { type: "arc", key: arc, title: slot.getAttribute("data-title") || "" };
      var choices = [["now", "Now"], ["next", "Next"], ["later", "Later"], ["clear", "No priority"]]
        .filter(function (c) { return c[0] !== (have || "clear"); })
        .map(function (c) { return [{ kind: "prioritize", choice: c[0] }, "Priority: " + c[1]]; });
      choices.push([{ kind: "speed" }, "Speed it up"], [{ kind: "note" }, "Note to the CEO"]);
      slot.appendChild(panel(t, choices, "note", "Prioritize or speed up " + arc + (have ? " (now " + have + ")" : "")));
    });
  }
  function teamRows(redo) {
    Array.prototype.forEach.call(document.querySelectorAll("#team .trow[data-role]"), function (row) {
      var slot = row.querySelector(".tctl"); if (!slot) return;
      // a panel the operator opened is never swapped under them; a closed one follows the newest reading
      if (slot.firstChild && (!redo || !slot.querySelector(".ctlopen"))) return;
      while (slot.firstChild) slot.removeChild(slot.firstChild);
      var role = row.getAttribute("data-role");
      var off = row.getAttribute("data-off") === "1";
      slot.appendChild(panel({ type: "role", key: role, title: "" }, roleChoices(roleOf(role), off), "note", (off ? "Set up " : "Control ") + role));
    });
    var tell = document.getElementById("tell");
    if (tell && !tell.firstChild) {
      tell.appendChild(E("div", "eyebrow", "Tell the CEO"));
      tell.appendChild(panel({ type: "org", key: "", title: "" }, [[{ kind: "note" }, "Send"]], "note", null));
    }
  }
  // the explorer's drawer asks for these (explorer.JS head): start and release on an item, a note on anything
  window.orgAsk = {
    drawerActions: function (kind, o) {
      var t = { type: kind === "pr" ? "pr" : kind, key: kind === "pr" ? "#" + o.number : (o.key || ""), title: o.title || "" };
      var choices = kind === "item"
        ? [[{ kind: "start" }, "Start now"]].concat(o.claimed_by ? [[{ kind: "release" }, "Release the claim"]] : []).concat([[{ kind: "note" }, "Note to the CEO"]])
        : [[{ kind: "note" }, "Note to the CEO"]];
      var p = panel(t, choices, "note", null); p.classList.add("xctlbar"); return p;
    },
    mode: function () { return MODE; },
    // the Decide view's own asks (a note, a batch of rulings) go through the same transport as every control here, so a published
    // page records them in its store and a copy of the page copies the words
    send: send
  };

  // --- the agents the page names, as links with a card (AGENTS_JS) ---------------------------------------------------
  var marking = false, obs = null;
  function mark() {
    var ag = window.orgAgents; if (!ag) return;
    marking = true; if (obs) obs.disconnect();
    ag.set({ "": { page: "", roles: (D.presence || {}).roles || [] } });
    // the sections, the roadmap, the explorer's list and drawer, the gantt, and the tiles and banner above them; not the
    // team section, which is the page the links go to
    Array.prototype.forEach.call(document.querySelectorAll("#secs, #secs-machinery, #cards, #bbody, #roadmap, #xbody, .xdrawer, #gantt, #tiles, #banner"), function (root) { ag.mark(root, ""); });
    marking = false; watch();
  }
  var t0 = null;
  function watch() {
    if (!window.MutationObserver) return;
    if (!obs) obs = new MutationObserver(function () { if (marking) return; clearTimeout(t0); t0 = setTimeout(function () { waitingRows(); mark(); }, 60); });
    obs.observe(document.body, { childList: true, subtree: true });
  }

  // --- live: a newer reading carries the team and the asks --------------------------------------------------------
  window.orgControls = {
    update: function (presence, asks) {
      if (presence) D.presence = presence;
      if (asks) D.asks = asks;
      Array.prototype.forEach.call(document.querySelectorAll("#team .trow[data-role]"), function (row) {
        var r = ((D.presence || {}).roles || []).filter(function (x) { return x.role === row.getAttribute("data-role"); })[0]; if (!r) return;
        var d = row.querySelector(".pdot"); if (d) d.className = "pdot " + cls(r.state);
        var s = row.querySelector(".tstate"); if (s) s.textContent = WORDS[r.state] || r.state || "";
        var mn = row.querySelector(".tmeans"); if (mn) mn.textContent = r.means || "";
        var w = r.work || {}, ts = row.querySelector(".tsess"), tr = row.querySelector(".trout"), rp = row.querySelector(".trep");
        if (ts && w.session) ts.textContent = w.session; if (tr && w.routine) tr.textContent = w.routine; if (rp && w.report) rp.textContent = w.report;
      });
      var asof = document.getElementById("team-asof");
      if (asof && D.presence && D.presence.team_as_of) asof.textContent = D.presence.team_as_of;
      teamRows(true);
      if (window.orgAgents) window.orgAgents.unmark(document);
      routeLine(); waitingRows(); mark();
    }
  };

  (async function start() {
    if (!TOKEN && window.claude && window.claude.use) {
      try { db = await window.claude.use("db"); } catch (e) { db = null; }
      var user = null, owner = false;
      try { user = await window.claude.use("user"); owner = user ? await user.isOwner() : false; me = user ? await user.id() : null; } catch (e) { owner = false; }
      if (db && owner && me) {
        MODE = "store";
        try { mcp = await window.claude.use("mcp"); } catch (e) { mcp = null; }
      }
    }
    routeLine(); waitingRows(); teamRows(); arcRows(); mark();
  })();
})();
</script>
"""


# --- the tempo knobs on the command page (0.47.0, SPEC §10) ----------------------------------------------------------

def _edge_text(o: dict[str, Any]) -> str:
    med = (f"median {o['median_hours']}h over n {o.get('n')}" if o.get("median_hours") is not None
           else f"no median over n {o.get('n') or 0}")
    return (f"{o['edge']}: {med}" + (f", target {o['target_hours']:g}h" if o.get("target_hours") is not None else "")
            + (f", {o['waiting']} waiting" if o.get("waiting") else ""))


def _knob_text(k: dict[str, Any] | None, tz: str | None) -> str:
    from .dashboard import _clock
    if not k:
        return "not set — it runs on its own cadence"
    return (f"interval ×{k.get('value'):g}" if isinstance(k.get("value"), (int, float)) and not isinstance(k.get("value"), bool)
            else f"unreadable value {k.get('value')!r}") + (f" until {_clock(k['expires_at'], tz)}" if k.get("expires_at") else "") \
        + f" — {k.get('reason') or 'no reason'}" + (f" ({k['by']})" if k.get("by") else "")


def tempo_html(d: dict[str, Any], tokens: dict[str, str] | None = None) -> str:
    """The fleet page's tempo section: per served org, per role — the edges the role owns as last measured, the knob in
    effect, and (served, with the org's token) a control to set or clear it. Scripts off, the readings are the whole
    section; unserved, there is no control and the section says how to set one from a terminal."""
    tempo = d.get("tempo") or {}
    pages, tz = d.get("pages") or {}, d.get("operator_timezone")
    tokens = tokens or {}
    blocks, n_set = [], 0
    for oid, t in tempo.items():
        rows = []
        for r in t.get("roles") or []:
            n_set += 1 if r.get("knob") else 0
            rng = r.get("range") or []
            can = bool(r.get("wake_on")) and len(rng) == 2 and oid in tokens and oid in pages
            owns = " · ".join(_edge_text(o) for o in r.get("owns") or []) or "owns no measured edge"
            if not r.get("wake_on"):
                why = "no on-demand wake — its cron is its only interval, and no knob moves a cron"
            elif not can:
                why = f"set it from a terminal: `org knob set {r['role']}.cadence_multiplier 2 --repo <checkout> --reason \"…\"`"
            else:
                why = ""
            rows.append(
                f"<div class='trow krow' data-org='{_e(oid)}' data-role='{_e(r['role'])}' data-can='{1 if can else 0}'"
                f" data-min='{_e(rng[0] if len(rng) == 2 else '')}' data-max='{_e(rng[1] if len(rng) == 2 else '')}'"
                f" data-cur='{_e((r.get('knob') or {}).get('value') if r.get('knob') else '')}'>"
                f"<span class='pdot {'ps-live' if r.get('knob') else 'ps-away'}' aria-hidden='true'></span>"
                f"<span class='tname2'>{agent_link(oid, r['role'], pages.get(oid), '<b>' + _e(r.get('name') or r['role']) + '</b>')} <span class='trole'>{_e(r['role'])}</span></span>"
                f"<span class='tstate'>{_e(r.get('cadence') or 'no cadence')}</span>"
                f"<span class='tmeans'>{_e(_knob_text(r.get('knob'), tz))}</span><span class='tctl kctl'></span>"
                f"<span class='twork'><span>{_e(owns)}</span>{('<span>' + _e(why) + '</span>') if why else ''}</span></div>")
        page = f"<a href='{_e(pages[oid])}'>{_e(oid)}</a>" if oid in pages else _e(oid)
        blocks.append(f"<div class='tempoorg'><div class='eyebrow torgname'>{page}</div>{''.join(rows) or '<div class=rmnone>no roles read</div>'}</div>")
    if not blocks:
        return ""
    cfg = {oid: {"token": tokens[oid], "ask": pages[oid] + "ask"} for oid in tempo if oid in tokens and oid in pages}
    return (f"<div class='act tempo' id='tempo'><div class='sechead'><span class='ct'>{n_set} set</span><h2>Tempo</h2>"
            "<p>Each knob multiplies how long an event waits before its role is woken for it, and the floor between two "
            "on-demand wakes: <b>2</b> wakes the role half as often, <b>0.5</b> twice as often. It never touches a cron, "
            "which stays the role's floor, and it expires by itself — at most seven days. Read the edge a role owns before "
            "moving it. Setting one writes the record on that org's board and tells its CEO.</p></div>"
            f"{''.join(blocks)}"
            "<script type='application/json' id='org-tempo'>" + json.dumps(cfg).replace("<", "\\u003c") + "</script></div>")


TEMPO_CSS = """
.tempo .tempoorg{padding:6px 0 10px}.tempo .torgname{padding:10px 18px 0}
.tempo .krow{grid-template-columns:14px minmax(120px,190px) minmax(90px,150px) minmax(0,1fr)}
.tempo .kctl{grid-column:2 / -1}.kctl .ctl{margin-top:0;flex-wrap:wrap}
.kctl input[type=number]{flex:0 0 74px;min-height:30px}.kctl select{font:inherit;font-size:13px;min-height:30px;border-radius:7px;
  border:1px solid var(--border);background:var(--surface);color:var(--ink)}
.kctl .kwhy{flex:1 1 150px;min-width:110px}
@media (max-width:620px){.tempo .krow{grid-template-columns:14px minmax(0,1fr)}}
"""


#: scripts on: a control on every row whose role has an interval to move. The ask is the page's one write: kind `knob`,
#: which the org's served reader checks against the range and the ceiling, writes to the board, and files for the CEO.
TEMPO_JS = r"""
<script>
(function () {
  "use strict";
  var C = {};
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x !== undefined && x !== null) e.textContent = String(x); return e; }
  var busy = false;
  async function post(org, role, value, ttl, note, said) {
    if (busy) return; busy = true;
    var c = C[org]; said.className = "ctlsaid"; said.textContent = "sending…";
    try {
      var r = await fetch(c.ask, { method: "POST", headers: { "Content-Type": "application/json", "X-Org-Ask": c.token },
        body: JSON.stringify({ kind: "knob", target: { type: "role", key: role, title: "" }, knob: { value: value, ttl: ttl }, note: note, at: new Date().toISOString() }) });
      var j = await r.json().catch(function () { return {}; });
      if (!r.ok) throw new Error(j.error || ("HTTP " + r.status));
      said.className = "ctlsaid ok"; said.textContent = j.said || "recorded";
    } catch (e) { said.className = "ctlsaid bad"; said.textContent = "not set: " + (e && e.message ? e.message : e); }
    busy = false;
  }
  // a function, not a one-off: the served fleet page swaps the Team view in place with a new reading, and binds its knobs again
  // (`dashboard.COMMAND_LIVE_JS`); a row already holding its control is left as it is
  window.orgTempoBind = function () {
  var el = document.getElementById("org-tempo"); if (!el) return;
  try { C = JSON.parse(el.textContent) || {}; } catch (e) { return; }
  Array.prototype.forEach.call(document.querySelectorAll("#tempo .krow[data-can='1']"), function (row) {
    var slot = row.querySelector(".kctl"), org = row.getAttribute("data-org"), role = row.getAttribute("data-role");
    if (slot && slot.querySelector(".ctl")) return;
    var lo = parseFloat(row.getAttribute("data-min")), hi = parseFloat(row.getAttribute("data-max")), cur = row.getAttribute("data-cur");
    if (!C[org] || !slot) return;
    var box = E("div", "ctl"), num = E("input"), ttl = E("select"), why = E("input", "kwhy"), said = E("span", "ctlsaid");
    num.type = "number"; num.min = lo; num.max = hi; num.step = "0.25"; num.value = cur || "1";
    num.setAttribute("aria-label", "Interval multiplier for " + role + ", " + lo + " to " + hi);
    [["1h", "1 h"], ["6h", "6 h"], ["24h", "24 h"], ["7d", "7 d"]].forEach(function (o) { var op = E("option", null, o[1]); op.value = o[0]; ttl.appendChild(op); });
    ttl.value = "24h"; ttl.setAttribute("aria-label", "How long the knob lasts");
    why.type = "text"; why.placeholder = "why (the record carries it)"; why.maxLength = 300; why.setAttribute("aria-label", "Reason");
    var set = E("button", "xbtn", "Set"); set.type = "button";
    set.onclick = function () {
      var v = parseFloat(num.value);
      if (!isFinite(v) || v < lo || v > hi) { said.className = "ctlsaid bad"; said.textContent = "the range is " + lo + "–" + hi; return; }
      post(org, role, v, ttl.value, why.value, said);
    };
    box.appendChild(num); box.appendChild(ttl); box.appendChild(why); box.appendChild(set);
    if (cur) { var clr = E("button", "xbtn", "Clear"); clr.type = "button"; clr.onclick = function () { post(org, role, null, "24h", why.value, said); }; box.appendChild(clr); }
    box.appendChild(said); slot.appendChild(box);
  });
  };
  window.orgTempoBind();
})();
</script>
"""
