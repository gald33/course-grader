"""`org status --html` — the same reading, as a page (SPEC §9).

A pure function: `render_html(status_dict)` returns one self-contained document and reaches nothing. The
page is scanned, not read, so state is encoded in form as well as colour — every tile carries the word
`RED` / `CLEAR` / `DARK` beside its mark, because a status colour must never carry meaning alone.

`DARK` is deliberately **not** a third severity. A tile nobody could measure is absent, not bad, so it
takes a muted neutral and a dashed edge rather than a warning hue — the whole point of rows 62 and 65 is
that "not measured" must never read as either "fine" or "failing".
"""

from __future__ import annotations

import datetime as dt
import html
import json
import re
from typing import Any

from . import __version__, console, vocab
from .status import FINDING

#: status steps, fixed — never reused for anything but state (dataviz: the status palette is reserved)
CRITICAL, GOOD = "#d03b3b", "#0ca30c"

STATE_MARK = {"RED": "●", "CLEAR": "○", "DARK": "—"}

CSS = """
:root{
  --bg:#fbfbfc; --surface:#fff; --surface-2:#f6f7f9; --ink:#12141a; --ink-2:#565c6b; --muted:#8b91a1;
  --border:#e3e5ea; --accent:#3d6ea8;
  --c-crit:#d03b3b; --c-wait:#fab219; --c-live:#2a78d6; --c-live2:#86b6ef; --c-ok:#0ca30c; --c-idle:#9aa0ae; --c-ring:#8b91a1;
  --red:var(--c-crit); --green:var(--c-ok); --dark-mark:var(--c-idle);
  --red-wash:#fdf2f2; --green-wash:#f1faf1; --dark-wash:#f6f7f9; --wait-wash:#fff8e6;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --c-crit:#e2584f; --c-wait:#fab219; --c-live:#3987e5; --c-live2:#1c5cab; --c-ok:#3fbb3f; --c-idle:#767c8b; --c-ring:#767c8b;
  --red:var(--c-crit); --green:var(--c-ok); --dark-mark:var(--c-idle);
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228; --wait-wash:#2a2415;
}}
:root[data-theme="dark"]{
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --c-crit:#e2584f; --c-wait:#fab219; --c-live:#3987e5; --c-live2:#1c5cab; --c-ok:#3fbb3f; --c-idle:#767c8b; --c-ring:#767c8b;
  --red:var(--c-crit); --green:var(--c-ok); --dark-mark:var(--c-idle);
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228; --wait-wash:#2a2415;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
  font-family:"IBM Plex Sans",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
  font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
.wrap{max-width:1180px;margin:0 auto;padding-inline:16px;padding-block:28px 56px}
h1{font-size:19px;font-weight:600;margin:0;letter-spacing:-.01em}
.sub{color:var(--ink-2);font-size:12.5px;margin-top:3px;
  font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-variant-numeric:tabular-nums}
.eyebrow{font-size:10.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.banner{display:flex;gap:12px;margin-top:20px;padding:14px 16px;border:1px solid var(--border);
  border-left-width:4px;border-radius:7px;background:var(--surface)}
.banner.RED{border-left-color:var(--red);background:var(--red-wash)}
.banner.CLEAR{border-left-color:var(--green);background:var(--green-wash)}
.banner.DARK{border-left-color:var(--dark-mark);border-left-style:dashed;background:var(--dark-wash)}
.banner p{margin:4px 0 0;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;
  word-break:break-word;line-height:1.55}
.note{margin-top:14px;padding:10px 13px;border:1px dashed var(--border);border-radius:7px;
  background:var(--surface-2);color:var(--ink-2);font-size:12.5px}
.grid{display:grid;gap:14px;margin-top:18px;grid-template-columns:repeat(auto-fit,minmax(330px,1fr))}
.tile{border:1px solid var(--border);border-radius:9px;background:var(--surface);padding:14px 16px;
  display:flex;flex-direction:column;gap:9px;min-width:0}
.tile.span{grid-column:1/-1}
.tile.DARK{border-style:dashed}
.thead{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap}
.chip{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:600;letter-spacing:.07em;
  padding:2px 8px;border-radius:99px;border:1px solid var(--border);white-space:nowrap}
.chip.RED{color:var(--red);border-color:var(--red)}
.chip.CLEAR{color:var(--green);border-color:var(--green)}
.chip.DARK{color:var(--dark-mark);border-style:dashed}
.tname{font-weight:600;font-size:14px}
.tier{font-size:11.5px;color:var(--muted)}
.lines{margin:0;font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;
  line-height:1.65;overflow-x:auto;font-variant-numeric:tabular-nums}
.lines div{padding:1px 0;word-break:break-word}
.lines div.hot{color:var(--red)}
.broken{font-size:11.5px;color:var(--muted);border-top:1px dotted var(--border);padding-top:8px;margin-top:auto}
.broken b{font-weight:600;color:var(--ink-2)}
table{border-collapse:collapse;width:100%;font-size:12.5px;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums}
th{text-align:left;font-weight:600;color:var(--muted);font-size:10.5px;letter-spacing:.07em;
  text-transform:uppercase;padding:0 10px 6px 0;white-space:nowrap}
td{padding:5px 10px 5px 0;border-top:1px solid var(--border);vertical-align:middle;white-space:nowrap}
td.wide{white-space:normal;min-width:150px}
.scroll{overflow-x:auto}
.bar{position:relative;display:inline-block;height:8px;min-width:90px;width:120px;vertical-align:middle;background:var(--surface-2);border-radius:4px}
.bar i{position:absolute;inset:0 auto 0 0;border-radius:4px;background:var(--green)}
.bar i.over{background:var(--red)}
.bar u{position:absolute;top:-3px;bottom:-3px;width:2px;background:var(--ink-2);opacity:.6}
.foot{margin-top:26px;padding-top:14px;border-top:1px solid var(--border);color:var(--muted);font-size:12px}
.foot code{font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);word-break:break-all}
.foot p{margin:5px 0}
@media (max-width:460px){.wrap{padding-block:20px 40px}.grid{grid-template-columns:1fr}}

/* --- the plain reading: prose in the sans face, figures in the mono one -------------------------- */
.verdict{margin-top:18px;padding:18px 20px 18px 22px;border:1px solid var(--border);border-left-width:5px;
  border-radius:9px;background:var(--surface);font-size:19px;line-height:1.45;text-wrap:balance;
  letter-spacing:-.005em}
.verdict.RED{border-left-color:var(--red)}
.verdict.CLEAR{border-left-color:var(--green)}
.verdict.DARK{border-left-color:var(--dark-mark);border-left-style:dashed}
.nums{display:grid;gap:10px;margin-top:14px;grid-template-columns:repeat(auto-fit,minmax(168px,1fr))}
.num{border:1px solid var(--border);border-radius:9px;background:var(--surface);padding:12px 14px;min-width:0}
.num .k{font-size:10.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.num .v{font-family:"IBM Plex Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums;
  font-size:22px;font-weight:600;line-height:1.25;margin-top:5px;letter-spacing:-.02em;word-break:break-word}
.num .v.RED{color:var(--red)}
.num .v.CLEAR{color:var(--green)}
.num .v.DARK{color:var(--dark-mark)}
.num .n{font-size:12px;color:var(--ink-2);margin-top:3px}
.sec{margin-top:22px;border:1px solid var(--border);border-radius:10px;background:var(--surface);overflow:hidden}
.sec.you{border-left:5px solid var(--c-wait)}
.sechead{padding:13px 18px;background:var(--surface-2);border-bottom:1px solid var(--border)}
.sechead h2{margin:0;font-size:15px;font-weight:600;letter-spacing:-.01em}
.sechead p{margin:3px 0 0;font-size:12.5px;color:var(--ink-2);max-width:68ch}
.sechead .ct{float:right;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;color:var(--muted);
  font-variant-numeric:tabular-nums}
.row{display:flex;gap:14px;align-items:flex-start;padding:13px 18px;border-top:1px solid var(--border)}
.row:first-of-type{border-top:none}
.row .body{flex:1;min-width:0}
.row .what{font-weight:600;font-size:14.5px;line-height:1.4;text-wrap:balance}
.row .why{margin-top:3px;font-size:13px;color:var(--ink-2);line-height:1.5;max-width:74ch}
.row .quote{margin-top:6px;padding:7px 10px;border-left:2px solid var(--border);background:var(--surface-2);
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px;color:var(--ink-2);
  white-space:pre-wrap;word-break:break-word;border-radius:0 5px 5px 0}
.age{flex:none;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px;color:var(--muted);
  font-variant-numeric:tabular-nums;white-space:nowrap;padding-top:2px}
details.instrument{margin-top:30px;border-top:1px solid var(--border);padding-top:16px}
details.instrument>summary{cursor:pointer;font-size:13px;color:var(--ink-2);list-style:none;
  display:flex;align-items:center;gap:7px;padding:4px 0}
details.instrument>summary::-webkit-details-marker{display:none}
details.instrument>summary::before{content:"▸";color:var(--muted);font-size:11px}
details.instrument[open]>summary::before{content:"▾"}
details.instrument>summary:hover{color:var(--accent)}
details.instrument>summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px;border-radius:4px}
.sub2{font-size:12.5px;color:var(--ink-2);margin:10px 0 0;max-width:74ch}
@media (max-width:460px){.sechead .ct{float:none;display:block;margin-bottom:2px}}

/* --- the command centre: the fleet at a glance, then the things only a person can clear -------- */
.fleet{width:100%;border-collapse:separate;border-spacing:0;font-size:12.5px;margin-top:4px}
.fleet th{text-align:left;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;
  color:var(--muted);padding:0 12px 7px 0;white-space:nowrap}
.fleet td{padding:8px 12px 8px 0;border-top:1px solid var(--border);white-space:nowrap;vertical-align:top}
.fleet td.org{font-weight:600;font-size:13px;white-space:nowrap;padding-right:18px}
.fleet td.org a{color:inherit;text-decoration:none;border-bottom:1px solid var(--border)}
.fleet td.org a:hover{color:var(--accent);border-bottom-color:var(--accent)}
.fleet td.org a:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:3px}
.fleet .cell{display:flex;align-items:center;gap:6px;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2)}
.fleet .cell.RED{color:var(--red)}
.fleet .cell a.cv{color:inherit;text-decoration:underline dotted;text-underline-offset:3px}
.fleet .cell a.cv:hover,.fleet .cell a.cv:focus-visible{color:var(--accent)}
.fleet td.wide{white-space:normal;color:var(--muted);font-size:12px}
.act{margin-top:20px;border:1px solid var(--border);border-left:5px solid var(--c-wait);border-radius:10px;
  background:var(--surface);overflow:hidden}
.arow{display:grid;grid-template-columns:78px 1fr auto;gap:14px;align-items:start;padding:13px 18px;
  border-top:1px solid var(--border)}
.arow:first-of-type{border-top:none}
.achip{font-size:10.5px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);
  padding-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.arow .what{font-weight:600;font-size:14.5px;line-height:1.4;text-wrap:balance}
.arow .why{margin-top:3px;font-size:13px;color:var(--ink-2);line-height:1.5;max-width:74ch}
.blocks{margin-top:7px;padding:6px 10px;border-radius:6px;background:var(--surface-2);
  font-size:12.5px;color:var(--ink);display:flex;gap:8px;align-items:baseline}
.blocks s{text-decoration:none;color:var(--accent);font-weight:600;flex:none}
.blocks em{font-style:normal;color:var(--ink-2)}
.blocks code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2)}
.row .why,.arow .why{display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}
.fl{color:inherit;text-decoration:none}.fl:hover,.fl:focus-visible{text-decoration:underline}
.fopen{display:block;margin-top:5px;font-size:11.5px;color:var(--accent);text-decoration:none;white-space:nowrap}
.fopen:hover,.fopen:focus-visible{text-decoration:underline}
.fdetail,.focusbar{display:none}
.fdetail{margin-top:10px;padding-top:8px;border-top:1px dashed var(--border);font-size:12.5px;line-height:1.5}
.fdetail .hol s{width:118px}.fback{display:inline-block;margin-top:8px;color:var(--accent);text-decoration:none;font-size:12.5px}
.focusbar a{color:var(--accent);text-decoration:none;font-weight:600}.fkeys{color:var(--muted);font-size:12px}
.fkeys kbd{font:inherit;font-size:11px;padding:0 5px;border:1px solid var(--border);border-radius:4px}
.frow{scroll-margin-top:12px}
/* the focused view: one item, by the URL's own fragment, so it needs no script and can be linked to; `.is-focus` is the same state set by script, because a live repaint replaces the row and the browser does not make the new one the target */
.frow:is(:target,.is-focus) .why{display:block;-webkit-line-clamp:unset;overflow:visible}
.frow:is(:target,.is-focus) .fdetail{display:block}.frow:is(:target,.is-focus) .fopen{display:none}
.wrap:has(.frow:is(:target,.is-focus))>.focusbar{display:flex;gap:14px;align-items:baseline;margin:10px 0}
.wrap:has(.frow:is(:target,.is-focus))>:not(.focusbar):not(.eyebrow):not(h1):not(:has(.frow:is(:target,.is-focus))){display:none}
:is(.sec,.act,#secs):has(.frow:is(:target,.is-focus)) .frow:not(:target):not(.is-focus){display:none}
:is(.sec,.act):has(.frow:is(:target,.is-focus)) .sechead,:is(.sec,.act):has(.frow:is(:target,.is-focus)) details.more>summary{display:none}
#secs:has(.frow:is(:target,.is-focus))>.sec:not(:has(.frow:is(:target,.is-focus))){display:none}
.ho{margin-top:7px;padding:6px 10px;border-radius:6px;background:var(--surface-2);font-size:12.5px;line-height:1.5}
.hol{display:flex;gap:10px;align-items:baseline}
.hol s{text-decoration:none;flex:none;width:118px;white-space:nowrap;color:var(--ink-2);font-weight:600}
.hol>span{min-width:0;color:var(--ink)}
.hodo{display:flex;gap:8px;align-items:flex-start}
.hodo pre{margin:0;flex:1;min-width:0;white-space:pre-wrap;overflow-wrap:anywhere;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2)}
.ho.norec{background:transparent;border:1px dashed var(--border)}.ho.norec .hol s{color:var(--muted)}
.hoopt button,.hoyes{flex:none}.hosaid em{font-style:normal;color:var(--ink-2)}.hosaidnow{font-size:12px;color:var(--ink-2)}
.hoans{display:none}[data-ask] div.hoans{display:flex}[data-ask] button.hoans{display:inline-block}
.hoopt{align-items:center}.horeply{display:flex;gap:8px;flex:1;min-width:0}
.horeply textarea{flex:1;min-width:0;font:inherit;font-size:12.5px;border:1px solid var(--border);border-radius:6px;padding:3px 7px;
  background:var(--surface);color:var(--ink);resize:vertical}
[data-ask] button.hoans,.hosend{font:inherit;font-size:11.5px;padding:1px 8px;border:1px solid var(--border);border-radius:5px;
  background:var(--surface);color:var(--ink);cursor:pointer}
.hoans:focus-visible,.hosend:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.hocopy{flex:none;font:inherit;font-size:11.5px;padding:1px 8px;border:1px solid var(--border);border-radius:5px;
  background:var(--surface);color:var(--ink);cursor:pointer}
.hocopy:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.arow .side{text-align:right;font-size:12px;color:var(--muted);white-space:nowrap;
  font-family:"IBM Plex Mono",ui-monospace,monospace}
.arow .side a{display:block;margin-top:5px;color:var(--accent);font-family:inherit;text-decoration:none}
.arow .side a:hover{text-decoration:underline}
.arow .side a:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:3px}
@media (max-width:620px){.arow{grid-template-columns:1fr;gap:6px}.arow .side{text-align:left}
/* the matrix is the glance, so on a phone it stacks into one block per org rather than scrolling
   sideways out of view: every cell prints its own signal name, which is why each carries data-k. */
.fleet,.fleet tbody,.fleet tr,.fleet td{display:block;width:100%}
.fleet thead{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
.fleet tr{border-top:1px solid var(--border);padding:10px 0}
.fleet tr:first-child{border-top:none}
.fleet td{border-top:none;padding:2px 0;white-space:normal;display:grid;
  grid-template-columns:84px 1fr;gap:10px;align-items:baseline}
.fleet td[data-k]::before{content:attr(data-k);font-size:10px;font-weight:600;letter-spacing:.08em;
  text-transform:uppercase;color:var(--muted);font-family:"IBM Plex Sans",system-ui,sans-serif}
.fleet td.org{display:block;font-size:14px;padding-bottom:4px}}

/* --- where the time went: spans on one axis ------------------------------------------------------
   The two stage hues are slots 1 and 2 of the validated categorical palette, stepped for each surface
   (not flipped). "No review recorded" reuses the page's own ABSENT grey, which is what it means: the
   bar could not be split because nothing was written, and that is the same kind of fact as a dark tile. */
:root{--s1:#4a3aa7; --s2:#e87ba4; --s0:#9aa0ae; --lab:112px}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--s1:#9085e9; --s2:#d55181; --s0:#767c8b}}
:root[data-theme="dark"]{--s1:#9085e9; --s2:#d55181; --s0:#767c8b}
.gkey{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 12px;font-size:12px;color:var(--ink-2)}
.gkey span{display:inline-flex;align-items:center;gap:6px}
.gkey i{width:15px;height:9px;border-radius:0 3px 3px 0;flex:none}
.gkey i.review{background:var(--s1)}
.gkey i.merge{background:var(--s2)}
.gkey i.none{background:var(--s0)}
.gkey s{text-decoration:none;color:var(--ink-2);font-size:11px}
.gplot{position:relative;padding-bottom:20px;padding-right:9px}
.ggrid{position:absolute;left:var(--lab);right:9px;top:0;bottom:20px;pointer-events:none}
.ggrid b{position:absolute;top:0;bottom:0;width:1px;background:var(--border)}
.grow{display:grid;grid-template-columns:var(--lab) 1fr;align-items:center;height:15px}
.glabel{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11px;color:var(--ink-2);
  font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:9px}
.gtrack{position:relative;height:15px}
.gspan{position:absolute;top:3px;height:9px;display:flex;gap:2px}
.gspan i{display:block;height:9px;min-width:2px}
.gspan i:last-child{border-radius:0 4px 4px 0}
.gspan i.review{background:var(--s1)}
.gspan i.merge{background:var(--s2)}
.gspan i.none{background:var(--s0)}
.gspan.open i:last-child{border-radius:0}
.gspan.open::after{content:"";position:absolute;right:-7px;top:0;border:4.5px solid transparent;
  border-left-color:var(--s1)}
.gaxis{position:absolute;left:var(--lab);right:9px;bottom:0;height:18px}
.gaxis b{position:absolute;top:0;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:10.5px;
  font-weight:400;color:var(--muted);transform:translateX(-50%);white-space:nowrap}
.gnote{margin:12px 0 0;font-size:12.5px;color:var(--ink-2);max-width:74ch}
/* The roadmap: one stacked bar per arc, in the six item states (org_core/vocab.py): ready is an empty outline,
   claimed and verifying are one blue at two depths (an ordinal pair, validate_palette.js --ordinal: light and
   dark ALL CHECKS PASS, 2026-10-03), blocked is the page's one amber, deferred is hatched grey, done is the
   recessive grey — finished work should not compete with the work in flight. Until 0.50.0 these were five
   categorical hues and four of them meant something else elsewhere on the page. Every bar carries its count
   in text and the counts have a table view. */
:root{--st-verifying:var(--c-live); --st-claimed:var(--c-live2); --st-ready:var(--surface-2); --st-blocked:var(--c-wait);
  --st-deferred:var(--c-idle); --st-done:var(--c-idle)}
.st-verifying{background:var(--st-verifying)} .st-claimed{background:var(--st-claimed)}
.st-ready{background:var(--st-ready)} .st-blocked{background:var(--st-blocked)}
.st-deferred{background:var(--st-deferred)} .st-done{background:var(--st-done)}
.rmbody{padding:14px 18px 10px}
.rmkey{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 12px;font-size:12px;color:var(--ink-2)}
.rmkey span{display:inline-flex;align-items:center;gap:6px}
.rmkey i{width:12px;height:10px;border-radius:3px;flex:none}
.rmkey b{font-weight:600;color:var(--ink);font-variant-numeric:tabular-nums}
.rmrow{display:grid;grid-template-columns:minmax(90px,150px) 1fr auto;align-items:center;gap:12px;min-height:24px}
.rmlabel{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2);white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}
.rmtrack{display:flex;gap:2px;height:10px;min-width:0}
.rmtrack i{display:block;height:10px;min-width:3px}
.rmtrack i:first-child{border-radius:4px 0 0 4px}
.rmtrack i:last-child{border-radius:0 4px 4px 0}
.rmtrack i:only-child{border-radius:4px}
.rmn{font-size:12px;color:var(--ink-2);font-variant-numeric:tabular-nums;white-space:nowrap}
.rmnone{padding:12px 18px;font-size:13.5px;color:var(--ink-2);border-bottom:1px solid var(--border)}
@media (max-width:560px){.rmrow{grid-template-columns:1fr auto;row-gap:5px;margin-bottom:10px}
  .rmtrack{grid-column:1 / -1;order:3}}
details.more>summary{cursor:pointer;padding:10px 18px;border-top:1px solid var(--border);font-size:12.5px;
  color:var(--ink-2);background:var(--surface-2)}
details.more>summary:hover{color:var(--accent)}
details.more>summary:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
details.gtable{margin-top:12px}
details.gtable>summary{cursor:pointer;font-size:12.5px;color:var(--ink-2)}
details.gtable>summary:hover{color:var(--accent)}
details.gtable>summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px;border-radius:4px}
details.gtable table{margin-top:9px}
@media (max-width:460px){:root{--lab:78px}.glabel{font-size:10px}}
/* Time zoom on the gantt. Every rule below names a class only GANTT_JS adds, so with scripts off none of
   them matches and the chart is the static one. One-finger vertical swipes stay the page's (pan-y). */
.gzoombar{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:0 0 10px;font-size:12px;color:var(--ink-2)}
.gzoombar button{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;min-width:32px;height:30px;
  padding:0 9px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--ink);cursor:pointer}
.gzoombar button:hover:not(:disabled){border-color:var(--accent);color:var(--accent)}
.gzoombar button:disabled{opacity:.4;cursor:default}
.gzoombar button:focus-visible,.gplot.gzoom:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.gview{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;font-variant-numeric:tabular-nums;
  color:var(--ink);margin-left:4px}
.ghint{flex-basis:100%;font-size:11px;color:var(--muted)}
.gplot.gzoom{touch-action:pan-y;border-radius:4px}
.gplot.zoomed{cursor:grab}
.gplot.zoomed.dragging{cursor:grabbing;user-select:none;-webkit-user-select:none}
.gplot.zoomed .gtrack{clip-path:inset(-3px 0 -3px 0)}
.gplot.zoomed.atend .gtrack{clip-path:inset(-3px -9px -3px 0)}
.gplot.zoomed .ggrid{overflow:hidden}
/* each arc opens onto its gantt: the arc's row is the <summary>, so it opens by click, tap or keyboard, scripts or not */
details.rmarc>summary{display:block;list-style:none;cursor:pointer;border-radius:4px}
details.rmarc>summary::-webkit-details-marker{display:none}
details.rmarc>summary .rmlabel::before{content:"\\25B8\\00a0";color:var(--muted)}
details.rmarc[open]>summary .rmlabel::before{content:"\\25BE\\00a0"}
details.rmarc>summary:hover .rmlabel{color:var(--accent)}
details.rmarc>summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.rmgantt{--lab:230px;padding:10px 0 14px;border-bottom:1px solid var(--border);margin-bottom:8px}
@media (max-width:460px){.rmgantt{--lab:128px}.rmgantt .gplot:not(.zoomed) .gaxis b:nth-child(even){display:none}}
.rmchip{font-style:normal;font-size:10px;font-weight:600;margin-left:6px;padding:1px 5px;border-radius:3px;
  border:1px solid var(--border);color:var(--ink-2);vertical-align:1px}
.rmchip.now{color:var(--accent);border-color:var(--accent)}
.rmprio{margin:14px 0 0;padding:10px 12px;border:1px solid var(--border);border-radius:6px;background:var(--surface-2)}
.rmprio>summary{cursor:pointer;list-style:none}
.rmprio>summary::-webkit-details-marker{display:none}
.rmprio>summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.rmprio h3{display:inline;margin:0;font-size:12.5px;font-weight:600;color:var(--accent)}
.rmprio h3::before{content:"\\25B8\\00a0"}
.rmprio[open] h3::before{content:"\\25BE\\00a0"}
.rmprio[open]>summary{margin-bottom:6px}
.rmprio p{margin:0 0 8px;font-size:11.5px;color:var(--ink-2);max-width:74ch}
.rmprio .pr{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:4px 10px;padding:4px 0;
  border-top:1px solid var(--border)}
.rmprio .pr span:first-child{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.rmprio .pr.arc span:first-child{font-weight:600}
.rmprio select{font:inherit;font-size:12.5px;height:30px;padding:0 6px;border:1px solid var(--border);border-radius:6px;
  background:var(--surface);color:var(--ink)}
.rmprio select:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.rmprio .tag{grid-column:1 / -1;font-size:11px;color:var(--muted)}
.rmprio .tag.asked{color:var(--accent)}
.rmprio .tag.bad{color:var(--red)}
.dgrow>.ic{margin-top:3px;align-self:flex-start}
.dgc{margin:4px 0 0;padding-left:18px;font-size:12.5px;color:var(--ink-2)}
.dgc code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px}
.dgus{margin-top:8px;font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.dgu{font-size:12.5px;color:var(--ink-2);padding:2px 0}
.dgu time{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--muted)}
.dgstate{font-size:10.5px;font-weight:600;padding:1px 7px;border-radius:99px;border:1px solid var(--border);color:var(--ink-2)}
.dgstate.dgx{color:var(--c-crit);border-color:var(--c-crit)}
.gspan.rmg.open::after{border-left-color:var(--c-ring)}
.gspan.rmg.rmv.open::after{border-left-color:var(--c-live)}
"""


#: a live store's document is capped at 256 KiB serialized (artifact runtime 0.2.58, `db.d.ts`: "at most 256 KiB
#: serialized"). The reading aims under this, trimming the explorer's prose first — never a count, a status or a claim.
# the second short line of the roadmap lead when the served store was not read; `LIVE_JS` says the same words
ROADMAP_NOTE_SHORT = "Live claims not read; showing the committed items."
STORE_DOC_BUDGET = 200_000
#: how much of each item's evidence the store's copy keeps; the page's own copy keeps it whole (`explorer.JS` FULL)
STORE_EVIDENCE_CHARS = 400


def reading_doc(st: dict[str, Any], *, source: str = "org status", evidence_chars: int | None = STORE_EVIDENCE_CHARS,
                fragments: bool = False, private_text: bool = False) -> dict[str, Any]:
    """One reading, flattened to what the page draws — defined once, so the copy embedded in the page and
    the copy a live store holds are the same shape and can never disagree.

    `report` is dropped: it is the whole measurement and a store document is capped, and the page renders
    none of it directly. The `brief` — the plain reading — rides along, so a live page repaints the words a
    person reads and the instrument beneath them from the same document, and the two can never disagree.

    The explorer (0.41.0) rides along too, with each item's evidence cut to its opening for the store (`evidence_chars`;
    `None` keeps it whole — the served page, which has no cap), and trimmed further if the whole would pass
    `STORE_DOC_BUDGET`, saying so. `fragments` adds the served page's own rendering of the sections the live script
    cannot draw — the pull-request gantt, every arc's gantt, the folded rows — for `org status --serve` only: a store
    document is written by whoever holds the store, so the page never takes markup from one. `private_text` keeps an
    in-app ticket's words, for the served page only (`explorer.model`).
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN, tier_unread

    rep = st.get("report") or {}
    unread_by_tier = tier_unread(st.get("could_not_read") or [])
    edges = []
    for name, e in (rep.get("edges") or {}).items():
        edges.append({"name": name, "tier": EDGE_TIER.get(name, "board"), "owner": EDGE_OWNER.get(name, "?"),
                      "median_hours": e.get("median_hours"), "n": e.get("n"), "waiting": e.get("waiting"),
                      "worst_item": e.get("worst_waiting_item"), "worst_hours": e.get("worst_waiting_hours"),
                      "target": (rep.get("targets") or {}).get(name),
                      "unread_why": unread_by_tier.get(EDGE_TIER.get(name, "board"), ""),
                      "note": NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)"
                                                          if EDGE_TIER.get(name) == "board" and not e.get("n") else "")})
    from .brief import brief

    from . import explorer

    b = brief(st)
    xm = explorer.model(st, evidence_chars=evidence_chars, private_text=private_text)
    model = console.org_model(st, b, xm)
    doc = {"at": st.get("at"), "at_local": _clock(st.get("at"), st.get("operator_timezone")),
           # the answered items ride in `console.answered` as the painter draws them, not twice: a store document is capped
           "org": st.get("org"), "headline": st.get("headline"), "brief": {k: v for k, v in b.items() if k != "answered"},
           "tiles": [{k: t[k] for k in ("id", "title", "tier", "state", "lines", "broken_looks_like")} for t in st["tiles"]],
           "edges": edges, "coverage": st.get("coverage") or {}, "tiers": st.get("tiers") or {},
           "could_not_read": st.get("could_not_read") or [], "source": source,
           "explorer": xm,
           # what the Brief and Decide views draw beyond `brief` (`console.reading_part`): a published page paints them from it
           "console": console.reading_part(model),
           # who is listening, and what the operator asked (0.42.0): the controls' marks move with each reading
           "presence": (st.get("subjects") or {}).get("presence"), "asks": ((st.get("subjects") or {}).get("asks") or [])[:30]}
    if fragments:
        doc["html"] = {"secs": _sections_html(b, TEAM_SECTIONS), "secs-machinery": _sections_html(b, MACHINERY_SECTIONS),
                       "ci": _ci_html(st),
                       "roadmap": _roadmap_html(b.get("roadmap") or {}), "gantt": _timeline_html(b.get("timeline") or {}),
                       "bbody": console.brief_html(model), "decide": console.decide_html(model),
                       "teamgroups": console.team_groups_html(console.team_model(st.get("subjects") or {}, model["cards"],
                                                                                 st.get("operator_timezone")), st.get("operator_timezone"))}
    return _fit(doc, STORE_DOC_BUDGET) if evidence_chars is not None else doc


def _fit(doc: dict[str, Any], budget: int) -> dict[str, Any]:
    """The store's copy under its cap, trimmed in steps until it fits, and saying which (`explorer.trimmed`): the
    evidence; the tickets' words; finished items, pull requests and tickets down to what they are (`reduced`, which the
    page's script fills back from its own reading); every prompt; every empty field; finished items; closed tickets and
    finished pull requests; last, the explorer's lists, counted. A count or a status of open work is trimmed only by
    that last step, which says so. Measured 2026-09-24: at 400 items the untrimmed copy was 416 KB against a 256 KiB
    cap, ~900 bytes of it per item the prompt; a 200-ticket queue alone passed the cap after every other step."""
    x = doc.get("explorer") or {}

    def size() -> int:
        return len(json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode())
    if size() <= budget or not x:
        return doc
    items = x.get("items") or []
    prs = (x.get("prs") or {}).get("rows") or []
    tix = (x.get("tickets") or {}).get("rows") or []
    finished = [o for o in items if o.get("status") == "done"] + [o for o in prs if o.get("state") in ("merged", "closed")] \
        + [t for t in tix if not t.get("open")]
    keep = ("id", "key", "label", "title", "status", "state", "open", "number", "arc", "priority", "url", "file_href",
            "items", "withheld")

    def reduce(o: dict[str, Any]) -> None:
        for k in [k for k in o if k not in keep]:
            o.pop(k)
        o["reduced"] = True

    def drop(where: dict[str, Any], key: str, keep_if: Any, count_as: str) -> None:
        rows = where.get(key) or []
        where[key] = [o for o in rows if keep_if(o)]
        x[count_as] = x.get(count_as, 0) + len(rows) - len(where[key])

    steps = [
        ("evidence", lambda: [i.update(evidence="", evidence_cut=True) for i in items if i.get("evidence")]),
        ("the tickets' words", lambda: [t.update(body="") for t in tix]),
        ("finished work reduced to what it is", lambda: [reduce(o) for o in finished]),
        ("every prompt", lambda: [o.pop("prompt", None) for o in [*items, *prs, *tix, *(x.get("arcs") or [])]]),
        ("empty fields", lambda: [[o.pop(k) for k in [k for k in o if o[k] in (None, "", [], {}, False) and k not in keep]]
                                  for o in [*items, *prs, *tix]]),
        ("finished items", lambda: drop(x, "items", lambda i: i.get("status") != "done", "items_left_out")),
        ("closed tickets and finished pull requests", lambda: (
            drop(x.get("tickets") or {}, "rows", lambda t: t.get("open"), "tickets_left_out"),
            drop(x.get("prs") or {}, "rows", lambda p: p.get("state") == "open", "prs_left_out"))),
        ("the explorer's lists", lambda: (x.update(arcs=[], lists_left_out=True),
                                          drop(x, "items", lambda i: False, "items_left_out"),
                                          drop(x.get("tickets") or {}, "rows", lambda t: False, "tickets_left_out"),
                                          drop(x.get("prs") or {}, "rows", lambda p: False, "prs_left_out"))),
    ]
    done: list[str] = []
    for name, step in steps:
        step()
        done.append(name)
        x["trimmed"] = ", then ".join(done)
        if size() <= budget:
            break
    return doc


#: the page is live by subscription, not by polling: it draws the reading it shipped with, then redraws
#: whenever a newer one lands in the artifact's store. org-core writes no store — rule 6 — so the writer is
#: whatever session can reach the org. With no store granted the page still shows its embedded reading and
#: says so, because a dashboard that silently shows stale numbers is the failure this whole file is about.
LIVE_JS = r"""
<script>
(function () {
  var EL = function (t, c, x) { var e = document.createElement(t); if (c) e.className = c;
    if (x !== undefined && x !== null) e.textContent = String(x); return e; };
  var MARK = { RED: "\u25cf", CLEAR: "\u25cb", DARK: "\u2014" };
  var FINDING = __FINDING__;   // generated from status.FINDING — two hand-kept copies drifted once
  var TRUST_HTML = __TRUST_HTML__;   // true only where the page polls the reader that rendered it (SOURCE_POLL)
  var isFinding = function (l) { for (var i = 0; i < FINDING.length; i++) if (l.indexOf(FINDING[i]) === 0) return true; return false; };
  var seen = null;

  function ago(iso) {
    var t = Date.parse(iso); if (isNaN(t)) return "";
    var m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return "just now"; if (m < 60) return m + " min ago";
    var h = m / 60; return (h < 48 ? h.toFixed(1) + "h ago" : Math.round(h / 24) + "d ago");
  }
  function tickAges() {
    var n = document.getElementById("age"); if (n && seen) n.textContent = " \u00b7 read " + ago(seen.at);
  }
  function banner(tiles) {
    for (var i = 0; i < tiles.length; i++) if (tiles[i].state === "RED") return "RED";
    for (var j = 0; j < tiles.length; j++) if (tiles[j].state === "DARK") return "DARK";
    return "CLEAR";
  }
  function edgeTable(d) {
    var wrap = EL("div", "scroll"), t = EL("table"), h = EL("thead"), hr = EL("tr");
    ["edge","tier","owner","median","n","waiting","worst now","vs target"].forEach(function (c) { hr.appendChild(EL("th", null, c)); });
    h.appendChild(hr); t.appendChild(h);
    var b = EL("tbody");
    (d.edges || []).forEach(function (e) {
      var r = EL("tr");
      if (e.unread_why) {                 // an unread source is never repainted as a zero (row 65)
        [e.name, e.tier, e.owner].forEach(function (v) { r.appendChild(EL("td", null, v)); });
        var u = EL("td", "wide", "not judged \u2014 " + e.unread_why);
        u.colSpan = 5; u.style.color = "var(--red)";
        r.appendChild(u); b.appendChild(r); return;
      }
      [e.name, e.tier, e.owner,
       (e.median_hours === null || e.median_hours === undefined) ? "\u2014" : e.median_hours + "h",
       e.n, e.waiting,
       e.worst_item ? e.worst_item + " " + e.worst_hours + "h" : "\u2014"].forEach(function (v, i) {
        var td = EL("td", i === 6 ? "wide" : null, v); r.appendChild(td);
      });
      var td = EL("td");
      if (e.worst_hours !== null && e.worst_hours !== undefined && e.target) {
        var bar = EL("span", "bar"), fill = EL("i"), tick = EL("u");
        var ratio = e.worst_hours / e.target;
        fill.style.width = Math.min(ratio, 1) * 100 + "%"; if (ratio > 1) fill.className = "over";
        tick.style.left = "100%"; bar.appendChild(fill); bar.appendChild(tick);
        bar.title = "worst " + e.worst_hours + "h against a " + e.target + "h target";
        td.appendChild(bar);
      } else { td.appendChild(document.createTextNode("\u2014")); }
      if (e.target) td.appendChild(document.createTextNode("  (target " + e.target + "h)"));
      r.appendChild(td); b.appendChild(r);
      if (e.note) { var nr = EL("tr"), nd = EL("td", "wide", e.note);
        nd.colSpan = 8; nd.style.color = "var(--muted)"; nd.style.borderTop = "none"; nd.style.paddingTop = "0";
        nr.appendChild(nd); b.appendChild(nr); }
    });
    t.appendChild(b); wrap.appendChild(t); return wrap;
  }
  function paintBrief(b) {
    // the plain half repaints from the same document as the instrument below it: a live page whose words
    // stay on the last reading while its tiles move is worse than one that never claimed to be live
    if (!b) return;
    var v = document.getElementById("verdict");
    if (v) { v.textContent = b.verdict || ""; v.className = "verdict " + (b.state || "DARK"); }
    var nums = document.getElementById("nums");
    if (nums) {
      nums.textContent = "";
      (b.numbers || []).forEach(function (n) {
        var d2 = EL("div", "num");
        d2.appendChild(EL("div", "k", n.label));
        d2.appendChild(EL("div", "v " + (n.tone || "DARK"), n.value));
        d2.appendChild(EL("div", "n", n.note));
        nums.appendChild(d2);
      });
    }
    // each group is drawn by the view that owns it (`TEAM_SECTIONS`, `MACHINERY_SECTIONS`); what waits on the operator is the Decide
    // view's cards, painted by `orgConsole.paint`, so no item is drawn twice
    var hosts = { team: document.getElementById("secs"), machinery: document.getElementById("secs-machinery"),
                  unchecked: document.getElementById("secs-machinery") };
    Object.keys(hosts).forEach(function (k) { if (hosts[k]) hosts[k].textContent = ""; });
    (b.sections || []).forEach(function (sec) {
      var secs = hosts[sec.id];
      if (!sec.count || !secs) return;
      var s2 = EL("section", "sec " + sec.id), head = EL("div", "sechead");
      head.appendChild(EL("span", "ct", sec.count));
      head.appendChild(EL("h2", null, sec.title));
      head.appendChild(EL("p", null, sec.lead));
      s2.appendChild(head);
      (sec.items || []).forEach(function (i) {
        var r = EL("div", "row" + (i.fid ? " frow" : ""));
        if (i.fid) r.id = "f-" + i.fid;
        if (i.ask_key) { r.setAttribute("data-ask-key", i.ask_key); r.setAttribute("data-ask-title", i.what || ""); }
        r.appendChild(EL("span", "dot " + (i.tone || "DARK")));
        var body = EL("div", "body");
        var wh = EL("div", "what");
        if (i.fid) { var fl = EL("a", "fl", i.what); fl.href = "#" + (i.xid || "f-" + i.fid); wh.appendChild(fl); } else wh.textContent = i.what;
        body.appendChild(wh);
        if (i.why) body.appendChild(EL("div", "why", i.why));
        if (i.quote) body.appendChild(EL("div", "quote", i.quote));
        if (i.holding) {
          var h = EL("div", "blocks");
          h.appendChild(EL("s", null, "holding up"));
          var hs = EL("span", null, i.holding + " ");
          hs.appendChild(EL("em", null, "— matched on"));
          hs.appendChild(document.createTextNode(" "));
          hs.appendChild(EL("code", null, ((i.holds || {}).on || []).join(", ")));
          h.appendChild(hs); body.appendChild(h);
        }
        r.appendChild(body);
        if (i.ago) { var a = EL("div", "age", i.ago); if (i.at) a.title = i.at; r.appendChild(a); }
        s2.appendChild(r);
      });
      secs.appendChild(s2);
    });
  }
  function briefRow(i) {
    var r = EL("div", "row");
    r.appendChild(EL("span", "dot " + (i.tone || "DARK")));
    var body = EL("div", "body");
    body.appendChild(EL("div", "what", i.what));
    if (i.why) body.appendChild(EL("div", "why", i.why));
    r.appendChild(body);
    if (i.ago) { var a = EL("div", "age", i.ago); if (i.at) a.title = i.at; r.appendChild(a); }
    return r;
  }
  function paintRoadmap(r) {
    // the section `_roadmap_html` draws, from the same document: a live page's claims move with its tiles
    var box = document.getElementById("roadmap");
    if (!box || !r) return;
    // each arc's gantt is the reading the page was rendered from: a repaint moves the counts and claims, and
    // carries every arc's gantt (and whether it was open) across, rather than drawing lifetimes a second way
    var kept = {};
    Array.prototype.forEach.call(box.querySelectorAll("details.rmarc"), function (d) {
      kept[d.getAttribute("data-arc")] = { open: d.open, gantt: d.querySelector(".rmgantt") };
    });
    box.textContent = "";
    var sec = EL("section", "sec rm"), head = EL("div", "sechead");
    if (r.read) head.appendChild(EL("span", "ct", r.total));
    head.appendChild(EL("h2", null, "The roadmap"));
    var lead = EL("p", null, r.read
      ? "What is being worked on right now, and where every item stands, arc by arc. Read from " + r.source + "."
        + (r.note ? " Live claims not read; showing the committed items." : "")
      : "Not read \u2014 " + (r.why || ""));
    if (r.read && r.note) lead.title = r.note;
    head.appendChild(lead);
    sec.appendChild(head);
    if (!r.read) { box.appendChild(sec); return; }
    if ((r.held || []).length) r.held.forEach(function (i) { sec.appendChild(briefRow(i)); });
    else sec.appendChild(EL("div", "rmnone", "Nothing is being worked on \u2014 no item carries a claim."));
    (r.unparsed || []).forEach(function (n) {
      sec.appendChild(EL("div", "rmnone", "UNPARSED ITEM " + n + ": the file does not parse, so the queue cannot see it."));
    });
    var body = EL("div", "rmbody"), key = EL("div", "rmkey"), labels = {}, order = [];
    (r.legend || []).forEach(function (x) {
      labels[x.status] = x.label; order.push(x.status);
      var sp = EL("span"); sp.appendChild(EL("i", "st-" + x.status));
      sp.appendChild(document.createTextNode(x.label + " ")); sp.appendChild(EL("b", null, x.n)); key.appendChild(sp);
    });
    body.appendChild(key);
    var tb = EL("tbody");
    (r.arcs || []).forEach(function (a) {
      var row = EL("div", "rmrow"), lab = EL("span", "rmlabel"), tr = EL("span", "rmtrack"), n = {};
      lab.appendChild(EL("i", "ic ic-arc")); lab.appendChild(document.createTextNode(a.arc));
      if (a.priority) lab.appendChild(EL("em", "rmchip " + a.priority, a.priority));
      lab.title = a.arc; tr.setAttribute("role", "img");
      tr.setAttribute("aria-label", a.arc + ": " + a.segs.map(function (g) { return g.n + " " + (labels[g.status] || g.status); }).join(", "));
      a.segs.forEach(function (g) {
        n[g.status] = g.n;
        var i = EL("i", "st-" + g.status); i.style.flex = g.n;
        i.title = a.arc + ": " + g.n + " " + (labels[g.status] || g.status) + " (" + g.pct + "%)"; tr.appendChild(i);
      });
      row.appendChild(lab); row.appendChild(tr); row.appendChild(EL("span", "rmn", a.done + " of " + a.total + " done"));
      var k = kept[a.arc];
      if (k && k.gantt) {
        var d = EL("details", "rmarc"), sm = EL("summary"); d.setAttribute("data-arc", a.arc); d.open = k.open;
        sm.appendChild(row); d.appendChild(sm); d.appendChild(k.gantt); body.appendChild(d);
      } else body.appendChild(row);
      var trow = EL("tr"); trow.appendChild(EL("td", null, a.arc));
      order.forEach(function (st) { trow.appendChild(EL("td", null, n[st] || 0)); });
      trow.appendChild(EL("td", null, a.total)); tb.appendChild(trow);
    });
    var det = EL("details", "gtable"), wrap = EL("div", "scroll"), t = EL("table"), th = EL("thead"), hr = EL("tr");
    det.appendChild(EL("summary", null, "The same counts as a table"));
    hr.appendChild(EL("th", null, "arc")); order.forEach(function (st) { hr.appendChild(EL("th", null, st)); });
    hr.appendChild(EL("th", null, "total")); th.appendChild(hr); t.appendChild(th); t.appendChild(tb);
    wrap.appendChild(t); det.appendChild(wrap); body.appendChild(det);
    sec.appendChild(body); box.appendChild(sec);
  }
  var teamPending = null;
  window.orgTeamApply = function () {
    var el = document.getElementById("teamgroups");
    if (teamPending === null || !el || el.querySelector(".tctl .ctl")) return;
    el.innerHTML = teamPending; teamPending = null;
    if (window.orgControls) window.orgControls.update(null, null);
  };
  function swapFragments(html) {
    // the served page only (TRUST_HTML): the reader's own rendering of what the painters above only approximate —
    // the folded rows, every arc's gantt, the pull-request gantt. Open arcs stay open; the zoom is bound afresh.
    var open = {}, views = {}, tables = {}, all = function (sel, f) { Array.prototype.forEach.call(document.querySelectorAll(sel), f); };
    function where(el) {                 // which gantt or table this is, across a repaint
      var d = el.closest("details.rmarc"); if (d) return "arc:" + d.getAttribute("data-arc");
      return el.closest("#gantt") ? "gantt" : (el.closest("#roadmap") ? "roadmap" : "");
    }
    all("details.rmarc[open]", function (x) { open[x.getAttribute("data-arc")] = 1; });
    all(".gplot[data-zoom-bound]", function (p) { if (p.orgView) views[where(p)] = p.orgView(); });
    all("#roadmap details.gtable[open], #gantt details.gtable[open]", function (d) { tables[where(d)] = 1; });
    ["secs", "secs-machinery", "ci", "roadmap", "gantt", "bbody", "decide", "teamgroups"].forEach(function (k) {
      var el = document.getElementById(k); if (!el || typeof html[k] !== "string") return;
      // a reply the operator is typing to the CEO is not swapped out from under them: this paint waits for the next one
      // a panel the operator opened (`.ctl`; `.ctlopen` is a closed control's button) is not swapped away; the reading it skipped waits,
      // and Close applies it (`orgTeamApply`) — otherwise the poll, which only paints on a new reading, never offers it again
      if (k === "teamgroups") { if (el.querySelector(".tctl .ctl")) { teamPending = html[k]; return; } teamPending = null; }
      if ((k === "secs" || k === "decide" || k === "teamgroups") && Array.prototype.some.call(el.querySelectorAll("textarea"), function (t) { return t.value; })) return;
      el.innerHTML = html[k];
    });
    if (window.orgConsole) window.orgConsole.refresh();
    if (window.orgRefocus) window.orgRefocus();
    all("details.rmarc", function (x) { if (open[x.getAttribute("data-arc")]) x.open = true; });
    if (window.orgGanttBind) window.orgGanttBind();
    all(".gplot[data-zoom-bound]", function (p) { var v = views[where(p)]; if (v && p.orgSet) p.orgSet(v[0], v[1]); });
    all("#roadmap details.gtable, #gantt details.gtable", function (d) { if (tables[where(d)]) d.open = true; });
  }
  function paint(d) {
    seen = d;
    paintBrief(d.brief);
    paintRoadmap((d.brief || {}).roadmap);
    if (TRUST_HTML && d.html) swapFragments(d.html);
    // the tabs' counts and the line under *Decide* are outside the swapped fragments; a published page, which takes no markup from
    // its store, paints the Brief and the cards itself from the reading (`orgConsole.paint`)
    if (window.orgConsole && d.console) window.orgConsole.paint(d, !(TRUST_HTML && d.html));
    if (window.orgExplore && d.explorer) window.orgExplore.render(d.explorer, TRUST_HTML);
    if (window.orgControls && d.presence) window.orgControls.update(d.presence, d.asks);
    document.getElementById("org").textContent = d.org || "";
    document.getElementById("readat").textContent = "read at " + (d.at_local || d.at || "");
    var hl = document.getElementById("headline"); hl.textContent = d.headline || "";
    var bn = document.getElementById("banner"); bn.className = "banner " + banner(d.tiles || []);
    var grid = document.getElementById("tiles"); grid.textContent = "";
    (d.tiles || []).forEach(function (t) {
      var sec = EL("section", "tile " + t.state + (t.id === "chain" ? " span" : ""));
      var head = EL("div", "thead");
      head.appendChild(EL("span", "chip " + t.state, MARK[t.state] + " " + t.state));
      head.appendChild(EL("span", "tname", t.title));
      head.appendChild(EL("span", "tier", t.tier + " \u2014 " + ((d.tiers || {})[t.tier] || "several sources")));
      sec.appendChild(head);
      var hasTable = t.id === "chain" && (d.edges || []).length;
      if (hasTable) sec.appendChild(edgeTable(d));
      var lines = EL("div", "lines");
      (t.lines || []).forEach(function (l) {
        if (hasTable && !isFinding(l)) return;
        lines.appendChild(EL("div", isFinding(l) ? "hot" : null, l));
      });
      sec.appendChild(lines);
      if (t.state !== "RED") {
        var br = EL("div", "broken"); br.appendChild(EL("b", null, "broken looks like: "));
        br.appendChild(document.createTextNode(t.broken_looks_like || "")); sec.appendChild(br);
      }
      grid.appendChild(sec);
    });
    var c = d.coverage || {}, foot = document.getElementById("cover"); foot.textContent = "";
    foot.appendChild(EL("b", null, "read " + c.measured + " of " + c.tiles + " tiles"));
    if (c.dark && c.dark.length) foot.appendChild(document.createTextNode(" \u00b7 dark: " + c.dark.join(", ")));
    if (d.source) foot.appendChild(document.createTextNode(" \u00b7 " + d.source));
    var un = document.getElementById("unread"); un.textContent = "";
    (d.could_not_read || []).forEach(function (x) {
      var pEl = document.createElement("p"); pEl.appendChild(EL("code", null, "could not read: " + x)); un.appendChild(pEl);
    });
    tickAges();
  }
  function history(docs) {
    var h = document.getElementById("history"); h.textContent = "";
    if (docs.length < 2) return;
    h.appendChild(EL("span", "eyebrow", "readings"));
    docs.forEach(function (d, i) {
      var b = EL("button", "hbtn" + (i === 0 ? " now" : ""), ago(d.at));
      b.title = d.at + " \u2014 " + (d.headline || "");
      b.onclick = function () {
        paint(d);
        Array.prototype.forEach.call(h.querySelectorAll(".hbtn"), function (x) { x.classList.remove("now"); });
        b.classList.add("now");
      };
      h.appendChild(b);
    });
  }
  function live(txt, on) {
    var n = document.getElementById("live");
    n.textContent = txt; n.className = "live " + (on ? "on" : "off");
  }

  var initial = null;
  try { initial = JSON.parse(document.getElementById("reading").textContent); } catch (e) {}
  // the page already shows this reading, drawn by the server; painting it again only lost what the painters cannot
  // draw (the folded rows, the markdown, the gantts, the explorer's whole evidence). A NEWER reading is painted.
  if (initial) { seen = initial; tickAges(); }
  setInterval(tickAges, 30000);

  __SOURCE__
})();
</script>
"""

#: the artifact source: a store subscription. org-core pushes nothing (rule 6) — the page only reads.
SOURCE_STORE = r"""

  (async function () {
    var db = null;
    try { db = window.claude && window.claude.use ? await window.claude.use("db") : null; } catch (e) { db = null; }
    if (!db) { live("not live \u2014 showing the reading this page shipped with", false); return; }
    live("live \u2014 watching for new readings", true);
    try {
      db.collection("readings").orderBy("at", "desc").limit(20).onSnapshot(
        function (snap) {
          var docs = snap.docs.map(function (x) { return x.data(); }).filter(Boolean);
          if (!docs.length) { live("live \u2014 no reading written yet; showing the embedded one", true); return; }
          // the reading the page already shows is not painted again: the painters would only lose what the server drew
          if (!seen || docs[0].at !== seen.at || docs[0].source !== seen.source) paint(docs[0]);
          history(docs);
          live("live \u2014 " + docs.length + " reading(s), newest " + ago(docs[0].at), true);
        },
        function (err) { live("live updates stopped (" + (err && err.code) + ") \u2014 showing the last reading received", false); }
      );
    } catch (e) { live("not live \u2014 " + e, false); }
  })();
"""

#: the served source: poll the process that took the reading. That process re-reads on its own interval, so
#: polling faster than it costs nothing — and the age on screen stays the truth about how old the data is.
SOURCE_POLL = r"""
  var POLL_URL = "__POLL__", POLL_MS = __POLL_MS__, lastKey = null;
  async function pollOnce() {
    try {
      var r = await fetch(POLL_URL, { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var txt = await r.text(), d = JSON.parse(txt), key = d.rev || txt;
      // a new reading, not a new clock (the reader's `rev`: what the page says, clocks taken out, plus what failed). The
      // fast lane moves claims under an unchanged full reading and a failed read adds a line — both went unpainted while
      // this compared `at` alone; and a repaint on every tick closed the reader's drawer prompt and reset the zoom (0.41.0)
      if (key !== lastKey) { lastKey = key; paint(d); }
      else {
        seen = d; tickAges();
        document.getElementById("readat").textContent = "read at " + (d.at_local || d.at || "");
        if (window.orgExplore && d.explorer) window.orgExplore.lanes(d.explorer.lanes);
      }
      live("live \u2014 " + (d.reader && d.reader.error ? "the last read failed; showing the one before" :
                                 "re-read " + ago((d.reader && d.reader.fast_at) || d.at)), !(d.reader && d.reader.error));
    } catch (e) {
      live("the reader stopped answering \u2014 showing the last reading received", false);
    }
  }
  pollOnce();
  setInterval(pollOnce, POLL_MS);
"""

LIVE_CSS = """
.live{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;padding:2px 9px;border-radius:99px;border:1px solid var(--border);color:var(--muted)}
.live.on{color:var(--green);border-color:var(--green)}
.live.on::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--green)}
.live.off::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--dark-mark)}
#history{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:14px}
.hbtn{font:inherit;font-size:11.5px;font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);
  background:var(--surface);border:1px solid var(--border);border-radius:99px;padding:3px 10px;cursor:pointer}
.hbtn:hover{border-color:var(--accent);color:var(--accent)}
.hbtn.now{border-color:var(--accent);color:var(--accent);font-weight:600}
.hbtn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
"""


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""))


#: the roles write markdown into the operator file and into their blockers, so `LUCILLE_ADMIN_JWT` and
#: *(Ruth, 2026-09-20)* reach this page as literal backticks and asterisks. Printing them raw made the one
#: thing a row is about — the name — the hardest part of the row to see (measured 2026-09-22 on the first
#: `org command` render). This renders the three inline forms and nothing else: no links, no images, no
#: blocks. It runs AFTER escaping, so nothing here can introduce markup the text did not already ask for.
_MD = (
    (re.compile(r"`([^`\n]{1,120})`"), r"<code>\1</code>"),
    (re.compile(r"\*\*(\S|\S[^*\n]{0,198}\S)\*\*"), r"<b>\1</b>"),
    # the emphasised run may not begin or end in a space: `a * b * c` is arithmetic, not an italic.
    (re.compile(r"(?<![*\w])\*(\S|\S[^*\n]{0,198}\S)\*(?!\*)"), r"<i>\1</i>"),
)


def _md(x: Any) -> str:
    """Escaped text with `code`, **bold** and *italic* rendered. The escape is first and unconditional."""
    out = _e(x)
    for rx, rep in _MD:
        out = rx.sub(rep, out)
    return out


def _handoff_said(answers: list[dict[str, Any]] | None) -> str:
    """What the board holds as the operator's answer to a handoff, and whether the CEO has acted on it. A board row is
    attributed, never signed: this prints what the board holds, not what the operator said. Every answer is listed, whatever
    order its own stamps claim, so a later-stamped row cannot hide an earlier one (Reed on #73). Shared by the old rows and the
    Decide card (`console.py`), so the two say the same words."""
    said = ""
    for a in answers or []:
        what = _e(a.get("choice") or "") + (" — " if a.get("choice") and a.get("note") else "") + _e(a.get("note") or "")
        who = f" (claims to be from {_e(a['by'])})" if a.get("by") else ""
        said += (f"<div class='hol hosaid'><s>on the board</s><span>an answer: {what}{who} "
                 + (f"<em>— the CEO acted: {_e(a.get('done') or 'done')}</em>" if a.get("acted")
                    else "<em>— not marked acted on yet</em>")
                 + "</span></div>")
    if answers:
        said += ("<div class='hol hosaid'><s></s><span><em>The board is shared and unsigned, so this is not proof it was you. "
                 "If you did not send it, say so in a reply below.</em></span></div>")
    return said


def _handoff_html(h: dict[str, Any] | None, *, org: str = "", norec: bool = False) -> str:
    """What a handoff adds under its heading (handoffs.py, rows 181-182): who decides it, what the CEO recommends, what waiting
    costs, the exact command, the options with the recommended one first, and — once the operator has answered — what they
    said and whether the CEO has acted. The answer buttons are always in the markup and shown only on a page that can send
    (`data-ask` on the document, set by HANDOFF_JS from the page's own ask configuration), so the static page and the live
    repaint draw the same rows. Nothing here is computed: the writer's words, escaped.

    `norec`: a waiting item with no handoff has no recommendation, and says so — the CEO's debt, visible, never a blank."""
    if not h:
        return ("<div class='ho norec'><div class='hol'><s>CEO recommends</s><span>nothing recorded — the CEO owes a "
                "recommendation, or the reason it has none (<code>org handoffs add</code>)</span></div></div>") if norec else ""
    from . import handoffs as hf
    rows = "".join(f"<div class='hol'><s>{_e(k)}</s><span>{_md(v)}</span></div>" for k, v in hf.lines(h) if v)
    opts = h.get("options") or []
    pick = hf.marked_pick(h)
    ordered = ([pick] if pick in opts else []) + [o for o in opts if o != pick]
    optrows = "".join(
        f"<div class='hol hoopt'><s>option</s><span>{_md(o)}</span>"
        f"<button type='button' class='hoans' data-choice='{_e(o)}'>{'Choose (recommended)' if o == pick else 'Choose'}</button></div>"
        for o in ordered)
    do = (f"<div class='hol'><s>do</s><span class='hodo'><pre>{_e(h['do'])}</pre>"
          f"<button type='button' class='hocopy' data-do='{_e(h['do'])}'>copy</button></span></div>") if h.get("do") else ""
    if h.get("note"):
        # another org's CEO decides it: the org-core CEO session hands it over by DM as itself, and the note is the operator's fallback
        # when that CEO is unreachable (handoffs.note_for_ceo, row 7)
        do += (f"<div class='hol honote'><s>send to {_e(h.get('org') or 'the org')}'s CEO</s><span class='hodo'><span>{_e(hf.NOTE_WORDS)}</span>"
               f"<button type='button' class='hocopy' data-do='{_e(h['note'])}'>copy the note</button></span></div>")
    answers = h.get("answered") or []
    said = _handoff_said(answers)
    can = "" if h.get("orphan") or (answers and all(x.get("acted") for x in answers)) else (
        (f"<div class='hol hoans'><s></s><span><button type='button' class='hoans hoyes' data-choice='Do as recommended'>"
         "Do as recommended</button></span></div>") if not opts and not no_rec(h) else "")
    reply = ("<div class='hol hoans hoask'><s>reply</s><span class='horeply'><textarea rows='1' maxlength='2000' "
             "placeholder='answer in your own words, or ask the CEO something' aria-label='Reply to the CEO'></textarea>"
             "<button type='button' class='hosend'>Send</button></span><span class='hosaidnow' role='status'></span></div>")
    return (f"<div class='ho' data-hid='{_e(h.get('id') or '')}' data-org='{_e(org)}' data-title='{_e((h.get('what') or '')[:120])}'>"
            f"{rows}{optrows}{do}{said}{can}{reply}</div>")


def _rec_line(r: dict[str, Any] | None) -> str:
    """How many of what waits on the operator arrive with the CEO's recommendation — the measure of the operator's load the
    CEO is asked to lower. Said in words with both numbers; `None` (facts that predate it) says nothing rather than 0 of 0."""
    if not r or not r.get("of"):
        return ""
    n, m = int(r["n"]), int(r["of"])
    return (f"{n} of {m} come with the CEO's recommendation." if n == m else
            f"{n} of {m} come with the CEO's recommendation; the other {m - n} wait on one — the CEO owes it, or the reason it has none.")


def no_rec(h: dict[str, Any]) -> bool:
    from . import handoffs as hf
    return hf.no_recommendation(h)


#: the page's one write for a handoff, and its copy buttons. `#org-ask-cfg` maps an org to where its ask goes and the token
#: that page printed (the served org page: key `_`; the served fleet page: one per org). A page with none shows no answer
#: control — the operator can still copy the command — and never a button that cannot work. One delegated listener, no
#: inline handler (a page may run under a CSP), so a live repaint of the rows needs nothing re-attached.
HANDOFF_JS = """<script>(function(){var el=document.getElementById("org-ask-cfg"),C={};try{if(el)C=JSON.parse(el.textContent)||{}}catch(_){}
var m=document.querySelector("meta[name='org-ask']");if(m&&!C._)C._={ask:"ask",token:m.getAttribute("content")};
if(Object.keys(C).length)document.documentElement.setAttribute("data-ask","1");
function cp(b){var t=b.getAttribute("data-do")||"";function ok(){var o=b.textContent;b.textContent="copied";setTimeout(function(){b.textContent=o},1500)}
function fb(){var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");ok()}catch(_){}a.remove()}
if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(ok,fb);else fb()}
var busy=false;
async function answer(box,choice,note){if(busy)return;var c=C[box.getAttribute("data-org")||"_"]||C._,said=box.querySelector(".hosaidnow");
if(!c){said.textContent="this copy of the page cannot send";return}
busy=true;said.textContent="sending…";
try{var r=await fetch(c.ask,{method:"POST",headers:{"Content-Type":"application/json","X-Org-Ask":c.token},
body:JSON.stringify({kind:"answer",target:{type:"handoff",key:box.getAttribute("data-hid"),title:box.getAttribute("data-title")||""},choice:choice||null,note:note||"",at:new Date().toISOString()})});
var j=await r.json().catch(function(){return{}});if(!r.ok)throw new Error(j.error||("HTTP "+r.status));
said.textContent=(j.said||"recorded")+" — your answer: "+(choice||note);
Array.prototype.forEach.call(box.querySelectorAll("button"),function(x){x.disabled=true});
box.dispatchEvent(new CustomEvent("org-answered",{bubbles:true,detail:{choice:choice||"",note:note||"",said:j.said||"recorded"}}))}
catch(e){said.textContent="not sent: "+(e&&e.message?e.message:e)}busy=false}
function unfold(){Array.prototype.forEach.call(document.querySelectorAll(".frow.is-focus"),function(x){x.classList.remove("is-focus")});
var h=location.hash;if(h.indexOf("#f-")!==0)return;var t=document.getElementById(h.slice(1));if(t)t.classList.add("is-focus");
for(var d=t&&t.closest?t.closest("details"):null;d;d=d.parentElement&&d.parentElement.closest?d.parentElement.closest("details"):null)d.open=true}
window.addEventListener("hashchange",unfold);window.orgRefocus=unfold;unfold();
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&location.hash.indexOf("#f-")===0&&!/^(TEXTAREA|INPUT)$/.test((e.target||{}).tagName||""))location.hash="all"});
document.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("button");if(!b)return;
if(b.classList.contains("hocopy"))return cp(b);var box=b.closest(".ho[data-hid]");if(!box)return;
var ta=box.querySelector("textarea");
if(b.classList.contains("hosend")){if(ta&&ta.value.trim())answer(box,"",ta.value.trim());return}
if(b.hasAttribute("data-choice"))answer(box,b.getAttribute("data-choice"),ta?ta.value.trim():"")});})();</script>"""


def _clock(at: Any, tz: str | None = None) -> str:
    """`2026-09-22 21:05 IDT (2026-09-22 18:05Z)` from an ISO instant, in the operator's zone (`clock.for_operator`);
    `2026-09-22 18:05 UTC` when none is declared. A header is glanced at; `T18:05:30+00:00` is not."""
    from .clock import zone
    try:
        t = dt.datetime.fromisoformat(str(at).replace("Z", "+00:00"))
    except ValueError:
        return _e(at)                       # unparseable: show what we were given, never a made-up time
    if zone(tz) is not dt.timezone.utc:
        from .clock import for_operator
        return for_operator(t, tz)
    return t.strftime("%Y-%m-%d %H:%M UTC" if (t.utcoffset() or dt.timedelta()) == dt.timedelta() else "%Y-%m-%d %H:%M %Z")


def _edge_rows(rep: dict[str, Any], tiers: dict[str, str], unread: list[str] | None = None) -> str:
    """The chain as a table: every median beside its n, every worst-waiting beside its target.

    A board-tier edge shows what it is: a worst-waiting-now and no median, because the board keeps one
    record per key (row 62). The bar compares the worst wait to that edge's target and to nothing else.
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN, tier_unread

    out = ["<div class='scroll'><table><thead><tr><th>edge</th><th>tier</th><th>owner</th>"
           "<th>median</th><th>n</th><th>waiting</th><th>worst now</th><th>vs target</th></tr></thead><tbody>"]
    unread_by_tier = tier_unread(unread or [])
    for name, e in (rep.get("edges") or {}).items():
        tier = EDGE_TIER.get(name, "board")
        why = unread_by_tier.get(tier, "")
        if why:                      # an unread source is never rendered as a zero (row 65)
            out.append(f"<tr><td>{_e(name)}</td><td>{_e(tier)}</td><td>{_e(EDGE_OWNER.get(name, '?'))}</td>"
                       f"<td colspan='5' class='wide' style='color:var(--red)'>not judged — {_e(why)}</td></tr>")
            continue
        t = (rep.get("targets") or {}).get(name)
        med = f"{e['median_hours']}h" if e.get("median_hours") is not None else "—"
        worst = f"{e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e.get("worst_waiting_item") else "—"
        bar = "—"
        if e.get("worst_waiting_hours") is not None and t:
            ratio = e["worst_waiting_hours"] / t
            pct = min(ratio, 1.0) * 100
            over = " over" if ratio > 1 else ""
            bar = (f"<span class='bar' title='worst {e['worst_waiting_hours']}h against a {t}h target'>"
                   f"<i class='{over.strip()}' style='width:{pct:.0f}%'></i><u style='left:100%'></u></span>")
        why = NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)" if tier == "board" and not e.get("n") else "")
        out.append(
            f"<tr><td>{_e(name)}</td><td>{_e(tier)}</td><td>{_e(EDGE_OWNER.get(name, '?'))}</td>"
            f"<td>{_e(med)}</td><td>{_e(e.get('n'))}</td><td>{_e(e.get('waiting'))}</td>"
            f"<td class='wide'>{_e(worst)}</td><td>{bar}{('  (target ' + str(t) + 'h)') if t else ''}</td></tr>")
        if why:
            out.append(f"<tr><td colspan='8' class='wide' style='color:var(--muted);border-top:none;padding-top:0'>{_e(why)}</td></tr>")
    out.append("</tbody></table></div>")
    return "".join(out)


def _pr_plots_html(st: dict[str, Any]) -> str:
    """One org's pull requests over time (`prplots.py`), on the Work view."""
    from . import prplots
    now = dt.datetime.fromisoformat(str(st.get("at")).replace("Z", "+00:00"))
    return prplots.section_html((st.get("subjects") or {}).get("pr_daily"), now, tz=st.get("operator_timezone"))


def _fleet_pr_plots_html(d: dict[str, Any], tz: str | None) -> str:
    """The fleet's total, then each org read on its own: an org nobody could read says so, and is counted out of the total."""
    from . import prplots
    now = dt.datetime.fromisoformat(str(d.get("at")).replace("Z", "+00:00"))
    orgs = d.get("orgs") or []
    recs = [(o["id"], o.get("pr_daily") if o.get("cells") else prplots.unread(f"the org was not read — {o.get('read')}")) for o in orgs]
    recs = [(i, r or prplots.unread("this reading predates the pull-request history")) for i, r in recs]
    out = prplots.section_html(prplots.combine([r for _, r in recs]) if recs else None, now, scope="Every org read, summed. ", tz=tz)
    return out + "".join(prplots.section_html(r, now, scope=f"{i}. ", tz=tz).replace("<h2>Pull requests over time</h2>", f"<h2>{_e(i)} · pull requests over time</h2>", 1)
                         for i, r in recs)


def _item_plots_html(st: dict[str, Any]) -> str:
    """One org's roadmap items over time (`itemplots.py`), with the Brief's accomplished list under it."""
    from . import command as cm
    from . import itemplots
    now = dt.datetime.fromisoformat(str(st.get("at")).replace("Z", "+00:00"))
    tz = st.get("operator_timezone")
    q = console.queue_view([cm.queue(st, now)], tz)
    return itemplots.section_html((st.get("subjects") or {}).get("item_daily"), now, tz=tz, done_html=console._windows_html(q) if q.get("read") else "")


def _fleet_item_plots_html(d: dict[str, Any], tz: str | None) -> str:
    """The fleet's total over the orgs whose item history was read, then each org on its own; an org not read is `not checked`."""
    from . import itemplots
    now = dt.datetime.fromisoformat(str(d.get("at")).replace("Z", "+00:00"))
    recs = []
    for o in d.get("orgs") or []:
        r = o.get("item_daily") if o.get("cells") else itemplots.unread(f"the org was not read — {o.get('read')}")
        recs.append((o["id"], r or itemplots.unread("this reading predates the item history")))
    out = itemplots.section_html(itemplots.combine([r for _, r in recs]) if recs else None, now, scope="Every org read, summed. ", tz=tz)
    return out + "".join(itemplots.section_html(r, now, scope=f"{i}. ", tz=tz, title=f"{i} · roadmap items over time") for i, r in recs)


def _work_html(b: dict[str, Any]) -> str:
    """The roadmap's bars and the pull-request gantt: the Work view's top (`console.py`). Until 0.55.0 this page opened with a
    verdict, four figures and the items grouped by who can clear them; the verdict and the figures are the Brief now, what waits on
    the operator is Decide, and the rest of the groups are the Team and Machinery views (`_sections_html`)."""
    return (f"<div id='roadmap'>{_roadmap_html(b.get('roadmap') or {})}</div>"
            f"<div id='gantt'>{_timeline_html(b.get('timeline') or {})}</div>"
            # one zoom script for every gantt on the page — the PRs' and each arc's — and none when nothing is drawn
            + (GANTT_JS if (b.get("timeline") or {}).get("read") or any(
                (a.get("gantt") or {}).get("read") for a in (b.get("roadmap") or {}).get("arcs") or []) else ""))


def _ci_html(st: dict[str, Any]) -> str:
    """The runners and the Actions queue (`ci.html_section`), the Machinery view's own section after the plain groups: the
    static page's and the served repaint's (`#ci`). A reading taken before 0.74.0 carries none and says so."""
    from . import ci
    s = st.get("subjects") or {}
    return ci.html_section(s.get("ci") or ci.reading(None), st.get("operator_timezone"), _clock)


#: which of the brief's groups each view draws. `you` is not here: what waits on the operator is the Decide view's cards
#: (`console.card_html`), drawn from the same items, so no item is drawn twice.
TEAM_SECTIONS, MACHINERY_SECTIONS = ("team",), ("machinery", "unchecked")


def _sections_html(b: dict[str, Any], ids: tuple[str, ...]) -> str:
    """The groups named in `ids`, each with its folded rest — the static page's and the served repaint's."""
    secs = []
    row = _brief_row
    for sec in b.get("sections") or []:
        if not sec["count"] or sec["id"] not in ids:
            continue
        rows = "".join(row(i) for i in sec["items"])
        rest = ("".join(row(i) for i in sec["more"]) and
                f"<details class='more'><summary>{len(sec['more'])} more</summary>"
                f"{''.join(row(i) for i in sec['more'])}</details>") if sec.get("more") else ""
        secs.append(f"<section class='sec {sec['id']}'><div class='sechead'>"
                    f"<span class='ct'>{sec['count']}</span><h2>{_e(sec['title'])}</h2>"
                    f"<p>{_e(sec['lead'])}</p></div>{rows}{rest}</section>")
    return "".join(secs)


def _focus_detail(fid: str, at: Any, source: Any, tz: str | None) -> str:
    """What only the focused view of one item adds (SPEC row 184): when it was written, in the operator's zone with the UTC
    instant beside it, and where it lives. Hidden in the list; the item's own text and controls are the same markup in both."""
    when = _clock(at, tz) if at else "no date — nothing in this reading can say when it was written, so its age is unknown"
    return (f"<div class='fdetail'><div class='hol'><s>written</s><span>{_e(when) if not at else when}</span></div>"
            + (f"<div class='hol'><s>where it lives</s><span>{_e(source)}</span></div>" if source else "")
            + f"<div class='hol'><s>link</s><span><code>#f-{_e(fid)}</code> — paste this page's address with it to hand someone this item</span></div>"
            "<a class='fback' href='#all'>← back to everything</a></div>")


FOCUSBAR = ("<div class='focusbar'><a href='#all'>← Back to everything</a>"
            "<span class='fkeys'>or press <kbd>Esc</kbd></span></div>")


def _brief_row(i: dict[str, Any]) -> str:
    ak = f" data-ask-key='{_e(i['ask_key'])}' data-ask-title='{_e(i.get('what'))}'" if i.get("ask_key") else ""
    fid = str(i.get("fid") or "")
    # a row that is a roadmap item (`xid`) links to the explorer's page for it; only a waiting card is addressed `#f-`
    to = _e(i.get("xid") or f"f-{fid}")
    link = (lambda t: f"<a class='fl' href='#{to}'>{t}</a>") if fid else (lambda t: t)
    return (f"<div class='row{' frow' if fid else ''}'{(' id=' + chr(39) + 'f-' + _e(fid) + chr(39)) if fid else ''}{ak}>"
            f"<span class='dot {i['tone']}'></span><div class='body'>"
            f"<div class='what'>{link(_md(i['what']))}</div>"
            + (f"<div class='why'>{_md(i['why'])}</div>" if i.get("why") else "")
            + (f"<div class='quote'>{_md(i['quote'])}</div>" if i.get("quote") else "")
            + _handoff_html(i.get("handoff"), norec=bool(i.get("norec")))
            # what it holds up (row 128), with the token the match was made on — the link is the reader's to judge
            + (f"<div class='blocks'><s>holding up</s><span>{_e(i['holding'])} <em>— matched on</em> "
               f"<code>{_e(', '.join(i['holds']['on']))}</code></span></div>" if i.get("holding") else "")
            + (_focus_detail(fid, i.get("at"), i.get("where") or i.get("source"), i.get("tz")) if fid else "")
            + "</div>"
            + ((f"<div class='age' title='{_e(i.get('at') or '')}'>{_e(i['ago'])}"
                + (f"<a class='fopen' href='#{to}'>open ›</a>" if fid else "") + "</div>") if i.get("ago") else
               (f"<div class='age'><a class='fopen' href='#{to}'>open ›</a></div>" if fid else ""))
            + "</div>")


def _roadmap_html(r: dict[str, Any]) -> str:
    """What is being worked on now, then one bar per arc. The page places the percentages `brief.roadmap`
    computed and does no arithmetic of its own; every bar says its counts in words as well as in colour."""
    head = "<div class='sechead'>{ct}<h2>The roadmap</h2><p{tip}>{lead}</p></div>"
    if not r.get("read"):
        return (f"<section class='sec rm'>{head.format(ct='', tip='', lead=_e('Not read — ' + str(r.get('why') or '')))}"
                "</section>")
    lead = ("What is being worked on right now, and where every item stands, arc by arc. Read from "
            f"{r.get('source')}.") + (f" {ROADMAP_NOTE_SHORT}" if r.get("note") else "")
    # the command, URL and server body the note carries are detail: they sit in the hover text, never in the lead
    tip = f" title='{_e(r['note'])}'" if r.get("note") else ""
    held = ("".join(_brief_row(i) for i in r.get("held") or [])
            or "<div class='rmnone'>Nothing is being worked on — no item carries a claim.</div>")
    key = "".join(f"<span><i class='st-{_e(x['status'])}'></i>{_e(x['label'])} <b>{x['n']}</b></span>"
                  for x in r.get("legend") or [])
    labels = {x["status"]: x["label"] for x in r.get("legend") or []}
    rows = []
    for a in r.get("arcs") or []:
        segs = "".join(f"<i class='st-{_e(g['status'])}' style='flex:{g['n']}' "
                       f"title='{_e(a['arc'])}: {g['n']} {_e(labels.get(g['status'], g['status']))} ({g['pct']:g}%)'></i>"
                       for g in a["segs"])
        chip = f"<em class='rmchip {_e(a['priority'])}'>{_e(a['priority'])}</em>" if a.get("priority") else ""
        row = (f"<div class='rmrow'><span class='rmlabel' title='{_e(a.get('title') or a['arc'])}'><i class='ic ic-arc'></i>{_e(a['arc'])}{chip}</span>"
               f"<span class='rmtrack' role='img' aria-label='{_e(a['arc'])}: "
               + _e(", ".join(f"{g['n']} {labels.get(g['status'], g['status'])}" for g in a["segs"]))
               + f"'>{segs}</span><span class='rmn'>{a['done']} of {a['total']} done</span></div>")
        # each arc opens onto its own gantt (the operator, 2026-09-24); a <details>, so it opens with scripts off
        rows.append(f"<details class='rmarc' data-arc='{_e(a['arc'])}'><summary>{row}</summary>"
                    f"<div class='rmgantt'>{_arc_gantt_html(a['arc'], a.get('gantt') or {})}</div></details>")
    order = [x["status"] for x in r.get("legend") or []]
    table = "".join(f"<tr><td>{_e(a['arc'])}</td>"
                    + "".join(f"<td>{next((g['n'] for g in a['segs'] if g['status'] == st), 0)}</td>" for st in order)
                    + f"<td>{a['total']}</td></tr>" for a in r.get("arcs") or [])
    thead = "".join(f"<th>{_e(st)}</th>" for st in order)
    unparsed = "".join(f"<div class='rmnone'>UNPARSED ITEM {_e(n)}: the file does not parse, so the queue cannot "
                       "see it.</div>" for n in r.get("unparsed") or [])
    ct = f"<span class='ct'>{r.get('total')}</span>"
    # what the priority pickers list (PRIORITY_JS): each arc's priority and its open items, as the reading had them
    prio = json.dumps({"arcs": {a["arc"]: {"priority": a.get("priority"), "items": a.get("open_items") or []}
                                for a in r.get("arcs") or []}}, ensure_ascii=False).replace("<", "\\u003c")
    rows.append(f"<script type='application/json' id='rm-prio'>{prio}</script>{PRIORITY_JS}")
    return (f"<section class='sec rm'>{head.format(ct=ct, tip=tip, lead=_e(lead))}"
            f"{held}{unparsed}<div class='rmbody'><div class='rmkey'>{key}</div>{''.join(rows)}"
            f"<details class='gtable'><summary>The same counts as a table</summary><div class='scroll'><table>"
            f"<thead><tr><th>arc</th>{thead}<th>total</th></tr></thead><tbody>{table}</tbody></table></div>"
            f"</details></div></section>")


def _delegations_html(d: dict[str, Any] | None, tz: str | None, handoffs: dict[str, Any] | None = None) -> str:
    """The operator's standing decisions, with every use (delegations.py, SPEC row 180): what is NOT coming to them, and
    each time one was used, what the exerciser said it checked and where. Pure: everything is `d`."""
    head = "<div class='sechead'>{ct}<h2>Standing decisions</h2><p>{lead}</p></div>"
    if not d or not d.get("read"):
        return ("<section class='sec dg'>" + head.format(ct="", lead=_e("Not read — these facts predate standing decisions "
                "(0.51.0), so the page cannot say what has been delegated.")) + "</section>")
    grants = d.get("grants") or []
    if not grants:
        return ("<section class='sec dg'>" + head.format(ct="", lead=_e(
            "Nothing is delegated: every act in SPEC §12 that is not a role's own comes to you.")) + "</section>")
    lead = ("Decisions you made once and kept, so they stop coming back. A role may use one only after it has checked "
            "every condition and written down where it saw each; every use is listed here for you to read, and "
            "deleting the entry in org.yaml withdraws it.")
    rows = []
    for g in grants:
        conds = "".join(f"<li><code>{_e(c['id'])}</code> — {_e(c['means'])}</li>" for c in g.get("when") or [])
        uses = "".join(
            f"<div class='dgu'><time>{_e(_clock(u.get('at'), tz))}</time> <b>{_e(u.get('role'))}</b> on "
            f"<code>{_e(u.get('target'))}</code> — {_e(u.get('evidence'))}</div>" for u in g.get("last_uses") or [])
        # what is open right now that the org-core CEO decides under this grant: listed here, not asked of the operator
        mine = [h for h in (handoffs or {}).get("open") or [] if h.get("delegation") == g.get("id") and not h.get("orphan")]
        open_now = ("<div class='dgus'>Open now, decided under this — not asked of you</div>"
                    + "".join(f"<div class='dgu'><b>{_md(h.get('what'))}</b>{_handoff_html(h)}</div>" for h in mine)) if mine else ""
        state = ("<span class='dgstate'>active</span>" if g.get("active")
                 else "<span class='dgstate dgx'>expired " + _e(g.get("expires")) + "</span>")
        rows.append(
            f"<div class='row dgrow'><i class='ic ic-rule'></i><div class='body'>"
            f"<div class='what'><code>{_e(g['id'])}</code> — <b>{_e(g['to'])}</b> may {_e(g['act_means'])} in "
            f"<b>{_e(', '.join(g['orgs']))}</b> {state}</div>"
            f"<div class='why'>{_e(g['what'])}</div>"
            f"<div class='why'>Only after checking, and citing where it saw each:</div><ul class='dgc'>{conds}</ul>"
            f"<div class='quote'>{_e(g['by'])}, {_e(g['on'])}: {_e(g['source'])}</div>"
            + (f"<div class='dgus'>{g['uses']} use{'s' if g['uses'] != 1 else ''}, latest first</div>{uses}"
               if g["uses"] else "<div class='dgus'>Not used yet.</div>")
            + open_now + "</div></div>")
    warn = ""
    if d.get("bad_lines") or d.get("orphans"):
        warn = (f"<div class='rmnone'>The use log has {int(d.get('bad_lines') or 0)} line(s) that do not read and "
                f"uses of grants that are not in org.yaml ({_e(', '.join(map(str, d.get('orphans') or [])) or 'none')}).</div>")
    return (f"<section class='sec dg' id='delegations'>{head.format(ct=f'<span class=ct>{len(grants)}</span>', lead=_e(lead))}"
            f"{warn}{''.join(rows)}</section>")


#: time zoom on "Where the time went" (the operator, 2026-09-24: *"give me time zoom gestures in the gantt"*).
#: The static chart is Python's percentages and stays exactly that with scripts off, and again whenever the
#: view is the whole window: at that zoom the script puts the saved markup back rather than re-drawing it.
#: Zoomed, it re-projects the same instants the table lists (data-start / data-verdict / data-end, UTC), so
#: this is a lens on Python's numbers, not a second computation of them. Ticks are UTC like the static axis.
GANTT_JS = r"""
<script>
(function () {
  var MIN = 60000, DAY = 1440 * MIN, NARROWEST = 5 * MIN, TICK_PX = 64;
  var STEPS = [1, 2, 5, 10, 15, 30, 60, 120, 180, 360, 720, 1440, 2880, 10080];
  var MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function day(t) { var d = new Date(t); return MON[d.getUTCMonth()] + " " + d.getUTCDate(); }
  function hm(t) { var d = new Date(t); return p2(d.getUTCHours()) + ":" + p2(d.getUTCMinutes()); }
  function span(ms) {
    var m = ms / MIN; return m < 90 ? Math.round(m) + " min" : (m / 60 < 48 ? (m / 60).toFixed(1) + "h" : (m / 1440).toFixed(1) + " d");
  }
  function btn(txt, label) {
    var b = document.createElement("button"); b.type = "button"; b.textContent = txt;
    b.setAttribute("aria-label", label); b.title = label; return b;
  }

  function bind(plot) {
    if (plot.getAttribute("data-zoom-bound")) return;
    var T0 = Date.parse(plot.getAttribute("data-since")), T1 = Date.parse(plot.getAttribute("data-until"));
    var grid = plot.querySelector(".ggrid"), axis = plot.querySelector(".gaxis");
    if (!(T1 > T0) || !grid || !axis) return;
    plot.setAttribute("data-zoom-bound", "1");
    var FULL = T1 - T0, FLOOR = Math.min(NARROWEST, FULL);
    var saved = { grid: grid.innerHTML, axis: axis.innerHTML }, bars = [];
    Array.prototype.forEach.call(plot.querySelectorAll(".gspan"), function (el) {
      var s = Date.parse(el.getAttribute("data-start")), e = Date.parse(el.getAttribute("data-end"));
      var v = Date.parse(el.getAttribute("data-verdict") || "");
      if (isNaN(s) || isNaN(e)) return;            // a bar it cannot place stays where Python put it
      var segs = el.querySelectorAll("i");
      bars.push({ el: el, s: s, e: Math.max(e, s), v: (v >= s && v <= e) ? v : null, segs: segs,
                  style: el.getAttribute("style"), segStyle: Array.prototype.map.call(segs, function (i) { return i.getAttribute("style"); }) });
    });
    var a = T0, b = T1;

    var bar = document.createElement("div"); bar.className = "gzoombar";
    bar.setAttribute("role", "group"); bar.setAttribute("aria-label", "Time zoom");
    var bOut = btn("−", "Zoom out"), bIn = btn("+", "Zoom in"), bL = btn("◀", "Earlier"),
        bR = btn("▶", "Later"), bReset = btn("Whole window", "Show the whole window");
    var view = document.createElement("span"); view.className = "gview"; view.setAttribute("aria-live", "polite");
    var hint = document.createElement("span"); hint.className = "ghint";
    hint.textContent = "Pinch, or ctrl/⌘ + scroll, to zoom · drag to pan · double-tap to reset · times UTC";
    [bOut, bIn, bL, bR, bReset, view, hint].forEach(function (n) { bar.appendChild(n); });
    plot.parentNode.insertBefore(bar, plot);
    plot.classList.add("gzoom");
    plot.tabIndex = 0;
    plot.setAttribute("aria-label", "Pull requests on one time axis. Plus and minus zoom, arrow keys pan, 0 resets.");

    function width() { return axis.getBoundingClientRect().width || 1; }
    function at(clientX) { var r = axis.getBoundingClientRect(); return a + (clientX - r.left) / (r.width || 1) * (b - a); }
    function set(na, nb) {
      var v = Math.min(Math.max(nb - na, FLOOR), FULL);
      if (na < T0) na = T0; if (na + v > T1) na = T1 - v;
      a = na; b = na + v; draw();
    }
    // a served repaint redraws the plot: it reads the view before and puts it back after (dashboard.swapFragments)
    plot.orgView = function () { return [a, b]; };
    plot.orgSet = function (na, nb) { set(na, nb); };
    function zoom(f, focus) {
      if (focus === undefined) focus = (a + b) / 2;
      var v = Math.min(Math.max((b - a) / f, FLOOR), FULL);
      var na = focus - (focus - a) * v / (b - a);
      set(na, na + v);
    }
    function pan(ms) { set(a + ms, b + ms); }
    function reset() { set(T0, T1); }

    function draw() {
      var whole = a <= T0 && b >= T1, v = b - a, W = width();
      plot.classList.toggle("zoomed", !whole);
      plot.classList.toggle("atend", b >= T1);
      bOut.disabled = bReset.disabled = whole; bIn.disabled = v <= FLOOR;
      bL.disabled = a <= T0; bR.disabled = b >= T1;
      view.textContent = whole ? "whole window, " + span(FULL)
        : day(a) + " " + hm(a) + " – " + (day(a) === day(b) ? "" : day(b) + " ") + hm(b) + ", " + span(v) + " of " + span(FULL);
      if (whole) {                                  // the static chart, exactly as Python drew it
        grid.innerHTML = saved.grid; axis.innerHTML = saved.axis;
        bars.forEach(function (x) {
          x.el.setAttribute("style", x.style);
          Array.prototype.forEach.call(x.segs, function (i, k) { i.setAttribute("style", x.segStyle[k]); });
        });
        return;
      }
      bars.forEach(function (x) {
        var w = (x.e - x.s) / v * 100;
        x.el.style.left = ((x.s - a) / v * 100) + "%";
        x.el.style.width = w + "%";
        x.el.style.width = "max(" + w + "%, " + (x.v !== null && x.segs.length > 1 ? 7 : 3) + "px)";
        if (x.v !== null && x.segs.length > 1) {
          x.segs[0].style.flex = String(Math.max(x.v - x.s, 1) / MIN);
          x.segs[1].style.flex = String(Math.max(x.e - x.v, 1) / MIN);
        }
      });
      var step = STEPS[STEPS.length - 1] * MIN;
      for (var k = 0; k < STEPS.length; k++) if (STEPS[k] * MIN * W / v >= TICK_PX) { step = STEPS[k] * MIN; break; }
      var g = "", l = "";
      for (var t = Math.ceil(a / step) * step; t <= b; t += step) {
        var pct = (t - a) / v * 100, px = pct / 100 * W;
        g += "<b style='left:" + pct + "%'></b>";
        if (px >= 18 && px <= W - 18) l += "<b style='left:" + pct + "%'>" + (step >= DAY || t % DAY === 0 ? day(t) : hm(t)) + "</b>";
      }
      grid.innerHTML = g; axis.innerHTML = l;
    }

    bIn.onclick = function () { zoom(2); };
    bOut.onclick = function () { zoom(0.5); };
    bL.onclick = function () { pan(-(b - a) / 3); };
    bR.onclick = function () { pan((b - a) / 3); };
    bReset.onclick = reset;
    plot.addEventListener("keydown", function (e) {
      var k = e.key;
      if (k === "+" || k === "=") zoom(2); else if (k === "-" || k === "_") zoom(0.5);
      else if (k === "0") reset(); else if (k === "ArrowLeft") pan(-(b - a) / 6);
      else if (k === "ArrowRight") pan((b - a) / 6); else return;
      e.preventDefault();
    });
    // ctrl/cmd + wheel is a mouse zoom and also what a trackpad pinch sends; a sideways scroll pans.
    // A plain vertical scroll is left alone, so the page scrolls over the chart as it always did.
    plot.addEventListener("wheel", function (e) {
      var unit = e.deltaMode === 1 ? 33 : (e.deltaMode === 2 ? 400 : 1);
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        zoom(Math.exp(-Math.max(-100, Math.min(100, e.deltaY * unit)) * 0.006), at(e.clientX));
      } else if (b - a < FULL && (Math.abs(e.deltaX) > Math.abs(e.deltaY) || e.shiftKey)) {
        e.preventDefault();
        pan((Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY) * unit / width() * (b - a));
      }
    }, { passive: false });
    // Safari's trackpad pinch arrives as gesture events, not as ctrl+wheel
    var gs = 1;
    plot.addEventListener("gesturestart", function (e) { e.preventDefault(); gs = 1; });
    plot.addEventListener("gesturechange", function (e) { e.preventDefault(); zoom(e.scale / gs, at(e.clientX)); gs = e.scale; });

    // pointers: one finger or the mouse drags, two fingers pinch. touch-action:pan-y hands vertical swipes
    // to the browser (it sends pointercancel), so only sideways drags and pinches reach this code.
    var pts = {}, n = 0, start = null, lastTap = null;
    function baseline() {
      var ids = Object.keys(pts), p = pts[ids[0]], q = pts[ids[1]];
      if (n >= 2) {
        var mid = (p.x + q.x) / 2;
        start = { pinch: true, d: Math.max(Math.hypot(p.x - q.x, p.y - q.y), 1), t: at(mid), v: b - a };
      } else if (n === 1) {
        start = { pinch: false, x: p.x, a: a, v: b - a };
      } else start = null;
    }
    plot.addEventListener("pointerdown", function (e) {
      if (e.pointerType === "mouse" && (e.button !== 0 || b - a >= FULL)) return;
      pts[e.pointerId] = { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, t0: Date.now() }; n++;
      try { plot.setPointerCapture(e.pointerId); } catch (err) {}
      if (e.pointerType === "mouse") plot.classList.add("dragging");
      baseline();
    });
    plot.addEventListener("pointermove", function (e) {
      var p = pts[e.pointerId]; if (!p || !start) return;
      p.x = e.clientX; p.y = e.clientY;
      var r = axis.getBoundingClientRect(), W = r.width || 1;
      if (start.pinch && n >= 2) {
        var ids = Object.keys(pts), P = pts[ids[0]], Q = pts[ids[1]];
        var v = Math.min(Math.max(start.v * start.d / Math.max(Math.hypot(P.x - Q.x, P.y - Q.y), 1), FLOOR), FULL);
        var na = start.t - ((P.x + Q.x) / 2 - r.left) / W * v;
        set(na, na + v);
      } else if (!start.pinch) {
        var pa = start.a - (p.x - start.x) / W * start.v;
        set(pa, pa + start.v);
      }
    });
    function up(e) {
      var p = pts[e.pointerId]; if (!p) return;
      delete pts[e.pointerId]; n--;
      plot.classList.remove("dragging");
      if (e.type === "pointerup" && e.pointerType !== "mouse" && n === 0 &&
          Math.abs(e.clientX - p.x0) < 10 && Math.abs(e.clientY - p.y0) < 10 && Date.now() - p.t0 < 300) {
        var now = Date.now();
        if (lastTap && now - lastTap.t < 320 && Math.abs(e.clientX - lastTap.x) < 30) { reset(); lastTap = null; }
        else lastTap = { t: now, x: e.clientX };
      }
      baseline();                                   // two fingers down to one: pan from here, no jump
    }
    plot.addEventListener("pointerup", up);
    plot.addEventListener("pointercancel", up);
    plot.addEventListener("dblclick", function (e) { e.preventDefault(); reset(); });
    window.addEventListener("resize", function () { if (b - a < FULL) draw(); });
    var box = plot.closest("details");                // an arc's gantt is laid out only once it is opened
    if (box) box.addEventListener("toggle", function () { if (box.open) draw(); });
    draw();
  }
  // a live repaint of the served page draws new plots (dashboard.swapFragments): they are bound the same way
  window.orgGanttBind = function () { Array.prototype.forEach.call(document.querySelectorAll(".gplot[data-since]"), bind); };
  window.orgGanttBind();
})();
</script>
"""


#: what a published org page declares so its priority pickers work: `db` with `priority_asks` writable by the
#: artifact's owner only (every other level reads it), and `user`, so the page can tell the owner and sign each ask.
#: Reed on #33 (2026-09-24): the root default is `write: "interact"`, every Contributor — without this rule anyone
#: the page was shared with could set the operator's priorities.
PRIORITY_CAPABILITIES = {"db": {"rules": [{"path": "priority_asks", "write": "owner"}]}, "user": {}}
#: what a published org page declares (0.42.0): both owner-only collections — the priorities' and the asks' — who is
#: viewing, and the operator's own switchboard on their device to relay an ask through (`asks.ASK_CAPABILITIES`)
PAGE_CAPABILITIES = {"db": {"rules": [{"path": "priority_asks", "write": "owner"}, {"path": "asks", "write": "owner"}]},
                     "user": {}, "mcp": {"servers": [{"server": "host:switchboard", "tools": ["dm"]}]}}

#: priorities from the page (the operator, 2026-09-24: "and the ability to prioritize items" … "or arcs"; ruled: the page
#: records, the CEO lands it). Only a published page granted `db` shows the pickers; anywhere else this does nothing
#: and the page is the static one. A change is one document in `priority_asks` — the viewer's own write, never
#: org-core's (rule 6) — and the chair lands it with `org priorities` and a PR. An ask the reading already carries is
#: shown as landed; one it does not, as waiting. The page never claims a priority it cannot see in the files.
PRIORITY_JS = r"""
<script>
(function () {
  var el = document.getElementById("rm-prio"); if (!el) return;
  var DATA; try { DATA = JSON.parse(el.textContent).arcs || {}; } catch (e) { return; }
  var PR = ["now", "next", "later"], asks = {}, db = null, me = null, readonly = false;
  function E(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = String(x); return e; }
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function when(iso) {                       // local first, the UTC instant beside it (two clocks, rows 142-143)
    var d = new Date(iso); if (isNaN(d)) return "";
    return p2(d.getHours()) + ":" + p2(d.getMinutes()) + " (" + p2(d.getUTCHours()) + ":" + p2(d.getUTCMinutes()) + "Z)";
  }
  function pick(kind, key, arc, have) {
    var ask = asks[kind + "--" + key], row = E("div", "pr" + (kind === "arc" ? " arc" : ""));
    var sel = E("select"), tag = E("span", "tag");
    [["", "unset"]].concat(PR.map(function (p) { return [p, p]; })).forEach(function (o) {
      var op = E("option", null, o[1]); op.value = o[0]; sel.appendChild(op);
    });
    sel.value = ask ? (ask.priority || "") : (have || "");
    sel.disabled = readonly;
    sel.setAttribute("aria-label", "Priority of " + (kind === "arc" ? "the arc " : "") + key);
    if (ask && (ask.priority || null) !== (have || null)) {
      tag.className = "tag asked";
      tag.textContent = "asked " + when(ask.at) + " — " + (have || "unset") + " → " + (ask.priority || "unset") + ", waiting to land";
    } else if (ask) tag.textContent = "landed";
    sel.onchange = function () {
      var v = sel.value || null, doc = { kind: kind, key: key, arc: arc, priority: v, was: have || null,
                                        by: me, at: new Date().toISOString() };
      tag.className = "tag"; tag.textContent = "saving…";
      Promise.resolve().then(function () { return db.doc("priority_asks/" + kind + "--" + key).set(doc); }).then(
        function () { asks[kind + "--" + key] = doc; render(); },
        function (err) {
          var code = (err && err.code) || "error";
          // a write below the path's level rejects `invalid_argument` (db.d.ts): read-only for the rest of the visit
          if (code === "invalid_argument" || code === "not_granted" || code === "revoked") { readonly = true; render(); }
          sel.value = ask ? (ask.priority || "") : (have || "");
          tag.className = "tag bad"; tag.textContent = "not saved (" + code + ")";
        });
    };
    var name = E("span", null, key); name.title = key;
    row.appendChild(name); row.appendChild(sel); row.appendChild(tag);
    return row;
  }
  function render() {
    Array.prototype.forEach.call(document.querySelectorAll("details.rmarc"), function (d) {
      var arc = d.getAttribute("data-arc"), a = DATA[arc], g = d.querySelector(".rmgantt"); if (!a || !g) return;
      var box = g.querySelector(".rmprio");
      if (!box) { box = E("details", "rmprio"); g.appendChild(box); }
      box.textContent = "";
      var waiting = 0;
      Object.keys(asks).forEach(function (k) {
        var x = asks[k]; if (x.arc !== arc) return;
        var have = x.kind === "arc" ? a.priority : ((a.items.filter(function (i) { return i.key === x.key; })[0] || {}).priority);
        if ((x.priority || null) !== (have || null)) waiting++;
      });
      var sm = E("summary"); box.appendChild(sm);
      sm.appendChild(E("h3", null, "Set priorities — this arc and its " + a.items.length + " open item(s)" +
        (waiting ? " · " + waiting + " waiting to land" : "")));
      box.appendChild(E("p", null, readonly ? "Read-only: this view cannot save a change." :
        "Set here, landed by the CEO as a pull request to the item files. An item's priority orders roadmap-core's " +
        "queue; an arc's orders this page and what the CEO reads, not the queue."));
      box.appendChild(pick("arc", arc, arc, a.priority));
      a.items.forEach(function (i) { box.appendChild(pick("item", i.key, arc, i.priority)); });
      if (!a.items.length) box.appendChild(E("p", null, "No open item in this arc."));
    });
  }
  (async function () {
    try { db = window.claude && window.claude.use ? await window.claude.use("db") : null; } catch (e) { db = null; }
    if (!db) return;                            // not a published page with a store: the static page stands
    // priority is the operator's call, so only the page's owner gets pickers, and every ask names its writer: a
    // Contributor's pick must never land as the owner's (Reed on #33). The page is published with
    // PRIORITY_CAPABILITIES, whose rule lets only the owner write `priority_asks` — this is the second lock.
    var user = null, owner = false;
    try { user = await window.claude.use("user"); } catch (e) { user = null; }
    try { owner = user ? await user.isOwner() : false; } catch (e) { owner = false; }
    try { me = user ? await user.id() : null; } catch (e) { me = null; }
    if (!owner || !me) return;                  // not the owner, or no identity to sign an ask with: no pickers
    render();
    try {
      db.collection("priority_asks").onSnapshot(function (snap) {
        asks = {};
        snap.docs.forEach(function (x) { var v = x.data(); if (v && v.kind && v.key) asks[v.kind + "--" + v.key] = v; });
        render();
      }, function () { render(); });
    } catch (e) { render(); }
  })();
})();
</script>
"""


def _gplot(t: dict[str, Any], rows: list[str]) -> str:
    """The plot both gantts draw: grid, rows, axis, and the window the zoom re-projects against (`GANTT_JS`)."""
    grid = "".join(f"<b style='left:{x['left']}%'></b>" for x in t.get("ticks") or [])
    axis = "".join(f"<b style='left:{x['left']}%'>{_e(x['label'])}</b>" for x in t.get("ticks") or [])
    return (f"<div class='gplot' data-since='{_e(t.get('since') or '')}' data-until='{_e(t.get('until') or '')}'>"
            f"<div class='ggrid'>{grid}</div>{''.join(rows)}<div class='gaxis'>{axis}</div></div>")


def _arc_gantt_html(arc: str, g: dict[str, Any]) -> str:
    """One arc's items as lifetimes (`brief.arc_gantt`), with the same spans as a table beneath."""
    if not g.get("read"):
        return f"<p class='gnote'>No gantt for this arc — {_e(g.get('why'))}.</p>"
    rows, table = [], []
    for r in g["rows"]:
        segs = (f"<i class='{r['first_cls']}' style='flex:{r['first_pct']}'></i>"
                f"<i class='st-verifying' style='flex:{r['second_pct']}'></i>" if r["split"]
                else f"<i class='{r['first_cls']}' style='flex:1'></i>")
        tip = (f"{r['key']} — {r['title']} · {r['status']}" + (f", priority {r['priority']}" if r.get("priority") else "")
               + (f", held by {r['claimed_by']}" if r.get("claimed_by") else "")
               + f" · filed {r['opened_at']}" + (f", verifying from {r['verifying_at']}" if r.get("verifying_at") else "")
               + (", still open" if r["open"] else (f", done {r['end_at']}" + (" (undated: the last commit to its file)"
                                                                               if r["end_undated"] else ""))))
        when = (f"data-start='{_e(r['opened_at'])}' data-end='{_e(r['end_at'] or g.get('until') or '')}'"
                + (f" data-verdict='{_e(r['verifying_at'])}'" if r["split"] else ""))
        mark = "▸ " if r.get("claimed_by") else ""
        rows.append(f"<div class='grow'><span class='glabel' title='{_e(r['title'])}'>{mark}{_e(r['key'])}</span>"
                    f"<span class='gtrack'><span class='gspan rmg{' rmv' if (r['split'] or r['first_cls'] == 'st-verifying') else ''}"
                    f"{' open' if r['open'] else ''}' title='{_e(tip)}' {when} "
                    f"style='left:{r['left']}%;width:{round(r['first_pct'] + r['second_pct'], 3)}%'>{segs}</span></span></div>")
        table.append(f"<tr><td>{_e(r['key'])}</td><td>{_e(r['status'])}</td><td>{_e(r.get('priority') or '—')}</td>"
                     f"<td>{_e(r['opened_at'])}</td><td>{_e(r.get('verifying_at') or '—')}</td>"
                     f"<td>{_e(r['end_at'] or 'still open')}{' (undated)' if r['end_undated'] else ''}</td></tr>")
    und = g.get("undated") or []
    note = (f"{len(g['rows'])} item(s), open ones first by priority. A bar starts when the item's file landed on the "
            f"branch — {g.get('filed_verifying', 0)} of these were filed already shipped, so a bar can start at "
            f"verifying; it is when the work was written down, not when it was asked for. ▸ marks a live claim."
            + (f" {len(und)} undated: {', '.join(und)}." if und else "") + (f" {g['note']}." if g.get("note") else ""))
    return (f"<div class='gkey'><span><i class='st-ready'></i>open, not yet shipped</span>"
            f"<span><i class='st-verifying'></i>shipped, being verified</span><span><s>▶</s>still open</span></div>"
            + _gplot(g, rows) + f"<p class='gnote'>{_e(note)}</p>"
            f"<details class='gtable'><summary>The same lifetimes as a table</summary><div class='scroll'><table>"
            f"<thead><tr><th>item</th><th>status</th><th>priority</th><th>filed</th><th>verifying</th><th>done</th>"
            f"</tr></thead><tbody>{''.join(table)}</tbody></table></div></details>")


def _timeline_html(t: dict[str, Any]) -> str:
    """The spans, placed. Every percentage was computed in Python, which is the same rule the rest of this file
    follows and the reason two surfaces cannot drift. The one exception is the zoom (`GANTT_JS`): zoomed, the
    page re-projects the instants each bar carries, and at the whole window it puts Python's markup back."""
    if not t.get("read"):
        return (f"<section class='sec tl'><div class='sechead'><h2>Where the time went</h2>"
                f"<p>Not drawn — {_e(t.get('why'))}.</p></div></section>")
    rows = []
    for r in t["rows"]:
        cls = "open" if r["open"] else ""
        segs = (f"<i class='review'style='flex:{r['first_pct']}'></i><i class='merge'style='flex:{r['second_pct']}'></i>"
                if r["split"] else f"<i class='{'review' if r['open'] else 'none'}'style='flex:1'></i>")
        tip = (f"#{r['number']} — opened {r['opened_at']}"
               + (f", reviewed after {r['review_hours']}h, merged {r['merge_hours']}h later"
                  if r["split"] else
                  (", still open" if r["open"] else ", merged with no review recorded"))
               + f" — {r['total_hours']}h in total")
        # the instants the zoom re-projects: the same ones the table below lists; an open request ends now
        when = (f"data-start='{_e(r['opened_at'])}' data-end='{_e(r['end_at'] or t.get('until') or '')}'"
                + (f" data-verdict='{_e(r['verdict_at'])}'" if r["split"] and r.get("verdict_at") else ""))
        rows.append(f"<div class='grow'><span class='glabel'>#{_e(r['number'])} {_e(r['role'])}</span>"
                    f"<span class='gtrack'><span class='gspan {cls}' title='{_e(tip)}' {when} "
                    f"style='left:{r['left']}%;width:{round(r['first_pct'] + r['second_pct'], 3)}%'>{segs}</span></span></div>")
    key = "".join(f"<span><s>▶</s>{_e(k['label'])}</span>" if k["id"] == "open" else
                  f"<span><i class='{k['id']}'></i>{_e(k['label'])}</span>" for k in t["legend"])
    table = "".join(
        f"<tr><td>#{_e(r['number'])}</td><td>{_e(r['role'])}</td><td>{_e(r['opened_at'])}</td>"
        f"<td>{_e(r['verdict_at'] or '—')}</td><td>{_e(r['end_at'] or 'still open')}</td>"
        f"<td>{_e(r['total_hours'])}h</td></tr>" for r in t["rows"])
    return (f"<section class='sec tl'><div class='sechead'><span class='ct'>{t['span_hours']}h</span>"
            f"<h2>Where the time went</h2>"
            f"<p>Every pull request in this window, longest first, on one time axis. This is the only stretch "
            f"of the org's chain with real per-item history — <b>a finding reaching a role, and a merge being "
            f"verified, are not drawn</b>, because those live on a board that keeps only the latest value and "
            f"overwrites it. Drawing the stages that happen to survive would say work begins when a pull "
            f"request opens.</p></div>"
            f"<div style='padding:14px 18px 6px'><div class='gkey'>{key}</div>"
            + _gplot(t, rows) +
            f"<p class='gnote'>{t['shown']} of {t['total']} drawn"
            + ((f"; the other one lasted {t.get('rest_under_ago')}" if t["rest"] == 1 else
                f"; the other {t['rest']} lasted {t.get('rest_under_ago')} or less") if t["rest"] else "")
            + f". {t['merged']} merged in this window and <b>{t['no_verdict']} of them carry no review</b>, so "
              f"those bars are one length with no split — not a gap in the measurement, but what happened."
            + (f" {t['open_now']} are still open." if t["open_now"] else "")
            + f"</p><details class='gtable'><summary>The same spans as a table</summary>"
              f"<div class='scroll'><table><thead><tr><th>pr</th><th>opened by</th><th>opened</th>"
              f"<th>first review</th><th>merged</th><th>total</th></tr></thead><tbody>{table}</tbody></table>"
              f"</div></details></div></section>")


def _team_cell(p: dict[str, Any] | None, page: str | None = None, tz: str | None = None, oid: str = "") -> str:
    """One org's roles as dots and names, in the served fleet's team column (0.42.0): who is listening, at a glance.

    Each role is an agent (`controls.agent_link`, 0.46.2): a link to its row on the org's own page, and a card of what it
    is up to — its listening state, its session and its routine, each as old as the CEO's snapshot says
    (`controls.card_lines`) — drawn by `controls.AGENTS_JS`. Scripts off, the same words are the link's `title`."""
    from .controls import STATE_WORDS, agent_link, with_cards
    if not p:
        return "<span class='cell DARK'><b></b>not read</span>"
    if not p.get("read"):
        return "<span class='cell DARK'><b></b>the roster was not read</span>"
    out = []
    for r in with_cards(p, tz)["roles"]:
        st = str(r.get("state") or "")
        who = r.get("name") or r.get("role")
        dot = (f"<span class='pdot ps-{_e(st.replace(' ', '-'))}' role='img' "
               f"aria-label='{_e(STATE_WORDS.get(st, st))}'></span>")
        out.append(agent_link(oid, r["role"], page, dot + _e(who), "tm", f"{who} ({r.get('role')})\n" + "\n".join(r["card"])))
    return "<span class='team-cell'>" + " ".join(out) + "</span>"


def _agent_registry(d: dict[str, Any]) -> dict[str, Any]:
    """Every served org's roles as the cards read them — `{org: {page, roles: [{role, name, state, means, card}]}}` — for
    the script that draws the card beside an agent wherever the page names one (`controls.AGENTS_JS`). An org whose roster
    was not read has no entry, so none of its agents is marked: an unread roster is never drawn as a team (row 65)."""
    from .controls import with_cards
    tz, pages, out = d.get("operator_timezone"), d.get("pages") or {}, {}
    for oid, p in (d.get("team") or {}).items():
        if p and p.get("read"):
            out[oid] = {"page": pages.get(oid, ""),
                        "roles": [{k: r.get(k) for k in ("role", "name", "state", "means", "card")} for r in with_cards(p, tz)["roles"]]}
    return out


#: on the fleet page, scripts on: the agents each waiting row names in its words — `what`, `why`, `blocks` — marked as the
#: org page marks them, against that row's own org's roster and never another's
COMMAND_MARK_JS = """
(function () {
  // a function: the served page marks again after it swaps a new reading in (`COMMAND_LIVE_JS`)
  window.fleetMark = function () {
    var ag = window.orgAgents, el = document.getElementById("org-agents"); if (!ag || !el) return;
    var reg; try { reg = JSON.parse(el.textContent); } catch (e) { return; }
    ag.set(reg);
    Array.prototype.forEach.call(document.querySelectorAll("#cards .card[data-org]"), function (row) {
      var org = row.getAttribute("data-org");
      Array.prototype.forEach.call(row.querySelectorAll(".cwhat, .fv, .cblocks, .crec"), function (n) { ag.mark(n, org); });
    });
  };
  window.fleetMark();
})();
"""


#: the fleet page, served: re-read `command.json`, and when what it says has moved (`Fleet.read`'s `rev`) fetch the page and swap
#: what it draws in place — each view's contents, the scope chips, the tabs' counts and the two indexes — as the org page swaps its
#: fragments (`swapFragments`). Until 0.60.30 it called `location.reload()`, and every reload painted one frame of an empty pane at the
#: top of the page (recorded 2026-10-11, Chromium 141; item command-center-reads-fresh row 4). A view with something typed or focused
#: in it is not swapped from under the operator: the rev is kept, so the next poll offers it again. A page it cannot parse falls back to the reload.
COMMAND_LIVE_JS = """
(function () {
  var REV = "__REV__", URL = "__POLL__", MS = __POLL_MS__, busy = false;
  function held(el) {
    var a = document.activeElement;
    if (a && a !== document.body && el.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return true;
    return Array.prototype.some.call(el.querySelectorAll("textarea, input.kwhy"), function (t) { return t.value; });
  }
  function swap(doc) {
    var panes = doc.querySelectorAll(".pane[data-pane]"), waits = false; if (!panes.length) return null;
    Array.prototype.forEach.call(panes, function (np) {
      var el = document.getElementById(np.id); if (!el || el.innerHTML === np.innerHTML) return;
      if (held(el)) { waits = true; return; }
      el.innerHTML = np.innerHTML;
    });
    ["scopes", "console-index", "org-agents"].forEach(function (id) {
      var n = doc.getElementById(id), el = document.getElementById(id); if (n && el && el.innerHTML !== n.innerHTML) el.innerHTML = n.innerHTML;
    });
    Array.prototype.forEach.call(doc.querySelectorAll(".tab[data-tab] .badge"), function (nb) {
      var b = document.querySelector(".tab[data-tab='" + nb.parentNode.getAttribute("data-tab") + "'] .badge"); if (!b) return;
      b.className = nb.className; b.textContent = nb.textContent; b.hidden = nb.hidden;
    });
    if (window.orgTempoBind) window.orgTempoBind();
    if (window.fleetMark) window.fleetMark();
    if (window.orgConsole) window.orgConsole.refresh();
    return { waits: waits };
  }
  async function tick() {
    if (busy) return; busy = true;
    try {
      var r = await fetch(URL, { cache: "no-store" }); if (!r.ok) return;
      var d = await r.json(); if (!d.rev || d.rev === REV) return;
      var p = await fetch(location.pathname + location.search, { cache: "no-store" }); if (!p.ok) return;
      var doc = new DOMParser().parseFromString(await p.text(), "text/html");
      var did = swap(doc); if (!did) { location.reload(); return; }
      // a view held back keeps the old rev, so the next poll offers it the reading again
      var m = doc.querySelector("meta[name=org-fleet-rev]"); if (!did.waits) REV = (m && m.getAttribute("content")) || d.rev;
    } catch (e) {} finally { busy = false; }
  }
  setInterval(tick, MS);
})();
"""


def render_command_html(d: dict[str, Any], *, note: str | None = None, live: bool = False, poll: str = "command.json",
                        poll_ms: int = 5000, ask_tokens: dict[str, str] | None = None) -> str:
    """The fleet as one console, in the same shell as each org's page (`console.py`, SPEC row 186): a Brief, the Decide view's cards for
    everything only a person can clear, the team and its tempo knobs, the signal matrix as the Machinery view, and a link to each org's
    own page for the work and the standing rules, which the fleet reading does not carry.

    The matrix is the glance — one row per org, one cell per signal, each cell a dot AND a reading, because a colour alone is not a
    state. Each card carries what it is holding up, the token that link was made on, and the one place to go and do something about it."""
    sig = d.get("signals") or []
    # served (`org command --serve`, 0.42.0): each org opens to its own page, and a column says who is listening
    pages, team = d.get("pages") or {}, d.get("team")
    tz = d.get("operator_timezone")
    model = console.fleet_model(d)
    head = "".join(f"<th>{_e(x)}</th>" for x in sig)
    body, tbody = [], []
    for o in d.get("orgs") or []:
        gh = (f" <a class='gh' href='https://github.com/{_e(o['repo'])}' target='_blank' rel='noopener' "
              f"title='{_e(o['repo'])} on GitHub'>↗</a>") if o.get("repo") else ""
        name = (f"<a href='{_e(pages[o['id']])}'>{_e(o['id'])}</a>{gh}" if o["id"] in pages
                else (f"<a href='https://github.com/{_e(o['repo'])}' target='_blank' rel='noopener'>{_e(o['id'])}</a>"
                      if o.get("repo") else _e(o["id"])))
        if team is not None:
            tbody.append(f"<tr><td class='org'>{name}</td><td data-k='team'>"
                         f"{_team_cell(team.get(o['id']), pages.get(o['id']), tz, o['id'])}</td></tr>")
        if not o.get("cells"):
            body.append(f"<tr><td class='org'>{name}</td>"
                        f"<td class='wide' data-k='read' colspan='{len(sig)}'>not read — "
                        f"{_e(o.get('read'))}</td></tr>")
            continue
        # a cell whose detail lives in one of the org's views (`ci`, 0.74.0) opens that view on the org's own page when it is served
        cell_text = lambda c: (f"<a class='cv' href='{_e(pages[o['id']])}#v-{_e(c['view'])}'>{_e(c['read'])}</a>"   # noqa: E731
                               if c.get("view") and o["id"] in pages else _e(c["read"]))
        cells = "".join(f"<td data-k='{_e(k)}'><span class='cell {o['cells'][k]['state']}'><b></b>"
                        f"{cell_text(o['cells'][k])}</span></td>" for k in sig)
        body.append(f"<tr><td class='org'>{name}</td>{cells}</tr>")

    from .controls import AGENTS_JS, CSS as controls_css, TEMPO_CSS, TEMPO_JS, tempo_html
    tempo_section = tempo_html(d, ask_tokens)
    # where an answer to a handoff goes, per org: the served fleet page's `/o/<id>/ask` and the token that org's page printed
    ask_cfg_cmd = ("<script type='application/json' id='org-ask-cfg'>"
                   + json.dumps({oid: {"ask": pages[oid] + "ask", "token": tok} for oid, tok in (ask_tokens or {}).items() if oid in pages}
                                ).replace("<", "\\u003c") + "</script>") if (ask_tokens and pages) else ""
    live_js = ("<script>" + COMMAND_LIVE_JS.replace("__REV__", str(d.get("rev") or "")).replace("__POLL__", json.dumps(poll)[1:-1])
               .replace("__POLL_MS__", str(int(poll_ms))) + "</script>") if live else ""
    registry = _agent_registry(d)
    # served, the script is on the page whether or not a roster was read yet: a roster read after the page loaded is swapped into
    # `#org-agents` (`COMMAND_LIVE_JS`), and until 0.60.32 a page first served without one had nothing to mark it with (item
    # command-center-reads-fresh row 5). An empty registry marks nobody (row 65); the static page has no later roster, so it is left out there.
    agents_js = (AGENTS_JS + "<script type='application/json' id='org-agents'>"
                 + json.dumps(registry, ensure_ascii=False).replace("<", "\\u003c") + "</script><script>" + COMMAND_MARK_JS
                 + "</script>") if (registry or live) else ""
    scopes = ([{"label": "The fleet", "href": "", "on": True, "mark": "wait" if model["cards"] else "ok"}]
              + [{"label": o["id"], "href": pages.get(o["id"], ""), "org": True, "mark": console.STATE.get(o.get("state"), "idle")}
                 for o in d.get("orgs") or []])
    org_links = lambda view, what: "".join(   # noqa: E731
        f"<div class='row'><i class='ic ic-org'></i><div class='body'><div class='what'>"
        + (f"<a href='{_e(pages[o['id']])}#v-{view}'>{_e(o['id'])} — {what} →</a>" if o["id"] in pages else
           f"{_e(o['id'])} — not served here, so its page cannot be opened from this console")
        + "</div></div></div>" for o in d.get("orgs") or [])
    team_pane = (("<section class='sec team'><div class='sechead'><span class='ct'>"
                  f"{len(d.get('orgs') or [])}</span><h2>The team, org by org</h2><p>Who is listening in each org. Hover an agent to see "
                  "what it is up to; click it to open its row on its org's page.</p></div><div class='scroll'>"
                  "<table class='fleet'><thead><tr><th>org</th><th>team</th></tr></thead>"
                  f"<tbody>{''.join(tbody)}</tbody></table></div></section>")
                 if team is not None else
                 "<section class='sec team'><div class='sechead'><h2>The team</h2><p>Not read here: the roster is read by the served "
                 "fleet (<code>org command --serve</code>), and this copy of the console was not served.</p></div></section>")
    panes = (console.brief_pane(model) + console.decide_pane(model)
             + console.pane("team", team_pane + tempo_section)
             + console.pane("work", _fleet_pr_plots_html(d, tz) + _fleet_item_plots_html(d, tz) + "<section class='sec'><div class='sechead'><h2>The work</h2><p>Each org's arcs, items, tickets and pull "
                                    "requests are read per org, on its own page.</p></div>" + org_links("work", "its work") + "</section>")
             + console.pane("machinery", "<section class='sec machinery'><div class='sechead'><h2>The machinery, org by org</h2><p>One row per "
                            "org, one cell per signal. A cell that says <b>not checked</b> is a source this reading could not see — "
                            "absent, not fine — and an org with no row at all could not be read at all.</p></div><div class='scroll'>"
                            f"<table class='fleet'><thead><tr><th>org</th>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"
                            "</div></section>")
             + console.pane("rules", "<section class='sec dg'><div class='sechead'><h2>Standing decisions</h2><p>What each org's CEO may "
                                     "decide without asking you, and every use, is read per org.</p></div>" + org_links("rules", "its standing decisions")
                            + "</section>"))
    rev_meta = f"<meta name='org-fleet-rev' content='{_e(d.get('rev') or '')}'>\n" if live else ""
    return f"""<title>Fleet Command</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="org-core" content="{__version__}">
{rev_meta}<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">
{console.HEAD_SCRIPT}
<style>{CSS}{vocab.CSS}{controls_css}{TEMPO_CSS if tempo_section else ''}{LIVE_CSS if live else ''}
.team-cell{{display:flex;flex-wrap:wrap;gap:4px 10px;font-size:12.5px}}
.tm{{white-space:nowrap;color:inherit;text-decoration:none;border-radius:5px;padding:0 3px;margin:0 -3px}}
a.tm:hover,a.tm:focus-visible{{background:var(--surface-2);outline:1px solid var(--border)}}
td[data-k=team]{{min-width:180px}}.org .gh{{color:var(--muted);text-decoration:none;font-size:12px}}.fleet td.org a.gh::before{{display:none}}{console.CSS}</style>
{live_js}
{console.shell_html(model, scopes, "<span class='live on'>live</span>" if live else "")}
<div class="wrap">
  {f'<div class="note">{_e(note)}</div>' if note else ''}
  {panes}
  {vocab.key_html()}
</div>
{console.overlays_html(model, [o['id'] for o in d.get('orgs') or [] if o['id'] in pages] or [''])}
{agents_js}
{TEMPO_JS if tempo_section else ''}
{ask_cfg_cmd}{console.JS}{HANDOFF_JS}
"""


#: the tokens in a line the page prints that move with the clock alone, normalised away: an ISO instant or a
#: `YYYY-MM-DD HH:MM` stamp, a bare `HH:MM` (optionally `Z` or a zone), an age or a median (`4.0h`, `1.1d`, `1.0–2.0h`,
#: `3 hours`). Every other number stays: a PR (`#29`, `pr-23`), a version (`0.38.1`), a count (`1 of 2`). Until 0.38.2
#: this was every digit run, so a board change that was only a number — `Merge PR #29` to `#30`, `0.38.0` to `0.39.0`
#: — fingerprinted the same and the committed page kept naming the old one (Reed's post-merge UNSOUND on #29,
#: 2026-09-24T20:11Z). Found by rendering one reading at two clocks and diffing every tile line and item (0.38.2).
_CLOCK_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?"   # an instant
    r"|(?<![\w.:#-])\d{1,2}:\d{2}(?::\d{2})?Z?(?![\w.:])"                             # a time of day
    r"|(?<![\w.#-])\d+(?:\.\d+)?(?:[–-]\d+(?:\.\d+)?)?\s?(?:h|d|min)(?![\w.])"          # 4.0h, 1.1d, 1.0–2.0h
    r"|(?<![\w.#-])\d+(?:\.\d+)? (?:minute|hour|day|week)s?\b")                          # ago(): 3 hours, 2 days
FINGERPRINT_RE = re.compile(r"<meta name=['\"]org-reading['\"] content=['\"]([0-9a-f]{16})['\"]")


def fingerprint(st: dict[str, Any]) -> str:
    """What the page says, as 16 hex characters, with the clock taken out.

    The committed page was re-read only when the operator file changed (0.25.4), so a wake whose board moved and whose
    file did not left the page as it was: measured on org-core 2026-09-24, a state fixed at 11:47Z still showed red on
    main hours later. Re-reading on every wake would write a commit — and on NumeroTech a production deploy — every
    two hours for a page whose only change is its ages. So the page carries this, and `org operator render
    --dashboard` writes a fresh reading when it differs from the committed page's: a tile's state, a finding, a
    waiting item or an item's roadmap status changing moves it; a later clock alone does not.

    Only clock-shaped tokens are taken out (`_CLOCK_RE`); a number that is not a clock — a PR, a version, a count —
    is what the page says, and moves it.

    Since 0.41.0 the explorer's state moves it too: an item's status or holder, a ticket's status, a pull request
    opening or closing.

    Broken looks like: two readings an hour apart with nothing but ages between them fingerprinting differently, a
    tile turning CLEAR without the fingerprint moving, a waiting item's `#29` becoming `#30` without it moving, or a
    claim taken on an item without it moving."""
    import hashlib

    from .brief import brief
    b = brief(st)
    sub = {
        "tiles": [(t.get("id"), t.get("state"), [_CLOCK_RE.sub("~", str(l)) for l in t.get("lines") or []])
                  for t in st.get("tiles") or []],
        "sections": [(sec["id"], [_CLOCK_RE.sub("~", str(i.get("what"))) for i in sec["items"] + sec["more"]])
                     for sec in b["sections"]],
        "roadmap": {k: v for k, v in ((st.get("subjects") or {}).get("roadmap") or {}).items() if k in ("counts", "read")},
        # what the explorer shows as state (0.41.0): each item's status and holder, each ticket's status, and which pull
        # requests are open — a claim taken or a pull request merged is the page changing, and a count may not move
        "explore": _explore_state(st.get("subjects") or {}),
    }
    return hashlib.sha256(json.dumps(sub, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _explore_state(s: dict[str, Any]) -> dict[str, Any]:
    tk = s.get("tickets") or {}
    return {"items": sorted((str(i.get("key")), str(i.get("derived")), str(i.get("claimed_by") or ""))
                            for i in ((s.get("roadmap") or {}).get("items") or [])),
            "tickets": sorted((str(t.get("id")), str(t.get("status"))) for t in (tk.get("rows") or [])),
            "open_prs": sorted(int(p["number"]) for p in (s.get("pr_index") or [])
                               if p.get("number") and not (p.get("merged_at") or p.get("closed_at")))}


def explorer_digest(x: dict[str, Any]) -> str:
    """What the explorer draws, as 16 hex characters with the clock taken out: every title, status, holder, priority,
    link and word, but not when it was read, how old a claim is, or a prompt's "as of". The served reader adds it to its
    `rev`, so an arc's priority or an item's evidence changing repaints the page — the fingerprint alone covers only
    state (the adversarial review of #34: a priority landed and stayed unpainted for up to an hour)."""
    import hashlib

    def strip(o: Any) -> Any:
        if isinstance(o, dict):
            return {k: strip(v) for k, v in o.items() if k not in ("at", "lanes", "when", "prompt", "claim_days")}
        if isinstance(o, list):
            return [strip(v) for v in o]
        return o
    text = _CLOCK_RE.sub("~", json.dumps(strip(x), sort_keys=True, ensure_ascii=False, default=str))
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def page_fingerprint(page: str) -> str | None:
    """The fingerprint a rendered page carries; `None` for a page written before 0.38.0, which is re-read once."""
    m = FINGERPRINT_RE.search(page or "")
    return m.group(1) if m else None


def render_html(st: dict[str, Any], *, sample_note: str | None = None, live: bool = False,
                source: str = "org status", poll: str | None = None, poll_ms: int = 5000,
                ask_token: str | None = None) -> str:
    """One self-contained page from one status dict. No network, no clock: everything is `st`.

    `live=True` adds the subscription layer: the page still renders this reading at rest, and redraws
    when a newer one lands in the artifact's store. The page never writes — org-core sends nothing
    (rule 6), so whoever can reach the org writes the readings.
    """
    from . import explorer
    from .brief import brief

    c = st.get("coverage") or {}
    tiers = st.get("tiers") or {}
    states = [t["state"] for t in st["tiles"]]
    banner = "RED" if "RED" in states else ("DARK" if "DARK" in states else "CLEAR")
    b = brief(st)
    # every arc, item, ticket and pull request, linked both ways, each one copyable as a prompt (0.41.0)
    # an in-app ticket's words only on the served page, which never leaves the machine that read them (Reed on #34)
    xm = explorer.model(st, private_text=bool(poll))
    explore_html = explorer.render(xm) + explorer.JS
    # the team's listening marks and the operator's controls (0.42.0); `ask_token` only on the served page
    from . import arcs, ci, controls
    arcs_html = arcs.html_section(arcs.model(st))
    model = console.org_model(st, b, xm)
    tm = console.team_model(st.get("subjects") or {}, model["cards"], st.get("operator_timezone"))
    team_html = (controls.team_html(st, ask_token=ask_token, groups=console.team_groups_html(tm, st.get("operator_timezone")))
                 + controls.AGENTS_JS + controls.JS)
    delegations_html = _delegations_html((st.get("subjects") or {}).get("delegations"), st.get("operator_timezone"),
                                         (st.get("subjects") or {}).get("operator_handoffs"))

    tiles = []
    for t in st["tiles"]:
        body = _edge_rows(st.get("report") or {}, tiers, st.get("could_not_read") or []) if t["id"] == "chain" and (st.get("report") or {}).get("edges") else ""
        lines = "".join(
            f"<div class='{'hot' if l.startswith(FINDING) else ''}'>{_e(l)}</div>"
            for l in t["lines"]) if (t["id"] != "chain" or not body) else "".join(
            f"<div class='hot'>{_e(l)}</div>" for l in t["lines"] if l.startswith(FINDING))
        tiles.append(
            f"<section class='tile {t['state']}{' span' if t['id'] == 'chain' else ''}'>"
            f"<div class='thead'><span class='chip {t['state']}'>{STATE_MARK[t['state']]} {t['state']}</span>"
            f"<span class='tname'>{_e(t['title'])}</span>"
            f"<span class='tier'>{_e(t['tier'])} — {_e(tiers.get(t['tier'], 'several sources'))}</span></div>"
            f"{body}<div class='lines'>{lines}</div>"
            + (f"<div class='broken'><b>broken looks like:</b> {_e(t['broken_looks_like'])}</div>" if t["state"] != "RED" else "")
            + "</section>")

    note = f"<div class='note'>{_e(sample_note)}</div>" if sample_note else ""
    dark = f" · dark: {', '.join(c.get('dark') or [])}" if c.get("dark") else ""
    age = f" · facts {_e(c.get('facts_gathered_at'))} ({_e(c.get('facts_age_hours'))}h old)" if c.get("facts_gathered_at") else ""
    unread = "".join(f"<p><code>could not read: {_e(x)}</code></p>" for x in (st.get("could_not_read") or []))
    seed = json.dumps(reading_doc(st, source=source, evidence_chars=None if poll else STORE_EVIDENCE_CHARS,
                                  fragments=bool(poll), private_text=bool(poll)), ensure_ascii=False).replace("<", "\\u003c")
    live_head = (f"<span class='live off' id='live'>not live</span>" if live else "")
    if poll:                                  # served: the page asks the reader that took this reading
        js = (LIVE_JS.replace("__FINDING__", json.dumps(list(FINDING))).replace("__TRUST_HTML__", "true")
              .replace("__SOURCE__", SOURCE_POLL.replace("__POLL__", poll).replace("__POLL_MS__", str(int(poll_ms)))))
        live = True
    else:                                     # published: the page watches the artifact's own store
        js = (LIVE_JS.replace("__FINDING__", json.dumps(list(FINDING))).replace("__TRUST_HTML__", "false")
              .replace("__SOURCE__", SOURCE_STORE))
    live_history = "<div id='history'></div>" if (live and not poll) else ""
    # the script goes LAST: it paints #tiles, #cover and #unread, which are further down the document
    live_script = (f"<script type='application/json' id='reading'>{seed}</script>{js}" if live else "")
    scopes = [{"label": st.get("org") or "", "href": "", "on": True, "org": True, "mark": console.STATE.get(model["state"], "idle")}]
    # one view each (`console.py`): Brief and Decide are the shell's own; the rest carry the sections this page has always had
    panes = (console.brief_pane(model) + console.decide_pane(model)
             + console.pane("team", f"<div id='secs'>{_sections_html(b, TEAM_SECTIONS)}</div>{team_html}")
             + console.pane("work", f"{_work_html(b)}{_pr_plots_html(st)}{_item_plots_html(st)}{arcs_html}{explore_html}")
             + console.pane("machinery", f"<div id='secs-machinery'>{_sections_html(b, MACHINERY_SECTIONS)}</div>"
             f"<div id='ci'>{_ci_html(st)}</div>"
             f"""<details class="instrument">
    <summary>The reading this came from — every finding in the tool's own words, with the source it was measured from</summary>
    <p class="sub2">Each tile names the <b>tier</b> it was read from, which is how much that tile's numbers are
       worth: <code>github</code> and <code>git</code> keep history, so their medians are real; the board keeps
       one record per key and overwrites it, so a board-ended number is only what is waiting <i>now</i>. A tile
       nobody could measure is <b>DARK</b> — absent, not failing, and shown with a dashed edge and a muted mark
       rather than a warning colour, so "not measured" reads as neither "fine" nor "broken".</p>
    <div class="banner {banner}" id="banner">
      <div><div class="eyebrow">headline</div><p id="headline">{_e(st.get('headline'))}</p></div>
    </div>
    <div class="grid" id="tiles">{''.join(tiles)}</div>
    <div class="foot">
      <p id="cover"><b>read {_e(c.get('measured'))} of {_e(c.get('tiles'))} tiles</b>{_e(dark)}{(' · ' + _e(source)) if live else ''}</p>
      <p>sessions tier: {_e(c.get('sessions_tier'))}</p>
      <span id="unread">{unread}</span>
    </div>
  </details>""")
             + console.pane("rules", delegations_html))
    return f"""<title>Org Status</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="org-core" content="{__version__}">
<meta name="org-reading" content="{fingerprint(st)}">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">
{console.HEAD_SCRIPT}
<style>{CSS}{vocab.CSS}{explorer.CSS}{controls.CSS}{arcs.CSS}{ci.CSS}{LIVE_CSS if live else ""}{console.CSS}</style>
{console.shell_html(model, scopes, live_head)}
<div class="wrap">
  {note}
  {FOCUSBAR}
  {panes}
  {live_history}
  {vocab.key_html()}
  {live_script}
</div>
{console.overlays_html(model, [st.get('org') or ''])}{console.JS}
{HANDOFF_JS}
"""
