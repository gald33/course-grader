"""Standing delegations: a decision the operator has made once, written down, so it stops coming back (SPEC row 180).

The operator, 2026-10-03: *"I feel I don't have a clear picture of what each task needs of me, and no easy tools
to push decisions down the ladder."* The same decision had come to them by hand, in chat, three times that week —
*may the org-core CEO merge Lucille's upgrade PR?* — and each time the answer was the same: yes, when its checks are
green and the release it installs was ruled SOUND.

A **delegation** is one of those answers, kept: *who* may do *which* act, in *which* orgs, once *which* conditions are
checked — granted by the operator on a date, with the words they said. It lives in `org.yaml` (`delegations:`), so it is
a reviewed, merged diff like every other change to what a role may do (`role_text_change`, SPEC §12), and the operator
withdraws it by deleting the entry.

What this module does, and does not:

  - It **validates** the grant. Only four acts can be delegated — `merge_to_main`, `role_text_change`,
    `session_archive`, `knob_outside_range`. The rest are refused at read, because §12 already says why a standing grant
    would be the thing the row forbids: `user_visible_send` is "in-session approval, every time", `credential_mint` is
    "one approval, one command", `irreversible_outward` is "ask every time, even an hour after a similar ask",
    `strategy`, `product_decision` and `prod_schema` are the operator's by what they are. A grant must name at least one
    condition, from a closed list, because a use that checks nothing is not a delegation but a hole.
  - It **records** every use (`.org/delegations.jsonl`, UTC, in git): who, the target, which conditions the exerciser
    says it checked, and where it saw them. `use` is refused unless the role is the one the grant names, the target is in
    scope, the grant has not expired, and every condition is named as checked with evidence cited.
  - It does **not** merge, spawn or send (CLAUDE.md rule 6), and it does **not** verify a condition is true — it cannot
    read GitHub from here. What it makes impossible is using a delegation *silently or sloppily*; what it makes possible
    is the operator reading, on the page, every time one was used and what the exerciser said it saw. A use whose
    evidence turns out false is a finding against the exerciser and the first thing the operator can withdraw.

Broken looks like: a delegation that grants an act §12 forbids a standing grant for; one with no condition; a `use` that
succeeds for a different role, a target outside the grant's orgs, an expired grant, or with a condition not checked; a
page that says "nothing is delegated" while `org.yaml` holds an entry, or one that lists a grant with no uses as used.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

#: the acts a standing grant may cover, and what each means when delegated (SPEC §12)
DELEGABLE = {
    "merge_to_main": "merge a pull request to the default branch",
    "role_text_change": "merge a change to a role's text (`.claude/agents/*.md`, `.claude/skills/*/SKILL.md`, `.claude/hooks/*`, `org.yaml`)",
    "session_archive": "archive a session",
    "knob_outside_range": "set a role's wake-interval multiplier outside its declared range",
}

#: the acts §12 forbids a standing grant for, with the row's own reason
REFUSED = {
    "user_visible_send": "§12: dated production evidence and in-session approval, every time",
    "credential_mint": "§12: one approval, one command, never kept",
    "irreversible_outward": "§12: ask every time, even an hour after a similar ask",
    "strategy": "§12: roles may say the queue is empty of it, never fill it",
    "product_decision": "§12: a fix that changes the user's experience rather than correcting it is the operator's",
    "prod_schema": "§12: a migration is the operator's",
    "spend_over_budget": "§12: the budget is the operator's line",
}

#: what an exerciser must have checked before a use, in the words the page prints
CONDITIONS = {
    "checks_green": "every required check on the pull request's head commit passed",
    "release_sound": "the org-core release the pull request installs is merged to org-core's main, and its reviewer's last verdict on its head was SOUND",
    "reviewer_sound": "the reviewer's last verdict on the pull request's head commit is SOUND",
    "no_conflict": "the pull request merges cleanly into its base",
}

LOG = Path(".org") / "delegations.jsonl"


class Refused(Exception):
    """A use that the grant does not allow; the message is every reason, one per line."""


def problems(manifest: dict[str, Any]) -> list[str]:
    """Every fault in the manifest's `delegations`, one line each; empty means sound. Read at `validate`, so a
    manifest with a bad grant fails closed like one with an unfilled draft."""
    out: list[str] = []
    seen: set[str] = set()
    roles = manifest.get("roles") or {}
    for i, d in enumerate(manifest.get("delegations") or []):
        where = f"delegations/{i}"
        did = d.get("id") or "?"
        if did in seen:
            out.append(f"{where}: id {did!r} is used twice — a use record would name two grants")
        seen.add(did)
        act = d.get("act")
        if act in REFUSED:
            out.append(f"{where} ({did}): `{act}` cannot be delegated — {REFUSED[act]}")
        elif act not in DELEGABLE:
            out.append(f"{where} ({did}): `{act}` is not a delegable act (one of {', '.join(sorted(DELEGABLE))})")
        to = d.get("to")
        if to not in roles or not (roles.get(to) or {}).get("enabled", True):
            out.append(f"{where} ({did}): `to: {to}` is not an enabled role of this org — a grant to nobody is read by nobody")
        when = d.get("when") or []
        if not when:
            out.append(f"{where} ({did}): no `when` — a use that checks nothing is a hole, not a delegation")
        for c in when:
            if c not in CONDITIONS:
                out.append(f"{where} ({did}): condition {c!r} is not one of {', '.join(sorted(CONDITIONS))}")
        on, exp = d.get("granted_on"), d.get("expires_on")
        if exp and on and str(exp) <= str(on):
            out.append(f"{where} ({did}): expires {exp} is not after it was granted, {on}")
    return out


def active(d: dict[str, Any], now: dt.datetime) -> bool:
    exp = d.get("expires_on")
    return not exp or str(exp) > now.date().isoformat()


def _uses(repo: Path) -> list[dict[str, Any]]:
    path = repo / LOG
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                rows.append(json.loads(line))
            except ValueError:
                rows.append({"at": None, "id": None, "bad_line": line[:80]})
    return rows


def read(repo: Path, manifest: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """The page's and the facts' copy: every grant with its uses, and the log's own faults. A reading always says
    whether the log was read, so 'no uses' is never a log nobody opened."""
    now = now or dt.datetime.now(dt.timezone.utc)
    rows = _uses(repo)
    grants = []
    for d in manifest.get("delegations") or []:
        mine = [u for u in rows if u.get("id") == d.get("id")]
        grants.append({
            "id": d.get("id"), "act": d.get("act"), "act_means": DELEGABLE.get(d.get("act"), d.get("act")),
            "to": d.get("to"), "orgs": list(d.get("orgs") or []), "what": d.get("what"),
            "when": [{"id": c, "means": CONDITIONS.get(c, c)} for c in d.get("when") or []],
            "by": d.get("granted_by") or "operator", "on": str(d.get("granted_on")), "source": d.get("source"),
            "expires": str(d["expires_on"]) if d.get("expires_on") else None, "active": active(d, now),
            "uses": len(mine), "last_uses": mine[-5:][::-1],
        })
    return {"read": True, "log": str(LOG), "grants": grants, "bad_lines": sum(1 for u in rows if u.get("bad_line")),
            "orphans": [u.get("id") for u in rows if u.get("id") and u.get("id") not in {d.get("id") for d in manifest.get("delegations") or []}]}


def _target_org(target: str) -> str:
    return target.split("#", 1)[0].split("/", 1)[0].strip().lower()


def check(manifest: dict[str, Any], did: str, *, role: str, target: str, checked: list[str], evidence: str,
          now: dt.datetime | None = None) -> dict[str, Any]:
    """The grant and the use, or `Refused` with every reason. Pure: it writes nothing."""
    now = now or dt.datetime.now(dt.timezone.utc)
    d = next((x for x in manifest.get("delegations") or [] if x.get("id") == did), None)
    if d is None:
        raise Refused(f"no delegation {did!r} in org.yaml — nothing is delegated under that name, so the act is the operator's")
    why = []
    if role != d.get("to"):
        why.append(f"it is delegated to `{d.get('to')}`, not `{role}`")
    if not active(d, now):
        why.append(f"it expired {d.get('expires_on')}")
    org = _target_org(target)
    if org not in [str(o).lower() for o in d.get("orgs") or []]:
        why.append(f"{target!r} is in {org or '?'!r}, and the grant covers {', '.join(d.get('orgs') or []) or 'no org'}")
    if "#" not in target:
        why.append(f"{target!r} names no pull request or item (write it as `<org>#<number>`)")
    missing = [c for c in d.get("when") or [] if c not in (checked or [])]
    if missing:
        why.append("not checked: " + ", ".join(f"{c} ({CONDITIONS.get(c, c)})" for c in missing))
    if not (evidence or "").strip():
        why.append("no evidence cited — say where you saw the conditions hold (a run URL, a verdict comment)")
    if why:
        raise Refused("; ".join(why) + " — so the act is the operator's: ask")
    return d


def use(repo: Path, manifest: dict[str, Any], did: str, *, role: str, target: str, checked: list[str], evidence: str,
        now: dt.datetime | None = None) -> dict[str, Any]:
    """Record one use, after `check`. The record is appended to `.org/delegations.jsonl` and committed with the work."""
    now = now or dt.datetime.now(dt.timezone.utc)
    d = check(manifest, did, role=role, target=target, checked=checked, evidence=evidence, now=now)
    rec = {"at": now.isoformat(timespec="seconds"), "id": did, "act": d["act"], "role": role, "target": target,
           "checked": sorted(set(checked)), "evidence": evidence.strip()}
    path = repo / LOG
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def for_role(manifest: dict[str, Any], role_id: str) -> list[dict[str, Any]]:
    """The grants a role's contract must carry: only the role's own, so a role with none renders exactly as before."""
    out = []
    for d in manifest.get("delegations") or []:
        if d.get("to") == role_id:
            out.append({**d, "what": str(d.get("what") or "").strip().rstrip("."), "act_means": DELEGABLE.get(d.get("act"), d.get("act")),
                        "orgs_text": ", ".join(d.get("orgs") or []), "granted_on": str(d.get("granted_on")),
                        "when_text": "; ".join(f"`{c}` — {CONDITIONS.get(c, c)}" for c in d.get("when") or [])})
    return out
