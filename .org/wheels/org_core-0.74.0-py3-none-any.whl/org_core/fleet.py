"""`org fleet` — every installed org's default branch read against the package (SPEC §11; row 108).

NumeroTech sat at 0.15.1 with the suite never applied while the package was at 0.16.0, and only a direct
question found it (roadmap item guard-installs-drifting-behind-the-package); on 2026-09-20 both orgs sat
behind again — 0.17.4 and 0.19.0 against 0.21.3 — until the installer happened to look. An installed org
cannot see org-core's releases from inside itself (`gh api repos/gald33/org-core` is 403 from its
sessions), so the reading is the fleet's: it runs where the package is, reads each org's default branch
over the GitHub API, and says who is behind, since when, and whether an upgrade PR is already open.
"""

from __future__ import annotations

import base64
import datetime as dt
import json
import re
import subprocess
from pathlib import Path
from typing import Any, Callable

import yaml

from . import __version__
from .tempo import hours

Runner = Callable[[list[str]], str]
VERSION_RE = re.compile(r'__version__\s*=\s*"(\d+)\.(\d+)\.(\d+)"')
UPGRADE_TITLE_PREFIX = "org-core "
CURRENT, AHEAD, BEHIND, BEHIND_PR_OPEN, UNREAD = "CURRENT", "AHEAD", "BEHIND", "BEHIND, PR OPEN", "UNREAD"
MAIN_REF = "origin/main"
WHEEL_RE = re.compile(r"org_core-(?P<v>[^-/]+)-py3-none-any\.whl$")
#: the wheel an org runs, against what org-core's main shipped. The first four are failures (exit 1).
UNRELEASED, NOT_FROM_MAIN, WHEEL_MISMATCH, NO_WHEEL, FROM_MAIN, UNVERIFIED = (
    "UNRELEASED", "NOT FROM MAIN", "WHEEL/LOCK MISMATCH", "NO WHEEL", "FROM MAIN", "UNVERIFIED")
BAD_PROVENANCE = (UNRELEASED, NOT_FROM_MAIN, WHEEL_MISMATCH, NO_WHEEL)


def _run(cmd: list[str]) -> str:
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd[:3])}: {(out.stderr or out.stdout).strip()[:300]}")
    return out.stdout


def parse_version(s: Any) -> tuple[int, int, int] | None:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", str(s or ""))
    return (int(m[1]), int(m[2]), int(m[3])) if m else None


def load_registry(path: Path) -> list[dict[str, Any]]:
    """`fleet/orgs.yaml`: `orgs: [{id, repo, default_branch?, checkout?}, …]` — every org the fleet knows about."""
    data = yaml.safe_load(path.read_text()) or {}
    orgs = data.get("orgs") or []
    for o in orgs:
        if not o.get("id") or not o.get("repo"):
            raise ValueError(f"{path}: every org needs `id` and `repo`: {o}")
    return orgs


def version_history(repo_root: Path, run: Runner = _run) -> tuple[list[tuple[str, tuple[int, int, int]]], str | None]:
    """(committed_at, version) for every commit on the default branch's first-parent chain that set `__version__`,
    oldest first, from one `git log -p` (a merge shows its diff against the first parent, so a release that arrived
    by merge is dated by the merge) — and a note when the checkout cannot say: a shallow clone (this session's
    org-core checkout reached two commits on 2026-09-20) dates nothing, and says so rather than dating wrongly."""
    if run(["git", "-C", str(repo_root), "rev-parse", "--is-shallow-repository"]).strip() == "true":
        return [], f"shallow clone at {repo_root}: when the package moved past an org is unknown — `git fetch --unshallow origin` to date it"
    ref, note = main_ref(repo_root, run)
    text = run(["git", "-C", str(repo_root), "log", "--first-parent", "--diff-merges=first-parent", "--reverse",
                "--format=commit %H %cI", "-p", ref, "--", "org_core/__init__.py"])
    out: list[tuple[str, tuple[int, int, int]]] = []
    when: str | None = None
    for line in text.splitlines():
        if line.startswith("commit "):
            parts = line.split()
            when = parts[2] if len(parts) > 2 else None
        elif line.startswith("+") and not line.startswith("+++"):
            m = VERSION_RE.search(line)
            if m and when:
                out.append((when, (int(m[1]), int(m[2]), int(m[3]))))
    return out, note


def main_ref(repo_root: Path, run: Runner = _run) -> tuple[str, str | None]:
    """`origin/main` when this checkout has it, else HEAD with a note saying so.

    Until 0.35.2 the history was read from HEAD, so on a release branch the branch's own unmerged versions
    counted as released — the reason the fleet's wheel check waited (roadmap item
    fleet-wheels-against-main-releases). Broken looks like: HEAD returned while `origin/main` resolves."""
    try:
        run(["git", "-C", str(repo_root), "rev-parse", "--verify", "--quiet", f"{MAIN_REF}^{{commit}}"])
        return MAIN_REF, None
    except (RuntimeError, OSError):
        return "HEAD", f"no {MAIN_REF} at {repo_root}: releases read from HEAD, which may carry versions main never did"


def refresh_main(repo_root: Path, run: Runner = _run) -> str | None:
    """Fetch GitHub's `main` into this checkout's `origin/main` before the fleet reads it; a note when it could not.

    Releases and wheels are read from the local `origin/main` (`main_ref`), and until 0.35.3 nothing moved it:
    a checkout whose ref sat behind GitHub read a just-released org as UNRELEASED and exited 1 — wrong in the
    alarming direction (Reed on #16, 2026-09-24T07:35:44Z; roadmap item fleet-main-ref-freshness). When this
    returns a note, `report` reads the ref as possibly stale and no version above its newest release fails.

    Broken looks like: None returned when the fetch failed, or a fetch that leaves `origin/main` where it was."""
    try:
        run(["git", "-C", str(repo_root), "fetch", "--quiet", "origin", f"+refs/heads/main:refs/remotes/{MAIN_REF}"])
        return None
    except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
        # the whole error: `_run` already caps git's stderr at 300 characters, and a 120 cut spent most of itself on
        # the command and the checkout path before git said why (Reed on #22)
        return f"could not fetch origin main ({e}): {MAIN_REF} read as it was, possibly stale"


def main_wheels(repo_root: Path, run: Runner = _run) -> tuple[dict[str, str], str | None]:
    """{git blob sha: version} for every org-core wheel `origin/main`'s first-parent chain ever carried under
    `.org/wheels/` — the bytes org-core shipped (SPEC row 130). An org's wheel is FROM MAIN when its blob sha
    (the GitHub contents API's `sha`) is one of these. Main has carried its own wheel since 0.29.1
    (2026-09-22); an older release has no entry, and reads UNVERIFIED rather than as a failure.

    Broken looks like: a blob main carried missing from the map (a merge's wheel read against its second
    parent, or a rename's new side dropped), or a blob that only a side branch carried present in it."""
    if run(["git", "-C", str(repo_root), "rev-parse", "--is-shallow-repository"]).strip() == "true":
        return {}, f"shallow clone at {repo_root}: which wheels main carried is unknown — `git fetch --unshallow origin`"
    ref, note = main_ref(repo_root, run)
    text = run(["git", "-C", str(repo_root), "log", "--first-parent", "--diff-merges=first-parent", "--raw", "--no-abbrev",
                "--format=", ref, "--", ".org/wheels/"])
    out: dict[str, str] = {}
    for line in text.splitlines():
        if not line.startswith(":"):
            continue
        meta, _, paths = line.partition("\t")
        fields = meta.split()
        new_sha = fields[3] if len(fields) > 3 else ""
        m = WHEEL_RE.search(paths.split("\t")[-1])
        if m and new_sha.strip("0"):
            out[new_sha] = m["v"]
    return out, note


def superseded_at(history: list[tuple[str, tuple[int, int, int]]], installed: tuple[int, int, int]) -> str | None:
    """When the package first moved past `installed`: the commit date of the first version above it."""
    for when, v in history:
        if v > installed:
            return when
    return None


def read_org(org: dict[str, Any], run: Runner = _run) -> dict[str, Any]:
    slug, branch = org["repo"], org.get("default_branch") or "main"
    rec: dict[str, Any] = {"id": org["id"], "repo": slug, "branch": branch, "installed": None, "lock_generated_at": None,
                           "lock_changed_at": None, "lock_commit": None, "upgrade_pr": None, "wheels": None, "could_not_read": []}
    try:
        content = json.loads(run(["gh", "api", f"repos/{slug}/contents/.org/lock.yaml?ref={branch}"]))["content"]
        lock = yaml.safe_load(base64.b64decode(content)) or {}
        rec["installed"] = str(lock.get("org_core")) if lock.get("org_core") else None
        rec["lock_generated_at"] = lock.get("generated_at")
        if rec["installed"] is None:
            rec["could_not_read"].append("lock: no `org_core` in .org/lock.yaml")
    except Exception as e:   # a 404 is "no install on that branch", and says so
        rec["could_not_read"].append(f"lock: {str(e)[:160]}")
    try:
        commits = json.loads(run(["gh", "api", f"repos/{slug}/commits?path=.org/lock.yaml&sha={branch}&per_page=1"]))
        if commits:
            rec["lock_changed_at"] = commits[0]["commit"]["committer"]["date"]
            rec["lock_commit"] = str(commits[0]["sha"])[:7]
    except Exception as e:
        rec["could_not_read"].append(f"lock history: {str(e)[:160]}")
    try:   # the wheel the org's hook installs: name and git blob sha, no download
        listing = json.loads(run(["gh", "api", f"repos/{slug}/contents/.org/wheels?ref={branch}"]))
        rec["wheels"] = [{"name": f["name"], "sha": f["sha"]} for f in listing if WHEEL_RE.search(str(f.get("name", "")))]
    except Exception as e:
        if "404" in str(e):
            rec["wheels"] = []       # no .org/wheels/ on that branch: nothing vendored, which is a reading
        else:
            rec["could_not_read"].append(f"wheels: {str(e)[:160]}")
    try:
        prs = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=open&per_page=50"]))
        ups = [p for p in prs if str(p.get("title", "")).startswith(UPGRADE_TITLE_PREFIX)]
        if ups:
            p = ups[0]
            rec["upgrade_pr"] = {"number": p["number"], "title": p["title"], "opened_at": p.get("created_at"), "head": str((p.get("head") or {}).get("sha", ""))[:7]}
    except Exception as e:
        rec["could_not_read"].append(f"open PRs: {str(e)[:160]}")
    return rec


def provenance(rec: dict[str, Any], released: set[tuple[int, int, int]] | None, shipped: dict[str, str] | None,
               stale: bool = False) -> tuple[str | None, str]:
    """Where the wheel an org runs came from, against org-core's main (SPEC rows 130, 140).

    UNRELEASED: no commit on main's first-parent chain ever declared the installed version — the 0.25.2 shape
    of 2026-09-22, two orgs running a wheel built from a working tree. NO WHEEL / WHEEL/LOCK MISMATCH: the
    lock names a version and `.org/wheels/` does not carry exactly that one wheel. NOT FROM MAIN: main
    carried a wheel of that version, and the org's bytes are none of them. FROM MAIN: the org's blob is one
    main carried. UNVERIFIED: the version was released but main never carried its wheel (before 0.29.1), or
    this checkout cannot say — a reading, not a pass and not a failure.

    `stale`: `origin/main` could not be refreshed (`refresh_main`), so a version above the newest one it declared
    may be a release this checkout has not fetched — UNVERIFIED, not UNRELEASED (SPEC row 141).

    Broken looks like: FROM MAIN for a blob main never carried, anything but UNRELEASED for a version main
    never declared on a fresh ref, or UNRELEASED for a version above a stale ref's newest release."""
    inst = parse_version(rec.get("installed"))
    if inst is None:
        return None, ""
    v = rec["installed"]
    wheels = rec.get("wheels")
    # the org's own wheel directory against its own lock needs nothing from main, so a stale ref never masks it: until
    # 0.38.0 the stale branch returned UNVERIFIED first and hid NO WHEEL and WHEEL/LOCK MISMATCH (Reed on #22)
    named = [w for w in (wheels or []) if (WHEEL_RE.search(w["name"]) or {"v": None})["v"] == v]
    wheel_fault = (None if wheels is None else
                   (NO_WHEEL, f"the lock says {v} and .org/wheels/ carries no wheel") if not wheels else
                   (WHEEL_MISMATCH, f"the lock says {v}, .org/wheels/ carries {', '.join(w['name'] for w in wheels)}")
                   if len(wheels) != 1 or not named else None)
    if released is not None and released and inst not in released:
        if stale and inst > max(released):
            return wheel_fault or (UNVERIFIED, f"{v} is above every version the local {MAIN_REF} declared, and it could not be refreshed")
        return UNRELEASED, f"no commit on org-core's main ever declared {v}"
    if wheels is None:
        return UNVERIFIED, "the org's .org/wheels/ could not be read"
    if wheel_fault:
        return wheel_fault
    sha = named[0]["sha"]
    if shipped is None:
        return UNVERIFIED, "which wheels main carried is unknown here"
    if sha in shipped:
        return FROM_MAIN, f"{named[0]['name']} is a wheel main carried ({sha[:8]})"
    if v in shipped.values():
        return NOT_FROM_MAIN, (f"main carried {v} as {', '.join(k[:8] for k, x in shipped.items() if x == v)}; the org's is {sha[:8]} — "
                               "built from a tree main did not carry")
    return UNVERIFIED, f"{v} is released, but main never carried its wheel, so the bytes cannot be checked"


def report(registry: list[dict[str, Any]], *, package_version: str = __version__, history: list[tuple[str, tuple[int, int, int]]] | None = None,
           history_note: str | None = None, now: dt.datetime | None = None, run: Runner = _run,
           shipped: dict[str, str] | None = None, shipped_note: str | None = None, fetch_note: str | None = None) -> dict[str, Any]:
    now = now or dt.datetime.now(dt.timezone.utc)
    pkg = parse_version(package_version)
    rows = []
    for org in registry:
        r = read_org(org, run)
        inst = parse_version(r["installed"])
        r["package"] = package_version
        if inst is None:
            r["state"] = UNREAD
        elif inst == pkg:
            r["state"] = CURRENT
        elif inst > pkg:
            r["state"] = AHEAD    # the org carries a newer wheel than this checkout: this reading is from a stale org-core
        else:
            r["state"] = BEHIND_PR_OPEN if r["upgrade_pr"] else BEHIND
        r["superseded_at"] = superseded_at(history or [], inst) if inst and inst < (pkg or inst) else None
        r["hours_behind"] = hours(r["superseded_at"], now.isoformat()) if r["superseded_at"] else None
        r["provenance"], r["provenance_why"] = provenance(r, {x for _, x in history} if history else None, shipped,
                                                           stale=fetch_note is not None)
        rows.append(r)
    unread = sum(1 for r in rows if r["state"] == UNREAD)
    behind = sum(1 for r in rows if r["state"] == BEHIND)
    bad = sum(1 for r in rows if r["provenance"] in BAD_PROVENANCE)
    return {"package": package_version, "at": now.isoformat(timespec="seconds"), "orgs": rows, "history_note": history_note, "fetch_note": fetch_note,
            "shipped_note": shipped_note, "current": sum(1 for r in rows if r["state"] == CURRENT), "behind_no_pr": behind,
            "unread": unread, "bad_wheels": bad, "exit": 2 if unread else (1 if behind or bad else 0)}


def render(rep: dict[str, Any]) -> str:
    L = [f"fleet — org-core {rep['package']} at {rep['at']}", ""]
    for r in rep["orgs"]:
        line = f"  {r['id']:<12} {r['repo']:<28} {r['branch']:<6} {str(r['installed'] or '?'):<8} {r['state']}"
        if r.get("upgrade_pr"):
            line += f" #{r['upgrade_pr']['number']} (opened {r['upgrade_pr']['opened_at']}, head {r['upgrade_pr']['head']})"
        if r.get("superseded_at"):
            line += f" — the package moved past it at {r['superseded_at']}, {r['hours_behind']}h ago"
        if r.get("lock_changed_at"):
            line += f"; lock last changed {r['lock_changed_at']} ({r['lock_commit']})"
        L.append(line)
        if r.get("provenance"):
            L.append(f"               wheel: {r['provenance']} — {r['provenance_why']}")
        for c in r["could_not_read"]:
            L.append(f"               could not read — {c}")
    if rep.get("fetch_note"):
        L.append(f"  (main: {rep['fetch_note']})")
    if rep.get("history_note"):
        L.append(f"  (dates: {rep['history_note']})")
    if rep.get("shipped_note"):
        L.append(f"  (wheels: {rep['shipped_note']})")
    L.append("")
    bad = rep.get("bad_wheels", 0)
    why = ("  (exit 2: an org could not be read)" if rep["unread"] else
           "  (exit 1: " + "; ".join(x for x in (
               "an org is behind and nobody has opened its upgrade" if rep["behind_no_pr"] else "",
               "an org runs a wheel org-core's main did not ship" if bad else "") if x) + ")" if rep["behind_no_pr"] or bad else "")
    L.append(f"{rep['current']} of {len(rep['orgs'])} current; {rep['behind_no_pr']} behind with no upgrade PR; "
             f"{bad} running a wheel main did not ship; {rep['unread']} unread" + why)
    return "\n".join(L)
