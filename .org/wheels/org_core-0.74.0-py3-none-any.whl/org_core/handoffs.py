"""Handoffs: what a role hands the operator, with what it needs of them (SPEC row 181).

The operator, 2026-10-03: *"I feel I don't have a clear picture of what each task needs of me."* Measured the same day
in one session: five things were open at once — an install PR waiting for a merge word, a command to run on the VM, a note
to send another org's CEO, a token to revoke, a restart the machine asked for — and the only list of them was the
assistant's last chat message. `Waiting on you` lists what the roles wrote into the operator file and the board's queue;
those are headings, and a heading does not say who can decide it, what is recommended, what waiting costs, or what to do.

A **handoff** is one such thing, written once by the role that holds it: a board row `coord/operator-handoffs/<id>` (one key each,
so none overwrites another or the actuator's own `coord/tempo/operator-queue` row), read by `org status` and `org command`
into the queue they already render. It carries:

  - `decides` — who can decide it: `operator`, `org_ceo` (the named org's CEO), or `org_core_ceo` (this org's CEO session,
    when a delegation covers it — `delegation` then names the grant, and the page says it is *not asked*);
  - `what`, `why`; `recommend` — what the writer would do; `cost` — what waiting costs, said plainly or `nothing known`;
  - `do` — the exact command or text, so answering is a paste, never a rewrite.

What this module does, and does not: it validates and records a handoff and marks it answered. It does not send it to
anyone (rule 6) — the page shows it, and the role that wrote it says so in its own message. A handoff is **not** a
ruling: `org asks` still carries what the operator decides from the page. And it does not decide `decides` — the writer
states it, and the page prints it as the writer's claim; an `org_core_ceo` handoff must cite a delegation that exists.

The board keeps a record seven days at most (row 7), so a handoff the operator has not answered in a week drops off the
board: the writer re-records it, which is a prompt to say whether it is still true. Since 0.60.39 (item
`command-center-decide-and-the-operator-queue` row 1, NumeroTech's CEO on 2026-10-07) a card with under a day left says how
long it has (`left_hours`, on both pages and in `org handoffs`), and one that left the board unanswered is still listed by
`org handoffs --all`, with its last text, from the committed facts files (`expired`) — a waiting card never vanishes for age
alone. Measured 2026-10-12 on org-core's board: two open cards, written 2026-10-04, had left it on 2026-10-11 08:53Z with no
answer, and the committed `facts-2026-10-10.json` was the one place their text was left. Since 0.60.41 (rows 4-8) every gather
carries those cards forward as `handoffs_left`, so they outlive the oldest facts file and stay on Decide until closed
(`org handoffs done <id>` closes one from its last text) or recorded again; `org handoffs` prints the cards with under a day
left first, for the CEO's floor wake to re-record or close — nobody renews a card by reading it. Since 0.66.2 a close outlives its
own board key the same way: each gather carries the cards whose last write is a close as `handoffs_closed` (`closed_rows`), and
`org handoffs done` on a card closed before whose key has expired writes that close back (item
`a-card-whose-board-key-expired-can-still-be-closed`, Atlas 2026-10-24: 11 Lucille cards closed 2026-10-17 were back on Decide).

Broken looks like: a handoff with no `decides`, or `org_core_ceo` citing a grant that does not exist; one the page shows
without its `do`; an answered one still listed; a queue that says "nothing waits" while a handoff is open.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from typing import Any

#: NOT `coord/handoffs/`: that prefix is the roles' own handoff convention (`coord/handoffs/<from>-to-<to>-<item>`, SPEC §13), which
#: `org tempo` reads as "a handoff with no receiver" when no ack follows. Measured 2026-10-04 on org-core's board: six role-to-role
#: rows already under it, which 0.52.0's operator handoffs shared the prefix with (SPEC row 183).
BOARD_PREFIX = "coord/operator-handoffs/"
TTL = 604800   # the board's ceiling (row 7)

#: who can decide a handoff, in the words the page prints
DECIDES = {
    "operator": "you",
    "org_ceo": "the org's CEO",
    "org_core_ceo": "the org-core CEO session, under a standing decision",
}

LIMITS = {"what": 200, "why": 600, "recommend": 400, "cost": 300, "do": 1500}
OPTION_CHARS, MAX_OPTIONS = 120, 6

#: A **close card** (`close`, item `an-item-that-needs-the-operator-to-close-reaches-them-as-a-recommendation`): an item whose done-line
#: needs the operator, from the role that owns closing it once it has done what it can. The operator, in chat on 2026-10-10: *"I would
#: look once I have a recommendation waiting."* and *"I prefer getting the full recommendations, no need for a 'fast path'"* — so one card
#: per item, whole: `why` is what was measured, `look` what the operator is asked to look at and where, `recommend` the role's reason,
#: `cost` what waiting costs, and the two options below with the role's pick. Its id is the item's, so filing it again replaces the
#: card (and renews its seven days on the board) instead of adding a second. Since 0.60.17 (`status.past_ruling`) every other row about a
#: `verifying` item is set apart from *Waiting on you*, so this card is the one way such an item reaches the operator; the answer on it
#: moves the item through `org handoffs settle`. Broken looks like: two cards for one item, a close card set apart as "being verified",
#: or an answer on one that leaves the item where it was.
CLOSE_OPTIONS = {"done": "Close as done", "reopen": "Reopen: back to ready"}
#: the status each option moves the item to on the work store
CLOSE_STATUS = {CLOSE_OPTIONS["done"]: "done", CLOSE_OPTIONS["reopen"]: "ready"}
LOOK_CHARS = 400
#: **The CEO's line on a close card** (the operator, in chat on 2026-10-11: *"make sure items get CEO recommendation (including when it
#: cannot recommend) before they are marked for operator call"*; item `nothing-reaches-the-operator-without-the-ceos-recommendation`).
#: The verifier or the registrar files the card with its own recommendation; the card is then the CEO's to answer, not the operator's,
#: until the CEO adds `ceo` with `org handoffs ceo <id>`: a recommendation with its pick (`close`), or `none: <why it cannot recommend>`.
#: Only then does the card reach *Waiting on you* (`status`, `queue_ceo` until then), and the page prints the role's recommendation
#: beside the CEO's, never one in place of the other. Broken looks like: a close card with no CEO line in the operator's count or on
#: Decide, one with a line still counted for the CEO, or the role's recommendation shown as the CEO's.
CEO_FIELDS = ("why", "look", "close", "recommend")


def ceo_owes(h: dict[str, Any] | None) -> bool:
    """A close card the CEO has not yet answered with its own line: held from the operator and counted for the CEO."""
    return bool(h) and h.get("kind") == "close_item" and not h.get("ceo")


#: **Every path, not only the close card** (0.60.21, the same item). What can put a row in front of the operator, read on org-core's
#: `main` at 0.60.20 on 2026-10-11 (`status.status` builds the one queue every page and the fleet console read):
#:   1. a forward — the actuator copies a role's `blocked` field into `coord/tempo/operator-queue` (`actuator.plan`, act `forward`): no
#:      recommendation at all, the role's words;
#:   2. an actuator `ask` — the same key, the actuator's own sentence (a suppressed role, an unproven spawned merge): no recommendation;
#:   3. the chair's own `blocked` field: the CEO's words, but a need, not a recommendation;
#:   4. an operator-file bullet under `Waiting on the operator`, and 5. a `ready` item of the operator's arc (`org-core-decisions`):
#:      a CEO line only when a handoff was recorded `--for` it (SPEC row 189);
#:   6. a handoff (`org handoffs add`): `recommend` is required, and handoffs are the CEO's to write (the operator, 2026-10-07,
#:      *"CEO only (today)"* on handoff 3d555d059a2f) — so its `recommend` is the CEO's line, unless it is a bare `none` with no reason;
#:   7. a close card: the role's recommendation, held until the CEO adds its own (`ceo_owes`, above).
#: A row of 1–5 reaches the operator once the CEO records a handoff for it (`--for` its `for_key`, which `org handoffs missing` prints);
#: until then it is the CEO's (`status` puts it in `queue_ceo`). Broken looks like: a forward, a bare bullet or an arc item with no
#: handoff in *Waiting on you*, on Decide or in the fleet's queue; or one with the CEO's handoff still counted for the CEO.
def ceo_line_given(h: dict[str, Any] | None) -> bool:
    """The handoff carries the CEO's line: a recommendation, or `none: <why it cannot recommend>`. A close card needs its `ceo` field."""
    if not h:
        return False
    if h.get("kind") == "close_item":
        return bool(h.get("ceo"))
    if no_recommendation(h):
        return bool(reason_given(h))
    return bool(h.get("recommended_option") or str(h.get("recommend") or "").strip())


def ceo_owes_row(q: dict[str, Any]) -> bool:
    """A row of the operator queue the CEO has not yet given its line on: held from the operator and counted for the CEO."""
    return not ceo_line_given(q.get("handoff"))


def _ceo_line(raw: Any) -> dict[str, Any]:
    """The CEO's line on a close card, checked: `{recommend, close, by, at}` — a recommendation with the option it picks, or
    `none: <why it cannot recommend>` with no pick. A bare `none` says nothing and is refused."""
    if not isinstance(raw, dict):
        raise HandoffError("the CEO's line is an object: `recommend`, and `close` unless it is `none: <why>`")
    rec = str(raw.get("recommend") or "").strip()
    pick = str(raw.get("close") or "").strip()
    if not rec or len(rec) > LIMITS["recommend"]:
        raise HandoffError(f"the CEO's line says what it recommends, or `none: <why it cannot recommend>` (at most {LIMITS['recommend']} characters)")
    if rec.lower().startswith("none"):
        if not _NONE_YET.sub("", rec).strip():
            raise HandoffError("`none` on its own says nothing: write `none: <why the CEO cannot recommend>`")
        if pick:
            raise HandoffError("a CEO line of `none: <why>` picks no option")
    elif pick not in CLOSE_OPTIONS:
        raise HandoffError(f"the CEO's recommendation picks one: `close` is one of {', '.join(CLOSE_OPTIONS)}")
    return {"recommend": rec, "close": pick or None, "by": str(raw.get("by") or "")[:120] or None, "at": str(raw.get("at") or "")[:40] or None}


def no_recommendation(h: dict[str, Any]) -> bool:
    """The CEO could not form one and said so (`--recommend "none yet: needs …"`): shown as the CEO's debt, never as advice."""
    return str(h.get("recommend") or "").strip().lower().startswith("none")


class HandoffError(ValueError):
    pass


#: **Every card names its roadmap item** (the operator, in chat 2026-10-12 16:39Z: *"cards must name the items, how else can we track?"*;
#: item `every-operator-card-names-its-item`). `org handoffs add` refuses a card with no item — a close card's `for` is its item — and
#: checks the key against the roadmap; nothing skips it. `validate` still reads a card with none, so the cards written before the rule
#: stay readable, and the listing names them until each is re-recorded or closed. Broken looks like: a card recorded with no item, or
#: an open one with none that the listing does not name.
NO_ITEM = ("every card names its roadmap item (`--item <key>`; a close card's `--for <key>`), so what is put to the operator can be "
           "tracked — if there is no item for it, file one first, then the card")


def item_now(roadmap: dict[str, Any] | None, key: str) -> tuple[bool, str | None]:
    """`(held, status)`: whether the roadmap reading holds `key`, and its status as the queue derives it (the served store's, where read)."""
    for r in (roadmap or {}).get("items") or []:
        if str(r.get("key")) == key:
            return True, str(r.get("derived") or r.get("status") or "") or None
    return False, None


#: **A card says when its item moved after it was asked** (row 6 of the same item). `add` records the item's status beside its key
#: (`item_status`); the reading compares it with the status now, as it reads the arc. A flag in words and a shape (CLAUDE.md rule 8),
#: never a close or a hide: the writer re-records the card or closes it. Broken looks like: a moved item drawn as unchanged, an item
#: gone from the roadmap with nothing said, or a roadmap that was not read drawn as "unchanged" rather than *not checked*.
MOVED_MARK = {"moved": "live", "gone": "crit", "not_checked": "idle"}


def item_moved(h: dict[str, Any] | None, roadmap: dict[str, Any] | None) -> dict[str, Any] | None:
    """`{"state", "mark", "words"[, "then", "now"]}` for a card whose item moved since it was written, left the roadmap, or could not be read;
    None when the card names no item or its item is where it was (or the card recorded no status to compare)."""
    key = str((h or {}).get("item") or "")
    if not key:
        return None
    if (roadmap or {}).get("items") is None:
        return {"state": "not_checked", "mark": MOVED_MARK["not_checked"],
                "words": "its item's status not checked — the roadmap was not read"}
    held, now = item_now(roadmap, key)
    if not held:
        return {"state": "gone", "mark": MOVED_MARK["gone"], "words": "item no longer on the roadmap"}
    then = h.get("item_status")
    if then and now and then != now:
        return {"state": "moved", "mark": MOVED_MARK["moved"], "then": then, "now": now,
                "words": f"item moved since this was asked: {then} → {now}"}
    return None


def name_no_item(hs: list[dict[str, Any]]) -> list[str]:
    """The ids of the open cards that name no roadmap item (written before the rule, or by hand): `org handoffs` warns with them."""
    return [h["id"] for h in hs if not h.get("done") and not h.get("left_board") and not h.get("expired") and not h.get("item")]


def handoff_id(h: dict[str, Any]) -> str:
    # a close card is the item's: one per item, whatever its wording or the moment it was filed
    raw = json.dumps(["close", h.get("org"), h.get("item")] if h.get("kind") == "close_item" else [h.get("org"), h.get("what"), h.get("at")],
                     sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:12]


def validate(raw: Any, manifest: dict[str, Any] | None = None, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """A handoff as a role wrote it, checked and normalised; `HandoffError` names what is wrong. Everything is bounded:
    it is rendered into a page and read by a person, and `do` is shown as code."""
    if not isinstance(raw, dict):
        raise HandoffError("a handoff is a JSON object")
    d = raw.get("decides")
    if d not in DECIDES:
        raise HandoffError(f"`decides` is one of {', '.join(DECIDES)} — who can decide it is the point of the record")
    out: dict[str, Any] = {"decides": d, "org": str(raw.get("org") or "")[:60] or None}
    for k, n in LIMITS.items():
        v = str(raw.get(k) or "").strip()
        if len(v) > n:
            raise HandoffError(f"`{k}` is at most {n} characters")
        out[k] = v
    for k in ("what", "recommend", "cost"):
        if not out[k]:
            raise HandoffError(f"`{k}` is empty — {'say what it is' if k == 'what' else 'a handoff that does not say this is a heading, which the page already has'}"
                               + (" (write `nothing known` if so)" if k == "cost" else ""))
    opts = [str(o).strip() for o in (raw.get("options") or []) if str(o).strip()]
    if len(opts) > MAX_OPTIONS or len(set(opts)) != len(opts) or any(len(o) > OPTION_CHARS for o in opts):
        raise HandoffError(f"`options` are at most {MAX_OPTIONS} distinct choices of {OPTION_CHARS} characters each")
    pick = str(raw.get("recommended_option") or "").strip()
    if pick and pick not in opts:
        raise HandoffError(f"`recommended_option` {pick!r} is not one of the options")
    out["options"], out["recommended_option"] = opts, pick or None
    dg = str(raw.get("delegation") or "")
    if d == "org_core_ceo":
        known = {x.get("id") for x in (manifest or {}).get("delegations") or []}
        if dg not in known:
            raise HandoffError(f"`org_core_ceo` decides only under a standing decision, and {dg or 'none'!r} is not one in org.yaml "
                               f"({', '.join(sorted(k for k in known if k)) or 'none exist'})")
    elif dg:
        raise HandoffError("`delegation` belongs only to an `org_core_ceo` handoff")
    out["delegation"] = dg or None
    at = raw.get("at") or (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    out["at"] = str(at)[:40]
    out["by"] = str(raw.get("by") or "")[:120] or None
    # the heading in the operator file (or the item's id) this is the recommendation for — as the page names it when it asks (the
    # `data-key` of *Ask <CEO> for a recommendation*): the card the operator asked from gains it (status.py, SPEC row 189). One line;
    # the heading's markdown code spans are the file's markup, as they are for a ruling (asks.validate)
    key = str(raw.get("for") or "").replace("`", "").strip()
    if len(key) > 160 or re.search(r"[\r\n]", key):
        raise HandoffError("`for` is the heading of an item in the operator file, or its id: one line of at most 160 characters")
    out["for"] = key or None
    # the roadmap item the card concerns (item `decide-filtered-to-one-arc`, row 2): its key only, never its arc — Decide reads the arc from the
    # roadmap when the page is drawn, so an item that moves arc moves its card with it. `org handoffs add --item` checks the key is an item
    item = str(raw.get("item") or "").strip()
    if item and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", item):
        raise HandoffError("`item` is a roadmap item's key, e.g. `decide-filtered-to-one-arc`")
    out["item"] = item or None
    st = str(raw.get("item_status") or "").strip()
    out["item_status"] = st[:40] or None      # the item's status when the card was written (`add` reads it from the roadmap; row 6)
    close = str(raw.get("close") or "").strip()
    look = str(raw.get("look") or "").strip()
    if close:
        if close not in CLOSE_OPTIONS:
            raise HandoffError(f"`close` is one of {', '.join(CLOSE_OPTIONS)} — what the role recommends for the item")
        if d != "operator":
            raise HandoffError("a close card is decided by `operator`: it is the item's done-line that needs them")
        if not key or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", key):
            raise HandoffError("a close card names its item's key in `for`")
        if not out["why"]:
            raise HandoffError("a close card says what was measured in `why`")
        if not look or len(look) > LOOK_CHARS:
            raise HandoffError(f"a close card says what the operator is asked to look at, and where, in `look` (at most {LOOK_CHARS} characters)")
        if opts and opts != list(CLOSE_OPTIONS.values()):
            raise HandoffError(f"a close card's options are its own two: {' / '.join(CLOSE_OPTIONS.values())}")
        if item and item != key:
            raise HandoffError(f"a close card's item is the one `for` names ({key}), not {item}")
        out["options"], out["recommended_option"] = list(CLOSE_OPTIONS.values()), CLOSE_OPTIONS[close]
        out["kind"], out["item"], out["look"], out["close"] = "close_item", key, look, close
        out["do"] = out["do"] or (f"Answer on this card: the answer moves the item (`org handoffs settle --apply`).\n"
                                  f"roadmap status {key} done     # close as done\nroadmap status {key} ready    # reopen")
        if raw.get("ceo"):
            out["ceo"] = _ceo_line(raw["ceo"])
    elif look:
        raise HandoffError("`look` belongs only to a close card (`close`)")
    if raw.get("ceo") and not close:
        raise HandoffError("the CEO's line (`ceo`) belongs only to a close card (`close`)")
    out["id"] = handoff_id(out)
    return out


def _env(manifest: dict[str, Any]) -> dict[str, str]:
    c = (manifest.get("ports") or {}).get("coordination") or {}
    env = {"SWITCHBOARD_WORKSPACE": str(c.get("workspace") or "")}
    if c.get("url"):
        env["SWITCHBOARD_URL"] = str(c["url"])
    return env


def record(h: dict[str, Any], manifest: dict[str, Any], run: Any) -> None:
    run(["switchboard", "--json", "board", "set", BOARD_PREFIX + h["id"], json.dumps(h, ensure_ascii=False), "--ttl", str(TTL)],
        _env(manifest))


def mark_done(hid: str, note: str, manifest: dict[str, Any], run: Any, *, now: dt.datetime | None = None,
              left: list[dict[str, Any]] | None = None, history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """The answer, on the record: what was done and when. An answered handoff leaves the list. A card that already left the board is
    closed from its last text in `left` (`expired`, from the facts): it is written back, done, so the next gather reads it answered —
    else a card off the board could never be closed, only re-recorded. One whose last write in `history` (the facts' board rows) is
    already a close, whose own key expired, is written back as it was, its `done` kept and `rewritten_at` added, so a reader whose
    history lacked the close reads it again (Atlas, 2026-10-24: `done` exited "No entry" on 11 such Lucille cards)."""
    env = _env(manifest)
    stamp = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    gone = next((h for h in left or [] if h.get("id") == hid), None)
    if gone is None:
        gone = last_write(history, hid)
    try:
        got = json.loads(run(["switchboard", "--json", "board", "get", BOARD_PREFIX + hid], env) or "{}")
    except RuntimeError as e:
        # `board get` exits 1 on a key it does not hold ("No entry at …"): only then, and only for a card the facts know, is it not an error
        if gone is None or "no entry" not in str(e).lower():
            raise
        got = {}
    v = got.get("value") if isinstance(got, dict) else None
    if isinstance(v, str):
        v = json.loads(v)
    if not isinstance(v, dict) or v.get("id") != hid:
        v = {k: x for k, x in gone.items() if k not in ("expired", "left_board", "expires_at", "left_hours")} if gone else None
        if v is None:
            raise HandoffError(f"no handoff {hid} on the board, nor in the facts this checkout holds (`git pull` it, then retry)")
    if isinstance(v.get("done"), dict) and not got:
        v["done"] = {**v["done"], "rewritten_at": stamp}       # closed before, its key expired: the same close, on the board again
    else:
        v["done"] = {"at": stamp, "note": note[:600]}
    run(["switchboard", "--json", "board", "set", BOARD_PREFIX + hid, json.dumps(v, ensure_ascii=False), "--ttl", str(TTL)], env)
    return v


def from_board(rows: list[dict[str, Any]] | None) -> tuple[list[dict[str, Any]], int]:
    """Every handoff on the board, newest first, and how many rows under the prefix were not one — counted, never
    swallowed, because the board is shared and a stray key must not read as an empty list."""
    out, bad = [], 0
    for r in rows or []:
        if not str(r.get("key", "")).startswith(BOARD_PREFIX):
            continue
        v = r.get("value")
        if isinstance(v, str):
            try:
                v = json.loads(v)
            except json.JSONDecodeError:
                bad += 1
                continue
        if isinstance(v, dict) and v.get("decides") in DECIDES and v.get("id") and v.get("what"):
            # when the board drops the row: the board's own field, never the writer's (`left_hours`)
            out.append({**v, "expires_at": r["expires_at"]} if r.get("expires_at") else v)
        else:
            bad += 1
    return sorted(out, key=lambda h: str(h.get("at") or ""), reverse=True), bad


def open_ones(rows: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    return [h for h in from_board(rows)[0] if not h.get("done")]


def answers_for(asks: list[dict[str, Any]] | None) -> dict[str, list[dict[str, Any]]]:
    """Every answer on the board to each handoff, by handoff id, in the order the listing gives them — never only "the
    latest by `at`": `at` is the writer's own field, a board row is attributed, never signed (SPEC row 182; Reed on #73, as on
    #68), and a later-stamped row must not hide an earlier one. Each says what it chose,
    what it said, who it claims to be from, and whether the CEO has marked it acted on."""
    out: dict[str, list[dict[str, Any]]] = {}
    for a in asks or []:
        t = a.get("target") or {}
        if a.get("kind") == "answer" and t.get("type") == "handoff" and t.get("key"):
            out.setdefault(t["key"], []).append({
                "choice": a.get("choice"), "note": a.get("note"), "at": a.get("at"), "id": a.get("id"), "by": a.get("by"),
                "done": (a.get("done") or {}).get("note") if a.get("done") else None, "acted": bool(a.get("done"))})
    return out


def as_queue_row(h: dict[str, Any], answered: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """The shape the operator queue already has (`status` builds `queue` from these), plus the handoff itself, which the
    two pages render under the heading."""
    return {"source": BOARD_PREFIX + h["id"], "since": h.get("at"), "head": str(h["what"])[:200], "body": h.get("why", ""),
            "handoff": {**{k: h.get(k) for k in ("id", "what", "org", "decides", "recommend", "cost", "do", "delegation", "by", "at",
                                                 "orphan", "options", "recommended_option", "for", "kind", "item", "item_status", "look", "ceo",
                                                 "left_hours", "expired", "left_board")},
                        "no_recommendation": no_recommendation(h), "answered": answered,
                        "note": note_for_ceo(h)}}


#: under this many hours left on the board, a card says how long it has (row 1 of `command-center-decide-and-the-operator-queue`)
WARN_HOURS = 24


def left_hours(h: dict[str, Any], now: dt.datetime) -> int | None:
    """Whole hours until the board drops this card, when that is under `WARN_HOURS`; else None — a card with days left says nothing,
    and one whose listing gave no expiry says nothing rather than a guess. Whole hours, rounded down, so a page re-read within the hour
    reads the same (the page reloads when what it prints moves). Broken looks like: a card with 5 hours left that says nothing, or a
    card with 3 days left that warns."""
    exp = _when(h.get("expires_at"))
    if exp is None:
        return None
    left = (exp - now).total_seconds() / 3600
    return max(0, int(left)) if left < WARN_HOURS else None


def left_board_words(h: dict[str, Any]) -> str:
    """What a card that left the board unanswered says on the page (row 4): when it left, and how it is answered now."""
    when = (f"expired {h['left_board']}" if h.get("left_board") else "left before its expiry (deleted?)")
    return (f"{when}, never answered — this is its last text. Record it again if it is still true (`org handoffs add`), "
            f"or close it (`org handoffs done {h.get('id')}`)")


#: what the page says beside an `org_ceo` card's note (row 7, ruled 2026-10-12 08:05Z)
NOTE_WORDS = ("the org-core CEO session hands this to that CEO by DM, as itself — the Do line names the DM. If that CEO is unreachable, "
              "copy the note below and paste it to that session yourself")


def left_words(n: int) -> str:
    """What a card says when it has under a day left on the board."""
    return (f"in {n} h" if n else "within the hour") + " — unless it is recorded again (`org handoffs add`); an unanswered card " \
        "that leaves is still listed by `org handoffs --all`"


def _when(raw: Any) -> dt.datetime | None:
    """An ISO instant as an aware datetime (naive read as UTC), or None — compared as instants, never as text: an expiry with
    microseconds and a `now` without sort as strings in the wrong order at the boundary (row 8, Reed on #211)."""
    try:
        t = dt.datetime.fromisoformat(str(raw or "").replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


def left_rows(history: list[dict[str, Any]] | None, live: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """The board rows of the cards that left the board unanswered — the last write of each, as the board listed it: every handoff in
    `history` (board rows as `tempo.gather_board` keeps them, from the facts files and the ledger they carry) that is not on the board now
    (`live`), was open the last time it was read, and was not asked again — a card with the same org and `what` written later, on the board
    or in the history, is the same question re-recorded (its own answer closes both). Rows, so a gather can carry them forward
    (`handoffs_left` in the facts): a card that left the board is kept past the oldest facts file (row 5)."""
    live_hs, _ = from_board(live)
    live_ids = {h["id"] for h in live_hs}
    last = _last_writes(history)        # walked oldest write first: the last write wins
    newest: dict[tuple[Any, Any], str] = {}
    for h in live_hs + [h for _, h in last.values()]:
        k = (h.get("org"), h.get("what"))
        newest[k] = max(newest.get(k, ""), str(h.get("at") or ""))
    return [r for hid, (r, h) in last.items()
            if hid not in live_ids and not h.get("done") and newest[(h.get("org"), h.get("what"))] <= str(h.get("at") or "")
            and not any(o.get("org") == h.get("org") and o.get("what") == h.get("what") for o in live_hs)]


def _last_writes(rows: list[dict[str, Any]] | None) -> dict[str, tuple[dict[str, Any], dict[str, Any]]]:
    """Each handoff's last write among `rows`, by id: (board row, handoff), walked oldest write first so the newest wins."""
    last: dict[str, tuple[dict[str, Any], dict[str, Any]]] = {}
    for r in sorted(rows or [], key=lambda r: str(r.get("updated_at") or "")):
        for h in from_board([r])[0]:
            last[h["id"]] = (r, h)
    return last


def closed_rows(rows: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """The board rows of the cards whose last write is a close (`done`), one per card. A gather carries them forward as
    `handoffs_closed`, so a close outlives its own board key, which the board drops in 7 days like any other (item
    `a-card-whose-board-key-expired-can-still-be-closed`): read in Lucille's facts 2026-10-25, 11 cards closed 2026-10-17 came back
    on Decide as never answered once their closes expired on 10-24, from the open write a facts file still held. Broken looks like:
    a closed card missing here, or a card re-recorded open after its close kept here."""
    return sorted((r for r, h in _last_writes(rows).values() if h.get("done")), key=lambda r: (r["key"], str(r.get("updated_at"))))


def last_write(rows: list[dict[str, Any]] | None, hid: str) -> dict[str, Any] | None:
    """The last text of handoff `hid` among `rows` (open or closed), without the board's own fields, or None."""
    got = _last_writes(rows).get(hid)
    return {k: x for k, x in got[1].items() if k not in ("expired", "left_board", "expires_at", "left_hours")} if got else None


def expired(history: list[dict[str, Any]] | None, live: list[dict[str, Any]] | None, now: dt.datetime) -> list[dict[str, Any]]:
    """The cards that left the board unanswered (`left_rows`), each its last text, with `left_board`: the board's expiry when that has
    passed, else None — it left before its time (deleted), which is said, never dressed as an expiry. The expiry and `now` are compared as
    instants (`_when`), never as ISO text (row 8).

    The list is as long as the facts files and the ledger they carry: a card written and dropped between two gathers was never read and
    cannot be listed. Broken looks like: an open card that left the board missing here, an answered or re-recorded one listed, or a
    deleted one printed as expired."""
    out = []
    now = now if now.tzinfo else now.replace(tzinfo=dt.timezone.utc)
    for h in from_board(left_rows(history, live))[0]:
        exp = _when(h.get("expires_at"))
        out.append({**h, "expired": True, "left_board": h.get("expires_at") if exp is not None and exp <= now else None})
    return sorted(out, key=lambda h: str(h.get("at") or ""), reverse=True)


def note_for_ceo(h: dict[str, Any]) -> str | None:
    """*Send to <CEO>* (row 2 of `command-center-decide-and-the-operator-queue`; SPEC row 181's "send to <CEO>"): a handoff another org's
    CEO decides (`org_ceo`) carries a note for that CEO. Row 7, ruled 2026-10-12 08:05Z: the org-core CEO session hands the card over
    by DM as itself — never as that CEO, nor in that org's sessions as its CEO (CLAUDE.md) — and the card names the DM in `do`; the
    note is the fallback the operator pastes when that CEO is unreachable. None for any other handoff. Broken looks like: an `org_ceo`
    card with no note, a note missing what is asked or what to do, a note on a card the operator decides, or a first line saying
    org-core does not send it."""
    if h.get("decides") != "org_ceo":
        return None
    who = f"{h['org']}'s CEO" if h.get("org") else "the org's CEO"
    L = [f"To {who}, from the operator, via org-core's page.",
         "", str(h.get("what") or "")]
    if h.get("why"):
        L += ["", f"Why: {h['why']}"]
    L += ["", f"Recommended by {h.get('by') or 'the org-core CEO session'}: {h.get('recommend') or ''}"]
    if h.get("cost"):
        L.append(f"What waiting costs: {h['cost']}")
    if h.get("do"):
        L += ["", "Do:", str(h["do"])]
    L += ["", f"When it is done, say so to the org-core CEO session: it closes handoff {h.get('id')} (`org handoffs done {h.get('id')}`)."]
    return "\n".join(L)


#: what the CEO's one-line reason leaves of a `none yet: <reason>` recommendation (the reason the CEO gave for having none)
_NONE_YET = re.compile(r"^none(\s+yet)?\s*[:\-—]*\s*", re.I)
SENT_PREFIX = "coord/missing-rec-sent/"


def reason_given(h: dict[str, Any] | None) -> str:
    """The CEO's stated reason for having no recommendation yet (`--recommend "none yet: <reason>"`), else `""`. A bare `none` says nothing."""
    if not h or not no_recommendation(h):
        return ""
    return _NONE_YET.sub("", str(h.get("recommend") or "").strip()).strip()


def missing(cards: list[dict[str, Any]]) -> dict[str, Any]:
    """Which waiting decisions carry no recommendation and no reason — a plain read of the cards (`console.card_*`, each with `recstate`,
    `kind`, `handoff`), no model, and no recommendation written (the CEO's call, SPEC row 182; the tool only detects and flags).

    `flagged`: a decision whose handoff record was read and holds neither a recommendation nor a reason. `reasoned`: the CEO said why it has
    none yet. `unread`: the board's handoffs were not read, so whether it carries one is unknown — *not checked*, never counted as missing.
    Only kind `decision` is asked of the CEO: a pull request or a permission prompt has its own way to be answered. A row counts only if it is a handoff card, an item of the operator's arc, or a bullet marked `[open]`
    (`counts`, set in `status`); the chair's `blocked` field, a board queue row and an unmarked bullet are listed on the page, never counted.
    Information-only cards
    cannot be told apart yet (item `decide-card-always-has-a-button-and-marks-the-recommended` is the one that marks them), so `flagged`
    can include one: the figure is an upper bound on decisions missing a recommendation, and is said so on the page.

    Broken looks like: a card with a recommendation in `flagged`, one with none left out of it, or an unread card counted as missing."""
    out: dict[str, Any] = {"flagged": [], "reasoned": [], "unread": [], "carry": 0, "asked": 0}
    for c in cards:
        if c.get("kind") != "decision" or c.get("counts") is False:
            continue        # a pointer (the chair's blocked field) or an unmarked bullet shows on the page but is not a decision to count
        out["asked"] += 1
        st = c.get("recstate")
        row = {"fid": c["fid"], "org": c.get("org") or "", "what": c.get("what") or "", "hours": c.get("hours"), "ago": c.get("ago") or "",
               "reason": reason_given(c.get("handoff"))}
        if st == "rec":
            out["carry"] += 1
        elif st == "unread":
            out["unread"].append(row)
        elif row["reason"]:
            out["reasoned"].append(row)
        else:
            out["flagged"].append(row)
    out["flagged"].sort(key=lambda r: -(r["hours"] if r["hours"] is not None else -1))
    return out


def missing_line(m: dict[str, Any]) -> str:
    """The Decide view's figure, with its state beside it. Nothing asked says nothing; unread is *not checked*, never 0."""
    if not m["asked"]:
        return ""
    bits = [f"{len(m['flagged'])} with no recommendation and no reason — flagged to the CEO" if m["flagged"] else "none missing a recommendation"]
    if m["reasoned"]:
        bits.append(f"{len(m['reasoned'])} with the CEO's reason for having none yet")
    if m["unread"]:
        bits.append(f"{len(m['unread'])} not checked (the handoff records were not read)")
    return "; ".join(bits) + "."


def dm_text(m: dict[str, Any], org: str = "") -> str:
    """The one DM that carries every flagged item to the CEO, by address. Addresses are `#f-<fid>` (SPEC row 184)."""
    rows = m["flagged"]
    lines = [f"missing_recommendation{' ' + org if org else ''}: {len(rows)} waiting decision(s) carry no recommendation and no reason. "
             "Answer each with `org handoffs add --for <heading> --item <key> --recommend \"…\"`, or `--recommend \"none yet: <why>\"`."] if rows else []
    for r in rows:
        lines.append(f"- #f-{r['fid']} waiting {r['ago'] or 'no date'}: {' '.join(str(r['what']).split())[:100]}")
    held = m.get("ceo_owes") or []
    cards = [r for r in held if r.get("id")]
    rows = [r for r in held if not r.get("id")]
    if cards:
        lines.append(f"ceo_line_owed{' ' + org if org else ''}: {len(cards)} close card(s) held from the operator until you add your line — "
                     "`org handoffs ceo <id> --recommend \"…\" --close done|reopen`, or `--recommend \"none: <why>\"`.")
        lines += [f"- {r['id']} ({r['item']}): {' '.join(str(r['what']).split())[:100]}" for r in cards]
    if rows:
        lines.append(f"ceo_recommendation_owed{' ' + org if org else ''}: {len(rows)} row(s) held from the operator until you record your "
                     "recommendation — `org handoffs add --decides operator --for \"<key>\" --item \"<item>\" --what \"…\" --recommend \"…\" --cost \"…\"`, "
                     "or `--recommend \"none: <why>\"`.")
        lines += [f"- --for {json.dumps(r['for'], ensure_ascii=False)}: {' '.join(str(r['what']).split())[:100]}" for r in rows]
    return "\n".join(lines)


def soon_lines(hs: list[dict[str, Any]]) -> list[str]:
    """`org handoffs`' first lines (row 6, ruled 2026-10-12 08:05Z): every open card with under a day left on the board, soonest first —
    the list the CEO's floor wake works, re-recording each card that is still true and closing the rest. Nobody renews a card by reading
    it: a renewed card stays after it stopped being true. Empty when none. Broken looks like: a card with hours left printed only in its
    own block further down, or a done or expired card in this list."""
    due = sorted((h for h in hs if not h.get("done") and not h.get("expired") and h.get("left_hours") is not None),
                 key=lambda h: h["left_hours"])
    if not due:
        return []
    L = [f"UNDER A DAY  {len(due)} card(s) leave the board within 24 h — re-record each that is still true (`org handoffs add`), "
         "close the rest (`org handoffs done <id>`):"]
    L += [f"  {h['id']}  {'in ' + str(h['left_hours']) + ' h' if h['left_hours'] else 'within the hour'}  "
          f"{' '.join(str(h.get('what') or '').split())[:100]}" for h in due]
    return L + [""]


def render(hs: list[dict[str, Any]]) -> str:
    """`org handoffs`: each handoff, who decides it, what is recommended, what waiting costs, and what to do."""
    if not hs:
        return "no handoff on the board — nothing a role handed the operator is open\n"
    L = soon_lines(hs)
    for h in hs:
        state = f"done {h['done']['at']}: {h['done'].get('note', '')}" if h.get("done") else "OPEN"
        if h.get("left_board") or h.get("expired"):
            state = (f"EXPIRED from the board {h['left_board']}, never answered — its last text" if h.get("left_board") else
                     "LEFT the board before its expiry (deleted?), never answered — its last text")
        elif not h.get("done") and h.get("left_hours") is not None:
            state += f" — leaves the board {left_words(h['left_hours'])}"
        L.append(f"{h['id']}  {h.get('at')}  {h.get('org') or '-'}  decides: {DECIDES.get(h['decides'])}"
                 + (f" ({h['delegation']})" if h.get("delegation") else "") + f"  [{state}]")
        L.append(f"    {h['what']}")
        L.append(f"    recommend: {h['recommend']}")
        for o in h.get("options") or []:
            L.append(f"    option{' (recommended)' if o == h.get('recommended_option') else ''}: {o}")
        L.append(f"    waiting costs: {h['cost']}")
        if h.get("do"):
            L.append("    do:")
            L += ["      " + x for x in h["do"].splitlines()]
    return "\n".join(L) + "\n"


def lines(h: dict[str, Any]) -> list[tuple[str, str]]:
    """The labelled lines a page prints under a handoff's heading: the same four on the org page and the command page."""
    who = DECIDES.get(h.get("decides"), "?")
    if h.get("orphan"):
        who = f"you — it cites `{h.get('delegation')}`, which is not a standing decision (withdrawn, never granted, or written without `org handoffs add`)"
    elif h.get("decides") == "org_core_ceo":
        who += f" — `{h.get('delegation')}`; it is not asked of you"
    need = re.sub(r"^none(\s+yet)?\s*[:\-—]*\s*", "", str(h.get("recommend") or "").strip(), flags=re.I)
    rec = ("none yet — the CEO owes one" + (f": {need}" if need else "")) if no_recommendation(h) else (h.get("recommend") or "")
    out = [("decides", who), ("CEO recommends", rec), ("waiting costs", h.get("cost") or "")]
    if h.get("kind") == "close_item":
        # the role's recommendation beside the CEO's, each under its own name — never the role's printed as the CEO's
        out[1:2] = [(f"{h.get('by') or 'the role that filed it'} recommends", h.get("recommend") or ""), ("CEO recommends", ceo_says(h))]
    if h.get("look"):
        out.insert(1, ("look at", h["look"]))
    if h.get("left_hours") is not None:
        out.append(("leaves the board", left_words(h["left_hours"])))
    return out


def marked_pick(h: dict[str, Any]) -> str | None:
    """The option a page marks *recommended*: on a close card the CEO's pick (none when the CEO's line is `none: <why>`), never the
    role's; on any other handoff its `recommended_option`."""
    if h.get("kind") == "close_item":
        return CLOSE_OPTIONS.get(str((h.get("ceo") or {}).get("close") or ""))
    return h.get("recommended_option")


def ceo_says(h: dict[str, Any]) -> str:
    """The CEO's line on a close card, as the page prints it: its recommendation and pick, its stated reason for having none, or that it
    owes one (a card in that state is held from the operator, so a page that prints this is reading the CEO's queue)."""
    c = h.get("ceo") or {}
    if not c:
        return "not yet — the CEO owes its line before this reaches the operator"
    if not c.get("close"):
        return "none — " + _NONE_YET.sub("", str(c.get("recommend") or "")).strip()
    return f"{CLOSE_OPTIONS[c['close']]} — {c.get('recommend') or ''}"


def settle(hs: list[dict[str, Any]], answers: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    """What the operator's answers on close cards move: for each open close card with an answer nobody has acted on, the status its
    item goes to (`to`), or `to: None` with the reason when the answers do not say one — words with no choice, or two choices that
    disagree — which is read by a person, never guessed. Reopening carries the operator's words as its reason (`note`).

    Broken looks like: an answered close card left out, an item moved on an answer already acted on, or a status chosen from words."""
    out = []
    for h in hs:
        if h.get("kind") != "close_item" or h.get("done"):
            continue
        fresh = [a for a in answers.get(h["id"], []) if not a.get("acted")]
        if not fresh:
            continue
        if ceo_owes(h):
            # the card never reached the operator: an answer on it is a row someone wrote to a public id, and moves nothing
            out.append({"id": h["id"], "item": h.get("item"), "answers": [a["id"] for a in fresh], "to": None, "note": "",
                        "why": "the CEO has not added its line, so the card never reached the operator — the answer moves nothing"})
            continue
        to = {CLOSE_STATUS.get(str(a.get("choice") or "").strip()) for a in fresh}
        row = {"id": h["id"], "item": h.get("item"), "answers": [a["id"] for a in fresh], "to": None,
               "note": "; ".join(str(a["note"]).strip() for a in fresh if str(a.get("note") or "").strip())}
        if len(to) == 1 and None not in to:
            row["to"] = to.pop()
        elif len(to - {None}) > 1:
            row["why"] = "the answers disagree — read them and move the item by hand"
        else:
            row["why"] = "an answer carries no choice — read the operator's words and move the item by hand"
        out.append(row)
    return out
