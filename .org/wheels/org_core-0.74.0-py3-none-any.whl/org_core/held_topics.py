"""Held topics: a topic the operator holds is refused in any outward text, and the list is the org's, never the package's (item
`outward-confidential-topics-never-leave-in-a-message`, SPEC §16 decision 16, CLAUDE.md rule 3).

Why. Read 2026-10-11 on Lucille's main 321d76f, `docs/investor/deck-outline.md` lines 160–163: one of Lucille's arcs is under an
operator IP hold dated 2026-09-28, to stay out of any application, pitch or Q&A until it is lifted. The hold existed only as prose a
drafting session had to remember; nothing read an outgoing text against it.

What it does. `check` reads one text against the org's held-topic list, which the caller passes in:

    holds: [{topic: "<a label safe to show>", phrases: ["<words>", ...], held_at: "<UTC instant>", by: "<who set it>",
             lifted_at: "<UTC instant>", lifted_by: "<who lifted it>"}, ...]      # the last two only once it is lifted

A hold is active at `now` unless it carries a `lifted_at` at or before `now` — a hold dated in the future is active already (it fails
closed), and a lift is dated and signed or it is not a lift. A text matching any phrase of an active hold is `blocked: held topic`.

The reading names the **topic** — its label, who set it and when — and never a phrase: `held`, `why` and every error this module raises
carry no word of the list, so the card the operator sees, and whatever stores it, does not leak what is held. A list this module cannot
read is refused whole (`GateError`), never read as "holds nothing"; `holds=None` — the list was not read at all — blocks the card too,
because a gate that skips the check when nobody passed the list is a gate that cannot fail. An org that holds nothing passes `[]`.

What it does not decide (open questions for the operator on the PR that added it): where the list lives in an org's config, the
phrase-matching rule (`fold` and `_pattern` below are a proposal: NFKC, invisible characters dropped, case-folded, whole words,
any run of whitespace, underscores or dashes between words, or none), and
who may propose a hold. Setting or lifting one is the operator's act (the item's proposal); this module cannot tell who wrote the list,
so that rests on where the list is kept.

Broken looks like: a held phrase in an approvable card, a refusal that prints a phrase of the list, or a package base that names any
org's topic.
"""
from __future__ import annotations

import datetime as dt
import re
import sys
import unicodedata
from typing import Any

from .claim_gate import GateError, _utc

BLOCKED = "held topic"
TOPIC_CHARS = 80
#: invisible characters a model emits inside words: zero-width space, non-joiner, joiner, word joiner, BOM, soft hyphen
_INVISIBLE = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff\u00ad"))
#: a separator between a phrase's words: whitespace, an underscore, or any dash Unicode knows (category Pd, and the minus sign)
_DASHES = "".join(chr(i) for i in range(sys.maxunicode + 1) if unicodedata.category(chr(i)) == "Pd") + "\u2212"
_SEP = "[\\s_" + re.escape(_DASHES) + "]*"
NOT_READ = "held topics: the org's held-topic list was not read — a card is approvable only once its text was read against it"


def holds(raw: Any) -> list[dict[str, Any]]:
    """The org's held-topic list, checked. Errors name the entry by its position and topic label, never by a phrase."""
    if raw is None:
        return []
    if not isinstance(raw, list) or not all(isinstance(h, dict) for h in raw):
        raise GateError("`holds` is a list of {topic, phrases, held_at, by[, lifted_at, lifted_by]}")
    out = []
    for i, h in enumerate(raw):
        topic = str(h.get("topic") or "").strip()
        if not topic or len(topic) > TOPIC_CHARS or re.search(r"[\r\n]", topic):
            raise GateError(f"held topic #{i + 1}: `topic` is a label of one line, at most {TOPIC_CHARS} characters")
        where = f"held topic #{i + 1} ({topic!r})"
        phrases = h.get("phrases")
        if not isinstance(phrases, list) or not phrases or not all(isinstance(p, str) and p.split() for p in phrases):
            raise GateError(f"{where}: `phrases` is a non-empty list of non-empty strings")
        held_at, by = _utc(h.get("held_at")), str(h.get("by") or "").strip()
        if held_at is None or not by:
            raise GateError(f"{where}: a hold is dated (`held_at`, a UTC instant) and says who set it (`by`)")
        lifted = None
        if h.get("lifted_at") is not None or h.get("lifted_by") is not None:
            lifted, lifted_by = _utc(h.get("lifted_at")), str(h.get("lifted_by") or "").strip()
            if lifted is None or not lifted_by:
                raise GateError(f"{where}: a lift is dated (`lifted_at`, a UTC instant) and says who lifted it (`lifted_by`) — "
                                "an undated lift is not a lift")
            if lifted < held_at:
                raise GateError(f"{where}: lifted before it was held")
        out.append({"topic": topic, "phrases": [p for p in phrases], "held_at": held_at, "by": by[:120], "lifted_at": lifted})
    return out


def fold(text: str) -> str:
    """Text as it is matched: NFKC (so full-width letters and compatibility forms read as their plain ones), invisible characters dropped,
    case folded. Reed on #234: a phrase written with U+2010, U+2011 or a zero-width space inside it was approvable."""
    return unicodedata.normalize("NFKC", str(text)).translate(_INVISIBLE).casefold()


def _pattern(phrase: str) -> re.Pattern[str]:
    """A proposal, not a ruling: whole words (a letter or digit on neither side; an underscore is a boundary), and where the phrase has a
    space, any run of whitespace, underscores or dashes, or none (`projectquokka`). Both sides are `fold`ed first."""
    words = fold(phrase).split()
    return re.compile(r"(?<![^\W_])" + _SEP.join(re.escape(w) for w in words) + r"(?![^\W_])")


def active(h: dict[str, Any], now: dt.datetime) -> bool:
    return h["lifted_at"] is None or h["lifted_at"] > now


def check(text: str, raw: Any, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """The held-topic reading of one text: `held`, one entry per active topic the text matches (label, who held it, when, how many
    matches — never which words); `state` `approvable` or `blocked`; `not_checked` when no list was passed."""
    now = now or dt.datetime.now(dt.timezone.utc)
    if raw is None:
        return {"state": "blocked", "blocked": BLOCKED, "held": [], "not_checked": [NOT_READ], "why": [NOT_READ]}
    held, folded = [], fold(text)
    for h in holds(raw):
        if not active(h, now):
            continue
        n = sum(len(_pattern(p).findall(folded)) for p in h["phrases"])
        if n:
            held.append({"topic": h["topic"], "held_at": h["held_at"].isoformat(timespec="seconds"), "by": h["by"], "matches": n})
    why = [f"held topic {x['topic']!r} (held {x['held_at']} by {x['by']}): the text matches it {x['matches']} time(s) — "
           "it does not leave while the operator holds it" for x in held]
    return {"state": "blocked" if held else "approvable", "blocked": BLOCKED if held else None, "held": held, "not_checked": [],
            "why": why}
