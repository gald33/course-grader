"""Roadmap items over time: the total by status including the future and the vision, and what is done, for one org and for the fleet
(the operator, 2026-10-10: *"we want to see totals including future/vision items, and also what's done"*; item
`the-command-center-plots-roadmap-items-over-time-by-status-with-the-future-and-the-done`, reworked to the operator's answers of the
same day, item `the-pr-and-item-plots-follow-the-operators-answers`).

The data is a RECORD of daily counts (`item_daily`), rebuilt from the reading's own roadmap section on every read, full or fast: the
item rows (the state now: the served store's where it was read) and `tempo._item_history` (when each item was added and first set
`verifying` / `done`, git-dated). Because it is recounted whole from those two, it has no incremental step that can undercount a day
(the class of bug #160 found in the pull-request plots' fast lane).

Bands, bottom to top, every day:
  done         status `done`                                  (dated by the item file's `done_at` commit)
  verifying    status `verifying`                             (dated by its `verifying_at` commit)
  not started  everything else                                (one band on every day: *"One 'not started' band in the past"*)
and for TODAY only, the not-started items split by the rule the page names (the files date no priority change, so a past day's split
would be today's fields painted backwards — the operator chose one band there):
  ready        priority `now` or `next`
  future       deferred (status or a `defer_reason`), or priority `later`
  vision       priority `vision`, or no priority, or an item of a `*-decisions` or `*-phases` arc
The first that fits wins, in the order: a decisions/phases arc or priority `vision` -> vision; deferred or `later` -> future; no
priority -> vision; else ready. So a deferred item with no priority is future (it says when), and a `now` item of a decisions arc is
vision (the arc says what it is). The operator, 2026-10-10: *"keep it, and add 'vision' category to 'vision' together with empty"*.
roadmap-core 0.4.0 and 0.5.0 accept only now|next|later (`roadmap_core/graph.py` `PRIORITIES`), so no item can carry `vision`
until roadmap-core does: the band reads it when an item carries it.

Per day, three series (*"Show both, separately"*): filed (the add commit), shipped (first reached `verifying`; an item that went
straight to `done` shipped that day) and done (reached `done`).

Undated: an item whose file has no add commit in the history (a store-only item, or one older than a shallow clone's graft) is counted
from the history's first day when the history is shallow and the file exists (a baseline, `older`), and from today otherwise; an item
that is `verifying` / `done` now with no dated commit moved in the store alone (SPEC row 144) and is counted there from today. The
record carries those counts, and the page says them.

Broken looks like: a last point that is not the count of the same items by status, an unread source drawn as an empty plot (it says
`not checked`), a store-only move drawn on a past day, a day with no moves drawn as a gap, a past day split into ready/future/vision.

Colours: the bands are entities, not states (CLAUDE.md rule 8), so they take the dataviz categorical palette in its fixed order, not
the state colours. Measured with the dataviz `validate_palette.js` (bundled skills 2.1.296, 2026-10-10) on the page's surfaces
(`#ffffff` light, `#1a1c21` dark), on the two adjacency lists the plot draws:
  the area   done, verifying, not started   light `#2a78d6,#eb6834,#6250d6`  ALL CHECKS PASS
                                            dark  `#3987e5,#d95926,#9085e9`  ALL CHECKS PASS
  today      done, verifying, ready, future, vision
                                            light `#2a78d6,#eb6834,#1baf7a,#eda100,#e87ba4`  ALL CHECKS PASS, contrast relief
                                                  (aqua 2.82, yellow 2.17, magenta 2.69 : 1) — every band is labelled with its
                                                  count and written in the table, which is the relief the validator asks for
                                            dark  `#3987e5,#d95926,#199e70,#c98500,#d55181`  ALL CHECKS PASS
Vision keeps its hatch, bands keep a surface-coloured edge, and every band is named with its rule in the legend.
"""
from __future__ import annotations

import datetime as dt
import html
from typing import Any

from . import prplots
from .prplots import MEAN_DAYS, ZOOM_DAYS

STACK = ("done", "verifying", "not_started")          # every day, bottom to top
SPLIT = ("ready", "future", "vision")                  # today only: the not-started items by rule
BANDS = STACK[:2] + SPLIT                              # today's column, bottom to top
RULES = {
    "done": "status done",
    "verifying": "status verifying",
    "not_started": "ready, future and vision together; split for today only",
    "ready": "not started, priority now or next",
    "future": "not started and deferred, or priority later",
    "vision": "not started and priority vision, or no priority, or in a decisions arc or a phases arc",
}
LABEL = {"done": "done", "verifying": "verifying", "not_started": "not started", "ready": "ready", "future": "future", "vision": "vision"}
NO_PRIORITY = ("", "None", "none", "null")


def _day(iso: Any) -> str | None:
    return prplots._day(iso)


def classify(item: dict[str, Any]) -> str:
    """The band of an item that has not started (the order is the module docstring's)."""
    arc = str(item.get("arc") or "")
    pr = str(item.get("priority") or "").strip()
    if arc.endswith("-decisions") or arc.endswith("-phases") or pr == "vision":
        return "vision"
    if str(item.get("status") or "") == "deferred" or str(item.get("defer_reason") or "").strip() or pr == "later":
        return "future"
    if pr in NO_PRIORITY:
        return "vision"
    return "ready"


def unread(why: str) -> dict[str, Any]:
    return {"read": False, "why": why[:200]}


def build(rm: dict[str, Any] | None, now: dt.datetime) -> dict[str, Any]:
    """The record from one reading's roadmap section (`tempo._roadmap`): `{read, at, first, through, days: {day: {done, verifying,
    not_started}}, split: {ready, future, vision}, filed, shipped, done, ...}`. `rm` unread -> `{read: False, why}`, never an empty record."""
    if not isinstance(rm, dict) or not isinstance(rm.get("items"), list):
        return unread(str((rm or {}).get("why") or "the roadmap was not read"))
    hist = rm.get("history") or {}
    if not hist.get("read"):
        return unread(f"the item history was not read — {hist.get('why') or 'no history'}")
    hitems = hist.get("items") or {}
    at = str(rm.get("read_at") or now.isoformat(timespec="seconds"))
    try:
        stamp = dt.datetime.fromisoformat(at.replace("Z", "+00:00"))
    except ValueError:
        stamp = now
    today = (stamp if stamp.tzinfo else stamp.replace(tzinfo=dt.timezone.utc)).astimezone(dt.timezone.utc).date().isoformat()
    shallow = bool(hist.get("shallow"))
    dated = [d for d in (_day((hitems.get(i["key"]) or {}).get("opened_at")) for i in rm["items"]) if d]
    start = min(dated, default=today)
    rows: list[dict[str, Any]] = []        # (open day, verifying day, done day, unstarted band, current state)
    undated_open = baseline = store_moves = 0
    for it in rm["items"]:
        h = hitems.get(it["key"]) or {}
        if h.get("deleted") and not it.get("in_files", True):
            continue
        cur = str(it.get("status") or "")
        cur = cur if cur in ("done", "verifying") else "open"
        opened = _day(h.get("opened_at"))
        if not opened:
            undated_open += 1
            if shallow and it.get("in_files", True):
                opened, baseline = start, baseline + 1
            else:
                opened = today
        v, d = _day(h.get("verifying_at")), _day(h.get("done_at"))
        if cur == "open":
            v = d = None                        # went back to ready (or never left): the history's later marks are not the state now
        elif cur == "verifying":
            d = None
        if cur != "open" and not (v or d):
            store_moves += 1
            v = d = None
        if cur == "done" and not d:
            d = today                            # `done` now, with no dated `done` commit: the move is today's
        if cur == "verifying" and not v:
            v = today
        if cur == "done" and v and v > d:
            v = d
        opened = min(opened, v or opened, d or opened)
        rows.append({"o": opened, "v": v, "d": d, "b": classify(it), "cur": cur})
    first = min([r["o"] for r in rows], default=today)
    n = (dt.date.fromisoformat(today) - dt.date.fromisoformat(first)).days + 1
    days: dict[str, dict[str, int]] = {}
    for i in range(n):
        day = (dt.date.fromisoformat(first) + dt.timedelta(i)).isoformat()
        c = dict.fromkeys(STACK, 0)
        for r in rows:
            if r["o"] > day:
                continue
            c["done" if r["d"] and r["d"] <= day else "verifying" if r["v"] and r["v"] <= day else "not_started"] += 1
        days[day] = c
    split = dict.fromkeys(SPLIT, 0)
    for r in rows:
        if r["cur"] == "open":
            split[r["b"]] += 1
    filed: dict[str, int] = {}
    shipped: dict[str, int] = {}
    done: dict[str, int] = {}
    for r in rows:
        filed[r["o"]] = filed.get(r["o"], 0) + 1
        s = r["v"] or r["d"]                     # first reached verifying; straight to done ships that day
        if s:
            shipped[s] = shipped.get(s, 0) + 1
        if r["d"]:
            done[r["d"]] = done.get(r["d"], 0) + 1
    return {"read": True, "at": at, "first": first, "through": today, "n": len(rows), "days": days, "split": split,
            "filed": filed, "shipped": shipped, "done": done,
            "shallow": shallow, "baseline": baseline, "undated_open": undated_open, "store_moves": store_moves,
            "source": rm.get("source")}


def combine(recs: list[dict[str, Any]]) -> dict[str, Any]:
    """The fleet's record: the daily counts of every org read, summed day by day over the span of them all."""
    got = [r for r in recs if r.get("read")]
    if not got:
        return unread("no org's roadmap history was read")
    first = min(r["first"] for r in got)
    last = max(r["through"] for r in got)
    days: dict[str, dict[str, int]] = {}
    for i in range((dt.date.fromisoformat(last) - dt.date.fromisoformat(first)).days + 1):
        day = (dt.date.fromisoformat(first) + dt.timedelta(i)).isoformat()
        c = dict.fromkeys(STACK, 0)
        for r in got:
            # before an org's first item it has none; after its last read day it keeps the last count (no read, no change claimed)
            v = r["days"].get(day) or (r["days"].get(r["through"]) if day > r["through"] else None)
            for b in STACK:
                c[b] += (v or {}).get(b, 0)
        days[day] = c
    out: dict[str, dict[str, int]] = {"filed": {}, "shipped": {}, "done": {}}
    for r in got:
        for f, dst in out.items():
            for d, k in (r.get(f) or {}).items():
                dst[d] = dst.get(d, 0) + k
    return {"read": True, "at": max(r["at"] for r in got), "first": first, "through": last, "orgs_read": len(got), "orgs": len(recs),
            "n": sum(r["n"] for r in got), "days": days, **out,
            "split": {b: sum((r.get("split") or {}).get(b, 0) for r in got) for b in SPLIT},
            "shallow": any(r.get("shallow") for r in got),
            "baseline": sum(r.get("baseline", 0) for r in got), "undated_open": sum(r.get("undated_open", 0) for r in got),
            "store_moves": sum(r.get("store_moves", 0) for r in got)}


def series(rec: dict[str, Any]) -> dict[str, Any]:
    days = sorted(rec["days"])

    def daily(f: str) -> list[int]:
        return [int((rec.get(f) or {}).get(d, 0)) for d in days]

    def mean(v: list[int]) -> list[float]:
        return [sum(v[max(0, i - MEAN_DAYS + 1):i + 1]) / min(MEAN_DAYS, i + 1) for i in range(len(v))]
    f, sh, dn = daily("filed"), daily("shipped"), daily("done")
    return {"days": days, "bands": {k: [rec["days"][d][k] for d in days] for k in STACK}, "split": dict(rec.get("split") or {}),
            "filed": f, "shipped": sh, "done": dn, "mean_filed": mean(f), "mean_shipped": mean(sh), "mean_done": mean(dn)}


# --- drawing ----------------------------------------------------------------------------------------------

W, H, PL, PR_, PT, PB = prplots.W, prplots.H, prplots.PL, prplots.PR_, prplots.PT, prplots.PB
COL_W = 8          # today's column, right of the plot


def _stack_svg(s: dict[str, Any], lo: int) -> str:
    """The three bands on every day, and today's column beside them: done and verifying as in the area, then the not-started
    items split into ready, future and vision — the one day whose split is not today's fields painted backwards."""
    days = s["days"][lo:]
    n = len(days)
    tot = [sum(s["bands"][k][lo + i] for k in STACK) for i in range(n)]
    ymax = max(tot + [1])
    x = prplots._scale(0, max(n - 1, 1), PL, W - PR_)
    y = prplots._scale(0, ymax, H - PB, PT)
    xs = [x(i) for i in range(n)]
    base = [0] * n
    out = []
    for k in STACK:
        top = [base[i] + s["bands"][k][lo + i] for i in range(n)]
        up = " ".join(f"{xs[i]:.1f},{y(top[i]):.1f}" for i in range(n))
        dn = " ".join(f"{xs[i]:.1f},{y(base[i]):.1f}" for i in reversed(range(n)))
        out.append(f"<polygon class='ipa i-{k}' points='{up} {dn}'/><polyline class='ipe' points='{up}'/>")
        base = top
    today = {"done": s["bands"]["done"][-1], "verifying": s["bands"]["verifying"][-1], **{k: int(s["split"].get(k, 0)) for k in SPLIT}}
    cx = W - PR_ + 3
    col, labels, acc = [], [], 0
    for k in BANDS:
        v = today[k]
        if v:
            col.append(f"<rect class='ipa i-{k}' x='{cx}' y='{y(acc + v):.1f}' width='{COL_W}' height='{y(acc) - y(acc + v):.1f}'/>"
                       f"<line class='ipe' x1='{cx}' x2='{cx + COL_W}' y1='{y(acc + v):.1f}' y2='{y(acc + v):.1f}'/>")
        labels.append((y(acc + v / 2), k, f"{LABEL[k]} {v}"))
        acc += v
    ls = sorted(labels)
    ys = [l[0] for l in ls]
    for i in range(1, len(ys)):
        ys[i] = max(ys[i], ys[i - 1] + 10)
    over = ys[-1] - (H - PB + 4) if ys else 0
    ys = [yy - over for yy in ys] if over > 0 else ys
    lab = "".join(f"<text class='prl' x='{cx + COL_W + 4}' y='{yy + 3:.1f}'>{html.escape(t)}</text>" for yy, (_, _, t) in zip(ys, ls))
    return (f"<svg viewBox='0 0 {W} {H}' class='prsvg' role='img' aria-label='roadmap items by status, stacked, with today split'>"
            f"{prplots._axes(days, ymax, x, y)}{''.join(out)}{''.join(col)}"
            f"<text class='prt' x='{cx + COL_W / 2:.1f}' y='{max(y(acc) - 3, 8):.1f}' text-anchor='middle'>today</text>{lab}</svg>")


RATE = (("ipf", "filed", "filed", "mean_filed"), ("ips", "shipped", "shipped", "mean_shipped"), ("ipd", "done", "done", "mean_done"))


def _rates_svg(s: dict[str, Any], lo: int) -> str:
    days = s["days"][lo:]
    n = len(days)
    ymax = max([v for _, _, f, _ in RATE for v in s[f][lo:]] + [1])
    x = prplots._scale(0, max(n - 1, 1), PL, W - PR_)
    y = prplots._scale(0, ymax, H - PB, PT)
    bw = max(0.5, min(5.0, (W - PR_ - PL) / max(n, 1) / 3.4))
    bars = []
    for i in range(n):
        for k, (cls, _, f, _) in enumerate(RATE):
            v = s[f][lo + i]
            if v:
                bars.append(f"<rect class='prbar {cls}' x='{x(i) + (k - 1.5) * bw:.1f}' y='{y(v):.1f}' width='{bw:.1f}' height='{y(0) - y(v):.1f}'/>")
    xs = [x(i) for i in range(n)]
    lines = "".join(f"<polyline class='prline {cls}' points='{prplots._pts(xs, [y(v) for v in s[m][lo:]])}'/>" for cls, _, _, m in RATE)
    lab = prplots._end_labels([(y(s[m][-1]), cls, f"{t} {s[m][-1]:.1f}/day") for cls, t, _, m in RATE])
    return (f"<svg viewBox='0 0 {W} {H}' class='prsvg' role='img' aria-label='items filed, shipped and done per day with a 7-day mean'>"
            f"{prplots._axes(days, ymax, x, y)}{''.join(bars)}{lines}{lab}</svg>")


def _legend() -> str:
    sw = "".join(f"<span class='prleg'><svg width='16' height='10' aria-hidden='true'><rect class='ipa i-{k}' width='16' height='10'/></svg> "
                 f"{LABEL[k]} <small>({html.escape(RULES[k])})</small></span>" for k in ("vision", "future", "ready", "not_started", "verifying", "done"))
    return sw


def section_html(rec: dict[str, Any] | None, now: dt.datetime, *, scope: str = "", note: str = "", tz: str | None = None,
                 done_html: str = "", title: str = "Roadmap items over time") -> str:
    """The Work view's *Roadmap items over time*; an unread record says *not checked* and why, never an empty plot. `done_html` is the
    Brief's accomplished windows (`console._windows_html`), the same list, not a second one."""
    from .clock import for_operator
    head = f"<div class='sechead'><h2>{html.escape(title)}</h2>"
    if not rec or not rec.get("read"):
        why = (rec or {}).get("why") or "the roadmap history was not read in this reading"
        return (f"<section class='sec prplots itplots'>{head}<p>{html.escape(scope)}</p></div><div class='prbody'>"
                f"<p class='prnc'><b>not checked</b> — {html.escape(str(why))}</p></div></section>")
    s = series(rec)
    n = len(s["days"])
    lo = max(0, n - ZOOM_DAYS)
    zoomed = n > ZOOM_DAYS
    notes = ["Past days carry one not-started band; today's column splits it into ready, future and vision by each item's fields now "
             "(the files date no priority change, so a past split would be today's fields painted backwards)"]
    if rec.get("baseline"):
        notes.append(f"{rec['baseline']} items are older than this checkout's history and are counted from {s['days'][0]}")
    if rec.get("undated_open"):
        notes.append(f"{rec['undated_open']} items have no add commit in the history (counted at {s['days'][0] if rec.get('baseline') else 'today'})")
    if rec.get("store_moves"):
        notes.append(f"{rec['store_moves']} items are verifying or done with no dated commit: they moved in the served store alone and change band today")
    if rec.get("orgs") and rec["orgs_read"] < rec["orgs"]:
        notes.append(f"{rec['orgs_read']} of {rec['orgs']} orgs read")
    if note:
        notes.append(note)
    read = for_operator(dt.datetime.fromisoformat(str(rec["at"])), tz) if rec.get("at") else ""
    sub = (f"<p>{html.escape(scope)}Items by status, by UTC day"
           + (f"; a day ends at 00:00Z, which is not midnight in {html.escape(tz)}" if tz else "")
           + f". Since {s['days'][0]} · read {html.escape(read)}.</p>")
    last = {k: s["bands"][k][-1] for k in STACK}
    total = sum(last.values())
    sp = s["split"]
    rows = "".join("<tr><td>" + d + "</td>" + "".join(f"<td>{s['bands'][k][i]}</td>" for k in STACK)
                   + f"<td>{s['filed'][i]}</td><td>{s['shipped'][i]}</td><td>{s['done'][i]}</td></tr>" for i, d in list(enumerate(s["days"]))[lo:][::-1])
    cell = lambda t, svg: f"<figure class='prfig'><figcaption>{t}</figcaption>{svg}</figure>"
    return (f"<section class='sec prplots itplots'>{HATCH}{head}{sub}</div>"
            f"<div class='prbody'><div class='prleghd'>{_legend()}<span class='prtot'>{total} items: {last['done']} done, {last['verifying']} verifying, "
            f"{last['not_started']} not started ({sp.get('ready', 0)} ready, {sp.get('future', 0)} future, {sp.get('vision', 0)} vision)</span></div>"
            f"<p class='prnc'>{html.escape('; '.join(notes))}</p><div class='prgrid'>"
            + cell(f"Items by status · since {s['days'][0]}", _stack_svg(s, 0)) + (cell(f"Items by status · last {ZOOM_DAYS} days", _stack_svg(s, lo)) if zoomed else "")
            + cell(f"Filed, shipped and done per day, 7-day mean · since {s['days'][0]}", _rates_svg(s, 0))
            + (cell(f"Filed, shipped and done per day, 7-day mean · last {ZOOM_DAYS} days", _rates_svg(s, lo)) if zoomed else "")
            + "</div><p class='prnc'>Shipped = first set verifying (or straight to done); done = set done. Two series, one bar each per day.</p>"
            + (f"<div class='itdone'><h3>What is done</h3>{done_html}</div>" if done_html else "")
            + "<details class='prtable'><summary>The last 30 days as a table</summary><table><thead><tr><th>day (UTC)</th>"
            + "".join(f"<th>{LABEL[k]}</th>" for k in STACK)
            + f"<th>filed</th><th>shipped</th><th>done that day</th></tr></thead><tbody>{rows}</tbody></table>"
            + f"<p class='prnc'>Today, not started: {sp.get('ready', 0)} ready, {sp.get('future', 0)} future, {sp.get('vision', 0)} vision.</p></details></div></section>")


# the bands are entities, so their hues are the validated categorical palette (the module docstring), in its fixed order — not a state
_LIGHT = "--ib-done:#2a78d6;--ib-verifying:#eb6834;--ib-not_started:#6250d6;--ib-ready:#1baf7a;--ib-future:#eda100;--ib-vision:#e87ba4"
_DARK = "--ib-done:#3987e5;--ib-verifying:#d95926;--ib-not_started:#9085e9;--ib-ready:#199e70;--ib-future:#c98500;--ib-vision:#d55181"
CSS = (":root{" + _LIGHT + "}\n@media (prefers-color-scheme:dark){:root:not([data-theme=\"light\"]){" + _DARK + "}}\n"
       ":root[data-theme=\"dark\"]{" + _DARK + "}\n" + "".join(f".i-{k}{{fill:var(--ib-{k})}}" for k in STACK + SPLIT if k != "vision") + """
.ipa{stroke:none}.i-vision{fill:url(#ithatch)}
.ipe{fill:none;stroke:var(--surface);stroke-width:1.5}
.prbar.ipf{fill:var(--surface);stroke:var(--ib-not_started);stroke-width:1.2}.prbar.ips{fill:var(--ib-verifying)}.prbar.ipd{fill:var(--ib-done)}
.prline.ipf{stroke:var(--ib-not_started);stroke-dasharray:5 3}.prline.ips{stroke:var(--ib-verifying);stroke-dasharray:1.5 3}.prline.ipd{stroke:var(--ib-done)}
.prleg small{color:var(--muted)}
.itdone{margin-top:12px}.itdone h3{font-size:13px;margin:0 0 4px}
""")

HATCH = ("<svg width='0' height='0' style='position:absolute' aria-hidden='true'><defs><pattern id='ithatch' width='5' height='5' "
         "patternUnits='userSpaceOnUse' patternTransform='rotate(45)'><rect width='5' height='5' style='fill:var(--surface)'/>"
         "<line x1='0' y1='0' x2='0' y2='5' style='stroke:var(--ib-vision)' stroke-width='2.5'/></pattern></defs></svg>")
