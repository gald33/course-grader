"""Runtime knobs (SPEC §10): a TTL'd, range-bounded override on the org's board, `org/knobs/<name>`.

One knob ships: `<role>.cadence_multiplier`, which multiplies that role's **wake interval** — the time an event waits
before the role is woken for it (`tempo.wake_now`: `target_hours`) and the floor between two on-demand wakes
(`min_interval_hours`). 2 means the role is woken half as often, 0.5 twice as often. It never touches a cron: no role
rewrites one, ever (SPEC §13.1), so the floor of a role is the same with the knob set or cleared.

Who sets it. The operator, anywhere (§10): `org knob set`, or a control on the command page, which is the operator's
own page (`serve`'s token and origin checks) — the control writes the record and also files an ask (`asks.py`, kind
`knob`), so the CEO is told, not surprised. A role may set one within the declared range; outside it the record is
`knob_outside_range`, the operator's (check 12 reports it, and a reader here ignores it rather than obey it).

How long. Seven days at most — the board's ceiling, which is the point: an adjustment nobody made permanent reverts on
its own. The default is a day.

Nothing here merges, spawns or sends (rule 6): it validates, and writes or deletes one board record.
"""

from __future__ import annotations

import datetime as dt
import json
import re
from typing import Any

PREFIX = "org/knobs/"
MAX_TTL = 604800
DEFAULT_TTL = 86400
#: the package default; `org.yaml` `knobs: {"*.cadence_multiplier": {range: [..]}}` or a role's own name wins (SPEC §2)
CADENCE = "cadence_multiplier"
DEFAULT_RANGE = (0.5, 4.0)
REASON_CHARS = 300


class KnobError(ValueError):
    pass


def _suffix(name: str) -> str:
    return name.split(".", 1)[1] if "." in name else name


def declared_range(name: str, manifest: dict[str, Any] | None) -> tuple[float, float] | None:
    """The range a knob may take: the manifest's entry for the exact name, else its `*.<suffix>` entry, else the package
    default for `cadence_multiplier`; None for a name with no declared range (a boolean or an unknown knob)."""
    declared = (manifest or {}).get("knobs") or {}
    for key in (name, "*." + _suffix(name)):
        rng = (declared.get(key) or {}).get("range")
        if isinstance(rng, (list, tuple)) and len(rng) == 2:
            return float(rng[0]), float(rng[1])
    return DEFAULT_RANGE if _suffix(name) == CADENCE else None


def role_of(name: str) -> str:
    return name.split(".", 1)[0]


def name_for(role: str) -> str:
    return f"{role}.{CADENCE}"


def parse_ttl(text: str | int | float) -> int:
    """`24h`, `90m`, `7d`, `3600` (seconds) -> seconds; at most the board's ceiling."""
    if isinstance(text, (int, float)):
        secs = int(text)
    else:
        m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*([smhd]?)\s*", str(text))
        if not m:
            raise KnobError(f"ttl {text!r} is not a duration like 90m, 24h or 7d")
        secs = int(float(m.group(1)) * {"": 1, "s": 1, "m": 60, "h": 3600, "d": 86400}[m.group(2)])
    if secs <= 0:
        raise KnobError("a knob lasts at least a second")
    if secs > MAX_TTL:
        raise KnobError(f"a knob lasts at most 7 d (the board's ceiling, {MAX_TTL} s); asked {secs} s")
    return secs


def validate(name: str, value: Any, manifest: dict[str, Any], *, ttl: str | int | float = DEFAULT_TTL, reason: str = "",
             by: str = "", now: dt.datetime | None = None) -> dict[str, Any]:
    """A knob to be set, checked: a role this org enables, a number inside the declared range, a TTL inside the ceiling.
    `KnobError` says which. Nothing is clamped — a value outside the range is refused, not quietly changed."""
    name = str(name or "")
    if not re.fullmatch(r"[a-z][a-z0-9-]*\." + CADENCE, name):
        raise KnobError(f"no knob named {name!r}; the knob that exists is <role>.{CADENCE}")
    role = role_of(name)
    roles = (manifest.get("roles") or {})
    if role not in roles or not (roles[role] or {}).get("enabled", True):
        raise KnobError(f"{role} is not an enabled role in this org")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise KnobError(f"{name} takes a number, not {value!r}")
    lo, hi = declared_range(name, manifest) or DEFAULT_RANGE
    if not lo <= float(value) <= hi:
        raise KnobError(f"{name}={value} is outside its declared range {lo:g}–{hi:g}")
    secs = parse_ttl(ttl)
    now = now or dt.datetime.now(dt.timezone.utc)
    reason = " ".join(str(reason or "").split())[:REASON_CHARS]
    return {"name": name, "value": float(value), "reason": reason or "set without a reason", "by": str(by or "")[:120] or None,
            "at": now.isoformat(timespec="seconds"), "ttl_seconds": secs,
            "expires_at": (now + dt.timedelta(seconds=secs)).isoformat(timespec="seconds")}


def _env(manifest: dict[str, Any]) -> dict[str, str]:
    from .asks import _env as env
    return env(manifest)


def write(rec: dict[str, Any], manifest: dict[str, Any], run: Any) -> None:
    run(["switchboard", "--json", "board", "set", PREFIX + rec["name"], json.dumps(rec), "--ttl", str(rec["ttl_seconds"])],
        _env(manifest))


def clear(name: str, manifest: dict[str, Any], run: Any) -> None:
    validate(name, 1, manifest)           # the name is checked as a set would; the value is not at issue
    run(["switchboard", "--json", "board", "delete", PREFIX + name], _env(manifest))


def apply_ask(ask: dict[str, Any], manifest: dict[str, Any], run: Any, now: dt.datetime | None = None) -> str:
    """The record a `knob` ask names, written (or deleted) before the ask is filed: a knob refused is an ask never made.
    Returns the sentence the page shows. `KnobError` is a `ValueError`, so the served page answers it as a 400."""
    k = ask["knob"]
    name = name_for(ask["target"]["key"])
    if k["value"] is None:
        clear(name, manifest, run)
        return f"{name} cleared"
    rec = validate(name, k["value"], manifest, ttl=k["ttl"], reason=ask.get("note") or "set from the command page",
                   by=ask.get("by") or "the operator, from the served page", now=now)
    write(rec, manifest, run)
    return f"{name} = {rec['value']:g} until {rec['expires_at']}"


def _value(row: dict[str, Any]) -> dict[str, Any] | None:
    v = row.get("value")
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            return None
    return v if isinstance(v, dict) else None


def from_board(rows: list[dict[str, Any]] | None, now: dt.datetime | None = None) -> dict[str, dict[str, Any]]:
    """Every knob on the board, by name. One past its own `expires_at` is dropped (the board drops it too; a stale
    gathered file may not have), and one with no readable number stays, so check 12 can name it."""
    now = now or dt.datetime.now(dt.timezone.utc)
    out: dict[str, dict[str, Any]] = {}
    for r in rows or []:
        key = str(r.get("key", ""))
        if not key.startswith(PREFIX):
            continue
        v = _value(r)
        if v is None:
            continue
        name = key[len(PREFIX):]
        exp = v.get("expires_at") or r.get("expires_at")
        try:
            if exp and dt.datetime.fromisoformat(str(exp).replace("Z", "+00:00")) <= now:
                continue
        except ValueError:
            pass
        out[name] = {**v, "name": name, "expires_at": exp}
    return out


def multiplier(knobs: dict[str, dict[str, Any]] | None, role: str, manifest: dict[str, Any] | None = None,
               rng: list[float] | tuple[float, float] | None = None) -> float:
    """What the role's wake interval is multiplied by: the knob when it is a number inside its range, else 1. A value
    outside the range is not obeyed — it is reported (check 12) — so a bad write cannot stretch a role to silence.

    The range is the one the knob was accepted against: `rng` when the caller carries it (the gathered facts' `knob_ranges`,
    which is how `wake_now` has no manifest), else the manifest's, else the package default. Judging by the default alone
    accepted a 6 into a declared 0.25–8 range and then did nothing with it (Reed's UNSOUND on #64)."""
    k = (knobs or {}).get(name_for(role))
    v = (k or {}).get("value")
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return 1.0
    lo, hi = (float(rng[0]), float(rng[1])) if rng and len(rng) == 2 else (declared_range(name_for(role), manifest) or DEFAULT_RANGE)
    return float(v) if lo <= float(v) <= hi else 1.0


def render(knobs: dict[str, dict[str, Any]]) -> str:
    if not knobs:
        return "no knob is set — every role runs on its own cadence\n"
    L = []
    for n, k in sorted(knobs.items()):
        L.append(f"{n} = {k.get('value')!r}  until {k.get('expires_at') or '?'}  by {k.get('by') or '?'}  — {k.get('reason') or 'no reason'}")
    return "\n".join(L) + "\n"
