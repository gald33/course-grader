"""The outward send gate: an outward role sends only the exact text the operator approved, by hash (rung 1, SPEC §16 decisions 16, 17).

The operator ruled rung 1 on 2026-09-27 09:20 IDT (06:20Z), *"Approve on page, role sends"*, restated it on 2026-10-02 as *"approve on
page, chase sends"*, and ruled the customer role *"Same as investors"* the same 2026-09-27 — so one gate serves every outward role. The
message goes out as the operator, from the operator's email (d17). Nothing ran a send through a page before this: Lucille's investor
track was drafts the operator sent by hand (read 2026-10-11 on Lucille's main 321d76f, `docs/investor/batch1-outreach-v5.md` line 3).

What this module is (item `outward-send-gate-approve-on-page-sends-the-approved-text`):

  - a **message card** — recipient, channel, the full text, and `sha256` of the text after `normalise` — which a role files and the page
    shows as a handoff card;
  - an **approval** — the hash the operator approved, with who approved it and when, and the recipient, channel and subject it was
    approved for (everything else that leaves in the email; Reed on #226 found the subject unbound);
  - one **send helper**, `send`, shared by every outward role: it takes the card, the approvals on record, the ledger of sends, and a
    transport, and refuses unless an approval exists whose hash equals the hash of the text it is about to send. Any edit after approval,
    one character, changes the hash and needs a new approval. An approval is used once: a second send of the same card is refused;
  - **sent** is the message id the role read back from the operator's sent folder (`mark_sent`), never the transport's return (verify
    the effect). Until then a send reads `handed_over`;
  - the **claim gate** (`claim_gate.py`, item `outward-claim-gate-runs-before-a-card-can-be-approved`) reads every card as it is filed:
    a card carrying a claim with no source, or one read past the freshness window, is `blocked: unsourced claim` and its `choices`
    carry no `approve`. `approve` re-runs the gate and refuses a blocked card; `send` refuses a card whose gate reading is not of the
    text about to go out, and runs the gate again itself on that text as of the approval's reading — never trusting the stored one.
    Freshness is held at approval, not at send, and only for the claim window: a card approved fresh and sent within `window_days`
    of the approval is sent as approved; one not sent by then is refused and goes back for a fresh approval (the operator's ruling of
    2026-10-25, item `an-outward-approval-lapses-after-seven-days`); one dated more than `claim_gate.SKEW` ahead of the send matches
    none (item `a-future-dated-outward-approval-is-refused`);
  - the **held-topic check** (`held_topics.py`, item `outward-confidential-topics-never-leave-in-a-message`) reads the same subject and
    text against the org's held-topic list, which the caller passes as `holds` to `message_card`, `approve` and `send` — never stored on
    the card, so the card carries no word of the list. A match is `blocked: held topic`, naming the topic and never the phrase; no list
    passed blocks too. Unlike freshness, a hold is read at every step as of that step: a hold set after approval stops the send, and a
    lift lets a new card through;
  - the **stated-ask check** (`stated_ask.py`, item `chase-role-package`) reads the same subject and text against the round the operator
    set, which the caller passes as `ask` like `holds`: a round sentence naming another amount, instrument or term is `blocked: not the
    stated ask`. It runs for a card whose role declares `outward.ask: required` (Chase) even with no ask passed, and for any card an
    ask is passed with; like a hold, it is read again at the send.

What it is not. It sends nothing on its own (CLAUDE.md rule 6): `transport` is the caller's, and every test hands it a fake. It does not
decide where cards, approvals and the ledger are kept — the caller passes them in; the board, the page's own store, or a committed file
are the operator's to choose (open question on the PR that added this). Every refusal is `SendRefused`, raised **before** the transport
is called.

Broken looks like: a send that goes out with no approval on record, with an approval for a different hash, recipient, channel or subject,
or twice on one approval, or on an approval older than the claim window or dated more than the claim gate's skew ahead of the send; an
approval made of a card the claim gate or a held topic blocked; a held phrase in an approvable card or a sent one; a card read as sent with no sent-folder message id beside it; or a transport called on any path that raises.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from typing import Any, Callable, Iterable

from . import claim_gate, held_topics, stated_ask

KIND = "outward_message"
#: the channels a card may name: the operator's own email is the only one ruled (d17, "You, from your email"). A new channel is a ruling first
CHANNELS = ("email",)
RECIPIENT_CHARS, TEXT_CHARS, SUBJECT_CHARS = 320, 20000, 300

#: what a send is, in the ledger: `handed_over` once the transport took it, `sent` once the sent folder shows it
HANDED_OVER, SENT = "handed_over", "sent"
#: the one choice the claim gate withholds from a blocked card
APPROVE_CHOICE = claim_gate.APPROVE


class SendRefused(RuntimeError):
    """The gate said no. The transport was not called."""


class CardError(ValueError):
    pass


def normalise(text: str) -> str:
    """The text as it is hashed: line endings made `\\n`, nothing else. Whitespace inside the text counts — a doubled space is a different
    message — so this never strips, folds or re-cases (the item's proposal; the rule is an open question for the operator)."""
    return str(text).replace("\r\n", "\n").replace("\r", "\n")


def text_hash(text: str) -> str:
    return hashlib.sha256(normalise(text).encode("utf-8")).hexdigest()


def card_id(c: dict[str, Any]) -> str:
    """Stable for one card: the role, the recipient, the channel and the moment it was filed — never the text, so an edit keeps the card
    and loses only its approval."""
    raw = json.dumps([KIND, c.get("role"), c.get("recipient"), c.get("channel"), c.get("at")], sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:12]


def message_card(raw: Any, *, now: dt.datetime | None = None, window_days: Any = None,
                 names: Iterable[str] | None = None, holds: Any = None, ask: Any = None) -> dict[str, Any]:
    """A message card as a role filed it, checked: who it goes to, by what channel, the full text and its hash, and the claim gate's
    reading of that text against the card's `sources` (`gate`, `choices`, `blocked`). `CardError` names what is wrong. The hash and
    the gate's reading are always computed here, never taken from the writer."""
    if not isinstance(raw, dict):
        raise CardError("a message card is a JSON object")
    role = str(raw.get("role") or "").strip()
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,40}", role):
        raise CardError("`role` names the outward role that files the card")
    rcpt = str(raw.get("recipient") or "").strip()
    if not rcpt or len(rcpt) > RECIPIENT_CHARS or re.search(r"[\r\n]", rcpt):
        raise CardError(f"`recipient` is one line of at most {RECIPIENT_CHARS} characters")
    ch = str(raw.get("channel") or "").strip()
    if ch not in CHANNELS:
        raise CardError(f"`channel` is one of {', '.join(CHANNELS)}")
    text = raw.get("text")
    if not isinstance(text, str) or not text.strip():
        raise CardError("`text` is the full message, as it will be sent")
    if len(text) > TEXT_CHARS:
        raise CardError(f"`text` is at most {TEXT_CHARS} characters")
    subject = str(raw.get("subject") or "")
    if len(subject) > SUBJECT_CHARS or re.search(r"[\r\n]", subject):
        raise CardError(f"`subject` is one line of at most {SUBJECT_CHARS} characters")
    at = str(raw.get("at") or (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"))[:40]
    out = {"kind": KIND, "role": role, "recipient": rcpt, "channel": ch, "subject": subject, "text": normalise(text), "at": at,
           "item": str(raw.get("item") or "").strip() or None}
    out["sha256"] = text_hash(out["text"])
    out["id"] = str(raw.get("id") or "") or card_id(out)
    try:
        out["sources"] = claim_gate._sources(raw.get("sources"))
        out["window_days"] = claim_gate.window(window_days)
        _gate(out, now=now, names=names, holds=holds, ask=ask)
    except claim_gate.GateError as e:
        raise CardError(str(e)) from e
    return out


def gated_text(c: dict[str, Any]) -> str:
    """What the claim gate reads: the subject, then the text — both leave in the email, as the operator."""
    subject = c.get("subject") or ""
    return (subject + "\n\n" if subject else "") + normalise(c.get("text") or "")


def _held(g: dict[str, Any], c: dict[str, Any], holds: Any, now: dt.datetime | None) -> dict[str, Any]:
    """Fold the held-topic reading of the card's subject and text into the claim gate's reading `g`: blocked if either is, and
    `blocked` says `held topic` first — a held topic is not fixed by a source."""
    h = held_topics.check(gated_text(c), holds, now=now)
    g["held"] = h["held"]
    g["not_checked"] = list(g.get("not_checked") or []) + h["not_checked"]
    if h["state"] != "approvable":
        g.update(state="blocked", blocked=held_topics.BLOCKED, choices=[], why=h["why"] + list(g.get("why") or []))
    return g


def _asked(c: dict[str, Any], ask: Any) -> dict[str, Any] | None:
    """The stated-ask reading of the card's subject and text (`stated_ask.py`, item `chase-role-package`), or None for a role that
    states no ask and was passed none. A role whose contract declares `outward.ask: required` is read even when the caller passed no
    ask — a stating text is then blocked, never unchecked."""
    if ask is None and not stated_ask.required(c.get("role") or ""):
        return None
    return stated_ask.check(gated_text(c), ask)


def _gate(c: dict[str, Any], *, now: dt.datetime | None = None, names: Iterable[str] | None = None, holds: Any = None,
          ask: Any = None) -> dict[str, Any]:
    """Run the claim gate, the held-topic check and the stated-ask check on the card's subject and text as they stand now, and bind the
    reading to their hash."""
    g = claim_gate.check(gated_text(c), c.get("sources"), now=now, window_days=c.get("window_days"),
                         names=c.get("names") if names is None else names)
    _held(g, c, holds, now)
    a = _asked(c, ask)
    g["ask"] = None if a is None else {"state": a["state"], "round_sentences": a["round_sentences"]}
    if a is not None:
        g["not_checked"] = list(g.get("not_checked") or []) + a["not_checked"]
        if a["state"] != "approvable":
            g.update(state="blocked", blocked=g.get("blocked") or stated_ask.BLOCKED,     # a held topic or an unsourced claim is said first
                     choices=[], why=list(g.get("why") or []) + a["why"])
    if names is not None:
        c["names"] = sorted({str(n).strip() for n in names if str(n).strip()})
    g["sha256"] = text_hash(gated_text(c))
    c.update(gate=g, choices=list(g["choices"]), blocked=g["blocked"])
    return g


def approvable(c: dict[str, Any]) -> bool:
    """The page offers `approve` only on a card whose gate reading is of its current subject and text and found nothing unsourced, stale
    or held."""
    g = c.get("gate") or {}
    return g.get("state") == "approvable" and g.get("sha256") == text_hash(gated_text(c)) and claim_gate.APPROVE in (c.get("choices") or [])


def approve(c: dict[str, Any], by: str, *, now: dt.datetime | None = None, holds: Any = None, ask: Any = None) -> dict[str, Any]:
    """The operator's approval of the card **as shown**: the hash of the text they read, the recipient and channel it goes to, who, and
    when. What the operator approved is the text on the card at this moment; an edit after this returns a different hash."""
    if not str(by or "").strip():
        raise CardError("an approval says who approved it")
    # the gate is re-run as the operator approves: an edit since filing, or a source that aged past the window while the card waited,
    # is read now, never trusted from the reading the card was filed with
    try:
        g = _gate(c, now=now, holds=holds, ask=ask)
    except claim_gate.GateError as e:
        raise CardError(f"card {c['id']}: {e}") from e
    if g["state"] != "approvable":
        fix = ("the operator holds this topic — it is not sent until the hold is lifted" if g["blocked"] == held_topics.BLOCKED
               else "repeat the operator's stated ask verbatim, or leave the round out, and file a new card" if g["blocked"] == stated_ask.BLOCKED
               else "remove the claim or re-read its source, and file a new card")
        raise CardError(f"card {c['id']}: {g['blocked']} — " + "; ".join(g["why"]) + f" — {fix}")
    a = {"card": c["id"], "sha256": text_hash(c["text"]), "recipient": c["recipient"], "channel": c["channel"],
         "subject": c.get("subject") or "", "by": str(by).strip()[:120], "at": (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"),
         "gate": {"state": g["state"], "read_at": g["read_at"], "claims": len(g["claims"]), "window_days": g["window_days"]}}
    a["id"] = hashlib.sha256(json.dumps([a["card"], a["sha256"], a["by"], a["at"]]).encode()).hexdigest()[:12]
    return a


def send(c: dict[str, Any], approvals: list[dict[str, Any]], ledger: list[dict[str, Any]],
         transport: Callable[[dict[str, Any]], Any], *, now: dt.datetime | None = None, holds: Any = None,
         ask: Any = None) -> dict[str, Any]:
    """Send the card through `transport` if, and only if, an approval of this card matches the hash of the text about to go out, for the
    same recipient and channel, and no send of this card is on the ledger. The send is written to `ledger` **before** the transport is
    called, so a transport that fails or a session that ends mid-send leaves the approval used, never re-usable — a refused re-send is
    the cheap side of that, a duplicate email is not. Returns the ledger row, `state` `handed_over`; `mark_sent` makes it `sent`."""
    h = text_hash(c.get("text") or "")
    mine = [a for a in approvals or [] if a.get("card") == c.get("id")]
    if not mine:
        raise SendRefused(f"card {c.get('id')}: no approval on record — nothing is sent that the operator did not approve")
    match = [a for a in mine if a.get("sha256") == h]
    if not match:
        raise SendRefused(f"card {c.get('id')}: the text about to go out (sha256 {h[:12]}) is not the text approved "
                          f"({', '.join(sorted({str(a.get('sha256'))[:12] for a in mine}))}) — an edit after approval needs a new approval")
    match = [a for a in match if a.get("recipient") == c.get("recipient") and a.get("channel") == c.get("channel")]
    if not match:
        raise SendRefused(f"card {c.get('id')}: approved for another recipient or channel — re-approve it as it now stands")
    # the subject leaves in the same email, as the operator: bound like the recipient (Reed on #226). An approval with no `subject` key
    # was made before the subject was bound, and matches none — it is re-approved, never read as approving any subject
    match = [a for a in match if "subject" in a and a["subject"] == (c.get("subject") or "")]
    if not match:
        raise SendRefused(f"card {c.get('id')}: the subject about to go out is not the subject approved — re-approve it as it now stands")
    # an approval made before the claim gate existed carries no `gate` reading, and matches none: it is re-approved through the gate
    match = [a for a in match if (a.get("gate") or {}).get("state") == "approvable"]
    if not match:
        raise SendRefused(f"card {c.get('id')}: approved without the claim gate's reading — re-approve it as it now stands")
    # an approval lapses with the claim window: a card not sent within `window_days` of its approval goes back for a fresh one (the
    # operator's ruling of 2026-10-25, card 840163826d27, choice 7). The shorter of the card's window and the one the approval read
    # holds; an approval with no readable UTC time has no age, and matches none
    at_send = now or dt.datetime.now(dt.timezone.utc)
    try:
        days = claim_gate.window(c.get("window_days"))
    except claim_gate.GateError as e:
        raise SendRefused(f"card {c.get('id')}: the claim window cannot be read — {e}") from e
    def _lapse(a: dict[str, Any]) -> int | float:
        try:
            return min(days, claim_gate.window((a.get("gate") or {}).get("window_days")))
        except claim_gate.GateError:
            return days
    # an approval dated more than `claim_gate.SKEW` ahead of the send has a negative age the window never reaches (Reed's SOUND on #308):
    # it matches none, as a source read past the skew is unreadable to the claim gate
    ahead = [a for a in match if (t := claim_gate._utc(a.get("at"))) is not None and t > at_send + claim_gate.SKEW]
    fresh = [a for a in match if a not in ahead and (t := claim_gate._utc(a.get("at"))) is not None
             and at_send - t <= dt.timedelta(days=_lapse(a))]
    if not fresh and ahead:
        when = sorted(f"{a.get('id')} at {a.get('at')}" for a in ahead)
        raise SendRefused(f"card {c.get('id')}: approval dated in the future ({', '.join(when)}) — more than "
                          f"{claim_gate.SKEW.total_seconds() / 60:g} min of skew ahead of {at_send.isoformat(timespec='seconds')}; "
                          "an approval is dated when the operator gave it, and the card goes back for a fresh one")
    if not fresh:
        ages = sorted(f"{a.get('id')} at {a.get('at') or 'no readable time'}" for a in match)
        raise SendRefused(f"card {c.get('id')}: approval lapsed — not sent within {days:g} d of its approval ({', '.join(ages)}); "
                          "the card goes back to the operator for a fresh approval")
    match = fresh
    if not approvable(c):
        raise SendRefused(f"card {c.get('id')}: the claim gate has no approvable reading of this text — {claim_gate.BLOCKED} or never read; "
                          "nothing leaves that the gate blocked")
    # the stored reading is the card's claim about itself: the gate is run again here on the subject and text about to go out, as of
    # the moment the approval read it (Reed's third probe on #231: an edited `gate` and `choices` went out). Freshness is held at that
    # moment, not at the send: a card the operator approved fresh is sent as approved (Reed's second probe), within the window above
    try:
        g = claim_gate.check(gated_text(c), c.get("sources"), now=claim_gate._utc(match[0]["gate"].get("read_at")),
                             window_days=c.get("window_days"), names=c.get("names"))
    except claim_gate.GateError as e:
        raise SendRefused(f"card {c.get('id')}: the claim gate cannot read this card — {e}") from e
    if g["state"] != "approvable":
        raise SendRefused(f"card {c.get('id')}: the claim gate, run on the text about to go out, says {claim_gate.BLOCKED} — "
                          + "; ".join(g["why"]))
    # a hold is read as of the send, never as of the approval: a topic the operator held after approving the card stops it here
    try:
        held = held_topics.check(gated_text(c), holds, now=now)      # its own name: `h` is the hash the ledger row carries
    except claim_gate.GateError as e:
        raise SendRefused(f"card {c.get('id')}: the held-topic list cannot be read — {e}") from e
    if held["state"] != "approvable":
        raise SendRefused(f"card {c.get('id')}: {held_topics.BLOCKED}, read on the text about to go out — " + "; ".join(held["why"]))
    # the ask is read as of the send, like a hold: an ask the operator changed after approving the card stops it here
    try:
        asked = _asked(c, ask)
    except claim_gate.GateError as e:
        raise SendRefused(f"card {c.get('id')}: the stated ask cannot be read — {e}") from e
    if asked is not None and asked["state"] != "approvable":
        raise SendRefused(f"card {c.get('id')}: {stated_ask.BLOCKED}, read on the text about to go out — " + "; ".join(asked["why"]))
    prior = [r for r in ledger if r.get("card") == c.get("id")]
    if prior:
        raise SendRefused(f"card {c.get('id')}: already handed over at {prior[0].get('at')} on approval {prior[0].get('approval')} — "
                          "an approval is used once; a second message is a new card")
    row = {"card": c["id"], "approval": match[0]["id"], "sha256": h, "recipient": c["recipient"], "channel": c["channel"],
           "role": c.get("role"), "at": (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"),
           "state": HANDED_OVER, "message_id": None}
    ledger.append(row)
    transport({"recipient": c["recipient"], "channel": c["channel"], "subject": c.get("subject") or "",
               "text": normalise(c["text"])})      # the bytes hashed are the bytes handed over
    return row


def mark_sent(row: dict[str, Any], message_id: str, *, now: dt.datetime | None = None) -> dict[str, Any]:
    """Sent is the message id the role found in the operator's sent folder after the send — never the transport's return. Refused with no id."""
    mid = str(message_id or "").strip()
    if not mid:
        raise CardError("sent is the message id read from the sent folder; with none, the send stays `handed_over`")
    row.update(state=SENT, message_id=mid[:300], sent_read_at=(now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"))
    return row


def is_sent(row: dict[str, Any] | None) -> bool:
    """A ledger row reads sent only with a sent-folder message id beside it."""
    return bool(row) and row.get("state") == SENT and bool(str(row.get("message_id") or "").strip())
