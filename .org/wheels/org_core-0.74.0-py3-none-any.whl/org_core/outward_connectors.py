"""The outward roles' connectors as manual install steps (item `outward-roles-connectors-are-manual-install-steps`, SPEC §6, §12,
§0 ruling 2 as relaxed 2026-09-26).

An outward role (Chase, Tess) works through the operator's own mail, calendar and drive. Attaching a connector to a session has no
API this package holds, so each one is a manual step (§6, "manual steps are real steps"): the operator grants it, on the operator's
account, and the step is proven only by a read a session performs and records — never by assertion, and never by a message to a
person. `org plan` prints the steps; `org verify` reads the recorded reads from its facts:

    connectors:
      <role>:
        <connector>: {read: passed|failed, at: <UTC ISO>, account: operator, proof: <the step's proof>,
                      send_scope: true|false|null,   # mail only: whether the connector holds a tool that sends
                      sent: false, why: <on a failed read>}

A contract may narrow the set with `outward.connectors: [mail, ...]`; without it, an outward role needs all three.

What this module does not decide (open for the operator; the item's proposal is undated): whether a mail connector with no send
scope is acceptable at rung 1 (it is reported as a finding — the card stops approved but unsent — and verify does not pass it);
and which tool a session uses to perform each read.

A read expires after `READ_DAYS` (the operator's ruling of 2026-10-25, card 840163826d27, choice 8: *"A connector read expires after
7 days, so a revoked grant shows within a week"*): one older reads as not checked, never as granted, and one dated more than `SKEW`
ahead of the clock is refused — a future date would otherwise hold a grant open a week past that date.

Broken looks like: a verify step that passes with no read on record, a mail proof that is a message to a person, a read on a
role's own account standing in for the operator's, or a grant revoked 10 days ago whose 10-day-old read still reads as proven.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from . import doctor as dr
from .claim_gate import SKEW
from .manifest import enabled_roles
from .outward_record import spec

STEP_ID = "connector"
ACCOUNT = "operator"
READ_DAYS = 7   # ruled 2026-10-25 (card 840163826d27, choice 8); a value is a ruling, not a knob

CONNECTORS: dict[str, dict[str, str]] = {
    "mail": {
        "grant": "attach the mail connector to the role's session, signed in to the operator's own mailbox "
                 "(one approval in the connector settings; the token is never exported, committed or written to a page)",
        "proof": "draft-created-and-deleted",
        "read": "a draft created in the operator's mailbox, read back by its id, then deleted — never a message to a person; "
                "the session also records whether the connector holds a send tool (`send_scope`)",
    },
    "calendar": {
        "grant": "attach the calendar connector to the role's session, signed in to the operator's own calendar "
                 "(one approval; never exported)",
        "proof": "events-listed",
        "read": "the operator's events for the next seven days listed, read only — no event created, changed or answered",
    },
    "drive": {
        "grant": "attach the drive connector to the role's session, signed in to the operator's own drive "
                 "(one approval; never exported)",
        "proof": "file-read",
        "read": "one file the operator names read by its id, read only — nothing created, shared or moved",
    },
}
BROKEN = ("<role>: <connector> not done — no read on record / a proof that sent a message / a read on an account that is not "
          "the operator's — and the role reported ready anyway")


def connectors_of(o: dict[str, Any]) -> list[str]:
    """The connectors an outward block needs, in the package's order; all three when it names none."""
    named = o.get("connectors")
    if not isinstance(named, list) or not named:
        return list(CONNECTORS)
    return [c for c in CONNECTORS if c in named] + [c for c in named if c not in CONNECTORS]


def contract_problems(contract: dict[str, Any]) -> list[str]:
    o = contract.get("outward")
    if not isinstance(o, dict) or "connectors" not in o:
        return []
    rid = contract.get("id", "?")
    named = o.get("connectors")
    if not isinstance(named, list) or not named:
        return [f"{rid}: `outward.connectors` is a list naming one or more of {', '.join(CONNECTORS)}"]
    unknown = [c for c in named if c not in CONNECTORS]
    if unknown:
        return [f"{rid}: `outward.connectors` names a connector org-core has no read for — {unknown!r} (known: {', '.join(CONNECTORS)})"]
    return []


def _outward_roles(manifest: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    return [(r, o) for r in enabled_roles(manifest) if (o := spec(manifest["roles"].get(r)))]


def manual_steps(manifest: dict[str, Any]) -> list[dict[str, str]]:
    """One step per connector of every enabled outward role: which grant, on whose account, and the read that proves it."""
    out = []
    for role, o in _outward_roles(manifest):
        for c in connectors_of(o):
            meta = CONNECTORS.get(c)
            if meta is None:
                continue
            out.append({"role": role, "connector": c, "account": "the operator's own (never a role's, never a shared one)",
                        "grant": meta["grant"], "read": meta["read"], "proof": meta["proof"]})
    return out


def plan_lines(manifest: dict[str, Any]) -> list[str]:
    return [f"{'manual':<13} {s['role']}: {s['connector']} — {s['grant']}; account: {s['account']}; verify: {s['read']}"
            for s in manual_steps(manifest)]


def _utc(s: Any) -> dt.datetime | None:
    if not isinstance(s, str) or not s.strip():
        return None
    try:
        d = dt.datetime.fromisoformat(s.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.utcoffset() == dt.timedelta(0) else None


def _judge(role: str, c: str, fact: Any, now: dt.datetime) -> tuple[str, str]:
    meta = CONNECTORS[c]
    head = f"{role}: {c}"
    if not isinstance(fact, dict):
        return dr.FAIL, f"{head} not done — no read on record; the operator grants it ({meta['grant']}), then a session performs the read: {meta['read']}"
    if fact.get("sent"):
        # whatever else the fact says: proving a connector by sending is the act the step exists to keep from happening
        return dr.FAIL, f"{head}: the read sent a message — never a proof (§12 `user_visible_send`); the read is: {meta['read']}"
    if fact.get("read") != "passed":
        return dr.FAIL, f"{head} not done — the read did not pass ({fact.get('why') or fact.get('read') or 'no outcome recorded'})"
    if fact.get("proof") != meta["proof"]:
        return dr.FAIL, f"{head} not done — proof {fact.get('proof')!r} is not the read this step names ({meta['proof']}: {meta['read']})"
    if fact.get("account") != ACCOUNT:
        return dr.FAIL, f"{head} not done — read on {fact.get('account')!r}, not the operator's own account"
    at = _utc(fact.get("at"))
    if at is None:
        return dr.FAIL, f"{head} not done — the read carries no UTC instant ({fact.get('at')!r}); a read without one is an assertion"
    when = at.strftime("%Y-%m-%d %H:%MZ")
    if at > now + SKEW:
        return dr.FAIL, (f"{head} not done — the read is dated {when}, in the future of {now.strftime('%Y-%m-%d %H:%MZ')} past "
                         f"{SKEW.total_seconds() / 60:g} min of skew; a read is dated when it was performed")
    age = (now - at) / dt.timedelta(days=1)
    if now - at > dt.timedelta(days=READ_DAYS):
        return dr.NEEDS_FACTS, (f"{head} not checked — its last read, at {when}, is {age:.1f} d old, past the {READ_DAYS} d window; "
                                f"a session reads it again: {meta['read']}")
    if c == "mail":
        scope = fact.get("send_scope")
        if scope is False:
            return dr.FAIL, (f"{head}: the draft read passed at {when}, and the connector has no send scope — a finding: every "
                             "approved card stops there, approved but unsent, with this reason")
        if scope is not True:
            return dr.FAIL, f"{head}: the draft read passed at {when}, but the send scope not read — whether it can send from the operator's address is unknown"
    return dr.PASS, f"{head} proven by its read at {when} ({meta['proof']}, on the operator's account)"


def verify_steps(manifest: dict[str, Any], facts: dict[str, Any] | None, *, now: dt.datetime | None = None) -> list[Any]:
    """`org verify`'s steps: each connector of each enabled outward role, proven by its recorded read within `READ_DAYS`, not
    checked when that read is older, or not done."""
    from .verify import Step
    now = now or dt.datetime.now(dt.timezone.utc)
    recorded = (facts or {}).get("connectors") or {}
    out = []
    for role, o in _outward_roles(manifest):
        mine = recorded.get(role) if isinstance(recorded.get(role), dict) else {}
        for c in connectors_of(o):
            if c not in CONNECTORS:
                out.append(Step(STEP_ID, dr.FAIL, f"{role}: {c} — org-core has no read for this connector", BROKEN))
                continue
            status, text = _judge(role, c, mine.get(c), now)
            out.append(Step(STEP_ID, status, text, BROKEN))
    return out
