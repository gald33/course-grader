"""Two guards for an outward role's files (item `tess-role-package`, SPEC §16 decision 17, §12).

An outward role (Tess, the customer role) sends as the operator and keeps a list of people. Two things about its files must
never drift quietly:

  - **its `never` lines are in the file it reads.** The rendered agent file's *What you never do* section carries every line of
    the contract's `never`, verbatim. `never_problems` names each one missing. The lock step of `org verify` already fails an
    edited base, but it says only "base section differs"; this guard says which `never` went missing, and it reads the
    contract, so it also holds when the lock was re-written over the edit;
  - **no person's address is under its paths.** The operator ruled (d17, 2026-09-27) that the role keeps its list of people
    *outside git*; a name or an address in a committed file is personal data published to everyone who can clone the repo.
    `addresses_under` reads every file under the role's paths — its package, its rendered agent and skill files, an example
    org's project section for it — and names each one that carries an email address, by path and line, never echoing the
    address itself. A name has no shape a scan can read; the address is the part a guard can hold.

`org verify` runs both for every enabled role whose contract declares an `outward` block, and org-core's own test suite runs
both on its own tree, so a commit that adds an address under `org_core/roles/tess/` fails CI.

Broken looks like: a rendered Tess agent file with one `never` line deleted and `never_problems` returning []; or an email
address committed under `org_core/roles/tess/` and `addresses_under` returning [].
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Iterable

#: an email address as a person's: local part, `@`, a dotted domain. Deliberately wide — a false alarm costs one edit, a miss
#: publishes a person
ADDRESS_RE = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
NEVER_HEADING = "## What you never do"

#: where an outward role's files live, relative to a repository root — the package (in org-core), the rendered files (every
#: installed org), and an example org's extracted project section (org-core's `examples/`)
ROLE_PATHS = ("org_core/roles/{role}", ".claude/agents/{role}.md", ".claude/skills/{role}", "examples/*/project/{role}")


def outward_roles(contracts: dict[str, dict[str, Any]]) -> list[str]:
    """The role ids whose contract declares an `outward` block, in the order given."""
    return [rid for rid, c in contracts.items() if isinstance((c or {}).get("outward"), dict)]


def never_section(text: str) -> str | None:
    """The body of the rendered *What you never do* section, or None when the file has no such heading."""
    i = text.find(NEVER_HEADING)
    if i < 0:
        return None
    rest = text[i + len(NEVER_HEADING):]
    j = rest.find("\n## ")
    return rest if j < 0 else rest[:j]


def never_problems(text: str, contract: dict[str, Any]) -> list[str]:
    """Each `never` line of the contract the rendered agent file does not carry as a bullet of its *What you never do*
    section, one line each; [] when every one is there."""
    rid = contract.get("id", "?")
    section = never_section(text)
    if section is None:
        return [f"{rid}: the agent file has no `{NEVER_HEADING}` section — every `never` line is missing"]
    bullets = {ln[2:].strip() for ln in section.splitlines() if ln.startswith("* ")}
    out = []
    for n in contract.get("never") or []:
        line = " ".join(str(n).split())
        if line not in {" ".join(b.split()) for b in bullets}:
            out.append(f"{rid}: `never` line missing from the agent file — {line[:90]}{'…' if len(line) > 90 else ''}")
    return out


def role_files(repo: Path, role: str) -> list[Path]:
    """Every file under the role's paths on disk, sorted."""
    out: set[Path] = set()
    for pat in ROLE_PATHS:
        for p in repo.glob(pat.format(role=role)):
            if p.is_file():
                out.add(p)
            elif p.is_dir():
                out.update(f for f in p.rglob("*") if f.is_file() and "__pycache__" not in f.parts)
    return sorted(out)


def _mask(addr: str) -> str:
    local, _, domain = addr.partition("@")
    return f"{local[:1]}…@…{domain.rsplit('.', 1)[-1]}"


def addresses_under(repo: Path, roles: Iterable[str]) -> list[str]:
    """`<path>:<line>: an email address (<masked>)` for every address in a file under an outward role's paths; [] for none.
    It reads the disk, not the index, so a file about to be committed is read too."""
    repo = Path(repo)
    out = []
    for role in roles:
        for f in role_files(repo, role):
            rel = f.relative_to(repo).as_posix()
            try:
                text = f.read_text(errors="replace")
            except OSError:
                continue
            for n, line in enumerate(text.splitlines(), 1):
                for m in ADDRESS_RE.finditer(line):
                    out.append(f"{rel}:{n}: an email address ({_mask(m.group(0))}) — a person's address never lands in git; "
                               "it belongs in the role's private list")
    return out
