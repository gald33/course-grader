"""The outward roles' record and clock (item `outward-roles-record-shape-and-clock`, SPEC §16 decisions 16 and 17).

An outward role (Chase, the investor role; Tess, the customer role) works a pipeline of people, not a queue of items. Its
contract declares the pipeline's stages and its floor in an `outward:` block, and `RolePackage.defaults` carries that block
into the role's manifest entry, where the doctor reads it:

    outward:
      stages: [found, sent, replied, meeting]     # the pipeline, in order
      floor_hours: 24                             # a card waiting on the operator longer than this is a finding

The clock: runtime `session` (persistent, with a listener parked like every agent, SPEC row 178) and a daily cron floor.
`contract_problems` refuses a contract that declares less.

The record, `roles/<role>/last-run`, carries beside the common fields:

    state: no-change | moved
    pipeline: {<stage>: <count>, ...}             # every declared stage, a count each, zeros included
    moved: [ ... ]                                # what moved since the last run; empty exactly when `state: no-change`
    waiting_on_operator: [{card, at, ...}, ...]   # the cards the operator has not ruled on, `at` the UTC instant filed
    in_stage: [{card, stage, since}, ...]         # each card in a stage the package ages, `since` the UTC instant it entered
    gate_blocked: [ ... ]                         # cards the claim gate refused (optional)
    findings: [ ... ]                             # what the floor aged into findings this run (optional)

The empty shape is `state: no-change` with every stage counted: "nobody moved today" is a record, and silence is not.

A package may declare `stage_ages_hours: {<stage>: <hours>}` (choice 9 of the twenty, ruled 2026-10-25: "Cards age on the
one daily floor; each package declares its own stage ages"). The doctor's check 15 then ages every `in_stage` row in such a
stage against its age, by card id, and reads a populated aged stage the record does not date as *not checked*, never young.

What this module does not decide: the stage names of either role, the floor's thresholds, which events wake the session (a
reply in the operator's inbox; for Tess, a `/start`), and where the gate keeps its cards — those are the operator's (the
item's proposal is undated). The doctor reads the cards the role's record names; it does not read the gate's store.

Broken looks like: a record with no `pipeline`, a stage the contract declares missing from it, `state: no-change` beside a
non-empty `moved`, a card with no UTC `at`, a card past the floor that no doctor line names, or a card past its stage's
age that no doctor line names.
"""

from __future__ import annotations

import datetime as dt
import re
from typing import Any

STATES = ("no-change", "moved")
DEFAULT_FLOOR_HOURS = 24.0
STAGE_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def spec(entry: dict[str, Any] | None) -> dict[str, Any] | None:
    """The `outward` block of a role's (layered) manifest entry, or None when the role is not an outward one."""
    o = (entry or {}).get("outward")
    return o if isinstance(o, dict) else None


def floor_hours(o: dict[str, Any]) -> float:
    return float(o.get("floor_hours") or DEFAULT_FLOOR_HOURS)


def stage_ages(o: dict[str, Any]) -> dict[str, float]:
    """The package's declared stage ages, `{stage: hours}`; {} when it declares none (its stages are then aged by nothing)."""
    ages = o.get("stage_ages_hours")
    return {str(k): float(v) for k, v in ages.items()} if isinstance(ages, dict) else {}


def contract_problems(contract: dict[str, Any]) -> list[str]:
    """What a role contract's `outward` block lacks, one line each; [] for a role that declares none.

    Broken looks like: [] for an outward contract whose runtime is `fresh`, whose cadence is hourly, or whose stages are
    empty or repeated."""
    from .doctor import cron_period_hours

    o = contract.get("outward")
    if o is None:
        return []
    rid = contract.get("id", "?")
    if not isinstance(o, dict):
        return [f"{rid}: `outward` is a mapping (stages, floor_hours)"]
    out: list[str] = []
    stages = o.get("stages")
    if not isinstance(stages, list) or not stages:
        out.append(f"{rid}: `outward.stages` names the pipeline's stages, in order — none named")
    else:
        bad = [s for s in stages if not isinstance(s, str) or not STAGE_RE.match(s)]
        if bad:
            out.append(f"{rid}: `outward.stages` are lower-case names — {bad!r}")
        if len(set(map(str, stages))) != len(stages):
            out.append(f"{rid}: `outward.stages` names a stage twice")
    # each package declares its own stage ages, aged on the one daily floor (choice 9 of the twenty, ruled 2026-10-25)
    ages = o.get("stage_ages_hours")
    if ages is not None:
        if not isinstance(ages, dict) or any(k not in (stages or []) for k in ages):
            out.append(f"{rid}: `outward.stage_ages_hours` maps declared stages to hours — {ages!r}")
        elif any(not isinstance(v, (int, float)) or isinstance(v, bool) or v <= 0 for v in ages.values()):
            out.append(f"{rid}: `outward.stage_ages_hours` are positive numbers of hours — {ages!r}")
    if o.get("ask") not in (None, "required"):
        out.append(f"{rid}: `outward.ask` is `required` (every card read against the operator's stated ask) or absent — {o.get('ask')!r}")
    fh = o.get("floor_hours", DEFAULT_FLOOR_HOURS)
    if not isinstance(fh, (int, float)) or isinstance(fh, bool) or fh <= 0:
        out.append(f"{rid}: `outward.floor_hours` is a positive number of hours — {fh!r}")
    if (contract.get("runtime") or {}).get("default") != "session":
        out.append(f"{rid}: an outward role is a persistent session woken by a reply — runtime default is "
                   f"{(contract.get('runtime') or {}).get('default')!r}, not `session`")
    if cron_period_hours(str((contract.get("cadence") or {}).get("default") or "")) != 24.0:
        out.append(f"{rid}: an outward role's cron is a daily floor that ages the pipeline — cadence "
                   f"{(contract.get('cadence') or {}).get('default')!r} is not daily")
    return out


def _utc(s: Any) -> dt.datetime | None:
    """A record's instant: ISO with a zero offset (`Z` or `+00:00`). A local time, or no offset, is None (CLAUDE.md rule 7)."""
    if not isinstance(s, str) or not s.strip():
        return None
    try:
        d = dt.datetime.fromisoformat(s.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if d.utcoffset() != dt.timedelta(0):
        return None
    return d


def record_problems(value: dict[str, Any], o: dict[str, Any]) -> list[str]:
    """What an outward role's finished record lacks against its declared stages, one line each; [] for a sound one.

    Broken looks like: [] for a record with no `pipeline`, or with `state: no-change` and something in `moved`."""
    out: list[str] = []
    stages = [str(s) for s in (o.get("stages") or [])]
    state = value.get("state")
    if state not in STATES:
        out.append(f"`state` is one of {', '.join(STATES)} — read {state!r}; an empty run is `no-change` with a count in each stage")
    pipe = value.get("pipeline")
    if not isinstance(pipe, dict):
        out.append(f"no `pipeline` — the count in each stage ({', '.join(stages)}), zeros included, is the record")
    else:
        missing = [s for s in stages if s not in pipe]
        if missing:
            out.append(f"`pipeline` lacks stage(s) {', '.join(missing)} — a stage with nobody in it is a 0, never absent")
        extra = [s for s in pipe if s not in stages]
        if extra:
            out.append(f"`pipeline` names stage(s) its contract does not: {', '.join(map(str, extra))}")
        bad = [s for s, n in pipe.items() if not isinstance(n, int) or isinstance(n, bool) or n < 0]
        if bad:
            out.append(f"`pipeline` counts are whole numbers ≥ 0 — not for {', '.join(map(str, bad))}")
    moved = value.get("moved") or []
    if not isinstance(moved, list):
        out.append("`moved` is a list of what moved since the last run")
    elif state == "no-change" and moved:
        out.append(f"`state: no-change` beside {len(moved)} thing(s) in `moved` — one of the two is wrong")
    elif state == "moved" and not moved:
        out.append("`state: moved` with nothing in `moved` — say what moved, or write `no-change`")
    cards = value.get("waiting_on_operator")
    if cards is None:
        out.append("no `waiting_on_operator` — the cards the operator has not ruled on, `[]` when there are none")
    elif not isinstance(cards, list):
        out.append("`waiting_on_operator` is a list of cards")
    else:
        for i, c in enumerate(cards):
            if not isinstance(c, dict) or not (c.get("card") or c.get("id")):
                out.append(f"waiting card {i}: names no `card` id")
            elif _utc(c.get("at")) is None:
                out.append(f"waiting card {c.get('card') or c.get('id')}: `at` {c.get('at')!r} is not a UTC instant — a record keeps UTC (rule 7)")
    rows = value.get("in_stage")
    if rows is not None and not isinstance(rows, list):
        out.append("`in_stage` is a list of {card, stage, since} — the cards in a stage the package ages")
    elif rows:
        for i, r in enumerate(rows):
            cid = (r.get("card") or r.get("id")) if isinstance(r, dict) else None
            if not cid:
                out.append(f"in_stage row {i}: names no `card` id")
            elif r.get("stage") not in stages:
                out.append(f"in_stage card {cid}: names stage `{r.get('stage')}`, which its contract does not declare")
            elif _utc(r.get("since")) is None:
                out.append(f"in_stage card {cid}: `since` {r.get('since')!r} is not a UTC instant — a record keeps UTC (rule 7)")
    for k in ("gate_blocked", "findings"):
        if k in value and not isinstance(value[k], list):
            out.append(f"`{k}` is a list")
    return out


def summary(value: dict[str, Any], o: dict[str, Any]) -> str:
    """`no-change · found 4 · sent 0 · replied 0 · meeting 0 · 1 card waiting · 2 aged` — the record in one line."""
    pipe = value.get("pipeline") if isinstance(value.get("pipeline"), dict) else {}
    parts = [str(value.get("state") or "?")] + [f"{s} {pipe.get(s, '?')}" for s in (o.get("stages") or [])]
    cards = value.get("waiting_on_operator") if isinstance(value.get("waiting_on_operator"), list) else []
    parts.append(f"{len(cards)} card(s) waiting on the operator")
    for k, label in (("gate_blocked", "blocked by the claim gate"), ("findings", "aged into findings")):
        if isinstance(value.get(k), list) and value[k]:
            parts.append(f"{len(value[k])} {label}")
    return " · ".join(parts)


def waiting_cards(value: dict[str, Any]) -> list[dict[str, Any]]:
    """The cards an outward record says wait on the operator, each with its UTC `since`; a card with no readable `at` has
    `since` None (its age is unknown, and `record_problems` names it)."""
    out = []
    for c in value.get("waiting_on_operator") or []:
        if not isinstance(c, dict):
            continue
        out.append({"card": str(c.get("card") or c.get("id") or "?"), "since": _utc(c.get("at")),
                    "to": c.get("recipient") or c.get("to"), "what": c.get("what") or c.get("subject")})
    return out


def staged_cards(value: dict[str, Any]) -> list[dict[str, Any]]:
    """The record's `in_stage` rows, each `{card, stage, since}` with `since` its UTC instant (None when unreadable, which
    `record_problems` names); [] when the record carries none."""
    rows = value.get("in_stage")
    out = []
    for r in rows if isinstance(rows, list) else []:
        if isinstance(r, dict) and (r.get("card") or r.get("id")):
            out.append({"card": str(r.get("card") or r.get("id")), "stage": str(r.get("stage")), "since": _utc(r.get("since"))})
    return out
