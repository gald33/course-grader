"""What a launcher reads and writes (item `launcher-role`; arc fleet-accounts-and-pools, rulings 3, 5, 6, 8, 14).

One launcher runs on each account that `fleet/accounts.yaml` marks `launcher: true`. It reads no repo and decides
nothing about what to build: it takes spawn requests from its pool's queue when its own account has headroom, spawns
there, archives what it spawned when the item closes, publishes its account's listing, and creates or rebinds a routine
on its own account only on the operator's approval relayed by Atlas. This module is the shape of that traffic — the
board keys, the documents under them, and the few decisions that must not be left to prose:

- `coord/pool/<pool>/spawn/<org>-<item>` — a spawn request (`REQUEST_SCHEMA`), written by an org's dispatcher (item
  `marshal-writes-spawn-requests`); a launcher holds one with a `switchboard claim` lease while it serves it.
- `coord/pool/<pool>/spawned/<org>-<item>` — what a launcher spawned for a request, with its account and session id,
  so that the archive and the dispatcher's cap read one ledger (`SPAWNED_SCHEMA`).
- `accounts/<account>/listing` — the account's full session and routine listing and its secret names
  (`LISTING_SCHEMA`): names only, never a value (ruling 14).
- `roles/launcher/<account>/last-run` — its record, one per account: several launchers write side by side, so a
  single `roles/launcher/last-run` would hold whichever wrote last.

The queue lives in the room of the org that keeps the fleet registry (org-core's, `gald33/org-core`) — the launcher's
own room, where Atlas writes too. That placement is a proposal, not a ruling: ruling 17 gives another operator's org
its own room, and its pool's queue would live there.

Nothing here spawns, archives, creates a routine or reads an account: the launcher does, and whether auto mode lets it
is unmeasured until item `first-launcher-on-research` (ruling 6: "No rule, test first").
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping

import jsonschema

#: the roles a launcher may spawn (ruling 8: "spawned per item and archived by their launcher when the item closes —
#: Mason, Reed, Drew"). Broken looks like: a request for the dispatcher or the CEO that validates.
SPAWNABLE_ROLES: tuple[str, ...] = ("builder", "reviewer", "planner")
#: the one headroom status a launcher claims on. `list_sessions` returns `rate_limit_info` per session; the statuses
#: read so far are `allowed` and `allowed_warning` (2026-10-17 on numerotech: 12 of 106 sessions at seven-day
#: `allowed_warning`; 2026-10-15 on gald33: 19 of 101). Whether `allowed_warning` should still claim is the operator's
#: call (open question on the PR); until then a warning is not headroom.
HEADROOM_OK: tuple[str, ...] = ("allowed",)
#: a secret's name: an environment variable's. Anything else in a names list — an `=`, a space, lower case — is a
#: value or a fragment of one, and the listing that carries it is refused before it is written (ruling 14).
SECRET_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")
SLUG_RE = r"^[a-z0-9][a-z0-9-]*$"
POOL_RE = r"^[A-Z][A-Z0-9-]*$"
ACCOUNT_RE = r"^[a-z][a-z0-9-]*$"
SESSION_RE = r"^session_[A-Za-z0-9]+$"
TRIGGER_RE = r"^trig_[A-Za-z0-9]+$"
UTC = r"Z$|\+00:00$"


def request_key(pool: str, org: str, item: str) -> str:
    return f"coord/pool/{pool}/spawn/{org}-{item}"


def request_prefix(pool: str) -> str:
    return f"coord/pool/{pool}/spawn/"


def spawned_key(pool: str, org: str, item: str) -> str:
    return f"coord/pool/{pool}/spawned/{org}-{item}"


def listing_key(account: str) -> str:
    return f"accounts/{account}/listing"


def record_key(account: str) -> str:
    return f"roles/launcher/{account}/last-run"


_AT = {"type": "string", "pattern": UTC, "description": "UTC, as every record keeps (CLAUDE.md rule 7)"}

REQUEST_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["at", "by", "pool", "org", "item", "role", "brief", "base"],
    "additionalProperties": False,
    "properties": {
        "at": _AT,
        "by": {"type": "string", "minLength": 1, "description": "the requesting role's name in its org (Marshal, Link)"},
        "pool": {"type": "string", "pattern": POOL_RE},
        "org": {"type": "string", "pattern": SLUG_RE},
        "item": {"type": "string", "pattern": SLUG_RE},
        "role": {"enum": list(SPAWNABLE_ROLES)},
        "pr": {"type": "integer", "minimum": 1, "description": "the pull request a reviewer is spawned for"},
        "repo": {"type": "string", "pattern": r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"},
        "brief": {"type": "string", "minLength": 1, "description": "the prompt, rendered by the requester from its org's main — the launcher passes it on verbatim and never reads the repo"},
        "base": {"type": "string", "pattern": r"^[0-9a-f]{7,40}$", "description": "the main sha the brief was read on (SPEC Appendix A, row 40)"},
    },
}

SPAWNED_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["at", "by", "account", "pool", "org", "item", "role", "session_id", "headroom", "state"],
    "additionalProperties": False,
    "properties": {
        "at": _AT,
        "by": {"type": "string", "minLength": 1},
        "account": {"type": "string", "pattern": ACCOUNT_RE},
        "pool": {"type": "string", "pattern": POOL_RE},
        "org": {"type": "string", "pattern": SLUG_RE},
        "item": {"type": "string", "pattern": SLUG_RE},
        "role": {"enum": list(SPAWNABLE_ROLES)},
        "pr": {"type": ["integer", "null"], "minimum": 1},
        "session_id": {"type": "string", "pattern": SESSION_RE},
        "headroom": {"enum": list(HEADROOM_OK), "description": "the reading the claim was made on — never a spawn without one"},
        "state": {"enum": ["live", "archived"]},
        "archived_at": _AT,
        "archived_because": {"enum": ["pr_merged", "pr_closed", "item_closed", "planning_stopped"]},
    },
    "allOf": [{"if": {"properties": {"state": {"const": "archived"}}},
               "then": {"required": ["archived_at", "archived_because"]}}],
}

_NAMES = {"type": "array", "items": {"type": "string", "pattern": SECRET_NAME_RE.pattern}, "uniqueItems": True}

LISTING_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["at", "by", "account", "pool", "sessions", "routines", "secrets", "canary"],
    "additionalProperties": False,
    "properties": {
        "at": _AT,
        "by": {"type": "string", "minLength": 1},
        "account": {"type": "string", "pattern": ACCOUNT_RE},
        "pool": {"type": "string", "pattern": POOL_RE},
        "claude_account": {"type": ["string", "null"]},
        "sessions": {
            "type": "object",
            "required": ["complete", "count", "items"],
            "additionalProperties": False,
            "properties": {
                "complete": {"type": "boolean", "description": "paged until has_more was false; false is a partial listing, said as one"},
                "count": {"type": "integer", "minimum": 0},
                "headroom": {"type": "object", "additionalProperties": {"type": "integer", "minimum": 0},
                             "description": "sessions per rate_limit_info status, as read"},
                "items": {"type": "array", "items": {
                    "type": "object", "required": ["id", "status"],
                    "properties": {"id": {"type": "string", "pattern": SESSION_RE}, "status": {"type": "string"},
                                   "title": {"type": "string"}, "tags": {"type": "array", "items": {"type": "string"}},
                                   "rate_limit": {"type": ["string", "null"]}}}},
            },
        },
        "routines": {
            "type": "object",
            "required": ["complete", "count", "items"],
            "additionalProperties": False,
            "properties": {
                "complete": {"type": "boolean"},
                "count": {"type": "integer", "minimum": 0},
                "items": {"type": "array", "items": {
                    "type": "object", "required": ["id", "name", "creator", "enabled"],
                    "properties": {"id": {"type": "string", "pattern": TRIGGER_RE}, "name": {"type": "string"},
                                   "creator": {"type": ["string", "null"], "description": "kept from the listing: doctor checks 3–5 never read it (arc evidence)"},
                                   "enabled": {"type": "boolean"}, "cron_expression": {"type": ["string", "null"]},
                                   "persistent_session_id": {"type": ["string", "null"]}}}},
            },
        },
        "secrets": {
            "type": "object",
            "required": ["declared", "held", "missing"],
            "additionalProperties": False,
            "description": "names only (ruling 14): what the pool's orgs declare, which of those this environment holds, and which it lacks",
            "properties": {"declared": _NAMES, "held": _NAMES, "missing": _NAMES},
        },
        "canary": {
            "type": "object",
            "required": ["board", "roadmap"],
            "additionalProperties": False,
            "description": "the cross-account reach (ruling 14): the pool's room on the hub, and the roadmap server — each `ok`, a failure in words, or `not checked`",
            "properties": {"board": {"type": "string", "minLength": 1}, "roadmap": {"type": "string", "minLength": 1}},
        },
    },
}


def _problems(doc: Any, schema: Mapping[str, Any], label: str) -> list[str]:
    v = jsonschema.Draft202012Validator(schema)
    out = []
    for err in sorted(v.iter_errors(doc), key=lambda e: list(e.absolute_path)):
        where = "/".join(str(p) for p in err.absolute_path) or "<root>"
        out.append(f"{label}: {where}: {err.message}")
    return out


def request_problems(doc: Any) -> list[str]:
    """A spawn request a launcher may serve has none. Broken looks like: a request for a role the launcher never spawns,
    with no brief, or with no base sha — a brief nobody can check against the checkout the role will read."""
    return _problems(doc, REQUEST_SCHEMA, "request")


def spawned_problems(doc: Any) -> list[str]:
    return _problems(doc, SPAWNED_SCHEMA, "spawned")


def listing_problems(doc: Any) -> list[str]:
    """A listing the launcher may publish has none. Broken looks like: a secret's value (or `NAME=value`) in a names
    list, `held` naming a secret no org declared, `missing` that disagrees with declared − held, or counts that differ
    from the items listed — a listing that says 0 sessions for a page it never read."""
    out = _problems(doc, LISTING_SCHEMA, "listing")
    if out:
        return out
    s = doc["secrets"]
    declared, held, missing = set(s["declared"]), set(s["held"]), set(s["missing"])
    if held - declared:
        out.append(f"listing: secrets/held: {sorted(held - declared)} declared by no org in the pool — publish only declared names")
    if missing != declared - held:
        out.append(f"listing: secrets/missing: is {sorted(missing)}, declared − held is {sorted(declared - held)}")
    for part in ("sessions", "routines"):
        if doc[part]["count"] != len(doc[part]["items"]):
            out.append(f"listing: {part}/count: {doc[part]['count']} for {len(doc[part]['items'])} items")
    return out


def secret_names(declared: Iterable[str], environment: Iterable[str]) -> dict[str, list[str]]:
    """{declared, held, missing} from the names the pool's orgs declare and the *names* this environment carries.

    Pass names, never `os.environ` itself: only membership is read, and nothing but a declared name is returned, so an
    undeclared variable — whatever it holds — never reaches the listing. Raises on a declared name that is not a name."""
    d = sorted(set(declared))
    bad = [n for n in d if not SECRET_NAME_RE.match(n)]
    if bad:
        raise ValueError(f"{len(bad)} declared secret name(s) are not variable names — a value was passed where a name belongs")
    env = set(environment)
    held = [n for n in d if n in env]
    return {"declared": d, "held": held, "missing": [n for n in d if n not in env]}


def declared_secret_names(manifest: Mapping[str, Any]) -> list[str]:
    """The environment-variable names an org's manifest declares its sessions need: every port's `credential` that is a
    variable name (a cache path like `~/.lucille/admin.jwt` is not, and is left out). Names only, from the manifest."""
    out: set[str] = set()

    def walk(v: Any) -> None:
        if isinstance(v, Mapping):
            for k, x in v.items():
                if k == "credential" and isinstance(x, str) and SECRET_NAME_RE.match(x):
                    out.add(x)
                else:
                    walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)

    walk((manifest or {}).get("ports") or {})
    return sorted(out)


def account_label(accounts_doc: Mapping[str, Any], uuid: str | None) -> str | None:
    """The label in `fleet/accounts.yaml` whose uuid (full, or the 8-hex prefix read so far) is this container's account;
    None when the account is unread or not listed — a launcher that cannot say which account it is on serves nothing."""
    u = (uuid or "").lower()
    if not u:
        return None
    hits = [label for label, a in ((accounts_doc or {}).get("accounts") or {}).items()
            if isinstance(a, Mapping) and a.get("uuid") and (u.startswith(str(a["uuid"]).lower()) or str(a["uuid"]).lower().startswith(u))]
    return hits[0] if len(hits) == 1 else None


def may_claim(account: Mapping[str, Any] | None, headroom: str | None, request: Mapping[str, Any]) -> tuple[bool, str]:
    """Whether a launcher on `account` (its entry in `fleet/accounts.yaml`) may claim `request`, on the headroom status it
    read this wake. The answer and why, in words for the record.

    Broken looks like: a claim with no headroom reading (`headroom` None), on a warning, on an account ruled to carry no
    launcher (gald33, ruling 4), or for a request from another pool."""
    if not account:
        return False, "this account is not in fleet/accounts.yaml — no pool, no queue"
    if not account.get("launcher"):
        return False, "this account is ruled to carry no launcher (fleet/accounts.yaml, ruling 4)"
    bad = request_problems(request)
    if bad:
        return False, "the request does not validate: " + bad[0]
    if request["pool"] != account.get("pool"):
        return False, f"the request is for pool {request['pool']}; this account serves {account.get('pool')}"
    if headroom is None:
        return False, "no headroom reading this wake — never spawn without one"
    if headroom not in HEADROOM_OK:
        return False, f"headroom reads {headroom!r}; a launcher claims only on {', '.join(HEADROOM_OK)}"
    return True, f"pool {request['pool']}, headroom {headroom}"


def archive_due(spawned: Mapping[str, Any], *, pr_state: str | None = None, item_status: str | None = None,
                planning_stopped: bool = False) -> str | None:
    """Why a session this launcher spawned is due to be archived, or None. `pr_state` is GitHub's (`open`, `closed`,
    `merged`) for the request's pull request; `item_status` the item's on the work store.

    Broken looks like: a builder whose PR merged that reads as not due, or a reviewer archived while its PR is open."""
    if spawned.get("state") != "live":
        return None
    if spawned.get("role") == "planner":
        return "planning_stopped" if planning_stopped else None
    if pr_state == "merged":
        return "pr_merged"
    if pr_state == "closed":
        return "pr_closed"
    if pr_state in (None, "") and item_status in ("done", "dropped"):
        return "item_closed"
    return None
