"""`org priorities` — land the priorities the operator set on the org page (0.40.0).

The operator, 2026-09-24: *"and the ability to prioritize items"*, *"or arcs"*; ruled: **the page records, the CEO
lands it**. A published org page with the `db` capability lets its owner set `now` / `next` / `later` on each open
item and each arc; every change is one document in the page's `priority_asks` collection (the page writes it — the
operator's own act, not org-core's). The chair reads that collection (`ArtifactData list`), saves it to a file, and
runs this command, which edits the item and arc files in a checkout and nothing else (rule 6). The edit then goes
the way every roadmap change goes: `roadmap validate && roadmap sync`, a PR, the merge, `roadmap push`.

Whose ask it is. Priority is the operator's call, and a `db` store's shared documents are writable by every
Contributor by default (runtime contract 0.2.58, `db.d.ts`), so three locks hold it (Reed on #33, 2026-09-24): the
page is published with `dashboard.PRIORITY_CAPABILITIES` (`priority_asks` writable by the owner only); the page draws
pickers only for its owner and signs every ask with the writer's id (`by`); and this command refuses an ask with no
`by`, and with `--by <owner id>` refuses one signed by anybody else.

An item's `priority` is roadmap-core's own field — the queue's sort key, authored in files and uploaded by `push`.
An arc's is org-core's: roadmap-core 0.4.0 validates an arc file carrying it and ignores it, so it orders the org
page and what the chair reads, not `roadmap ready`. The page says so beside the picker.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

#: roadmap-core's `graph.PRIORITIES`; `None` clears a judgement (the file then carries no `priority` line)
PRIORITIES = ("now", "next", "later")
#: what `by` says for an ask read from the board — never an id a `--by` can match
BOARD_WRITER = "board (unverified)"
KINDS = {"item": "items", "arc": "arcs"}
_TOP = re.compile(r"^priority:.*\n?", re.M)


def _docs(raw: Any) -> list[dict[str, Any]]:
    """The asks from whatever the store listing looks like: a bare list, `{"docs"|"documents"|"items": [...]}`, or a
    mapping of id -> doc; each entry either the document itself or `{"id", "data": {...}}`."""
    if isinstance(raw, dict):
        for k in ("docs", "documents", "items", "data", "results"):
            if isinstance(raw.get(k), list):
                return _docs(raw[k])
        return [dict(v, id=k) if isinstance(v, dict) else {} for k, v in raw.items()]
    out = []
    for d in raw or []:
        if isinstance(d, dict):
            v = d.get("value")
            if "key" in d and "value" in d and not str(d["key"]).startswith("coord/asks/"):
                continue                                  # a board row that is not an ask (a knob, a record)
            if isinstance(v, str) and str(d.get("key", "")).startswith("coord/asks/"):
                try:
                    v = json.loads(v)
                except ValueError:
                    v = None
            if isinstance(v, dict) and str(d.get("key", "")).startswith("coord/asks/"):    # a board row (`switchboard board list`)
                d = dict(v, _board=True)       # remembered: whoever holds the workspace key can write this row
            out.append(dict(d["data"], id=d.get("id")) if isinstance(d.get("data"), dict) else d)
    return out


def _board_ask(d: dict[str, Any]) -> dict[str, Any]:
    """A `prioritize` ask as the page-owner shape this module reads: the target is its arc or item, `clear` is no priority.

    Who wrote it depends on where it was read. A document from a published page's `asks` collection is signed by the
    platform (`by` is the viewer's user id, written by the page's runtime). A **board row** (`coord/asks/<id>`) is only
    *attributed*: every session holding the org's workspace key can write one, so its `by` and `via` are text a writer
    chose, not a signature (Reed's UNSOUND on #68, 2026-10-01 — a forged row passed `--by` while the genuine served-page
    row failed it). A board row therefore carries no `by` here, only `says` — what it claims — and `load_asks` lands it
    only on `board=True`, labelled unverified, for the CEO to match against the relay DM it received."""
    t = d.get("target") or {}
    board = bool(d.get("_board"))
    return {"kind": t.get("type"), "key": t.get("key"), "priority": None if d.get("choice") == "clear" else d.get("choice"),
            "at": d.get("at"), "id": d.get("id"), "by": None if board else d.get("by"), "board": board,
            "says": (d.get("by") or d.get("via") or None) if board else None}


def load_asks(path: Path, *, by: str | None = None, board: bool = False) -> list[dict[str, Any]]:
    """Every well-formed ask, the latest per (kind, key) by its `at`. Malformed ones come back with `result: invalid`
    rather than disappearing: an ask the operator made that this cannot read must be said, not dropped. An ask with no
    writer is `invalid` (nobody can say it is the operator's); with `by`, one signed by anyone else is `not-owner`.

    A row read from the board is **attributed, never signed** (`_board_ask`): it comes back `unverified` and is not
    landed, unless `board=True` — the CEO's choice to land it, each row then labelled `board (unverified)` and never
    compared with `by`, because nothing in a board row can be."""
    latest: dict[tuple[str, str], dict[str, Any]] = {}
    bad = []
    for d in _docs(json.loads(path.read_text())):
        if d.get("kind") == "prioritize":
            d = _board_ask(d)
        elif d.get("kind") in ("rule", "start", "release", "pause", "resume", "note", "wake", "run", "setup", "knob", "speed", "shutdown"):
            continue                      # another kind of ask on the same board: not a priority, not an invalid one
        kind, key, pr, who = d.get("kind"), d.get("key"), d.get("priority"), d.get("by")
        row = {"kind": kind, "key": key, "priority": pr, "at": d.get("at"), "id": d.get("id"), "by": who}
        if d.get("board"):
            row = dict(row, by=BOARD_WRITER, says=d.get("says"), unverified=True)
            if not board:
                bad.append(dict(row, result="unverified", why="a board row is attributed, not signed: anyone holding the "
                                "workspace key can write it — match it against the relay DM, then land it with --accept-board"))
                continue
            who = BOARD_WRITER                # skips the writer and `by` checks below: nothing in a board row can satisfy them
        if kind not in KINDS or not isinstance(key, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]*", key) \
                or (pr is not None and pr not in PRIORITIES) or not isinstance(who, str) or not who:
            bad.append(dict(row, result="invalid", why="no writer (`by`)" if not who else "malformed"))
            continue
        if by is not None and who != by and not row.get("unverified"):
            bad.append(dict(row, result="not-owner"))
            continue
        k = (kind, key)
        if k not in latest or str(d.get("at") or "") >= str(latest[k].get("at") or ""):
            latest[k] = row
    return sorted(latest.values(), key=lambda a: (a["kind"], a["key"])) + bad


def _set(text: str, value: str | None, after: tuple[str, ...]) -> str:
    """The file with its top-level `priority:` line set to `value` (removed for None). An absent line goes after the
    first of `after` found at top level, else at the end. Indented lines — an `evidence: |` block that mentions
    priority — are never touched."""
    line = f"priority: {value}\n" if value else ""
    if _TOP.search(text):
        return _TOP.sub(line, text, count=1)
    if not line:
        return text
    for key in after:
        m = re.search(rf"^{key}:.*\n", text, re.M)
        if m:
            return text[:m.end()] + line + text[m.end():]
    return text + ("" if text.endswith("\n") else "\n") + line


def _current(text: str) -> str | None:
    m = _TOP.search(text)
    return m.group(0).split(":", 1)[1].strip().strip("'\"") or None if m else None


def apply(repo: Path, asks: list[dict[str, Any]], *, base: str = "roadmap", write: bool = False) -> list[dict[str, Any]]:
    """One row per ask: `changed` (the file now says what the operator asked; written only with `write`), `already`
    (it said so — landed), `unknown` (no such item or arc file), or `invalid` (carried from `load_asks`)."""
    rows = []
    for a in asks:
        if a.get("result") in ("invalid", "not-owner", "unverified"):
            rows.append(a)
            continue
        path = repo / base / KINDS[a["kind"]] / f"{a['key']}.yaml"
        if not path.is_file():
            rows.append(dict(a, result="unknown", file=str(path.relative_to(repo))))
            continue
        text = path.read_text()
        was = _current(text)
        row = dict(a, was=was, file=str(path.relative_to(repo)))
        if was == a["priority"]:
            rows.append(dict(row, result="already"))
            continue
        if write:
            path.write_text(_set(text, a["priority"], ("arc", "status", "title") if a["kind"] == "item" else ("title",)))
        rows.append(dict(row, result="changed"))
    return rows
