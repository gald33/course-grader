"""The tool-permission prompts an installed role will meet with nobody there to answer (SPEC §18, row 134).

Every role org-core installs runs unattended — a routine's fresh session, a spawned one-shot, a persistent session
bound to a clock. A tool that stops for an approval prompt in that container waits for a person who is not coming.
Measured three times before this module existed, each on the same tool: row 97 (2026-09-20) — NumeroTech's
dispatcher `REQUIRES_ACTION` on `mcp__Supabase__execute_sql`, US$1,823 in the 24 h before; row 114 (2026-09-21) —
NumeroTech's reviewers stalled 13–19 h on the same approval; row 120 (2026-09-22) — a reviewer 34.39 h on it,
cost still accruing. The doctor found each one after the fact (check 11's `BLOCKED`). Nothing at install, which is
the only moment the org can still choose, said a word.

This is a reading and a refusal, not a grant. `settings.py` refuses to commit an `env` key because "a committed env
key is a standing grant nobody is present for" (Lucille #1492/#1537); a committed permission allowlist is the same
kind of grant, so org-core writes none. It reads which roles the manifest routes to a tool known to prompt, and it
refuses to verify an install whose manifest has not said, in `prompts:`, what it decided about each.

What is known to prompt is measured, not guessed: `KNOWN` lists only tools a live session has been seen waiting on.
A tool the org knows prompts and org-core has not measured is declared by the org in `prompts:` — which decides it.
"""

from __future__ import annotations

from typing import Any

#: tools a live session has been measured waiting on for approval, by name suffix, with the evidence. A suffix,
#: because the server prefix is the org's (a connector named `Supabase` is `mcp__Supabase__execute_sql`).
KNOWN: dict[str, str] = {
    "__execute_sql": "measured waiting for approval in unattended sessions three times: rows 97, 114, 120 "
                     "(13 h to 34 h each, cost accruing)",
}

#: how a manifest routes a role to a tool: (port, field, value prefix, tool suffix). A role reaches the tool when its
#: contract needs the port (`needs.ports` or `optional_ports`) and the org's port is declared this way.
ROUTES: tuple[tuple[str, str, str, str], ...] = (
    ("prod_read", "method", "supabase-mcp", "__execute_sql"),
    ("checks", "executor", "supabase-mcp", "__execute_sql"),
)

#: what an org can decide about a prompt its roles will meet. `preapproved`: the operator has allowed the tool where
#: the role runs (a connector's tool policy, a routine's override) — recorded here, granted there, never by org-core.
#: `attended`: a person answers it, so the wait is expected. `refused`: the role must not call it, and says CANNOT
#: TELL where it would have — told in the role's own base (`refused_for`, rendered into the agent file's operator
#: boundary), and `org verify` says where that is in force (item `refused-prompts-are-not-enforced`).
DECISIONS = ("preapproved", "attended", "refused")


def _needs(contract: dict[str, Any]) -> tuple[set[str], list[str]]:
    needs = contract.get("needs") or {}
    ports = set(needs.get("ports") or []) | set(needs.get("optional_ports") or [])
    return ports, [str(t) for t in (needs.get("tools") or [])]


def _known(tool: str) -> str | None:
    return next((why for suffix, why in KNOWN.items() if tool.endswith(suffix)), None)


def reached(manifest: dict[str, Any], packages: dict[str, Any]) -> list[dict[str, str]]:
    """Every (role, tool) the manifest routes an enabled role to, where the tool is known to prompt — with the route
    that got it there and the evidence that it prompts. Sorted, one row per pair.

    Broken looks like: NumeroTech's shape (`prod_read.method: supabase-mcp`) reaches nothing for the verifier, or
    Lucille's (`ssh-psql-readonly`, `executor: psql`) reaches anything."""
    from .manifest import enabled_roles
    ports = manifest.get("ports") or {}
    out: dict[tuple[str, str], dict[str, str]] = {}
    for role in enabled_roles(manifest):
        pkg = packages.get(role)
        if pkg is None:
            continue
        needed_ports, needed_tools = _needs(getattr(pkg, "contract", {}) or {})
        for port, field, prefix, tool in ROUTES:
            decl = ports.get(port) or {}
            value = str(decl.get(field) or "") if isinstance(decl, dict) else ""
            if port in needed_ports and value.startswith(prefix):
                out.setdefault((role, tool), {"role": role, "tool": tool, "via": f"ports.{port}.{field}: {value}",
                                              "evidence": _known(tool) or ""})
        for tool in needed_tools:
            why = _known(tool)
            if why:
                out.setdefault((role, tool), {"role": role, "tool": tool, "via": "the role's contract (needs.tools)",
                                              "evidence": why})
    return [out[k] for k in sorted(out)]


def decision(manifest: dict[str, Any], role: str, tool: str) -> dict[str, Any] | None:
    """The manifest's decision covering this role's use of this tool: an entry in `prompts:` whose key names the tool
    (the same suffix either way round) and whose `roles`, when given, include the role."""
    for key, entry in (manifest.get("prompts") or {}).items():
        k = str(key)
        if not (tool.endswith(k) or k.endswith(tool)):
            continue
        if not isinstance(entry, dict):
            continue
        roles = entry.get("roles")
        if roles and role not in roles:
            continue
        return {"key": k, **entry}
    return None


def read(manifest: dict[str, Any], packages: dict[str, Any]) -> list[dict[str, Any]]:
    """`reached` with each row's decision attached (`None` when the manifest says nothing)."""
    return [{**r, "decision": decision(manifest, r["role"], r["tool"])} for r in reached(manifest, packages)]


def refused_for(manifest: dict[str, Any], role_id: str) -> list[dict[str, str]]:
    """The tools this role must not call: every `refused` decision whose `roles` include it — or, with no `roles`,
    every enabled role, since nothing narrowed the refusal. Empty for a role with none, so its files render as before.

    Broken looks like: a refusal scoped to the verifier reaches the reviewer's file, or an unscoped one skips a role."""
    from .manifest import enabled_roles
    out = []
    for key, entry in (manifest.get("prompts") or {}).items():
        if not isinstance(entry, dict) or entry.get("decision") != "refused":
            continue
        roles = entry.get("roles")
        if (roles and role_id not in roles) or (not roles and role_id not in enabled_roles(manifest)):
            continue
        by = ", ".join(str(entry[k]) for k in ("by", "at") if entry.get(k))
        out.append({"tool": str(key), "by": by, "note": str(entry.get("note") or "").strip().rstrip(".")})
    return sorted(out, key=lambda r: r["tool"])


#: the words the agent template renders for a refusal, and the words `org verify` looks for in the installed file
TOLD = "refused by this org: never call it"


def deny_rules(settings: dict[str, Any] | None) -> list[str]:
    """The `permissions.deny` entries in a parsed `.claude/settings.json` — org-core writes none (path (a) of the item
    was not taken), so any here are the org's own, and verify reports them as a second enforcement when one names the tool."""
    perms = (settings or {}).get("permissions") or {}
    deny = perms.get("deny") if isinstance(perms, dict) else None
    return [str(d) for d in deny] if isinstance(deny, list) else []


BROKEN = ("PROMPTS <role>: <tool> raises an approval prompt and this container has no one to answer it; "
          "the manifest does not say what to do about it")


def lines(rows: list[dict[str, Any]]) -> list[tuple[bool, str]]:
    """(ok, text) per reached pair — the words `org verify` and `org plan` print."""
    out = []
    for r in rows:
        d = r["decision"]
        if d is None:
            out.append((False, f"PROMPTS {r['role']}: {r['tool']} (via {r['via']}) raises an approval prompt and this "
                               f"container has no one to answer it; the manifest does not say what to do about it — "
                               f"{r['evidence']}. Decide it under `prompts:` ({' | '.join(DECISIONS)})"))
        else:
            by = ", ".join(str(d[k]) for k in ("by", "at") if d.get(k))
            out.append((True, f"{r['role']}: {r['tool']} is {d.get('decision')}" + (f" ({by})" if by else "")
                              + (f" — {d['note']}" if d.get("note") else "")))
    return out


__all__ = ["BROKEN", "DECISIONS", "KNOWN", "ROUTES", "TOLD", "decision", "deny_rules", "lines", "reached", "read", "refused_for"]
