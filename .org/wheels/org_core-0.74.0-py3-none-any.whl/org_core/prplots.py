"""Pull requests over time: the totals so far and the rate per day, for one org and for the fleet (the operator, 2026-10-09:
*"I want plots for rates and totals for PRs over time"*; item `the-command-center-plots-pull-request-rates-and-totals-over-time`).

The data is a RECORD, not a copy of the pull requests: per UTC day, how many were opened, how many merged and how many closed
without merging (`pr_daily`, in the facts, so `.org/tempo/facts-<date>.json` keeps it). A pull request is in exactly one of three
states — open, merged, closed (not merged) — and the plots draw the three apart (the operator, 2026-10-10: *"closed is not open nor
merged"*). `gather_pr_index` reads the 100 most-recently-updated pull requests, which reached back about 14 days on org-core
(2026-10-08), so it cannot draw a total since the start. `fetch` pages `pulls?state=all&sort=created&direction=desc&per_page=100`,
and runs ONCE A UTC DAY (the operator, 2026-10-10: *"Read history once a day"*; `due`): every other read, full lane or fast, only
recomputes the days since that read (`extend`) — the full lane from `catch_up`'s pages of the most-recently-updated pull requests,
the fast lane from the one index page it already takes — and says `stale` when what it read does not reach back to the start of the
full read's day, never an undercount. A stale record is drawn as stale: the page says the plot ends at the full read, in words.

Measured colours (dataviz `validate_palette.js`, bundled skills 2.1.295, 2026-10-09): merged = the healthy state, open/opened = in
motion, closed (not merged) = idle (`org_core/vocab.py`; no hue is defined here; closed is drawn dotted with a square marker, so it
is never told by its grey alone). Light `#2a78d6,#0ca30c`: ALL CHECKS PASS (tritan ΔE 6.2, so legal only with
secondary encoding). Dark `#3987e5,#3fbb3f`: FAIL lightness band (green 0.698); the pair is the page's own healthy/in-motion
pair, so it is kept and the plots never rely on colour: merged is a solid line with a filled marker, opened a dashed line with a
hollow one, bars are filled (merged) and outlined (opened), both are labelled at the line's end and written in a table.

Broken looks like: a total that does not equal GitHub's merged count for the repository, a day with no pull requests drawn as a gap
instead of `0`, an unread source drawn as an empty plot (it says `not checked`), a window shorter than asked not saying `since <date>`.
"""
from __future__ import annotations

import datetime as dt
import html
import json
from typing import Any, Callable

PAGE = 100
MAX_PAGES = 50           # 5,000 pull requests; past it the record says `since` and the plot says so
CATCH_UP_PAGES = 10      # the full lane's catch-up between daily reads: 1,000 updates since the read's day began, else `stale`
ZOOM_DAYS = 30
MEAN_DAYS = 7


def _day(iso: Any) -> str | None:
    if not iso:
        return None
    try:
        t = dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except ValueError:
        return None
    return (t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)).astimezone(dt.timezone.utc).date().isoformat()


def _stamp(iso: Any) -> str | None:
    """An ISO instant normalised to UTC, so two compare as strings."""
    try:
        t = dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except ValueError:
        return None
    return (t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)).astimezone(dt.timezone.utc).isoformat()


def _tally(rows: list[dict[str, Any]], opened: dict[str, int], merged: dict[str, int], closed: dict[str, int], since: str = "") -> None:
    """Count each pull request's events by UTC day: opened (created), merged, and closed without merging — a merged one is
    closed too on GitHub (`closed_at` set), so it counts as merged and never as closed."""
    for r in rows:
        o = _day(r.get("created_at") or r.get("opened_at"))
        m = _day(r.get("merged_at"))
        c = None if m else _day(r.get("closed_at"))
        for d, into in ((o, opened), (m, merged), (c, closed)):
            if d and d >= since:
                into[d] = into.get(d, 0) + 1


def fetch(slug: str, run: Callable[..., str], now: dt.datetime) -> dict[str, Any]:
    """The full paged read: every pull request of the repository, newest-created first, to a record of daily counts."""
    opened: dict[str, int] = {}
    merged: dict[str, int] = {}
    closed: dict[str, int] = {}
    pages, n, oldest, full = 0, 0, None, True
    while True:
        pages += 1
        rows = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=all&sort=created&direction=desc&per_page={PAGE}&page={pages}"], None) or "[]")
        rows = [r for r in rows if isinstance(r, dict) and r.get("number")]
        _tally(rows, opened, merged, closed)
        n += len(rows)
        if rows:
            oldest = _day(rows[-1].get("created_at"))
        if len(rows) < PAGE:
            break
        if pages >= MAX_PAGES:
            full = False
            break
    first = min([*opened, *merged, *closed], default=None)
    at = now.isoformat(timespec="seconds")
    return {"read": True, "at": at, "full_at": at, "through": now.astimezone(dt.timezone.utc).date().isoformat(), "pages": pages, "n": n,
            "first": first, "since": None if full else oldest, "opened": opened, "merged": merged, "closed": closed}


def due(rec: dict[str, Any] | None, now: dt.datetime) -> bool:
    """Whether the full paged read is due: once a UTC day. A record that was not read, that predates the closed series (0.60.16),
    or whose full read was on an earlier UTC day is due; one read today is not, stale or not (the day's catch-up covers that)."""
    if not rec or not rec.get("read") or "closed" not in rec:
        return True
    return str(rec.get("through") or "") < now.astimezone(dt.timezone.utc).date().isoformat()


def catch_up(rec: dict[str, Any], slug: str, run: Callable[..., str], now: dt.datetime) -> dict[str, Any]:
    """The full lane between daily reads: page the most-recently-updated pull requests back to the start of the full read's day
    (a few pages a day, not the ~20 of the whole history) and `extend` from them. Past `CATCH_UP_PAGES` it stops and `extend` says
    `stale`; a failed page keeps the record and says why."""
    start = f"{rec.get('through')}T00:00:00+00:00"
    rows: list[dict[str, Any]] = []
    try:
        for page in range(1, CATCH_UP_PAGES + 1):
            got = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=all&sort=updated&direction=desc&per_page={PAGE}&page={page}"], None) or "[]")
            got = [r for r in got if isinstance(r, dict) and r.get("number")]
            rows += got
            seen = [t for t in (_stamp(r.get("updated_at")) for r in got) if t]
            if len(got) < PAGE or (seen and min(seen) <= start):
                break
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        return dict(rec, stale=True, stale_why=f"the catch-up read failed — {str(e)[:120]}")
    return extend(rec, rows, now, complete=len(rows) % PAGE != 0)


def extend(rec: dict[str, Any] | None, idx: list[dict[str, Any]] | None, now: dt.datetime, *, complete: bool = False) -> dict[str, Any] | None:
    """Recompute the days from the last full read's day onward from `idx`, a list of pull requests newest-updated first: the fast
    lane's one index page, or `catch_up`'s pages. A list that does not reach back to the start of that day (a full page, oldest
    updated later) cannot say, so the record is kept as it was and marked `stale`. `complete` says the list is every pull request
    of the repository (its last page was short), which reaches any day."""
    if not rec or not rec.get("read") or not isinstance(idx, list) or "closed" not in rec:
        return rec
    d0 = str(rec.get("through") or "")
    if not d0:
        return rec
    # a full page reaches back only to its oldest update: it must reach the START of the read's day (00:00Z), not merely that day,
    # or the rows updated earlier the same day are missing and the day is silently undercounted
    start = f"{d0}T00:00:00+00:00"
    seen = [t for t in (_stamp(p.get("updated_at")) for p in idx) if t]
    if not complete and len(idx) >= PAGE and (not seen or min(seen) > start):
        return dict(rec, stale=True, stale_why=f"the {len(idx)} most recently updated pull requests do not reach back to {d0} 00:00Z")
    opened = {d: n for d, n in rec["opened"].items() if d < d0}
    merged = {d: n for d, n in rec["merged"].items() if d < d0}
    closed = {d: n for d, n in rec["closed"].items() if d < d0}
    _tally(idx, opened, merged, closed, since=d0)
    first = min([*opened, *merged, *closed], default=None)
    at = now.isoformat(timespec="seconds")
    return dict(rec, opened=opened, merged=merged, closed=closed, first=first, stale=False, stale_why=None, at=at, extended_at=at)


def unread(why: str) -> dict[str, Any]:
    return {"read": False, "why": why[:200]}


def series(rec: dict[str, Any], now: dt.datetime) -> dict[str, Any]:
    """Dense daily series from the first pull request to today (UTC): a day with none is 0, with running totals and 7-day means."""
    today = now.astimezone(dt.timezone.utc).date()
    first = dt.date.fromisoformat(rec["first"]) if rec.get("first") else today
    days = [(first + dt.timedelta(d)).isoformat() for d in range((today - first).days + 1)]
    o = [int(rec["opened"].get(d, 0)) for d in days]
    m = [int(rec["merged"].get(d, 0)) for d in days]
    c = [int((rec.get("closed") or {}).get(d, 0)) for d in days]

    def cum(v: list[int]) -> list[int]:
        out, s = [], 0
        for x in v:
            s += x
            out.append(s)
        return out

    def mean(v: list[int]) -> list[float]:
        return [sum(v[max(0, i - MEAN_DAYS + 1):i + 1]) / min(MEAN_DAYS, i + 1) for i in range(len(v))]
    co, cm_, cc = cum(o), cum(m), cum(c)
    # the three states at each day's end: every pull request opened so far is exactly one of open, merged, closed
    return {"days": days, "opened": o, "merged": m, "closed": c, "cum_opened": co, "cum_merged": cm_, "cum_closed": cc,
            "open": [a - b - x for a, b, x in zip(co, cm_, cc)],
            "mean_opened": mean(o), "mean_merged": mean(m), "mean_closed": mean(c)}


def combine(recs: list[dict[str, Any]]) -> dict[str, Any]:
    """The fleet's record: the daily counts of every org read, summed."""
    got = [r for r in recs if r.get("read")]
    if not got:
        return unread("no org's pull-request history was read")
    opened: dict[str, int] = {}
    merged: dict[str, int] = {}
    closed: dict[str, int] = {}
    for r in got:
        for src, dst in ((r["opened"], opened), (r["merged"], merged), (r.get("closed") or {}, closed)):
            for d, n in src.items():
                dst[d] = dst.get(d, 0) + n
    since = sorted(r["since"] for r in got if r.get("since"))
    stale = [r for r in got if r.get("stale")]
    return {"read": True, "at": max(r["at"] for r in got), "orgs_read": len(got), "orgs": len(recs), "n": sum(r.get("n", 0) for r in got),
            "first": min([*opened, *merged, *closed], default=None), "since": since[-1] if since else None,
            "stale": bool(stale), "stale_orgs": len(stale), "stale_at": min((str(r["at"]) for r in stale), default=None),
            "opened": opened, "merged": merged, "closed": closed}


# --- drawing ----------------------------------------------------------------------------------------------

W, H, PL, PR_, PT, PB = 400, 150, 34, 100, 10, 22


def _scale(lo: float, hi: float, a: float, b: float) -> Callable[[float], float]:
    span = (hi - lo) or 1
    return lambda v: a + (v - lo) / span * (b - a)


def _pts(xs: list[float], ys: list[float]) -> str:
    return " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))


def _axes(days: list[str], ymax: float, x: Callable[[float], float], y: Callable[[float], float]) -> str:
    out = []
    for v in sorted({0, round(ymax / 2), round(ymax)}):
        out.append(f"<line class='prg' x1='{PL}' x2='{W - PR_}' y1='{y(v):.1f}' y2='{y(v):.1f}'/>"
                   f"<text class='prt' x='{PL - 4}' y='{y(v) + 3:.1f}' text-anchor='end'>{v}</text>")
    n = len(days)
    for i, anchor in ((0, "start"), (n - 1, "end")):
        out.append(f"<text class='prt' x='{x(i):.1f}' y='{H - 6}' text-anchor='{anchor}'>{days[i][5:]}</text>")
    return "".join(out)


def _end_labels(ls: list[tuple[float, str, str]]) -> str:
    """Direct labels at a line's end. Two at nearly the same height are pushed apart so neither hides the other."""
    ls = sorted(ls)
    ys = [l[0] for l in ls]
    for i in range(1, len(ys)):                     # push each down from the one above it, then the run back up inside the plot
        ys[i] = max(ys[i], ys[i - 1] + 11)
    over = ys[-1] - (H - PB + 4) if ys else 0
    if over > 0:
        ys = [y - over for y in ys]
    return "".join(f"<text class='prl' x='{W - PR_ + 6}' y='{y + 3:.1f}'>{html.escape(t)}</text>" for y, (_, _, t) in zip(ys, ls))


def _marker(cls: str, cx: float, cy: float, r: float = 3.5) -> str:
    """Each state's own end marker, so the three are told apart by shape as well as by line and colour: open a hollow circle,
    merged a filled circle, closed a square."""
    if cls == "prc":
        return f"<rect class='prdot prc' x='{cx - r:.1f}' y='{cy - r:.1f}' width='{2 * r:.1f}' height='{2 * r:.1f}'/>"
    return f"<circle class='prdot {cls}{' hollow' if cls == 'pro' else ''}' cx='{cx:.1f}' cy='{cy:.1f}' r='{r}'/>"


def _totals_svg(s: dict[str, Any], lo: int) -> str:
    """The three states at each day's end: open now, merged so far, closed without merging so far — never one line that holds
    the closed ones in with the opened (the operator, 2026-10-10)."""
    days = s["days"][lo:]
    lines = (("pro", "open", s["open"][lo:]), ("prm", "merged", s["cum_merged"][lo:]), ("prc", "closed", s["cum_closed"][lo:]))
    ymax = max([v for _, _, vs in lines for v in vs] + [1])
    x = _scale(0, max(len(days) - 1, 1), PL, W - PR_)
    y = _scale(0, ymax, H - PB, PT)
    xs = [x(i) for i in range(len(days))]
    return (f"<svg viewBox='0 0 {W} {H}' class='prsvg' role='img' aria-label='pull requests open, merged and closed without merging, by day'>"
            f"{_axes(days, ymax, x, y)}"
            + "".join(f"<polyline class='prline {c}' points='{_pts(xs, [y(v) for v in vs])}'/>" for c, _, vs in lines)
            + "".join(_marker(c, xs[-1], y(vs[-1])) for c, _, vs in lines)
            + _end_labels([(y(vs[-1]), c, f"{t} {vs[-1]}") for c, t, vs in lines]) + "</svg>")


def _rates_svg(s: dict[str, Any], lo: int) -> str:
    days = s["days"][lo:]
    ser = (("pro", "opened", s["opened"][lo:], s["mean_opened"][lo:]), ("prm", "merged", s["merged"][lo:], s["mean_merged"][lo:]),
           ("prc", "closed", s["closed"][lo:], s["mean_closed"][lo:]))
    ymax = max([v for _, _, vs, _ in ser for v in vs] + [1])
    n = len(days)
    x = _scale(0, max(n - 1, 1), PL, W - PR_)
    y = _scale(0, ymax, H - PB, PT)
    bw = max(0.5, min(5.0, (W - PR_ - PL) / max(n, 1) / 3.4))
    bars = []
    for i in range(n):
        for k, (cls, _, vs, _) in enumerate(ser):
            if vs[i]:
                bars.append(f"<rect class='prbar {cls}' x='{x(i) + (k - 1.5) * bw:.1f}' y='{y(vs[i]):.1f}' width='{bw:.1f}' height='{y(0) - y(vs[i]):.1f}'/>")
    xs = [x(i) for i in range(n)]
    return (f"<svg viewBox='0 0 {W} {H}' class='prsvg' role='img' aria-label='pull requests opened, merged and closed without merging per day with a 7-day mean'>"
            f"{_axes(days, ymax, x, y)}{''.join(bars)}"
            + "".join(f"<polyline class='prline {c}' points='{_pts(xs, [y(v) for v in mv])}'/>" for c, _, _, mv in ser)
            + _end_labels([(y(mv[-1]), c, f"{t} {mv[-1]:.1f}/day") for c, t, _, mv in ser]) + "</svg>")


def _legend() -> str:
    return "".join(f"<span class='prleg'><svg width='26' height='10' aria-hidden='true'><line class='prline {c}' x1='1' x2='25' y1='5' y2='5'/>"
                   f"{_marker(c, 13, 5, 3)}</svg> {t}</span>"
                   for c, t in (("pro", "open · per day, opened"), ("prm", "merged"), ("prc", "closed, not merged")))


def stale_html(rec: dict[str, Any], tz: str | None) -> str:
    """A stale record in words, where the plot is: the days since its last full read are not counted, so the plot ends there and
    the page says so first — never the last full read presented as current (Reed on #165)."""
    from .clock import for_operator
    if not rec.get("stale"):
        return ""
    at = str(rec.get("stale_at") or rec.get("at") or "")     # the fleet's: the earliest a stale org was counted to
    when = html.escape(for_operator(dt.datetime.fromisoformat(at), tz)) if at else "an earlier read"
    who = f"{rec['stale_orgs']} of {rec['orgs_read']} orgs: " if rec.get("stale_orgs") and rec.get("orgs_read") else ""
    why = f" — {html.escape(str(rec['stale_why']))}" if rec.get("stale_why") else ""
    return (f"<p class='prstale' role='status'><span class='sg s-idle g-idle' aria-hidden='true'></span><b>stale</b> — {who}counted to "
            f"{when}; what happened since is not in these plots{why}. Every full-lane read tries to catch up again, and the whole history is "
            "re-read once after 00:00Z.</p>")


def section_html(rec: dict[str, Any] | None, now: dt.datetime, *, scope: str = "", note: str = "", tz: str | None = None) -> str:
    """The Work view's *Pull requests over time*: totals and rates, since the first pull request and over the last 30 days, and a table.
    `rec` is an org's `pr_daily` or `combine`'s; an unread one says *not checked* and why, never an empty plot."""
    from .clock import for_operator
    head = "<div class='sechead'><h2>Pull requests over time</h2>"
    if not rec or not rec.get("read"):
        why = (rec or {}).get("why") or "the pull-request history was not read in this reading"
        return f"<section class='sec prplots'>{head}<p>{html.escape(scope)}</p></div><div class='prbody'><p class='prnc'><b>not checked</b> — {html.escape(str(why))}</p></div></section>"
    s = series(rec, now)
    n = len(s["days"])
    lo = max(0, n - ZOOM_DAYS)
    zoomed = n > ZOOM_DAYS          # a history of 30 days or less is its own zoom: drawn once, not twice
    notes = []
    if rec.get("since"):
        notes.append(f"read back only to {rec['since']} (the page limit) — a total since the first pull request, not drawn")
    if rec.get("orgs") and rec["orgs_read"] < rec["orgs"]:
        notes.append(f"{rec['orgs_read']} of {rec['orgs']} orgs read")
    if note:
        notes.append(note)
    if "closed" not in rec:
        notes.append("this record predates the closed series: a pull request closed without merging is counted as open until the next full read")
    read = for_operator(dt.datetime.fromisoformat(str(rec["at"])), tz) if rec.get("at") else ""
    full = (f" · full history read {html.escape(for_operator(dt.datetime.fromisoformat(str(rec['full_at'])), tz))}, once a UTC day"
            if rec.get("full_at") and rec.get("full_at") != rec.get("at") else "")
    sub = (f"<p>{html.escape(scope)}Open, merged and closed without merging, by UTC day"
           + (f"; a day ends at 00:00Z, which is not midnight in {html.escape(tz)}" if tz else "")
           + f". Since {s['days'][0]} · counted to {html.escape(read)}{full}.</p>")
    rows = "".join(f"<tr><td>{d}</td><td>{s['opened'][i]}</td><td>{s['merged'][i]}</td><td>{s['closed'][i]}</td>"
                   f"<td>{s['open'][i]}</td><td>{s['cum_merged'][i]}</td><td>{s['cum_closed'][i]}</td></tr>"
                   for i, d in list(enumerate(s["days"]))[lo:][::-1])
    cell = lambda title, svg: f"<figure class='prfig'><figcaption>{title}</figcaption>{svg}</figure>"
    return (f"<section class='sec prplots'>{head}{sub}</div>"
            f"<div class='prbody'>{stale_html(rec, tz)}<div class='prleghd'>{_legend()}<span class='prtot'>{s['cum_opened'][-1]} opened: "
              f"{s['open'][-1]} open, {s['cum_merged'][-1]} merged, {s['cum_closed'][-1]} closed</span></div>"
            + (f"<p class='prnc'>{html.escape('; '.join(notes))}</p>" if notes else "")
            + "<div class='prgrid'>"
            + cell(f"By state · since {s['days'][0]}", _totals_svg(s, 0)) + (cell(f"By state · last {ZOOM_DAYS} days", _totals_svg(s, lo)) if zoomed else "")
            + cell(f"Per day, 7-day mean · since {s['days'][0]}", _rates_svg(s, 0)) + (cell(f"Per day, 7-day mean · last {ZOOM_DAYS} days", _rates_svg(s, lo)) if zoomed else "")
            + "</div><details class='prtable'><summary>The last 30 days as a table</summary><table><thead><tr><th>day (UTC)</th><th>opened</th><th>merged</th>"
              f"<th>closed, not merged</th><th>open at day's end</th><th>merged, total</th><th>closed, total</th></tr></thead><tbody>{rows}</tbody></table></details></div></section>")


# the colours are the vocabulary's (`org_core/vocab.py`): merged is healthy, open is in motion, closed unmerged is idle — no hue here
CSS = """
.prbody{padding:12px 18px 16px}
.prplots .prleghd{display:flex;flex-wrap:wrap;gap:4px 18px;align-items:center;margin:2px 0 8px;font-size:12px;color:var(--ink-2)}
.prleg{display:inline-flex;align-items:center;gap:6px}.prtot{margin-left:auto;font-weight:600;color:var(--ink)}
.prgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:10px 16px}
.prfig{margin:0;padding:8px 10px;border:1px solid var(--border);border-radius:8px;background:var(--surface)}
.prfig figcaption{font-size:12px;color:var(--ink-2);margin-bottom:2px}
.prsvg{width:100%;height:auto;display:block}
.prg{stroke:var(--border);stroke-width:1}.prt{fill:var(--muted);font-size:9.5px}
.prl{font-size:9.5px;fill:var(--ink)}
.prline{fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.prline.pro{stroke:var(--c-live);stroke-dasharray:5 3}.prline.prm{stroke:var(--c-ok)}
.prdot{stroke-width:2}.prdot.pro{stroke:var(--c-live);fill:var(--surface)}.prdot.prm{stroke:var(--c-ok);fill:var(--c-ok)}
.prline.prc{stroke:var(--c-idle);stroke-dasharray:1.5 3}.prdot.prc{stroke:var(--c-idle);fill:var(--c-idle)}
.prbar.prm{fill:var(--c-ok);opacity:.85}.prbar.pro{fill:var(--surface);stroke:var(--c-live);stroke-width:1.2}
.prbar.prc{fill:var(--c-idle);opacity:.7}
.prstale{margin:0 0 8px;padding:6px 10px;border:1px solid var(--border);border-radius:6px;font-size:12.5px;display:flex;gap:8px;align-items:center}
.prplots .sechead h2::before{--m:var(--i-pr);display:inline-block}
.prnc{margin:4px 0 8px;font-size:12px;color:var(--ink-2)}
.prtable{margin-top:10px;font-size:12px}.prtable summary{cursor:pointer;color:var(--ink-2)}
.prtable table{border-collapse:collapse;margin-top:6px}.prtable td,.prtable th{padding:2px 12px 2px 0;text-align:left;font-variant-numeric:tabular-nums}
"""
