"""Role packages (SPEC.md §3): discovery and the contract each one ships."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from . import ROLE_IDS

ROLES_DIR = Path(__file__).parent / "roles"

# file kind -> where it lands in an installed repo
TARGETS = {
    "agent": ".claude/agents/{role}.md",
    "skill": ".claude/skills/{role}/SKILL.md",
}


def parse_version(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


@dataclass
class RolePackage:
    id: str
    dir: Path
    contract: dict[str, Any]
    addenda: dict[str, Path] = field(default_factory=dict)   # kind -> agent.base.md / skill.base.md, rendered after the core
    record_schema: dict[str, Any] | None = None

    KINDS = ("agent", "skill")

    @property
    def version(self) -> str:
        return str(self.contract.get("version", "0"))

    def migration_for(self, installed_version: str) -> str | None:
        """The migration to apply when upgrading an install at `installed_version` to this package, if any."""
        inst = parse_version(installed_version)
        for at, kind in (self.contract.get("migrations") or {}).items():
            if inst < parse_version(at) <= parse_version(self.version):
                return str(kind)
        return None

    def defaults(self) -> dict[str, Any]:
        """The manifest-shaped defaults this package contributes (layered under org.yaml)."""
        c = self.contract
        d: dict[str, Any] = {"name": c.get("display", self.id)}
        rt = c.get("runtime", {})
        if "default" in rt:
            d["runtime"] = rt["default"]
        cad = c.get("cadence", {})
        for k in ("default", "label", "tolerance", "period_hours"):
            if k in cad:
                d[{"default": "cadence", "label": "cadence_label"}.get(k, k)] = cad[k]
        for k in ("model", "effort", "cap", "max_concurrent"):
            if k in c:
                d[k] = c[k]
        rep = c.get("report") or {}
        if (rep.get("per_task") or rep.get("per_account")) and rep.get("key"):
            # a record per task (`roles/planner/<topic>`), never a `last-run` the doctor would read as a recurring key
            # nothing refreshes (check 7) — the planner runs once per conversation (SPEC §16 decision 14)
            # — or per account (`roles/launcher/<account>/last-run`): several launchers run side by side, one per account
            d["report_key"] = rep["key"]
        if isinstance(c.get("outward"), dict):
            # an outward role's pipeline and floor, read by the doctor's checks 1 and 15 (item `outward-roles-record-shape-and-clock`)
            d["outward"] = dict(c["outward"])
        return d

    def target(self, kind: str) -> str:
        return TARGETS[kind].format(role=self.id)


def discover(roles_dir: Path = ROLES_DIR) -> dict[str, RolePackage]:
    """Every role package on disk, in cast order. A package with no contract is an error, not a skip."""
    found: dict[str, RolePackage] = {}
    for role_id in ROLE_IDS:
        d = roles_dir / role_id
        if not d.is_dir():
            continue
        contract_path = d / "role.yaml"
        if not contract_path.exists():
            raise FileNotFoundError(f"role package {role_id} has no role.yaml")
        contract = yaml.safe_load(contract_path.read_text()) or {}
        if contract.get("id") != role_id:
            raise ValueError(f"{contract_path}: id is {contract.get('id')!r}, directory is {role_id!r}")
        pkg = RolePackage(id=role_id, dir=d, contract=contract)
        for kind, fname in (("agent", "agent.base.md"), ("skill", "skill.base.md")):
            p = d / fname
            if p.exists():
                pkg.addenda[kind] = p
        for key in ("description", "tools", "skill_description", "summary", "never", "boundary", "report"):
            if key not in contract:
                raise ValueError(f"{contract_path}: contract lacks `{key}`, which the core templates render")
        from .outward_connectors import contract_problems as connector_problems
        from .outward_record import contract_problems
        bad = contract_problems(contract) + connector_problems(contract)
        if bad:
            raise ValueError(f"{contract_path}: " + "; ".join(bad))
        rs = d / "record.schema.json"
        if rs.exists():
            pkg.record_schema = json.loads(rs.read_text())
        found[role_id] = pkg
    return found


def runtime_problems(manifest: dict[str, Any], packages: dict[str, RolePackage]) -> list[str]:
    """Every enabled role the manifest binds to a runtime its package does not allow, one line each (SPEC §3,
    `runtime.allowed`: "refuse an install that binds a role to a runtime that cannot hold what it needs").

    Nothing read the field before 0.43.0: measured 2026-09-25 on 0.42.4, a manifest binding the CEO to `fresh` passed
    `org validate` though §5's table says a `fresh` routine cannot spawn or archive sessions — and the operator's
    ruling on decision 14 (2026-09-23) is *"CEO should always be able to spawn sessions"*.

    Broken looks like: [] for a layered manifest with `roles.ceo.runtime: fresh`, or a line for either shipped
    example manifest."""
    out: list[str] = []
    for role_id, entry in (manifest.get("roles") or {}).items():
        pkg = packages.get(role_id)
        if pkg is None or not entry.get("enabled", True):
            continue
        allowed = list((pkg.contract.get("runtime") or {}).get("allowed") or [])
        runtime = entry.get("runtime")
        if runtime and allowed and runtime not in allowed:
            out.append(f"roles/{role_id}/runtime: `{runtime}` is not one {pkg.contract.get('display', role_id)}'s package allows "
                       f"({', '.join(allowed)}) — SPEC §3 refuses an install that binds a role to a runtime that cannot hold what it needs")
    return out


def defaults_by_role(packages: dict[str, RolePackage]) -> dict[str, dict[str, Any]]:
    return {rid: pkg.defaults() for rid, pkg in packages.items()}
