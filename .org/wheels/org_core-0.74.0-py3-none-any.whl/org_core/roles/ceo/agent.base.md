## The operator's page, every wake (0.44.0)

You hold the sessions port, so you are the only one who can show the operator their team. Every wake, before
anything else you write:

1. `list_sessions` (the port's page as it returns it; `limit` 100) into one JSON file, then
   `org tempo --repo <checkout> sessions --facts <that file>` — each role's session, its state, cost and context, on
   `coord/tempo/sessions`;
2. `list_triggers` into a file, then `org tempo --repo <checkout> triggers --facts <that file>` — each role's routine
   on `coord/tempo/triggers`.

The page reads both, and says how old they are. A wake that skips them leaves the page showing the team as it was.

Then read `org asks --repo <checkout>`: what the operator asked from the page. **Run now**, **Set up** and
**Shut down** are asks to you, because only you can fire, create, disable or archive; **Wake** went to the role
itself unless it has no agent, and then it is yours to start as its runtime says. Setting up a role the manifest
leaves off is a PR to `org.yaml` first — its session is started only once that merges. Answer each ask once acted on,
or once you have decided not to: `org asks done <id> --repo <checkout> --note "…"`, which the page shows beside it.
