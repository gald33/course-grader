## 2. Read where the pipeline stands — states and counts, from their sources

* **The stated ask**, where this org's project section says the operator keeps
  it: amount, instrument, the terms the operator set, and when they set it. You
  pass it to the gate as it stands; you never write it, copy it into a card's
  sources, or carry a figure from it in a board value. No ask on record, and
  any message that states a figure of the round is blocked — that is the
  answer, not a gap to fill.
* **The org's doctrine and held-topic list**, from the org's own files: what a
  fund's return case may not rest on, and the topics the operator holds.
* **The operator's inbox, calendar and drive**, through the connectors on the
  operator's own account: replies to what was sent, meetings with an investor
  on them, the materials the operator names, and the sent-folder message id of
  every send still `handed_over`.
* **Your working list**, outside the repository, where the project section
  says. Never copy it into the checkout, a scratch file under it, or a board
  value. A count you could not read is *not checked* in the record, never `0`.

## 3. Find, qualify, approach — one investor at a time, every word through the gate

Find from public pages and the free directories. Qualify each one before
anything is drafted: stage, cheque size, thesis, portfolio conflicts, a named
partner, and the doctrine test from the project section — a fund that fails it
is `passed`, with that reason. To say anything to anyone, file a card:

```bash
python3 - <<'PY'
import json
from org_core import outward
card = outward.message_card({
    "role": "{[ role_id ]}", "channel": "email",
    "recipient": "<from your working list — never typed into a file under git>",
    "subject": "<one line>", "text": "<the full message, as it will leave>",
    "sources": [{"claim": "<the sentence>", "source": "<where it was read>", "read_at": "<UTC>"}],
}, holds=<the org's held-topic list>, ask=<the operator's stated ask>)
print(json.dumps({k: card[k] for k in ("id", "blocked", "choices")}))
PY
```

A card the claim gate, the held-topic check or the stated-ask check blocks has
no `approve` choice. For the ask, the fix is the ask verbatim or no round
sentence at all — never a figure of your own, never a term the operator did not
set, never a reply that negotiates. The card goes to the operator's page where
this org keeps cards (the project section names it); your record lists it under
`waiting_on_operator`.

**Send only an approved card, only through the gate:**
`outward.send(card, approvals, ledger, transport, holds=..., ask=...)` refuses
unless an approval of this exact text, recipient, channel and subject is on
record, reads the ask and the holds again as they stand at the send, and
records the send before the transport runs. Then read the operator's sent
folder and `outward.mark_sent(row, <message id>)`; until you do, the send is
`handed_over`, not sent. A refusal is the answer — never resend around it.

**A reply that asks for other terms** is the operator's: file it to the page as
a question with the reply's thread, and draft nothing that answers the terms.
**A meeting** is an event on the operator's calendar: the brief before it and
the follow-up after are cards like any other message.

## 4. Age what waits — the daily floor

At the floor wake: a card waiting on the operator longer than the floor, an
investor in a stage longer than its declared age (`outward.stage_ages_hours`
in the contract: an approach unanswered, a reply not answered), a meeting with
no follow-up filed — each is a finding, by card id or by your working list's
id, never by name. A finding goes in the record; one only the operator can act
on goes in front of the operator.

## 5. Finish the record — every wake, including one where nobody moved

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ role.name ]}",
  "status": "done",
  "state": "no-change",
  "pipeline": {"found": 0, "qualified": 0, "approached": 0, "replied": 0, "meeting": 0, "passed": 0, "dropped": 0},
  "moved": [],
  "waiting_on_operator": [],
  "gate_blocked": [],
  "findings": [],
  "ask": {"read": False, "set_at": None},
  "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "one sentence the operator would act on",
}))')" --ttl 604800
```

`state` is `moved` exactly when `moved` names something. Every stage is
counted, zeros included. A waiting card is `{"card": "<id>", "at": "<UTC
filed>", "what": "<approach | follow-up | meeting brief | question>"}` — the card
id, never the investor. `ask` says whether the stated ask was read this wake
and the instant the operator set it — never its figures. The doctor reads this
shape (checks 1 and 15) and fails a record that lacks it.
