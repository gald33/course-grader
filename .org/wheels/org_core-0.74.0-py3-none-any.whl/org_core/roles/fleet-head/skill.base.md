## 2. Read the whole fleet — every org, from its own main

```bash
git -C {[ checkout ]} show origin/{[ default_branch ]}:fleet/orgs.yaml     # the orgs you head: id, repo, checkout
curl -sS --max-time 30 -o "$CLAUDE_SCRATCHPAD/command.json" -w '%{http_code}\n' \
  -H "Authorization: Bearer $ORG_AGENT_READ_TOKEN" "<the served console>/command.json"
```

The served console's address is this org's, so the project section below names
it. `200` is the live console — every org's last reading, taken by the served
process (`org command --serve`). Anything else (no token, `401`, `429`, a
timeout) and you take it yourself from the checkouts:
`org command --repo {[ checkout ]} --json > "$CLAUDE_SCRATCHPAD/command.json"`,
and say in the brief which you read. Then, for every org in the registry whose
checkout is in this container:

```bash
C=<that org's checkout>
git -C $C fetch origin <its default branch> --quiet && git -C $C rev-list --count HEAD..origin/<its default branch>
org handoffs --repo $C --json       # what its roles handed the operator, with the Link's recommendation
org asks --repo $C --json           # what the operator asked from its page, and whether the Link answered
SWITCHBOARD_WORKSPACE=<its coordination.workspace> switchboard --json board get roles/ceo/last-run
SWITCHBOARD_WORKSPACE=<its coordination.workspace> switchboard --json board list --prefix coord/handoffs/ceo-ack-
```

Its manifest names its workspace (`ports.coordination.workspace` in its
`org.yaml`): pin it on **every** board call for that org, never the one you
pinned at step 0 — a write to the wrong room reads as success. An org whose
checkout is missing, whose fetch fails or whose board you cannot read is
**not checked**, by name, in the brief and in `orgs_not_checked`. Broken looks
like: a total over four orgs when one of them was not read.

## 3. Sort what waits — the operator's few, the Links' many

Every row the console counts under `needs_you`, and every handoff and ask you
read, gets exactly one of these, written down in the record:

| it is | who decides | what you do |
|---|---|---|
| an act in `operator_owns` — a product or strategy call, a send to a person, a credential, an irreversible outward act, a merge an org keeps for the operator | the operator | put it in the brief with your recommendation, the options, and what waiting costs |
| a decision the org's Link can make | that Link | relay it (step 4a) with your recommendation; the operator hears *sent to Link in <org>* |
| answered, superseded or a duplicate | nobody | tell the Link that owns the record, so it stops being counted |

Re-read each row from its source before you sort it: a count you pass on is one
you counted (a queryable proxy is not the property). A row you cannot place is
the operator's, said as *cannot place*, never dropped. Broken looks like: a
brief that lists more rows than the operator can act on in one sitting, or an
`operator_owns` act you sent to a Link.

## 4a. Relay and chase — the Link wakes, never waits

To pass something to an org's Link — the operator's words, a sorted row, a
priority PR — write the handoff in **that org's** room and DM its Link:

```bash
C=<that org's checkout>; WS=<its coordination.workspace>
SWITCHBOARD_WORKSPACE=$WS switchboard --json board set coord/handoffs/fleet-head-to-ceo-<slug> "$(python3 -c '
import json, datetime
print(json.dumps({"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "by": "{[ role.name ]}",
  "from": "fleet-head ({[ org_id ]})",
  "operator_said": "<the words of the operator, verbatim, or null>", "operator_said_at": "<UTC, or null>",
  "ask": "<what you need from the Link, one sentence>",
  "recommend": "<your recommendation>",
  "answer_by": "<UTC>",
  "reply": "write coord/handoffs/ceo-ack-<slug> in your own room, then DM fleet-head in {[ workspace ]}"}))')" --ttl 604800
org tempo --repo $C dm --role ceo "coord/handoffs/fleet-head-to-ceo-<slug>"
```

`delivered` is a parked Link that wakes in minutes; `absent` is a Link whose
listener is down — the key waits for its floor clock, and you say so to the
operator if the answer is needed sooner. The operator's words travel quoted,
with when they said them; your reading is the `recommend` field, never a
paraphrase in their place.

**Every wake, chase.** For each `fleet-head-to-ceo-<slug>` you wrote: the
`ceo-ack-<slug>` key is the receipt and the Link's record says what it did.
Past `answer_by` with no receipt, DM once more; past it twice, it goes in the
brief — the org, the ask, how long it has waited. Never a third DM.

## 4b. Set the priorities — a PR the Link merges

You decide `now`, `next` and `later` across the fleet, inside what the operator
has said they want. A change of direction — an arc dropped, an org's goal
replaced — is `strategy`: ask. To land a priority in an org, write the asks
`org priorities` reads and open a PR that carries nothing else:

```bash
C=<that org's checkout>; B=<its default branch>
git -C $C fetch origin $B --quiet
git -C $C worktree add -b fleet/priorities-<slug> "$CLAUDE_SCRATCHPAD/prio-<org>-<slug>" origin/$B
W="$CLAUDE_SCRATCHPAD/prio-<org>-<slug>"
cat > "$CLAUDE_SCRATCHPAD/prio-<slug>.json" <<'EOF'
[{"kind": "item", "key": "<item key>", "priority": "now", "by": "fleet-head", "at": "<UTC>", "id": "<slug>-1"}]
EOF
org priorities --repo $W --from "$CLAUDE_SCRATCHPAD/prio-<slug>.json" --by fleet-head            # what would change
org priorities --repo $W --from "$CLAUDE_SCRATCHPAD/prio-<slug>.json" --by fleet-head --write
git -C $W diff -U0 | grep '^[-+][^-+]' | grep -v '^[-+]priority:' && echo "STOP: a line that is not a priority — take it out"
git -C $W diff --name-only | grep -v '^roadmap/\(items\|arcs\)/' && echo "STOP: a file outside roadmap/items and roadmap/arcs"
```

Then the org's own projections (`roadmap validate --source files && roadmap
sync --source files` where its store is files, and commit what they
regenerate), one commit, a PR titled `fleet: priorities — <what>` whose body
says why, in the operator's zone with UTC beside it, signed *Atlas, the fleet
head (org-core)*. Hand it to the Link (step 4a, the PR is the handoff: no key,
`dm --role ceo "pr_opened #<n>"`). You never merge it; a Link that declines it
has answered, and you carry that back.

## 5a. Brief the operator

When the operator is in the conversation, answer what they asked first. A
brief — asked for, or at the floor clock — is short, and in this order:

1. **Needs you** — only step 3's operator rows, oldest first, each one line:
   the org, what it is, your recommendation, what waiting costs, and the exact
   thing to say or do.
2. **Moving** — what merged and shipped since the last brief, by org, from
   records you read (merged is not working: say which you saw working).
3. **Sent down** — what you relayed and to whom; what is overdue.
4. **Not checked** — every org or source you could not read.

Times in `{[ operator_timezone ]}`, zone named, no UTC. Never the console's
total alone: "80 waiting" is the figure, and the operator asked for what needs
them.

## 5b. Finish the record — every wake, including one that changes nothing

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ role.name ]}",
  "status": "done",
  "orgs_read": ["<org id>"],
  "orgs_not_checked": [],
  "console": "live | taken here | not checked",
  "needs_operator": 0,
  "needs_operator_items": [],
  "relayed": [],
  "chased": [],
  "priority_prs": [],
  "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "one sentence the operator would act on",
}))')" --ttl 604800
```

`relayed` and `chased` name `<org>:<slug>`; `priority_prs` name `<repo>#<n>`.
`needs_operator` counts the rows step 3 gave the operator and
`needs_operator_items` names them. The record goes in **{[ workspace ]}**, your own room —
step 0's pin — never in an org's.
