## 2. Which account, which pool — before any other act

```bash
git -C {[ checkout ]} fetch origin {[ default_branch ]} --quiet
git -C {[ checkout ]} show origin/{[ default_branch ]}:fleet/accounts.yaml > "$CLAUDE_SCRATCHPAD/accounts.yaml"
git -C {[ checkout ]} show origin/{[ default_branch ]}:fleet/orgs.yaml > "$CLAUDE_SCRATCHPAD/orgs.yaml"
org pool account --repo {[ checkout ]}       # this container's account label; `unmapped` (exit 1) when its uuid is in no entry
```

Read your entry in `fleet/accounts.yaml`: its `pool`, and `launcher: true`.
`unmapped`, or `launcher: false` (gald33, ruling 4), and you serve nothing this
wake: write the record (step 5) with `account` as read, `headroom: "not
checked"`, and the reason in `blocked`. Your pool's orgs are the entries of
`fleet/orgs.yaml` with that `pool`. Broken looks like: a spawn from an account
the registry does not list, or a request served for another pool.

## 3a. Read the account — headroom, sessions, routines

Call `list_sessions` on your own account and page it with `after_id` until
`has_more` is false; keep each session's id, status, title, tags and
`rate_limit_info` status. Then `list_triggers` the same way, keeping `id`,
`name`, `creator`, `enabled`, `cron_expression` and `persistent_session_id`.
A page you could not read makes the listing `complete: false`, said in the
record as `partial` — never a count over pages you never saw.

**Headroom** is the status this account reads now: the `rate_limit_info`
status the most recent session carries, read this wake. No session to read it
from, a failed call, or a status other than `allowed` is no headroom — you
claim nothing (step 4b) and say which in the record. Broken looks like: a
`headroom` field copied from an earlier wake, or a claim made on a warning.

## 3b. Publish the listing — names, never values

```bash
for repo in <each pool org's repo, from orgs.yaml>; do
  gh api "repos/$repo/contents/org.yaml" -H "Accept: application/vnd.github.raw" > "$CLAUDE_SCRATCHPAD/manifest-${repo//\//-}.yaml"
done
org pool secrets --repo {[ checkout ]} $(for f in "$CLAUDE_SCRATCHPAD"/manifest-*.yaml; do printf -- '--manifest %s ' "$f"; done)
```

That is one file per org read over the API — the manifest, never a checkout
and never code: a launcher reads no repo (ruling 3). `org pool secrets` prints
`{declared, held, missing}`: the variable names the manifests declare, which of
them this environment carries, and which it lacks. It reads names only, and
returns no name nobody declared. **Never print the environment, and never put
a value in any file, record or message** (ruling 14). An org whose manifest you
could not read is named in the record as not checked, and its names are not in
`declared`.

The canary is the cross-account reach: `board` is `ok` when
`switchboard --json board list --prefix "coord/pool/<pool>/"` answered in
{[ workspace ]}, else the error in words; `roadmap` is `ok` when `roadmap ready`
answered, else the error. Then write the listing, check it, and publish it:

```bash
L="$CLAUDE_SCRATCHPAD/listing.json"     # {at, by, account, pool, claude_account, sessions{complete,count,headroom,items}, routines{complete,count,items}, secrets, canary}
org pool check --repo {[ checkout ]} --kind listing "$L" && \
  switchboard --json board set "accounts/<account>/listing" "$(cat "$L")" --ttl 604800
```

`check` refuses a names list with anything but a variable name in it, a
`held` name no org declared, and a count that is not the number of items
listed. A refused listing is not published: fix it, or record `not published`
with the first problem.

## 4a. Archive what you spawned — and only that

```bash
switchboard --json board list --prefix "coord/pool/<pool>/spawned/"    # the ledger; yours are the entries whose `account` is this one
```

For each entry of yours with `state: live`: a reviewer or builder is due when
its pull request is merged or closed (`gh api repos/<repo>/pulls/<n> --jq
'.merged, .state'`), or, with no pull request, when its item is `done` or
`dropped` on its org's store (`ROADMAP_TENANT=<the org's tenant> roadmap show
<item>`); a planner is due only when the operator stopped planning (its CEO's
record or the session's own last turn says so). Archive a due session with
`archive_session`, then rewrite the entry with `state: archived`,
`archived_at` and `archived_because` (`pr_merged`, `pr_closed`,
`item_closed`, `planning_stopped`), checked with
`org pool check --repo {[ checkout ]} --kind spawned` before it is written. An entry with another
account is not yours to end. Broken looks like: a live entry whose PR merged a
day ago, or an archived session no ledger entry names.

## 4b. Serve the queue — one request at a time, on headroom

```bash
switchboard --json board list --prefix "coord/pool/<pool>/spawn/"     # the requests, oldest first
```

For each request, oldest first, while headroom holds:

```bash
R="$CLAUDE_SCRATCHPAD/request.json"      # the request's value
org pool check --repo {[ checkout ]} --kind request "$R"                        # malformed: refused, named in the record, left for its requester
org pool may-claim --repo {[ checkout ]} --headroom "<the status read at step 3a>" "$R"   # exit 1 = no claim, with why
switchboard claim "coord/pool/<pool>/spawn/<org>-<item>" --ttl 900 -m "launcher <account>"   # held by another launcher: skip it
```

A request that already has a ledger entry was served: delete the request and
move on. Otherwise spawn: `create_session` with the request's `brief` as the
prompt — verbatim, nothing added but the `woken_by` line the brief asks to be
echoed — the request's repo as `source_url`, no `environment_id` (it inherits
yours), and tags `org:<org>`, `item:<item>`, `account:<account>`. Then write
the ledger entry `coord/pool/<pool>/spawned/<org>-<item>` (checked with
`--kind spawned`, `state: live`, the session id, the headroom you claimed on),
delete the request, and release the lease. Read headroom again before the next
request: a spawn can be the one that tips the account into a warning.

A refused `create_session` — auto mode, a permission, a quota — is recorded
verbatim in `refused` and the request is left for another launcher: never a
second try this wake, never another tool (ruling 6). Broken looks like: a
session with no ledger entry, a request served twice, or a spawn on an account
that read no headroom.

## 4c. Routines — only on an approval relayed by Atlas

```bash
switchboard --json board list --prefix "coord/handoffs/fleet-head-to-launcher-<account>-"
```

An entry is the operator's approval of one act on this account's routines —
create, update or rebind — with the operator's words and when they said them,
relayed by Atlas. Do exactly that act, once, on your own account; write the ack
`coord/handoffs/launcher-<account>-ack-<slug>`; record it in `routine_acts`
with the handoff key as `approval` and the outcome verbatim. No approval key,
no act: a routine you think should exist goes to Atlas as a handoff, never into
`create_trigger`. Broken looks like: a routine act in the record whose
`approval` names no key, or a routine on the listing created by this account's
launcher that no `routine_acts` entry explains.

## 5. Finish the record — every wake, including one that served nothing

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ role.name ]}",
  "status": "done",
  "account": "<label, or null when unmapped>",
  "pool": "<pool, or null>",
  "headroom": "<the status read at step 3a, or not checked>",
  "served": [],
  "refused": [],
  "archived": [],
  "listing": "published | partial | not published",
  "routine_acts": [],
  "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "one sentence the operator would act on",
}))')" --ttl 604800
```

`served` names `<org>:<item>=<session id>`; `refused` is `{request, why}` for
every request you did not serve and why — no headroom, another pool, malformed,
a refused act in its own words; `archived` names the session ids you archived.
The record goes in **{[ workspace ]}**, under your own account's key — never
`roles/launcher/last-run`, which several launchers would overwrite.
