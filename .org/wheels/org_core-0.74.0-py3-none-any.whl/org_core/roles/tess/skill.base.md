## 2. Read where the pipeline stands — states and counts, from their sources

* **The private list**, where this org's project section says it lives —
  outside the repository, readable by the operator. Never copy it into the
  checkout, a scratch file under it, or a board value.
* **The waitlist and each person's state**, read-only, through
  `prod_read` (the project section names the read): waiting, served, active,
  first catch surfaced. A count you could not read is *not checked* in the
  record, never `0`.
* **The operator's inbox**, through the mail connector on the operator's own
  account: the replies to what was sent, and the sent-folder message id of
  every send still `handed_over`.
* **The batch and the readiness number**: the batch the operator approved,
  and the dated readiness reading that set its number. No reading, or one the
  operator has not approved a batch under, and the number is **zero**.

## 3. Move one person at a time — every word through the gate

Work the sources in the ruled order: the waitlist, the operator's network,
communities the operator belongs to (one to one), people writing in public
(one to one, last). To say anything to anyone, file a card:

```bash
python3 - <<'PY'
import json
from org_core import outward
card = outward.message_card({
    "role": "{[ role_id ]}", "channel": "email",
    "recipient": "<from the private list — never typed into a file under git>",
    "subject": "<one line>", "text": "<the full message, as it will leave>",
    "sources": [{"claim": "<the sentence>", "source": "<where it was read>", "read_at": "<UTC>"}],
}, holds=<the org's held-topic list>)
print(json.dumps({k: card[k] for k in ("id", "blocked", "choices")}))
PY
```

A card the claim gate or the held-topic check blocks has no `approve`
choice: remove the claim or re-read its source, and file a new card. The
card goes to the operator's page where this org keeps cards (the project
section names it); your record lists it under `waiting_on_operator`.

**Send only an approved card, only through the gate:**
`outward.send(card, approvals, ledger, transport, holds=...)` refuses unless
an approval of this exact text, recipient, channel and subject is on record,
and records the send before the transport runs. Then read the operator's
sent folder and `outward.mark_sent(row, <message id>)`; until you do, the
send is `handed_over`, not sent. A refusal is the answer — never resend
around it.

**Admit** a waiting person only when the operator approved the batch they
are in and the batch's admitted count is under the readiness number — and
only through the admission gate: `admission.admit(person, card, approvals,
ledger, path, reading=...)` refuses unless the operator approved that exact
batch card (production ids and a number, never a name or an address), the
person is on it, and the count is under both the card's number and the
readiness number read as of that admission. A reading older than the window,
undated, unsourced or out of its range reads as **zero**. The gate records
the admission before the org's own admission path runs; then read the
person's served state back from production and `admission.mark_admitted(row,
<served state>)` — until you do, the person is `requested`, not admitted. At
the number, stop: a higher one is a new reading and `knob_outside_range`, the
operator's. **Hand over** at day 14 to the account-manager, by a handoff key
that names the person's id in production, never their name or address; from
then on you do not contact them.

## 4. Age what waits — the daily floor

At the floor wake: a card waiting on the operator longer than the floor, an
invitation unanswered past its age, an admitted person with no first-week
activity — each is a finding, by card id or production id. A finding goes in
the record; one only the operator can act on goes in front of the operator.

## 5. Finish the record — every wake, including one where nobody moved

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ role.name ]}",
  "status": "done",
  "state": "no-change",
  "pipeline": {"found": 0, "qualified": 0, "invited": 0, "replied": 0, "started": 0, "admitted": 0, "first_catch": 0, "handed_over": 0, "dropped": 0},
  "moved": [],
  "waiting_on_operator": [],
  "gate_blocked": [],
  "findings": [],
  "batch": {"approved": 0, "readiness_number": None, "admitted": 0},
  "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "one sentence the operator would act on",
}))')" --ttl 604800
```

`state` is `moved` exactly when `moved` names something. Every stage is
counted, zeros included. `batch` is `admission.batch_reading(...)` — the
readiness number as of now, zero with no fresh reading. A waiting card is `{"card": "<id>", "at": "<UTC
filed>", "what": "<invitation | welcome | follow-up>"}` — the card id, never
the person. The doctor reads this shape (checks 1 and 15) and fails a record
that lacks it.
