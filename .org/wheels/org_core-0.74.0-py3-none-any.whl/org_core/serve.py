"""`org status --serve` — the reading, re-taken per request (SPEC §13).

A process that can reach the org serves the page. Nothing is pushed, stored or sent (rule 6), and the
measurement stays the single implementation in Python: the page renders what this reader computed and does
none of its own arithmetic, so there is nothing to drift.

Modelled on switchboard's own viewer (`gald33/switchboard`, `extras/viewer`, read 2026-09-20 against hub
2.4.1): a small read-only server, polled by the page it serves.

**The reader throttles, and says so.** A live gather is 1 + 3N `gh` calls, so re-reading on every request
would make a polling page cost a fan-out per poll. `interval` is the floor between full reads, and `fast_interval`
the floor between re-reads of the cheap sources (0.41.0); the page may poll faster and simply sees the same reading. The age on screen is always the age of the READING, never the poll
rate — a dashboard whose refresh rate is mistaken for its freshness is the failure this file exists to avoid.

**A read that fails does not take the page down.** The last good reading stays on screen, stamped with what
went wrong and how long ago it was taken, because a blank page and a stale page are not the same finding.
"""

from __future__ import annotations

import collections
import datetime as dt
import hashlib
import json
import math
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from . import dashboard as dash

#: how often the reader may take a FULL reading, in seconds: the board, and every pull request's reviews and checks.
#: 30 until 0.41.0 — ~91 `gh` calls a read on org-core (measured 2026-09-24), which at that floor projects to ~10,900 an
#: hour against the 15,000/h the API reported through that container's proxy (which bucket, unverified). The fast lane
#: (`DEFAULT_FAST_INTERVAL`) is what keeps the page live between full reads.
DEFAULT_INTERVAL = 300.0
#: how often the fast lane re-reads the cheap sources — the roadmap's claims and statuses, the ticket queue, the pull
#: request index (`tempo.refresh_fast`): ~1 s and at most two GitHub calls a read
DEFAULT_FAST_INTERVAL = 20.0
#: how long the background loop keeps reading after the last request, in seconds. Past it the loop sleeps on an event (no
#: ticking, no reads) until the next request wakes it. The floors above stay the MOST stale a page that is being looked at can
#: be; this is what stops them running for nobody. 10 minutes: long enough that a tab left in the background (browsers throttle
#: its timers, not stop them) never sees a gap, short enough that a night with no page open costs nothing.
DEFAULT_IDLE_AFTER = 600.0
DEFAULT_PORT = 8799          # switchboard-viewer's port + 1, so both can run side by side
DEFAULT_HOST = "127.0.0.1"   # local by default: the reader holds the org's credentials, the page holds none


def _iso(t: dt.datetime | None) -> str | None:
    return t.isoformat(timespec="seconds") if t else None


class Reader:
    """Takes a reading at most every `interval` seconds and renders it once per reading, not per request.

    Two lanes since 0.41.0 (the operator, 2026-09-24: *"can we make it live data as much as possible?"*): `take` is the
    full reading, `take_fast` re-reads the cheap sources over the last full facts, every `fast_interval`. The floor
    counts from the last ATTEMPT, so a source that fails is retried on its clock and never on every poll — until
    0.41.0 a failed read left the reading stale-by-definition and every poll from every tab re-ran it, holding the one
    lock (the read-only review of 2026-09-24). `start()` moves the reading to a background thread so a request never
    waits on one; `current()` is the synchronous form, one read at a time."""

    def __init__(self, take: Callable[[dt.datetime], dict[str, Any]], *, interval: float = DEFAULT_INTERVAL,
                 poll_ms: int = 5000, source: str = "org status --serve", clock: Callable[[], dt.datetime] | None = None,
                 take_fast: Callable[[dt.datetime], dict[str, Any]] | None = None,
                 fast_interval: float = DEFAULT_FAST_INTERVAL,
                 on_ask: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
                 idle_after: float = DEFAULT_IDLE_AFTER):
        self._take, self._interval, self._poll_ms, self._source = take, interval, poll_ms, source
        self._take_fast, self._fast_interval = take_fast, fast_interval
        self._clock = clock or (lambda: dt.datetime.now(dt.timezone.utc))
        self._lock = threading.Lock()          # one read at a time
        self._swap = threading.Lock()          # the published reading, swapped whole
        self._doc: dict[str, Any] | None = None
        self._st: dict[str, Any] | None = None   # the status reading itself, which the fleet page reads (`Fleet`)
        self._html: str = ""
        self._rev: str = ""
        self._tz: str | None = None
        self._taken: dt.datetime | None = None
        self._attempted: dt.datetime | None = None
        self._fast_taken: dt.datetime | None = None
        self._fast_attempted: dt.datetime | None = None
        self._error: str = ""
        self._fast_error: str = ""
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        # idle (0.60.58): the background loop reads only within `idle_after` seconds of the last request (0 or less: always)
        self._idle_after = idle_after
        self._wake = threading.Event()
        self._last_request: dt.datetime = self._clock()
        # the operator's asks (0.42.0): `on_ask` records and relays one; the page carries this token and `/ask` answers
        # nothing without it, so another site open in the same browser cannot post to 127.0.0.1 in the operator's name
        import secrets
        self._on_ask = on_ask
        self.ask_token = secrets.token_urlsafe(24) if on_ask else None
        self.reads = 0          # how many times the org was actually read in full, not how many requests were served
        self.fast_reads = 0

    @staticmethod
    def _due(last: dt.datetime | None, every: float, now: dt.datetime) -> bool:
        return last is None or (now - last).total_seconds() >= every

    def _publish(self, st: dict[str, Any], reads: int, fast_reads: int) -> None:
        src = self._source + (f" · read {reads}" if reads > 1 else "") + (f" · fast lane {fast_reads}" if fast_reads else "")
        # the served page has no store cap: every item's evidence whole, and its own rendering of what the script
        # cannot draw (dashboard.reading_doc `fragments`)
        doc = dash.reading_doc(st, source=src, evidence_chars=None, fragments=True, private_text=True)
        html = dash.render_html(st, live=True, poll="status.json", poll_ms=self._poll_ms, source=src,
                                ask_token=self.ask_token)
        # what the page says, clocks taken out, and the hour: a poll repaints when this moves, and otherwise only ticks
        # its ages — at most once an hour for the ages the reading itself printed
        # + the Brief and Decide's own digest: a recommendation the CEO writes, an option it adds or an answer that lands is the page
        # changing, and the fingerprint covers only what an item is called (`console.digest`)
        # + the CI section's digest (ci.digest, 0.74.0): a job joining the queue or a runner going busy repaints it; its ages do not
        from . import ci
        rev = (dash.fingerprint(st) + "|" + dash.explorer_digest(doc.get("explorer") or {}) + "|" + str((doc.get("console") or {}).get("digest"))
               + "|" + ci.digest((st.get("subjects") or {}).get("ci") or {}) + "|" + str(st.get("at") or "")[:13])
        with self._swap:
            self._doc, self._st, self._html, self._rev, self._tz = doc, st, html, rev, st.get("operator_timezone")

    def refresh(self) -> None:
        """Take whichever lane is due, the full one first. Raises only when there is no reading at all to show."""
        with self._lock:
            now = self._clock()
            if self._due(self._attempted, self._interval, now):
                self._attempted = now
                try:
                    st = self._take(now)
                    # counted once it is on the page: a read counted before its reading was published was a read
                    # nobody could see (CI, 2026-09-24: `reads` 1 and an empty snapshot, on a slower runner)
                    self._publish(st, self.reads + 1, self.fast_reads)
                    self.reads += 1
                    self._taken, self._error = now, ""
                    self._fast_attempted = self._fast_taken = now   # a full reading re-read the fast lane's sources too
                    self._fast_error = ""
                except Exception as e:                  # a failed read keeps the last good one on screen
                    self._error = f"{type(e).__name__}: {e}"[:300]
                    if self._doc is None:
                        raise
                return
            if self._take_fast and self._doc is not None and self._due(self._fast_attempted, self._fast_interval, now):
                self._fast_attempted = now
                try:
                    st = self._take_fast(now)
                    self._publish(st, self.reads, self.fast_reads + 1)
                    self.fast_reads += 1
                    self._fast_taken, self._fast_error = now, ""
                except Exception as e:
                    self._fast_error = f"{type(e).__name__}: {e}"[:300]
            if self._doc is None and self._error:
                # nothing good to show: the reason, every time, never an empty page (0.40.0 answered 503 with it)
                raise RuntimeError(f"the first read failed: {self._error}")

    def touch(self) -> None:
        """A request arrived: a viewer exists now. Resets the idle window and wakes the background loop if it was asleep."""
        self._last_request = self._clock()
        self._wake.set()

    def idle(self) -> bool:
        """True when nobody has asked for `idle_after` seconds, so the background loop should not read."""
        return self._idle_after > 0 and (self._clock() - self._last_request).total_seconds() > self._idle_after

    def snapshot(self) -> tuple[dict[str, Any], str]:
        """The reading as published now, with what the reader knows about it: when each lane last read, and what failed.

        Taking it is a request: it counts as a viewer (`touch`), which is how every page and `status.json` read reaches the loop."""
        self.touch()
        with self._swap:
            doc, html = self._doc, self._html
        if doc is None:
            return {}, ""
        doc = dict(doc)
        doc["reader"] = {"full_at": _iso(self._taken), "fast_at": _iso(self._fast_taken), "every": self._interval,
                         "fast_every": self._fast_interval if self._take_fast else None,
                         "reads": self.reads, "fast_reads": self.fast_reads, "error": self._error or self._fast_error or None}
        extra = []
        when = lambda t: dash._clock(_iso(t), self._tz)   # noqa: E731 — a page prints the operator's clock (rule 7)
        if self._error:
            extra.append(f"the reader's last attempt failed ({self._error}) — this reading was taken at {when(self._taken)}")
        if self._fast_error:
            extra.append(f"the fast lane's last attempt failed ({self._fast_error}) — claims, tickets and pull requests "
                         f"are as of {when(self._fast_taken or self._taken)}")
        if extra:
            doc["could_not_read"] = list(doc.get("could_not_read") or []) + extra
        import hashlib
        doc["rev"] = hashlib.sha256((self._rev + json.dumps(doc.get("could_not_read") or [])).encode()).hexdigest()[:16]
        return doc, html

    def ask(self, raw: Any) -> dict[str, Any]:
        """One ask from the page: recorded and relayed by `on_ask`; then the fast lane re-reads at once, so the page
        shows the ask on the board within one poll rather than one fast interval."""
        if not self._on_ask:
            raise PermissionError("this reader takes no asks")
        self.touch()
        got = self._on_ask(raw)
        self._fast_attempted = None
        return got

    def status(self) -> dict[str, Any] | None:
        """The last published status reading (`status.status`), or None before the first."""
        with self._swap:
            return self._st

    def error(self) -> str:
        return self._error

    def started(self) -> dt.datetime | None:
        """When the reader last began a full read (the first one, while nothing has been published)."""
        return self._attempted

    def current(self) -> tuple[dict[str, Any], str]:
        """The reading, re-taken only if a lane's floor has passed. One read at a time; the rest wait for it."""
        self.refresh()
        return self.snapshot()

    def start(self, tick: float = 1.0) -> None:
        """Read in the background from now on: a request is answered from the last reading and never waits on a read
        (except the very first, when there is nothing yet to answer with).

        **The loop idles when nobody is looking** (0.60.58). Starting counts as a request, so the first reading is taken at
        once; after that it reads only within `idle_after` seconds of a request (`touch`), and past that it blocks on an event —
        no ticks, no reads — until the next request wakes it. Until 0.60.58 it read on its floors all day with no page open: the
        `org command --serve` on lucille-vm, three orgs at a 60 s fast lane and a 900 s full one, was stopped by the operator for
        the CPU it held. The page that wakes it is answered from the last reading at once; the floors then decide what is re-read."""
        if self._thread:
            return
        self.touch()

        def loop() -> None:
            while not self._stop.is_set():
                self._wake.clear()          # cleared BEFORE the check: a touch after it sets the event again, and the wait returns
                if self.idle():
                    self._wake.wait()
                    continue
                try:
                    self.refresh()
                except Exception:           # the first read failed: `snapshot` is empty and the handler says why
                    pass
                self._stop.wait(tick)
        self._thread = threading.Thread(target=loop, name="org-status-reader", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    @property
    def background(self) -> bool:
        return self._thread is not None


#: the names a local page is reached by. Anything else in `Host` is refused, on every request: the page prints the ask
#: token, and a DNS-rebinding page is same-origin with this server, so a token alone does not keep it out (Reed on
#: #36, 2026-09-25: `Host: attacker.example` read the token from `/` and posted an ask that reached `on_ask`)
LOOPBACK_NAMES = ("127.0.0.1", "localhost", "[::1]")

#: what the agent token may GET: the fleet's reading, one org's reading, and (a single-org server) its own `/status.json`.
#: Neither carries an ask token — `Fleet.html` and the org page put it in the HTML only
AGENT_READS = re.compile(r"/(command\.json|status\.json|o/[^/]+/status\.json)")

#: the agent token's allowance: this many requests in any 60 seconds, then 429 with a `Retry-After` (0.58.0, item
#: fleet-read-rate-limit). Proposed, not measured against the VM: the pages poll every 5 s (12 a minute each) and a read is
#: served from the reader's cached snapshot (~1-2 ms on the test fixture), so 60 a minute is five times a page's poll and
#: costs the service nothing a loop could not also cost without it — the limit is a security measure (the operator,
#: 2026-10-05), not a capacity one
AGENT_RATE_PER_MIN = 60


class RateLimit:
    """At most `per_minute` requests in any 60 s window, per key. A refused request is not recorded, so a loop that keeps
    hitting the limit does not push its own wait further out. Thread-safe: the server handles each request in its own thread."""
    WINDOW = 60.0

    def __init__(self, per_minute: int, clock: Callable[[], float] | None = None) -> None:
        self.per_minute = int(per_minute)
        self._clock = clock or time.monotonic
        self._seen: dict[str, Any] = {}
        self._lock = threading.Lock()

    def take(self, key: str) -> int:
        """0 when the request may go on; else the whole seconds (at least 1) until the oldest of the window's requests leaves it."""
        now = self._clock()
        with self._lock:
            q = self._seen.setdefault(key, collections.deque())
            while q and now - q[0] >= self.WINDOW:
                q.popleft()
            if len(q) < self.per_minute:
                q.append(now)
                return 0
            return max(1, math.ceil(self.WINDOW - (now - q[0])))


class _Handler(BaseHTTPRequestHandler):
    """What every served page shares: the `Host` and `Origin` checks, and one org's page, reading and asks."""
    protocol_version = "HTTP/1.1"
    allow_hosts: tuple[str, ...] = ()
    #: a secret the proxy in front adds to every request as `X-Org-Proxy` (`--proxy-secret-env`, 0.42.1). With it set,
    #: a request that did not come through the proxy is refused, whatever its `Host`: the login stands in the proxy, and
    #: `--allow-host` alone admits anything that can open a socket to the service and name the proxy's host (Reed on
    #: #37, 2026-09-25: `curl -H "Host: command.lucille-ai.com" http://<docker0>:8798/` got the page and its ask token)
    proxy_secret: str = ""
    #: a read-only bearer token for agents (`--agent-token-env`, 0.57.0). It opens `AGENT_READS` by GET and nothing else: a
    #: request carrying `Authorization: Bearer …` is judged only here, so a token (right or wrong) never reaches `/ask`,
    #: the page or any other path. Empty means no agent can read: a Bearer request is refused, never waved through.
    agent_token: str = ""
    #: the allowance behind that token (`--agent-rate`, 0.58.0): counted per token, once the token is right — a wrong one is
    #: refused 401 and never held in memory, so a flood of guesses cannot grow it
    agent_limit: RateLimit | None = None

    def _send(self, code: int, body: bytes, ctype: str, headers: dict[str, str] | None = None) -> None:
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").strip().lower()
        port = self.server.server_address[1]
        local = {f"{n}:{port}" for n in LOOPBACK_NAMES}
        return host in local or host in {h.lower() for h in self.allow_hosts}

    def _origin_ok(self) -> bool:
        """A browser's `Origin`, when sent, is this page's own: the scheme and the `Host` already admitted."""
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        host = (self.headers.get("Host") or "").strip().lower()
        return origin.strip().lower() in (f"http://{host}", f"https://{host}")

    def _proxy_ok(self) -> bool:
        if not self.proxy_secret:
            return True
        import hmac
        return hmac.compare_digest((self.headers.get("X-Org-Proxy") or "").encode(), self.proxy_secret.encode())

    def _refuse_agent(self) -> bool:
        """A Bearer request is an agent's: the right token, a GET, and one of the two reads — else refused (401 a token that is
        not ours or none configured, 403 a right token asking for more than a read). No Bearer header is the login's path."""
        # every Authorization value is read: a proxy that matches any one of a repeated header and a service that reads the first
        # disagree about who the request is (Reed on #83: `Basic x` then `Bearer junk` got 200 with no login and no token)
        auths = self.headers.get_all("Authorization") or []
        if not any(a[:7].lower() == "bearer " for a in auths):
            return False
        import hmac
        if len(auths) != 1:
            self._send(400, b"one Authorization header, please\n", "text/plain; charset=utf-8")
            return True
        got = auths[0][7:].strip().encode()
        if not self.agent_token or not hmac.compare_digest(got, self.agent_token.encode()):
            self._send(401, b"not an agent token this server knows\n", "text/plain; charset=utf-8")
            return True
        # every request the right token makes counts, whatever it asks for: a loop on /ask or a bad path is a loop too
        wait = self.agent_limit.take(hashlib.sha256(got).hexdigest()) if self.agent_limit else 0
        if wait:
            self._send(429, f"too many reads with this token; try again in {wait} s\n".encode(), "text/plain; charset=utf-8",
                       {"Retry-After": str(wait)})
            return True
        if self.command != "GET" or not AGENT_READS.fullmatch(self.path.split("?", 1)[0]):
            self._send(403, b"this token reads /command.json and /o/<id>/status.json, and nothing else\n",
                       "text/plain; charset=utf-8")
            return True
        return False

    def _refuse_host(self) -> bool:
        if not self._proxy_ok():
            self._send(403, b"not through this server's proxy\n", "text/plain; charset=utf-8")
            return True
        if not self._host_ok():
            self._send(403, b"not this server's host\n", "text/plain; charset=utf-8")
            return True
        return self._refuse_agent()

    def _org_get(self, reader: Reader, path: str) -> None:
        """`path` relative to the org's page: "" or "index.html" is the page, "status.json" the reading."""
        try:
            doc, html = reader.snapshot() if reader.background else reader.current()
            if not doc and reader.background:
                # the background reader is taking the first reading (Lucille's took minutes, measured 2026-09-24):
                # answer now, saying so, rather than holding the request behind that read — which a browser shows as a
                # page that never loads (the operator, 2026-09-25: "lucille's dashboard doesn't even load")
                self._first_reading(reader, path)
                return
            if not doc:                       # not serving in the background: the first read, in this request
                doc, html = reader.current()
        except Exception as e:
            self._send(503, f"the reader could not take a reading: {e}".encode(), "text/plain; charset=utf-8")
            return
        if path in ("", "index.html"):
            self._send(200, html.encode(), "text/html; charset=utf-8")
        elif path == "status.json":
            self._send(200, json.dumps(doc, ensure_ascii=False).encode(), "application/json; charset=utf-8")
        else:
            self._send(404, b"not found\n", "text/plain; charset=utf-8")

    def _first_reading(self, reader: Reader, path: str) -> None:
        """503 while the first reading is taken: a page that refreshes itself and says what the last attempt hit."""
        import html as _h
        err = reader.error()
        if path == "status.json":
            self._send(503, json.dumps({"reading": "first", "since": _iso(reader.started()), "error": err or None}).encode(),
                       "application/json; charset=utf-8")
            return
        since = _iso(reader.started()) or "just now"
        body = ("<!doctype html><meta charset='utf-8'><meta http-equiv='refresh' content='5'>"
                "<meta name='viewport' content='width=device-width,initial-scale=1'><title>Taking the first reading</title>"
                "<body style='font:15px/1.5 system-ui,sans-serif;max-width:640px;margin:48px auto;padding:0 16px'>"
                "<h1 style='font-size:20px'>Taking this org's first reading</h1>"
                f"<p>Started {_h.escape(since)}. A full read calls every source the page shows, and a large org takes "
                "minutes. This page reloads itself every 5 seconds.</p>"
                + (f"<p style='color:#b42318'><b>The last attempt failed:</b> {_h.escape(err)}</p>" if err else "")
                + "</body>")
        self._send(503, body.encode(), "text/html; charset=utf-8")

    def _org_ask(self, reader: Reader, route: Callable[[Any], tuple[Reader, Any]] | None = None) -> None:
        """The token and the origin are the posting page's own; `route` (the fleet's) may then send the ask to another org's reader — the
        token proved who posted, and that org's reader takes the ask as it would from its own page."""
        if not reader.ask_token or self.headers.get("X-Org-Ask") != reader.ask_token or not self._origin_ok():
            self._send(403, b"not this page's ask\n", "text/plain; charset=utf-8")
            return
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > 16384:
            self._send(400, b"an ask is one small JSON object\n", "text/plain; charset=utf-8")
            return
        try:
            raw = json.loads(self.rfile.read(n).decode("utf-8"))
            use, raw = route(raw) if route else (reader, raw)
            got = use.ask(raw)
        except (ValueError, PermissionError) as e:        # AskError is a ValueError
            self._send(400, json.dumps({"error": str(e)[:300]}).encode(), "application/json; charset=utf-8")
            return
        except Exception as e:                           # recorded or not, the page is told which
            self._send(502, json.dumps({"error": f"{type(e).__name__}: {str(e)[:260]}"}).encode(),
                       "application/json; charset=utf-8")
            return
        self._send(200, json.dumps(got, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def log_message(self, fmt: str, *args: Any) -> None:
        pass                                             # the reading is the output; requests are not


def handler_for(reader: Reader, *, allow_hosts: tuple[str, ...] = (), proxy_secret: str = "", agent_token: str = "",
                agent_limit: RateLimit | None = None) -> type[BaseHTTPRequestHandler]:
    """One org's page at `/`. `allow_hosts`: names a proxy in front serves it under (`--allow-host`), matched exactly."""
    class Handler(_Handler):
        def do_GET(self) -> None:                            # noqa: N802 — the stdlib's spelling
            if self._refuse_host():
                return
            self._org_get(reader, self.path.split("?", 1)[0].lstrip("/"))

        def do_POST(self) -> None:                           # noqa: N802
            if self._refuse_host():
                return
            if self.path.split("?", 1)[0] != "/ask":
                self._send(404, b"not found\n", "text/plain; charset=utf-8")
                return
            self._org_ask(reader)
    Handler.allow_hosts, Handler.proxy_secret, Handler.agent_token = tuple(allow_hosts), proxy_secret, agent_token
    Handler.agent_limit = agent_limit
    return Handler


# --- the fleet: every org the operator commands, on one server ---------------------------------------------------------

class Fleet:
    """Every org in the registry, each read by its own `Reader`, and the fleet console composed from their last readings.

    The operator, 2026-09-25: *"we say 'org' but there are many orgs I command. so we need to at least see them all"*.
    `/` is the console (`command.read` over each org's last reading, with each org's team); `/o/<id>/` is that org's
    own page, controls and all, and an ask there goes to that org's board and that org's CEO — never another's. An org
    that cannot be read is a row saying why, never a row left out (`command`'s rule)."""

    def __init__(self, members: list[dict[str, Any]], *, poll_ms: int = 5000,
                 clock: Callable[[], dt.datetime] | None = None, note: str | None = None, feedback_to: str | None = "org-core"):
        # members: {"org": {id, repo, …}, "reader": Reader | None, "why": str}
        self.members = members
        self._poll_ms, self._note = poll_ms, note
        # where a bug or a feature request about the dashboard goes, from any org's page: the org that maintains it (0.56.0, row 190)
        self.feedback_to = feedback_to
        self._clock = clock or (lambda: dt.datetime.now(dt.timezone.utc))
        self.by_id = {str(m["org"]["id"]): m for m in members}

    def feedback_reader(self) -> "Reader | None":
        """The reader that takes feedback about the dashboard: `feedback_to`'s, when this fleet has it and it can take an ask. None otherwise,
        and the posting page's own org takes it — recorded, and told to its own CEO, which can pass it on."""
        m = self.by_id.get(self.feedback_to or "")
        r = m.get("reader") if m else None
        return r if r is not None and r.ask_token else None

    def start(self) -> None:
        for m in self.members:
            if m.get("reader"):
                m["reader"].start()

    def stop(self) -> None:
        for m in self.members:
            if m.get("reader"):
                m["reader"].stop()

    def read(self) -> dict[str, Any]:
        from . import command as cm
        orgs = []
        for m in self.members:
            r = m.get("reader")
            if r:
                r.touch()            # the console shows this org's last reading: looking at it is a request
            st = r.status() if r else None
            why = m.get("why") or (f"not read yet{(' — ' + r.error()) if r and r.error() else ''}" if r else "not read")
            orgs.append({"org": m["org"], "status": st, "why": why})
        d = cm.read(orgs, self._clock())
        d["team"] = {oid: ((m["reader"].status() or {}).get("subjects") or {}).get("presence")
                     for oid, m in self.by_id.items() if m.get("reader") and m["reader"].status()}
        d["pages"] = {oid: f"o/{oid}/" for oid, m in self.by_id.items() if m.get("reader")}
        d["tempo"] = {oid: cm.tempo(p) for oid, p in d["team"].items() if p}
        d["rev"] = fleet_rev(d, self._clock())
        return d

    def html(self) -> str:
        # each org's ask token goes into the page and nowhere else (not `command.json`): the tempo controls post to that
        # org's own `/o/<id>/ask`, which answers nothing without it (rule 6's loopback, token and origin checks)
        tokens = {oid: m["reader"].ask_token for oid, m in self.by_id.items() if m.get("reader") and m["reader"].ask_token}
        return dash.render_command_html(self.read(), note=self._note, live=True, poll="command.json",
                                        poll_ms=self._poll_ms, ask_tokens=tokens)


def fleet_rev(d: dict[str, Any], now: dt.datetime) -> str:
    """What the fleet page says, with the clocks taken out, plus the hour: the page reloads when this moves.

    Measured 2026-10-11 (org-core 0.60.20, Chromium 141, a one-org fleet re-read every 3 s over a fixed reading): the page
    reloaded 15 times in 15 s with nothing on it changed, because each org's `queue.at`, `throughput.at` and team `at` are
    the reading's own time; every reload painted one frame of an empty pane, scrolled to the top (the operator, 2026-10-10:
    "the page re-render is flickery"). On the VM, three orgs each re-read their fast lane every 60 s. So the readings' times,
    each waiting row's age (`hours`, the `ago` printed from it) and the order the ages sort the rows into are left out, and
    the hour is put in, as the org page's `Reader` does: an age the page printed is at most an hour stale. Broken looks
    like: the same reading a minute later carrying another rev, or a new or changed waiting row leaving the rev unchanged."""
    orgs = [{k: ({kk: vv for kk, vv in v.items() if kk != "at"} if isinstance(v, dict) else v) for k, v in o.items()}
            for o in d.get("orgs") or []]
    # sorted: the rows are ordered by age, among other things, so the clock alone reorders them (a row's `hours` steps by 2.4)
    rows = sorted((json.dumps({k: v for k, v in r.items() if k not in ("hours", "ago")}, sort_keys=True, default=str)
                   for r in d.get("needs_you") or []))
    # an answer landing, or the CEO marking one acted on, moves the page too (the operator's answered list, 0.63.1)
    rows += sorted(json.dumps({k: v for k, v in r.items() if k not in ("hours", "ago")}, sort_keys=True, default=str)
                   for r in d.get("answered") or [])
    team = {oid: ({k: v for k, v in p.items() if k != "at"} if isinstance(p, dict) else p) for oid, p in (d.get("team") or {}).items()}
    return hashlib.sha256(json.dumps([d.get("verdict"), orgs, rows, team, d.get("tempo"), now.strftime("%Y-%m-%dT%H")],
                                     sort_keys=True, default=str).encode()).hexdigest()[:16]


def fleet_handler_for(fleet: Fleet, *, allow_hosts: tuple[str, ...] = (), proxy_secret: str = "", agent_token: str = "",
                agent_limit: RateLimit | None = None) -> type[BaseHTTPRequestHandler]:
    class Handler(_Handler):
        def _route(self) -> tuple[Reader | None, str] | None:
            path = self.path.split("?", 1)[0]
            parts = path.split("/", 3)                      # "", "o", id, rest
            if len(parts) >= 3 and parts[1] == "o":
                m = fleet.by_id.get(parts[2])
                if m is None or not m.get("reader"):
                    return None
                if len(parts) == 3:                          # /o/<id> — the page's relative links need the slash
                    return m["reader"], "\x00redirect"
                return m["reader"], parts[3]
            return None

        def do_GET(self) -> None:                            # noqa: N802
            if self._refuse_host():
                return
            path = self.path.split("?", 1)[0]
            if path in ("/", "/index.html"):
                self._send(200, fleet.html().encode(), "text/html; charset=utf-8")
                return
            if path == "/command.json":
                self._send(200, json.dumps(fleet.read(), ensure_ascii=False, default=str).encode(),
                           "application/json; charset=utf-8")
                return
            got = self._route()
            if got is None:
                self._send(404, b"not found\n", "text/plain; charset=utf-8")
                return
            reader, rest = got
            if rest == "\x00redirect":
                self.send_response(308)
                self.send_header("Location", path + "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self._org_get(reader, rest)

        def do_POST(self) -> None:                           # noqa: N802
            if self._refuse_host():
                return
            got = self._route()
            if got is None or got[1] != "ask":
                self._send(404, b"not found\n", "text/plain; charset=utf-8")
                return
            origin = self.path.split("?", 1)[0].split("/", 3)[2]

            def route(raw: Any) -> tuple[Reader, Any]:
                if not (isinstance(raw, dict) and raw.get("kind") == "feedback"):
                    return got[0], raw
                # which page posted it is the server's knowledge, not the page's claim: it overwrites `from_org`
                ctx = dict(raw["context"]) if isinstance(raw.get("context"), dict) else {}
                ctx["from_org"] = origin
                return fleet.feedback_reader() or got[0], {**raw, "context": ctx}
            self._org_ask(got[0], route)
    Handler.allow_hosts, Handler.proxy_secret, Handler.agent_token = tuple(allow_hosts), proxy_secret, agent_token
    Handler.agent_limit = agent_limit
    return Handler


class _Server(ThreadingHTTPServer):
    def handle_error(self, request: Any, client_address: Any) -> None:
        """A tab closed on a kept-alive connection is not an error worth a traceback; anything else still is."""
        import sys
        if isinstance(sys.exc_info()[1], (ConnectionResetError, BrokenPipeError)):
            return
        super().handle_error(request, client_address)


def make_server(reader: Reader | Fleet, *, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
                allow_hosts: tuple[str, ...] = (), proxy_secret: str = "", agent_token: str = "",
                agent_rate: int = AGENT_RATE_PER_MIN) -> ThreadingHTTPServer:
    """Bound but not yet serving, so a test can drive it and shut it down; `serve` is the thin wrapper."""
    make = fleet_handler_for if isinstance(reader, Fleet) else handler_for
    httpd = _Server((host, port), make(reader, allow_hosts=tuple(allow_hosts), proxy_secret=proxy_secret,
                                     agent_token=agent_token, agent_limit=RateLimit(agent_rate)))
    httpd.daemon_threads = True
    return httpd


def url_of(httpd: ThreadingHTTPServer, host: str = DEFAULT_HOST) -> str:
    return f"http://{host}:{httpd.server_address[1]}/"


def serve(reader: Reader | Fleet, *, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
          ready: Callable[[str], None] | None = None, allow_hosts: tuple[str, ...] = (), proxy_secret: str = "",
          agent_token: str = "", agent_rate: int = AGENT_RATE_PER_MIN) -> None:
    """Serve until interrupted. `ready` is called with the URL once the socket is bound."""
    httpd = make_server(reader, host=host, port=port, allow_hosts=allow_hosts, proxy_secret=proxy_secret, agent_token=agent_token,
                       agent_rate=agent_rate)
    reader.start()
    if ready:
        ready(url_of(httpd, host))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        reader.stop()
        httpd.server_close()
