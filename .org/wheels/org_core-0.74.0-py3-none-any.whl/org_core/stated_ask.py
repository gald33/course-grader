"""The stated ask: an outward message may repeat the round the operator set, and never state another (item `chase-role-package`,
SPEC §16 decision 16).

Why. The operator ruled d16's third question on 2026-09-27 at 09:20 IDT (06:20Z), *"Role may state the ask"*: the investor role
repeats, verbatim, the round the operator has written down — amount, instrument, terms — inside messages the operator approves, and
it never negotiates, counters, or states terms the operator has not set. Setting or changing the ask stays the operator's. A rule a
role has to remember is the shape the claim gate replaced (2026-10-07: a rule and a reviewer existed and the stale figure stood), so
the ask is read by the gate, like a claim: a message that states another amount, instrument or term is refused before the operator
is asked to approve it.

What it does. `check` reads one text against the ask the caller passes in:

    ask: {amount: "<the round, e.g. $1.5M>", instrument: "<e.g. post-money SAFE>",
          terms: {"<term, e.g. valuation cap>": "<its value, e.g. $12M>", ...},      # optional; only the terms the operator set
          set_at: "<UTC instant>", by: "<who set it>"}

A sentence is **about the round** when it names an instrument, a term, or a round word (raise, round, invest, funding, allocation, a cheque or check size).
In such a sentence:

  - every money figure (`$1.5M`, `USD 1,500,000`, `1.5 million`) equals the ask's amount, or the value of a term the same sentence
    names — currency too, when both name one (a cap's figure stated as the amount raised is another amount);
  - every percentage equals the value of a term the same sentence names;
  - every instrument named is the ask's instrument (`SAFE` inside `post-money SAFE` is the same one);
  - every term named is one the ask sets (a pro rata right the operator did not set is a term stated, and refused);
  - no amount is written in words: a magnitude word (thousand, million, billion, mn, bn, k) that no digit carries — `two million
    dollars` — is refused, because the gate reads figures and an amount it cannot read is never one it passes.

Any mismatch is `blocked: not the stated ask`, naming what differs and never quoting the ask's own figures — the reading sits on a card
the operator's page shows, and the ask is the operator's to show. `ask=None` — no ask was read — blocks a text that states any of the
four, and leaves a text that states none approvable: a message that names no figure needs no ask. A sentence that is not about the
round is not read here (its figures are the claim gate's).

What it does not decide. Where an org keeps its ask (with the approvals, in the page's owner-only signed collection — ruling 5 of the
twenty, 2026-10-25 — is a follow-up item; until then the role reads it where the org's project section says). The vocabulary below is
a proposal: a false alarm costs one edit, and a round sentence that also carries a traction percentage is refused until the two are
split. Lists name kinds of instrument and term, never any org's round (CLAUDE.md rule 3).

Broken looks like: an approvable card whose round sentence names an amount, instrument or term that differs from the stored ask; a
reading that quotes the ask's figures; or `ask=None` letting a stated amount through.
"""
from __future__ import annotations

import functools
import re
from decimal import Decimal, InvalidOperation
from typing import Any

from .claim_gate import GateError, _utc

BLOCKED = "not the stated ask"
NOT_READ = "stated ask: no ask was read — a message that states an amount, instrument or term is approvable only against the ask the operator set"

#: instruments, longest first so `convertible note` wins over `convertible`. Matched case-insensitively except SAFE, whose lower case is a word
INSTRUMENTS = ("post-money safe", "pre-money safe", "convertible note", "convertible loan", "priced round", "preferred shares",
               "preferred stock", "common shares", "common stock", "revenue-based financing", "venture debt", "safe", "kiss",
               "convertible", "warrant")
#: terms a round can set
TERMS = ("valuation cap", "pre-money valuation", "post-money valuation", "liquidation preference", "most favored nation",
         "most favoured nation", "pro rata", "pro-rata", "board seat", "interest rate", "maturity", "discount", "mfn", "valuation",
         "cap")
#: words that make a sentence about the round even with no instrument or term in it
ROUND_WORDS = re.compile(r"\b(?:rais(?:e|es|ed|ing)|round|invest(?:s|ed|ing|ment)?|cheques?|check\s+sizes?|allocation|funding)\b", re.I)

_SENTENCE = re.compile(r"(?<=[.!?])\s+|\n+")
_CURRENCY = {"$": "USD", "usd": "USD", "us$": "USD", "dollar": "USD", "dollars": "USD", "€": "EUR", "eur": "EUR", "euro": "EUR",
             "euros": "EUR", "£": "GBP", "gbp": "GBP", "pounds": "GBP", "₪": "ILS", "ils": "ILS", "nis": "ILS", "shekel": "ILS",
             "shekels": "ILS"}
_MULT = {"k": 10**3, "thousand": 10**3, "m": 10**6, "mm": 10**6, "mn": 10**6, "million": 10**6, "b": 10**9, "bn": 10**9,
         "billion": 10**9}
_CUR_PRE = r"(?P<pre>us\$|\$|€|£|₪|usd|eur|gbp|ils|nis)\s?"
_NUM = r"(?P<num>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)"
_MULT_RE = r"(?:\s?(?P<mult>thousand|million|billion|mm|mn|bn|k|m|b)\b)?"
_CUR_POST = r"(?:\s?(?P<post>usd|eur|gbp|ils|nis|dollars?|euros?|pounds|shekels?)\b)?"
_MONEY = re.compile(r"(?<![\w.])(?:" + _CUR_PRE + r")?" + _NUM + _MULT_RE + _CUR_POST, re.I)
#: a magnitude word, to find the ones no digit carries — `two million dollars` is an amount `_MONEY` cannot read (Reed's UNSOUND on #299,
#: 2026-10-25), so a round sentence that holds one is refused rather than read as stating none
_MAGNITUDE = re.compile(r"\b(?:thousand|million|billion|mn|bn|k)s?\b", re.I)
_PERCENT = re.compile(r"(?<![\w.])(?P<num>\d+(?:\.\d+)?)\s?(?:%|percent\b|per cent\b)", re.I)


def _money(m: re.Match[str]) -> tuple[Decimal, str | None] | None:
    """(value, currency) for a money match, or None when the number carries neither a currency nor a multiplier — `3 founders` is
    not money."""
    pre, mult, post = (m.group("pre") or "").lower(), (m.group("mult") or "").lower(), (m.group("post") or "").lower()
    if not (pre or mult or post):
        return None
    try:
        v = Decimal(m.group("num").replace(",", "")) * _MULT.get(mult, 1)
    except InvalidOperation:
        return None
    return v.normalize(), _CURRENCY.get(pre or post)


def figures(text: str) -> tuple[list[tuple[Decimal, str | None]], list[Decimal]]:
    """The money figures and the percentages in a text."""
    money = [f for f in (_money(m) for m in _MONEY.finditer(text)) if f is not None]
    pct = [Decimal(m.group("num")).normalize() for m in _PERCENT.finditer(text)]
    return money, pct


def unread_amounts(text: str) -> int:
    """How many magnitude words in a text no digit carries (`two million`, `a few thousand`): an amount in words, which this gate
    cannot compare with the ask and so never passes."""
    carried = [m.span("mult") for m in _MONEY.finditer(text) if m.group("mult")]
    return sum(1 for m in _MAGNITUDE.finditer(text) if not any(a <= m.start() < b for a, b in carried))


def _fold(s: str) -> str:
    return " ".join(str(s).lower().replace("‑", "-").replace("‐", "-").split())


def _named(vocab: tuple[str, ...], text: str) -> list[str]:
    """The words of `vocab` a text names, longest first, each span counted once (`post-money SAFE` is one instrument, not also a
    `post-money valuation` term or a bare `SAFE`)."""
    out, taken = [], []
    for w in sorted(vocab, key=len, reverse=True):
        flags = 0 if w == "safe" else re.I
        pat = r"\bSAFEs?\b" if w == "safe" else r"\b" + re.escape(w).replace(r"\-", "[-\\s]?").replace(r"\ ", r"\s+") + r"s?\b"
        for m in re.finditer(pat, text, flags):
            if any(a < m.end() and m.start() < b for a, b in taken):
                continue
            taken.append((m.start(), m.end()))
            out.append(w)
    return out


def ask(raw: Any) -> dict[str, Any] | None:
    """The org's stated ask, checked. Errors never echo a figure."""
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise GateError("`ask` is {amount, instrument, terms?, set_at, by}")
    amount = str(raw.get("amount") or "").strip()
    a_money = [f for f in (_money(m) for m in _MONEY.finditer(amount)) if f is not None]
    if len(a_money) != 1:
        raise GateError("the ask's `amount` is one money figure, with its currency or a multiplier")
    instrument = _fold(raw.get("instrument") or "")
    if not _named(INSTRUMENTS, instrument):
        raise GateError(f"the ask's `instrument` names one of: {', '.join(sorted(set(INSTRUMENTS)))}")
    terms_raw = raw.get("terms") or {}
    if not isinstance(terms_raw, dict):
        raise GateError("the ask's `terms` maps each term the operator set to its value")
    terms: dict[str, str] = {}
    for k, v in terms_raw.items():
        named = _named(TERMS, _fold(k))
        if not named:
            raise GateError(f"the ask's term {str(k)[:40]!r} is not one this gate reads — one of: {', '.join(sorted(set(TERMS)))}")
        terms[_fold(k)] = str(v if v is not None else "").strip()
    set_at = _utc(raw.get("set_at"))
    if set_at is None:
        raise GateError("the ask's `set_at` is the UTC instant the operator set it — an undated ask is a proposal, not the ask")
    if not str(raw.get("by") or "").strip():
        raise GateError("the ask's `by` names who set it — setting the ask is the operator's act")
    return {"amount": a_money[0], "instrument": instrument, "terms": terms, "figures": {k: figures(v) for k, v in terms.items()},
            "set_at": set_at.isoformat(timespec="seconds"), "by": str(raw["by"]).strip()[:120]}


def _term_set(term: str, a: dict[str, Any]) -> bool:
    """A term named in the text is one the ask sets: the same term, or one a set term's own words contain (`cap` inside `valuation
    cap`)."""
    return bool(_set_terms([term], a))


def _same(f: tuple[Decimal, str | None], g: tuple[Decimal, str | None]) -> bool:
    return f[0] == g[0] and (f[1] is None or g[1] is None or f[1] == g[1])


def _set_terms(named: list[str], a: dict[str, Any]) -> list[str]:
    """The ask's own terms that the terms named in a sentence refer to."""
    out = []
    for t in named:
        tt = t.replace("-", " ")
        out += [k for k in a["terms"] if tt == k.replace("-", " ") or re.search(r"\b" + re.escape(tt) + r"\b", k.replace("-", " "))]
    return out


def _money_ok(f: tuple[Decimal, str | None], a: dict[str, Any], terms: list[str]) -> bool:
    """A money figure is the ask's amount, or the value of a term the same sentence names — a cap's figure stated as the amount
    raised is another amount."""
    return _same(f, a["amount"]) or any(_same(f, g) for k in terms for g in a["figures"][k][0])


def check(text: str, raw: Any) -> dict[str, Any]:
    """`{state, blocked, why, round_sentences, not_checked}` for one text against the stated ask. `why` names the sentence by its
    position and the kind of difference — never a figure of the ask."""
    a = ask(raw)
    why: list[str] = []
    n_round = 0
    stated = False
    for i, s in enumerate((p for p in _SENTENCE.split(str(text or "")) if p.strip()), 1):
        instruments, terms = _named(INSTRUMENTS, s), _named(TERMS, s)
        if not (instruments or terms or ROUND_WORDS.search(s)):
            continue
        n_round += 1
        money, pct = figures(s)
        worded = unread_amounts(s)
        if not (instruments or terms or money or pct or worded):
            continue
        stated = True
        if a is None:
            continue
        mine = _set_terms(terms, a)
        if worded:
            why.append(f"sentence {i}: an amount in words — write it in figures, so it can be read against the stated ask")
        for f in money:
            if not _money_ok(f, a, mine):
                why.append(f"sentence {i}: an amount that is not the stated ask's — the role repeats the ask; it never states another")
        for p in pct:
            if not any(p in a["figures"][k][1] for k in mine):
                why.append(f"sentence {i}: a percentage the stated ask does not set — split a traction figure into its own sentence")
        for ins in instruments:
            if ins != a["instrument"] and not re.search(r"\b" + re.escape(ins) + r"\b", a["instrument"]):
                why.append(f"sentence {i}: an instrument that is not the stated ask's")
        for t in terms:
            if not _term_set(t, a):
                why.append(f"sentence {i}: a term the operator has not set ({t}) — stating it is negotiating")
    if a is None and stated:
        return {"state": "blocked", "blocked": BLOCKED, "why": [NOT_READ], "round_sentences": n_round, "not_checked": [NOT_READ]}
    return {"state": "blocked" if why else "approvable", "blocked": BLOCKED if why else None, "why": why,
            "round_sentences": n_round, "not_checked": []}



@functools.lru_cache(maxsize=None)
def required(role: str) -> bool:
    """Whether a role's contract declares `outward.ask: required` — the roles whose cards are read against the ask even when the
    caller passed none, so a role that forgot to pass it is blocked, never unchecked."""
    from .roles import discover
    pkg = discover().get(str(role or ""))
    return bool(pkg) and ((pkg.contract.get("outward") or {}).get("ask") == "required")
