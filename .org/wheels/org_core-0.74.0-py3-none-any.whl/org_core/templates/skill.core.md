# {[ role_id ]}

> **You are {[ role.name ]}.** Read `.claude/agents/{[ role_id ]}.md` for the role and its
> limits. This is how a run goes. The base steps are rendered from the contract;
> this org's detailed procedure — if it has one — is in the project section below,
> and it decides *how*, never *whether*.

## 0. Pin the workspace before any board call

```bash
cd {[ checkout ]}
export SWITCHBOARD_WORKSPACE={[ workspace ]}
switchboard --json whoami        # confirm: "workspace": "{[ workspace ]}"
```

A report in the wrong room is indistinguishable from no report, and the CLI
reports success either way.

Then `git -C {[ checkout ]} status --short`, before you touch the checkout:
in-process subagents and other sessions share it (NumeroTech, 2026-09-17: a
methods run found the builder mid-build there — eleven modified files minutes
after a clean status). If anything you did not modify is modified, do not branch
or commit there: take your own worktree
(`git worktree add "$CLAUDE_SCRATCHPAD/{[ role_id ]}-wt" origin/{[ default_branch ]} --detach`)
and branch from `origin/{[ default_branch ]}`, never from the branch you found.
{% if work_store_mode == 'files' %}
The work store is files with a gitignored local store, so a cold container reads
an **empty** store at exit 0 — `ready` says "nothing ready", `list` says "no
items", `validate` says "ok — 0 items" — and every role reads its own false
finding: no item answers this ticket, a quiet day, an empty verifying band
(NumeroTech, 2026-09-17, in a clean clone with 24 item files). Seed it from the
files before any read, once your checkout is the branch you mean:

```bash
{[ roadmap_cli ]} push && {[ roadmap_cli ]} doctor     # seed, then check; only then read the queue
```
{% endif %}
{% if role.runtime in ('session', 'spawned') %}## 0b. Register, then read your inbox

```bash
org tempo --repo {[ checkout ]} register --role {[ role_id ]}{% if role.runtime == 'spawned' %} --item <key>{% endif %}     # your agent id into coord/tempo/agents{% if role.runtime == 'session' %}, so senders can wake you; answers `listener_alive` for step 6{% else %}, so your records pair with the wake that spawned you{% endif %}
switchboard --json inbox                                        # a DM naming a handoff key or a PR is why you were woken: act on that first
```
{% if role.runtime == 'spawned' %}
Several sessions of this role run side by side, so name your subject: `--item <key>` for the item the prompt that
spawned you names, `--pr <n>` for a pull request — and register again with `--pr <n>` once you open one. A DM addressed
by that item or PR (`org tempo dm --item`, `--pr`, or a `#<n>` in its text) then reaches this session, not whichever
of the role's sessions registered last (org-core 2026-10-11: two builders spawned a second apart, one registration lost).
{% endif %}
A session keeps the checkout it was created with, so on the tenth wake it reads the files of the first — in a
`files`-mode org that is the queue itself (`roadmap/items/`), and a role reads `ready` an item `origin/{[ default_branch ]}`
has closed (org-core row 137, read 2026-09-23 on 0.35.1: of the role procedures only the doctor's fetched). **Every wake,
before you read the queue:**

```bash
git -C {[ checkout ]} fetch origin {[ default_branch ]} --quiet
git -C {[ checkout ]} rev-list --count HEAD..origin/{[ default_branch ]}     # commits behind; 0 = current
```

Behind, and the tree is clean on `{[ default_branch ]}`: `git -C {[ checkout ]} merge --ff-only origin/{[ default_branch ]}`.
Behind on any other branch: read **the queue and anything you report as `{[ default_branch ]}`'s state** from
`origin/{[ default_branch ]}` (`git -C {[ checkout ]} show origin/{[ default_branch ]}:<path>`); your own branch's work stays
where it is — a role woken to fix its own PR reads and edits that branch. With changes that are not yours in the tree: do not
build on it — take your own worktree at `origin/{[ default_branch ]}` (step 0).
A fetch that fails is said in your record (`blocked`), not read as "current". Broken looks like: a count above 0 that you
read past, or an item you call `ready` that `git show origin/{[ default_branch ]}:roadmap/items/<key>.yaml` shows closed.

{% if role.runtime == 'session' %}A DM is a wake, not a task list: do what it names, write your record, re-park
(step 6). An empty inbox means your cron fired: run the whole procedure.
`listener_alive: true` means the listener you parked last turn is still running
(your cron fired into a parked session): it wakes you when it exits, so step 6
parks nothing this turn.
{% else %}A DM in the inbox is what you were spawned for, if the prompt did not name it: do what it names. An empty inbox means
you were spawned for the one thing the prompt names: do that, write your record, and end (step 6) — a spawned role parks
no listener.
{% endif %}
{% endif %}## 1. Read what is already known

```bash
switchboard --json board get {[ report_key ]}     # your own last record; absent = first run, the last one died, or it expired — a write after an expiry returns revision 1 exactly like a first write, so never read revision 1 as "never written"; say which you cannot tell
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"     # the org-core and suite versions this container runs; {"report": "absent"} when the setup never ran here, empty when this line itself failed — the doctor's check 21 tells the three apart (row 91). `export`, not a `SUITE="$SUITE"` prefix: the `$(python3 …)` below is expanded before any prefix reaches a command, so the prefix form hands python an empty SUITE (NumeroTech 2026-09-21, row 112; measured by running the rendered block). Run both lines in ONE shell: an `export` made in one Bash call is gone in the next
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "by": "{[ role.name ]}", "status": "in_progress", "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "run started, not finished — if you are reading this, the session ended before step 3"}))')" --ttl 604800
```

Open the record **now**, before any work, and finish it at step 3. A record
written last is never written when the session ends first — a turn that runs
out, an operator who redirects you, a run that simply finishes its business —
and the end of a session has no prompt. Lucille measured the cost on
2026-09-19: the CEO's record had never existed, on an org four days old, while
every run had asked for it as its last step. An open record that step 3 never
overwrites is what the doctor reads as "ended before its last step" (check 1).

Then `{[ operator_surface ]}`{% if watchlist is defined %} and the dated commitments in `{[ watchlist ]}`{% endif %}. Do not
re-derive what a previous run already established; read it. (A date or a count
you can re-read from its source in one call is a read, not a re-derivation —
re-read it; the watchlist is a projection of the source, never the source. The
same for a finding you are about to repeat or an operator bullet you carry
forward: re-read its premise from the source first — NumeroTech 2026-09-20
flagged two migrations "18 days behind" on four consecutive runs after the
operator had applied them.)
{% if addendum %}
{[ addendum ]}{% else %}
## 2. Do the work

{[ contract.summary ]}. The project section below says how this org does it.
If that section is empty, do not improvise: write a record with
`blocked: "no procedure for this org yet"` and stop.

## 3. Finish the record — every run, including an empty one

Overwrite the record step 1 opened: same key, same TTL; the point of the
rewrite is that `status` stops saying `in_progress`.

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ role.name ]}",
  "status": "done",
{% for k in counts_required %}  "{[ k ]}": 0,
{% endfor %}{% for k in lists_optional %}  "{[ k ]}": [],
{% endfor %}{% if record_evidence %}  "evidence": "the dated reading of this run: what you read, where, and when",
{% endif %}  "blocked": None,
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "headline": "one sentence a human should act on",
}))')" --ttl 604800
switchboard --json say ops "{[ role_id ]} ({[ role.name ]}): <headline>" --ttl 86400
```

{% if lists_optional %}The counts are numbers. The `_items` lists beside them carry the item keys those
numbers count — the tempo item flow and the dispatcher's `finding_refuted` wake
read names, and a count carries none (row 94: names written into the count
fields crashed both Docs' doctors on 2026-09-20).
{% endif %}{% if record_evidence %}{% if lists_optional %}
{% endif %}`evidence` is where the run's reading goes: the paragraph of what you read, where and
when, with its dates and sources. `blocked` holds only what stops you or what another role must do, one
condition per sentence, and `None` when nothing does. A non-null `blocked` is an alarm wherever it is read: it
DMs the CEO (`blocked_written`), the actuator forwards it to the operator queue, and the operator file prints it
under **blocked:**. Measured 2026-10-16: a `done` verifier record carried its whole 1,585-character run summary
there and a `done` registrar record its 994-character reading, and both printed as blocked on the operator file
(item `a-run-record-has-a-place-for-evidence-that-is-not-blocked`). `evidence` stays on the board; nothing
forwards it.

{% endif %}`at` is the time you write it; the doctor compares it with the hub's own
timestamp and flags a run time that is not the run time. `suite` is what the
setup script reported at session start — the org-core and suite versions this
container actually runs; the doctor's check 21 reads it against the lock, which
is how a container whose hook installed nothing gets noticed (org-core rows 87,
88: two restarted sessions sat on an org-core seven releases behind, visible
only in their own records). Write it with the CLI,
as above, never with the MCP `board_set`: that tool takes no TTL argument and
writes `expires_in: 86400` silently, so a record made correctly is gone in a day
and the next observer reads the absence as this role having died (Lucille,
2026-09-19, measured on `roles/ceo/last-run`: revision 1 landed via MCP at one
day and had to be rewritten via the CLI for the seven this file asks for).
{% if contract.stamps %}
{% if role_id == 'ceo' %}
## 4. Render the operator file from the board

```bash
org operator --repo {[ checkout ]} render --dashboard     # every role's three lines from roles/<role>/last-run, and the page beside it
git -C {[ checkout ]} add {[ operator_surface ]} {[ dashboard ]}     # both, in ONE commit on main
```

`{[ dashboard ]}` is the same reading as a page. It is re-read only when the
operator file changed (or the page is missing), so it rides the commit you were
already making and costs no extra commit or deploy; a page older than the file
never happens, and one older than the board says so in its own "read at" line.
It is best effort: when it cannot be read, the operator file is still written —
commit that alone and say so in your record.

`{[ operator_surface ]}` is the one report the operator reads without an agent,
and you are the one role with a path to `main`: a role's own stamp travels in its
PR and sits behind whatever merges before it, so the file said `never ran` for
roles that ran daily (org-core rows 65, 98). Render it every wake, commit the
result directly on `main` — it is generated from the board, nothing of yours —
and say in your record when the render could not read the board (exit 2).
If the harness refuses that commit on `main` (NumeroTech 2026-09-20T23:30Z: the
chair's own permission guard denied a direct push as "Merge Without Review"),
do not route around it: commit the render on a branch, open the PR, and say in
your record that the file is behind by whatever merges before it — the guard
refused an act the base assumed, and the operator decides which one gives.
{% else %}
## 4. Your section of the operator file

```
{[ operator_surface ]}  ->  ### {[ role.name ]} — {[ role_id ]} · {[ role.cadence_label if role.cadence_label is defined else role.cadence ]}
```

The chair renders it from your record every wake (`org operator render`):
**last run** from `at`, **outcome** from `headline`, **blocked** from `blocked`.
Do not edit the file from your branch — a stamp in a PR sits behind whatever
merges before it, and the file then says you never ran (rows 65, 98). Write the
record; the file follows.
{% endif %}
{% endif %}
## 5. Escalate

What no role can act on goes to the operator, once, in the operator file's
"Waiting on the operator". Everything else goes in your record's `blocked`
field, then `org tempo --repo {[ checkout ]} dm --role ceo "blocked_written {[ role_id ]}"` —
the CEO listens (row 86); its next clock fire reads the field if the DM finds
no listener.
{% endif %}
{% if role_id == 'ceo' %}
## 5a. What you put in front of the operator arrives with your recommendation

The command page is how the operator talks to you, and its job is to lower their load, not to forward yours. The operator,
2026-10-04: *"The CEO needs to leave a recommendation, or choice, in the item whenever possible to minimize operator load."*
A bullet under "Waiting on the operator" starts `- [open] …` (`[done]` once answered): only a marked bullet is counted as a decision awaiting your
recommendation, and doctor check 15 reports one that carries neither (item `the-open-marker-is-written-where-operator-file-bullets-are-written`).
So when something reaches the operator — a bullet under "Waiting on the operator", a blocked ask you carry up — also record
it as a handoff, and form the recommendation yourself: read the evidence, decide what you would do, say it.

```bash
org handoffs --repo {[ checkout ]} add --decides operator --org <org> --item <key> --what "<the thing>" --why "<what it is>" \
  --recommend "<what you would do, and why>" --cost "<what waiting costs, or: nothing known>" \
  [--option "<a real alternative>" ... --recommended-option "<the one you recommend, as written>"] [--do "<the exact command or text>"]
```

* `--decides` says who can decide it: `operator`, `org_ceo` (another org's CEO) or `org_core_ceo` (only under a standing
  decision the operator has granted — `--delegation <id>`). Put the thing in front of the one who can decide it.
* Every card names its roadmap item: `--item <key>`. Decide files it under that item's arc, so the operator can
  show one arc at a time and nothing put to them goes untracked. If what you are handing over has no item yet, file
  one first, then the card. A card with no item cannot be tracked (the operator, 2026-10-12: "cards must name the
  items, how else can we track?").
* Offer `--option`s only when there are real alternatives, and mark yours. With no options the operator's one tap is *Do as
  recommended*; either way they can reply in their own words.
* When you cannot form a recommendation, say so and what you need: `--recommend "none yet: needs <x>"`. The page shows that as
  a debt you owe, and counts it — it never reads as advice.
* The operator's answer reaches you as an `answer` ask (a DM and a board row, `coord/asks/…`) naming the handoff. A board row is
  attributed, never signed: act on the DM you received and check the board row matches it. If they differ, or only a row
  exists, it is not the operator's answer yet — ask them. Act on it, or say why not, then `org handoffs --repo {[ checkout ]} done <id> --note "<what you did>"`: the page shows your note beside their answer.
* The record lives seven days on the board. One the operator has not answered in a week is yours to record again, and the
  moment to ask whether it is still true.
{% endif %}
{% if role_id == 'ceo' and 'planner' in enabled %}
## 5b. The operator asks to plan a feature: brief {[ names.planner ]}, spawn, archive

{[ names.planner ]} (the planner, `spawned`; org-core SPEC §16 decision 14, approved by the operator
2026-09-25) is the session the operator plans a feature in, so the conversation is not held
inside yours. Nothing else starts it: no cron, no DM route — you spawn it, on
the operator's ask, and only then. It parks no listener (ruling 7: persistent seats only); archiving it is how it ends.

1. **Write the brief from `origin/{[ default_branch ]}`**, never from a branch (row 40): the role
   reads the base, and a brief describing another one is a false claim it has to find.
   The brief carries **pointers, not pasted text**:
   * the operator's question, in their words;
   * the topic slug its record will use: `roles/planner/<topic>`;
   * the item keys and arcs it touches, the spec and doc sections by heading, and the dated
     measurements that bear on it by their source (a row, a record key, an item's evidence).

   {[ names.planner ]} pulls the rest itself (`{[ roadmap_cli ]} show`, repoctx, reads). Broken looks like:
   a brief that pastes an item's evidence or a spec section — that is where the cost comes
   back (row 67, 2026-09-19: two planning sessions, $393 and $397, more than either builder).
2. **Spawn it** with the tool ending in `__create_session`: `source_url` {[ repo_url ]}, the brief
   as `prompt`, title `{[ org_id ]} · planner · <topic>`, tags `org:{[ org_id ]}` and `role:planner`.
   Name the session and the topic in your record, and tell the operator where to talk to it.
   You do not wake it again: the operator converses with it directly.
3. **Its output is items, nothing else.** {% if work_store_mode == 'files' %}In this org (`files`) it opens one PR per
   conversation carrying only files under `roadmap/`; your merge rule reads that diff like any
   other, and a file outside `roadmap/` is a refusal, not a merge.{% else %}In this org (`{[ work_store_mode ]}`) it
   writes the items through the work-store port and opens no PR — a PR from it is a refusal.{% endif %}
   It never builds, claims, dispatches or merges.
4. **Archive it once its items are filed**: `roles/planner/<topic>` reads `state: filed` naming
   `items_filed` (or `state: no-proposal` with a `reason`), and the operator has stopped.
   Your boundary lists this one `session_archive` (granted with the planner, decision 14);
   every other archive stays the operator's.
{% endif %}{% if role.runtime == 'session' %}
## 6. Park the listener before you end — and re-park it, always: every turn no listener is already running

Start it with your runner's background mechanism and **pass its timeout explicitly** — `run_in_background: true` with
`timeout: {[ listen_timeout_ms ]}` (ms) on the Bash call — never `&` or `nohup`:

```bash
switchboard listen --until "$(org tempo --repo {[ checkout ]} park-until)"    # {[ listen_label ]}; Bash: run_in_background true, timeout {[ listen_timeout_ms ]}
```

The listener is {[ listen_label ]}, re-armed on every expiry (ruling 7 of arc fleet-accounts-and-pools, 2026-10-19/20,
superseding row 178's 24-hour one). The runner stops a background command at 2 h (7,200,000 ms) and, when no `timeout`
is passed, at 30 min (1,800,000 ms): a listener started without one dies at 30 min, and a day-long one died at 2 h with
nothing to re-park it (Lucille's doctor, "runner caps background tasks at 2h", every run from 2026-10-07). A
{[ listen_label ]} park with a {[ listen_timeout_ms ]} ms timeout reaches its own deadline first, under the cap.
`org tempo --repo {[ checkout ]} park-until --timeout-ms` prints the same number. Broken looks like: a listener that
exits at 30 min (`failed`, killed by the runner, not exit 2), or a turn that ends with none parked.

Its exit is your next wake: exit 0 a DM arrived (read `switchboard --json inbox`
and act), exit 2 the deadline passed (re-park — that expiry is your health tick,
one short turn every {[ listen_label ]}), exit 1 the hub was unreachable five times running (re-park, and
say so in your record). The runner labels any non-zero exit **`failed`**, so a
clean deadline comes back as `failed with exit code 2`: that is the designed
outcome, not a crash — re-park (Lucille, 2026-09-19: one reviewer misread it five
times and stopped re-parking). A runner stop at its timeout is an exit like any other: re-park it, and write no
`blocked` for it. Run the command bare, never `…; echo $?`: a compound
command exits with its last command's status, so the wrapper reports 0 and the
code you wanted is gone. Measured 2026-09-19: the runner re-invoked the session
six seconds after the listener exited. One listener per session: when step 0b's
`register` answered `listener_alive: true`, the one parked last turn is still
running and will wake you — park nothing. A role that ends a turn with
no listener running is unreachable until its cron, and the doctor reads it as not
listening (check 4).
{% elif role.runtime == 'spawned' %}
## 6. End when your record is written — a spawned role parks no listener

Only a persistent seat parks one (ruling 7 of arc fleet-accounts-and-pools, 2026-10-19/20, superseding row 178): you
were spawned for one thing, and when your record (step 3) is written you are done. Never park `switchboard listen`,
never arm a `send_later` check-in, never poll for a verdict or a merge. A DM for this role later — a correction, a question —
routes to the actuator, which spawns a session for it; the launcher that spawned you archives it when the item closes
(ruling 8). Broken looks like: a spawned session with a `listener/<agent id>` heartbeat.
{% endif %}
