"""Tempo — the org's speed, measured, then made variable (SPEC §13).

Three halves. `gather` pulls the timestamped facts a tempo reading needs — the board
(records and handoff keys), the pull requests (opened, verdict, merged), the routines'
fires, the committed run ledgers — into one JSON so the reading is reproducible from a
file, and so a day's files can be merged into a week's. `report` turns those facts into
edge latencies (finding → dispatch → PR → verdict → merge → verified), the cycle per PR
kind, the handoffs nobody received, and the wakes. `wake_now` is the variable half: given
each role's declared events and targets, the roles a port-holding session should fire now
rather than at their next cron tick. Nothing here writes to the board, to GitHub or to the
routines: it reads, and it says.
"""

from __future__ import annotations

import datetime as dt
import json
import contextlib
import contextvars
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Callable

from . import ROLE_IDS
from . import knobs as _kn

Runner = Callable[[list[str], dict[str, str] | None], str]

VERDICT_RE = re.compile(r"\b(UNSOUND|SOUND|CANNOT TELL)\b")
#: a role's signature: a capitalised name and its role in parentheses — any name, because names are each org's
#: (Lucille's Link and Reed, org-core's Wren, the doctor's Hale since decision 13); the role is what attributes.
ROLE_SIG_RE = re.compile(r"\b([A-Z][a-z]+)\b\s*\((ceo|dispatcher|builder|reviewer|verifier|checks-watch|registrar|account-manager|methods|doctor)\)")
PRODUCT_PREFIXES = ("src/", "prisma/", "supabase/migrations/", "backend/", "worker/", "web/", "modules/", "marketplace/")
ORG_PREFIXES = (".claude/", ".org/", "org.yaml", "docs/human/", "docs/ai/", "docs/AGENT_ORG.md", "CLAUDE.md", "checks/")
ROADMAP_PREFIXES = ("roadmap/", "ARCS.md")
PR_NUMBER_RE = re.compile(r"/pull/(\d+)|(?:^|[\s#])#?(\d{1,6})(?=$|[\s,;)])")

#: the events a role may declare in `tempo.wake_on`, and what each one reads (SPEC §13.1)
EVENTS = ("pr_opened", "correction_pushed", "verdict_sound", "handoff_written", "finding_refuted", "blocked_written", "receiver_missing", "merged")
#: hours; an edge slower than its target is what check 19 reports (targets from the 2026-09-19 design panel)
DEFAULT_TARGETS: dict[str, float] = {
    "finding_to_dispatch": 24, "dispatch_to_pr": 24, "open_to_verdict": 1, "verdict_to_merge": 1,
    "unsound_open": 24, "merge_to_verified": 72, "handoff_received": 1, "blocked_forwarded": 1,
    "pr_needing_action": 4,   # an open PR red, conflicted or changes-requested with nobody acting this long is unwatched (Lucille 2026-09-19: 66 unwatched PR-hours)
}
#: package defaults for the roles that have an event to wake on; the manifest's `roles.<r>.tempo` wins.
#: `on_demand` is the actuator's act: `spawn` a one-shot session, `fire_trigger` a sourced fresh routine, `none`.
#: `on_demand: auto` follows the role's runtime — `session` → `dm` (the receiver is listening; the operator's ruling of
#: 2026-09-19: every role but the builder is a persistent agent that parks a listener), `spawned` → `spawn`, `fresh` → `fire_trigger`.
#: From 2026-10-02 (row 178) a spawned role parked a listener after its item too; since 0.63.0 (ruling 7 of arc
#: fleet-accounts-and-pools, 2026-10-19/20) it parks none — only a persistent seat (`session`) listens. `org tempo dm` and the
#: plan still DM a spawned session that is parked right now (one an older package started), and spawn when none is.
#: The operator's three rulings on the wake graph, later the same day (rows 75–77): the reviewer is "a fresh spawn without
#: context" (`spawned` — a sender's DM to it is routed to the actuator, which spawns it on that wake, `wake_route`); the CEO is
#: "persistent and only the big picture" (`wake_on: []`, `on_demand: none` — nothing wakes it; SOUND verdicts and forwarded
#: blocks wait for its clock, and `targets()` derives `verdict_to_merge` from that clock); the dispatcher is a receiver
#: (`auto` → `dm`) because routed wakes land on it, while the plan never DMs the actuator it runs in.
DEFAULT_ROLE_TEMPO: dict[str, dict[str, Any]] = {
    "reviewer": {"wake_on": ["pr_opened", "correction_pushed"], "target_hours": 0.5, "min_interval_hours": 0, "on_demand": "auto", "max_concurrent": 3, "order": "oldest_first"},
    # the CEO is persistent and always listening (the operator, 2026-09-20, row 86; for one day before that, woken by nothing — row 77):
    # a SOUND verdict, a handoff to it and a role's blocked field DM it; its cron is the floor. An org opts out with `wake_on: []`, `on_demand: none`.
    "ceo": {"wake_on": ["verdict_sound", "handoff_written", "blocked_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "dispatcher": {"wake_on": ["finding_refuted"], "target_hours": 2, "min_interval_hours": 1, "on_demand": "auto"},
    # a spawned session listens after its one item like every role does (the operator, 2026-10-02): the listener replaces the
    # `self_wake` check-ins (`send_later` at PR+45/+105 min, a six-hour floor) the builder carried before
    "builder": {"on_demand": "spawn"},
    # a merge is the event that moves an item out of `ready` (a sender's measurement, 2026-10-07: nine merges, `ready` read 47–48 until
    # the registrar was DMed after each); the registrar settles on dated evidence, never on the wake alone
    "registrar": {"wake_on": ["handoff_written", "merged"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "account-manager": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "verifier": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "checks-watch": {"on_demand": "none"}, "methods": {"on_demand": "none"}, "doctor": {"on_demand": "none"},
    # the planner (SPEC §16 decision 14, approved 2026-09-25): the CEO spawns it with `create_session` on the operator's ask,
    # and the operator talks to it directly — no cron and no DM route, so the actuator never spawns one, and it parks no listener (ruling 7: persistent seats only)
    "planner": {"on_demand": "none"},
    # the fleet head (row 191, 2026-10-17): a persistent session the operator talks to; a Link's reply to what it relayed is a
    # handoff to it, so it listens (`auto` → `dm`) like the CEO, and its cron is the floor
    "fleet-head": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    # a launcher (item launcher-role; arc fleet-accounts-and-pools, rulings 3, 8): one per account, persistent, its hourly cron the
    # floor. It is woken by its pool's queue, not by `org tempo dm --role launcher` — several run side by side, so a DM by role
    # reaches whichever registered last; how a request wakes one is item marshal-writes-spawn-requests (a proposal until then)
    "launcher": {"on_demand": "none"},
    # the customer role (d17, built 2026-10-21 on the ruling of 2026-10-11): a persistent session woken by a reply or a handoff, with
    # a daily floor; what wakes it on a `/start` is open for the operator (item tess-role-package)
    "tess": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    # the investor role (d16, built 2026-10-25 on the ruling of 2026-10-11): a persistent session woken by a reply or a handoff, with
    # a daily floor, like Tess (item chase-role-package)
    "chase": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
}
#: minutes a persistent role parks its listener for before re-parking: 105, re-armed on every expiry (ruling 7 of arc
#: fleet-accounts-and-pools, 2026-10-19/20, superseding row 178's restarting 24-hour listener). The runner stops a background
#: command at 2 h (Lucille's Doc, "listener (runner caps background tasks at 2h)" in `could_not_reach` on every run from
#: 2026-10-07; Atlas unreachable 2026-10-18 16:47Z → 10-19 04:45Z), so a day-long park died at 2 h and nothing re-parked it; a
#: 105-minute one exits on its own deadline (exit 2) before the cap and the session re-parks. The hub's listener re-registers
#: presence every 25 s under a 90 s TTL, so a park is presence for its length. One listener per session: `register` answers
#: `listener_alive` from the hub's `listener/<agent_id>` heartbeat key, and a turn that finds one running parks nothing.
#: Persistent seats only: a `spawned` or `fresh` role never parks one (`parks_listener`).
DEFAULT_LISTEN_MINUTES = 105
#: the runner's background-command defaults, read 2026-10-19 from the Bash tool's description: 1,800,000 ms when no
#: `timeout` is passed, 7,200,000 ms at most. A listener started without an explicit timeout dies at 30 min.
RUNNER_BACKGROUND_DEFAULT_MS = 1_800_000
RUNNER_BACKGROUND_MAX_MS = 7_200_000
#: minutes the background timeout runs past the listen deadline, so `switchboard listen` reaches its own exit 2 first
LISTEN_TIMEOUT_MARGIN_MINUTES = 5


def listen_timeout_ms(listen_minutes: float) -> int:
    """The `timeout` a listener's background command must be started with: its deadline plus a margin, never above the
    runner's cap. 105 min → 6,600,000 ms (110 min), under 7,200,000. Broken looks like: a value at or below
    RUNNER_BACKGROUND_DEFAULT_MS, which kills the listener at 30 min whatever its deadline."""
    return int(min(RUNNER_BACKGROUND_MAX_MS, (float(listen_minutes) + LISTEN_TIMEOUT_MARGIN_MINUTES) * 60_000))


def parks_listener(runtime: str | None) -> bool:
    """Whether a role of this runtime parks a listener: a persistent seat (`session`) only (ruling 7, 2026-10-19/20). A
    `spawned` role ends with its item and is reached through the actuator; a `fresh` routine ends with its run."""
    return runtime == "session"
#: hours a merge stays a `merged` event for a role that has not fired since: older ones are the daily clock's (a proposal)
MERGED_WINDOW_HOURS = 24
#: hours a spawned role's session may be on the roster with no listener parked before that is a lapse: a one-item run is
#: minutes to a few hours, and it parks the listener as its last step (SPEC row 178; a proposal, not a measurement)
SPAWNED_MIDTURN_HOURS = 3
#: hours a persistent role's session may go with no listener parked after it registered before that is a lapse. `switchboard
#: listen` exits on the message that wakes the session (measured 2026-10-07 on switchboard 2.5.0, by NumeroTech's Reed at
#: 11:55:59Z and by the org-core CEO session), so a session at work has no `listener/<agent id>` heartbeat until it re-parks;
#: every wake's first act is `org tempo register`, so the registration marks the wake. Inside this bound that gap is read as
#: `midturn` — named, never red; past it, the session ended without re-parking or its listener died (a proposal, not a
#: measurement: the gap's length per wake was never measured)
PERSISTENT_MIDTURN_HOURS = 2
AGENTS_KEY = "coord/tempo/agents"
#: one board key per spawned session, `<prefix><role>/<agent id>`, living until its listen deadline (0.60.36): a
#: `register` from a package before 0.60.31 rewrites AGENTS_KEY as `{at, roles}` and drops its `spawned` map, but never
#: touches a key it does not know (org-core 2026-10-11: Reed's 0.37.1 checkout at 19:39:02Z)
SPAWNED_SLOT_PREFIX = "coord/tempo/spawned/"


def spawned_slot_key(role: str, agent_id: str) -> str:
    return f"{SPAWNED_SLOT_PREFIX}{role}/{agent_id}"
RUNTIME_ACT = {"session": "dm", "spawned": "spawn", "fresh": "fire_trigger"}


def on_demand_act(role_cfg: dict[str, Any], runtime: str | None) -> str:
    act = str(role_cfg.get("on_demand") or "auto")
    if act != "auto":
        return act
    return RUNTIME_ACT.get(str(runtime or ""), "none")


def actuator_of(manifest: dict[str, Any]) -> str:
    return str((manifest.get("tempo") or {}).get("actuator") or "dispatcher")


def wake_route(role: str, manifest: dict[str, Any]) -> tuple[str, str]:
    """Whom a sender's `org tempo dm --role <role>` reaches, and how (rows 75, 77): `("dm", role)` for a listening persistent
    role and for the actuator itself; `("route", <actuator>)` for a spawned or fresh role — the DM lands on the actuator's
    listener as `wake <role>: <text>` and its plan spawns or fires the role on that wake; `("clock", role)` for a role nothing
    wakes on demand (`on_demand: none` — the doctor, or an org that opts a role out; the board key is the handoff and its cron
    reads it. The CEO was that role for one day, row 77; since 0.15.0 it listens, row 86)."""
    entry = (manifest.get("roles") or {}).get(role) or {}
    runtime = entry.get("runtime") or _default(role, "runtime")
    if isinstance(runtime, dict):   # an unlayered manifest: role.yaml's `runtime: {allowed, default}`
        runtime = runtime.get("default")
    cfg = dict(DEFAULT_ROLE_TEMPO.get(role, {}))
    cfg.update(entry.get("tempo") or {})
    act = on_demand_act(cfg, runtime)
    if role == actuator_of(manifest) or act == "dm":
        return "dm", role
    if act in ("spawn", "fire_trigger"):
        return "route", actuator_of(manifest)
    return "clock", role


def actuator_duty(manifest: dict[str, Any]) -> dict[str, Any]:
    """What the actuator is for in this org: the role the manifest names for it, whether that role is enabled, and the
    enabled roles that are started only through it (`wake_route` answers `route` — spawned or fired, never listening).

    An org that enables neither the actuator nor any role routed to it has nothing for one to do, so a missing
    heartbeat there is not a death. Measured 2026-09-23 on org-core's own reading (0.31.3): one role, the CEO, which
    listens, and a page whose headline was "DEAD actuator … the four-call wake is not running" — red for a part the
    org was never meant to have. The converse is the real failure, and this names it too: a role routed to an
    actuator that is not enabled has nothing that will ever start it.

    Broken looks like: `routed` is empty for a manifest enabling the builder with the dispatcher disabled, or
    `enabled` is False for Lucille's manifest."""
    role = actuator_of(manifest)
    roles = manifest.get("roles") or {}
    on = [r for r, e in roles.items() if (e or {}).get("enabled", True)]
    routed = sorted(r for r in on if r != role and wake_route(r, manifest) == ("route", role))
    return {"role": role, "enabled": role in on, "routed": routed}


#: the machine form a routed DM carries: `wake reviewer: pr_opened #211`
REQUEST_RE = re.compile(r"\bwake\s+([a-z][a-z0-9-]*)\s*:\s*([a-z_]+)\s+(\S+)", re.I)


def requests_from_inbox(inbox: Any) -> list[dict[str, Any]]:
    """The routed wakes in an actuator's inbox (`switchboard --json inbox`, a list or `{messages: [...]}`): one request per
    `wake <role>: <event> <what>` line, with who sent it and when. A request names the thing to act on now, target or not."""
    msgs = inbox.get("messages") if isinstance(inbox, dict) else inbox
    out: list[dict[str, Any]] = []
    for m in msgs or []:
        if not isinstance(m, dict):
            continue
        body = m.get("body") if m.get("body") is not None else m.get("text")
        if isinstance(body, dict):
            body = body.get("text") or body.get("body") or json.dumps(body)
        for role, event, what in REQUEST_RE.findall(str(body or "")):
            out.append({"role": role.lower(), "event": event.lower(), "what": what.rstrip(".,;"), "from": m.get("from") or m.get("sender") or m.get("agent_id"),
                        "at": m.get("at") or m.get("ts") or m.get("created_at")})
    return out


def cron_period_hours(cadence: str, now: dt.datetime | None = None) -> float | None:
    """The gap between two consecutive fires of a cron, in hours; None when the cadence is not a cron."""
    now = now or dt.datetime.now(dt.timezone.utc)
    n1 = cron_next(cadence, now)
    n2 = cron_next(cadence, n1) if n1 else None
    return round((n2 - n1).total_seconds() / 3600, 2) if n1 and n2 else None


# --- cron: the next fire, for a listener's --until and the hold rule ------------------

def _cron_field(spec: str, lo: int, hi: int) -> set[int]:
    out: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        step = 1
        if "/" in part:
            part, st = part.split("/", 1)
            step = max(1, int(st))
        if part in ("*", ""):
            rng = range(lo, hi + 1)
        elif "-" in part:
            a, b = part.split("-", 1)
            rng = range(int(a), int(b) + 1)
        else:
            rng = range(int(part), int(part) + 1)
        out |= {x for x in rng if (x - rng.start) % step == 0}
    return out


def cron_next(cadence: str, now: dt.datetime, horizon_days: int = 8) -> dt.datetime | None:
    """The next fire of a 5-field UTC cron after `now`, minute by minute, or None when the shape is not a cron."""
    parts = (cadence or "").split()
    if len(parts) != 5:
        return None
    try:
        mins, hrs, doms, mons, dows = (_cron_field(parts[0], 0, 59), _cron_field(parts[1], 0, 23), _cron_field(parts[2], 1, 31),
                                       _cron_field(parts[3], 1, 12), {d % 7 for d in _cron_field(parts[4], 0, 7)})
    except ValueError:
        return None
    t = (now.astimezone(dt.timezone.utc) + dt.timedelta(minutes=1)).replace(second=0, microsecond=0)
    end = t + dt.timedelta(days=horizon_days)
    while t <= end:
        if t.minute in mins and t.hour in hrs and t.day in doms and t.month in mons and ((t.weekday() + 1) % 7) in dows:
            return t
        t += dt.timedelta(minutes=1)
    return None


# --- the agents registry: who is listening, and how to address them ------------------

def agents_registry(board: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """role -> {agent_id, name, session_id, registered_at, listen_until} from coord/tempo/agents."""
    row = _latest_records(board).get(AGENTS_KEY)
    v = _value(row) if row else {}
    roles = v.get("roles") if isinstance(v, dict) else None
    return {r: e for r, e in (roles or {}).items() if isinstance(e, dict)}


def spawned_registry(board: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """role -> every session of a spawned role registered side by side (`spawned` in coord/tempo/agents), newest first.
    `roles` keeps one slot per role, so two builders spawned a second apart overwrote each other there (org-core 2026-10-11:
    Mason's 15:22:23Z registration replaced at 15:22:29Z); `spawned` keeps each by its agent id, with the item and PRs it
    registered for, which is how a DM addressed by subject finds its session (`address`). Since 0.60.36 each session also
    keeps its own key (`spawned_slot_key`), read here beside the map: a `register` from a package before 0.60.31 rewrites
    AGENTS_KEY as `{at, roles}`, and the map went with it (org-core 2026-10-11 19:39:02Z)."""
    latest = _latest_records(board)
    row = latest.get(AGENTS_KEY)
    v = _value(row) if row else {}
    spawned = v.get("spawned") if isinstance(v, dict) else None
    found: dict[str, dict[str, dict[str, Any]]] = {}

    def keep(role: str, aid: str, e: dict[str, Any]) -> None:
        e = dict(e, agent_id=e.get("agent_id") or aid)
        had = found.setdefault(role, {}).get(e["agent_id"])
        if had is None or str(e.get("registered_at") or "") > str(had.get("registered_at") or ""):
            found[role][e["agent_id"]] = e
    for role, by_aid in (spawned or {}).items():
        if isinstance(by_aid, dict):
            for aid, e in by_aid.items():
                if isinstance(e, dict):
                    keep(role, aid, e)
    # each session's own slot key, which no older package's `register` can drop (SPAWNED_SLOT_PREFIX)
    for k, r in latest.items():
        if k.startswith(SPAWNED_SLOT_PREFIX) and k.count("/") == SPAWNED_SLOT_PREFIX.count("/") + 1:
            role, aid = k[len(SPAWNED_SLOT_PREFIX):].split("/", 1)
            if _value(r):
                keep(role, aid, _value(r))
    return {role: sorted(rows.values(), key=lambda e: str(e.get("registered_at") or ""), reverse=True) for role, rows in found.items()}


def address(entries: list[dict[str, Any]], *, item: str | None = None, prs: Any = ()) -> dict[str, Any] | None:
    """The newest registration in `entries` that registered for `item` or for one of `prs`; None when none did — the
    caller then knows only the role, and addresses the role's newest registration as before."""
    want = {int(n) for n in prs or ()}
    for e in entries:
        if item and e.get("item") == item:
            return e
        if want and want & {int(n) for n in e.get("prs") or ()}:
            return e
    return None


#: a role's listening state, and what a plain (non-urgent) DM does to it — the page's marks, in the reading's words
PRESENCE_STATES = {
    "parked": "asleep with a listener parked — a message wakes it in seconds",
    "busy": "on do-not-disturb — only urgent messages wake it; anything else waits for its next look",
    "between turns": "on the roster, no listener parked — it reads messages on its next turn",
    "away": "on the roster, marked away until its declared return",
    "gone": "registered, and not on the roster — nothing is listening",
    "unregistered": "no agent registered for this role — nothing can be sent to it",
}


def presence(facts: dict[str, Any], manifest_room: dict[str, Any] | None = None) -> dict[str, Any]:
    """Every role's agent and its listening state, the room's viewer link, and every agent on the roster no role names.

    `read` is false when the roster was not read: an unread roster is never drawn as a team that is all gone (row 65).
    The heartbeats (`listener_beats`) are read with the board; facts from before 0.42.0 carry none, and then a role on
    the roster is `between turns` — true as far as those facts go, and the page says the heartbeats were not read."""
    from .asks import viewer_link
    reg = agents_registry(facts.get("board", []))
    agents = facts.get("agents")
    beats = facts.get("listener_beats")
    by_id = {str(a.get("agent_id")): a for a in (agents or []) if isinstance(a, dict) and a.get("agent_id")}
    parked = {b["agent_id"]: b for b in (beats or [])}
    room = dict(manifest_room or {})
    link = viewer_link(room.get("url"), room.get("workspace"), note=str(room.get("note") or ""))

    def state(aid: str | None) -> str:
        if not aid:
            return "unregistered"
        if aid in parked:
            return "busy" if parked[aid].get("dnd") else "parked"
        a = by_id.get(aid)
        if a is None:
            return "gone"
        return "away" if a.get("away") else "between turns"

    session_of, routine_of = _team_rows(facts)
    knob_rows = _kn.from_board(facts.get("board"))
    roles, named = [], set()
    for role, meta in (facts.get("roles") or {}).items():
        e = reg.get(role) or {}
        aid = e.get("agent_id")
        named.add(aid)
        st = state(aid) if agents is not None else None
        b = parked.get(aid or "") or {}
        roles.append({"role": role, "name": (meta or {}).get("name") or role, "agent_id": aid, "state": st,
                      "means": PRESENCE_STATES.get(st or "", "the roster was not read"),
                      "until": b.get("until"), "dnd": b.get("dnd"),
                      "seen": (by_id.get(aid or "") or {}).get("last_seen_at"), "runtime": (meta or {}).get("runtime"),
                      "cadence": (meta or {}).get("cadence"),
                      "session": session_of.get(role), "routine": routine_of.get(role),
                      "knob": knob_rows.get(_kn.name_for(role)), "knob_range": (facts.get("knob_ranges") or {}).get(role),
                      # the events that wake the role on demand: a role with none has no interval for a knob to move
                      "wake_on": list(((meta or {}).get("tempo") or {}).get("wake_on") or [])})
    others = [{"agent_id": aid, "name": a.get("name"), "state": state(aid), "seen": a.get("last_seen_at"),
               "branch": a.get("branch")} for aid, a in by_id.items() if aid not in named]
    off = [{"role": r, "name": (m or {}).get("name") or r, "runtime": (m or {}).get("runtime")}
           for r, m in (facts.get("roles_off") or {}).items()]
    return {"read": agents is not None, "beats_read": beats is not None, "roles": roles, "others": others, "off": off,
            "team": facts.get("team_snapshot"),
            "room": {"workspace": room.get("workspace"), "hub": room.get("url"), "viewer": link},
            "at": facts.get("presence_at") or facts.get("gathered_at")}


def _team_rows(facts: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    """Each role's live session (the most recently updated of this org's, not archived) and its routine, from whatever
    session and trigger lists the facts carry — passed in by a port holder, or the CEO's board snapshots (0.44.0)."""
    from .doctor import _role_of, _session_row, _this_org
    mani = {"roles": facts.get("roles") or {}, "org": {"id": facts.get("org"), "repo": facts.get("repo")}}
    sessions: dict[str, dict[str, Any]] = {}
    for raw in facts.get("sessions") or []:
        r = _session_row(raw)
        if r["status"].upper().endswith("ARCHIVED") or not _this_org(r, mani):
            continue
        role = _role_of(r, mani)
        if role == "other":
            continue
        if role not in sessions or str(r["updated_at"] or "") > str(sessions[role]["updated_at"] or ""):
            sessions[role] = {"id": r["id"], "title": r["title"], "status": r["status"], "bucket": r["bucket"],
                              "updated_at": r["updated_at"], "cost": r["cost"] if r["cost_known"] else None,
                              "tokens": r["tokens"] if r["tokens_known"] else None, "needs": r["needs"] or None,
                              "doing": _doing(raw)}
    routines: dict[str, dict[str, Any]] = {}
    for role, t in _triggers_by_role(facts).items():
        lr = t.get("last_run") or {}
        routines[role] = {"id": t.get("id"), "name": t.get("name"), "cron": t.get("cron_expression"),
                          "enabled": t.get("enabled"), "next_run_at": t.get("next_run_at"),
                          "last_fired_at": lr.get("fired_at") or t.get("last_fired_at"), "last_status": lr.get("status")}
    return sessions, routines


def _doing(raw: dict[str, Any]) -> str | None:
    """What a session says it is doing: its last turn's summary, else its task summary (list_sessions, 2026-09-25)."""
    c = raw.get("ccr", raw) if isinstance(raw, dict) else {}
    pts = (c.get("external_metadata") or {}).get("post_turn_summary") or c.get("post_turn_summary") or {}
    return (str(pts.get("status_detail") or c.get("task_summary") or "")[:200]) or None


def roster_ids(agents: list[Any]) -> set[str]:
    """The agent ids present on the hub's roster (`switchboard --json agents`), whatever the row shape."""
    out: set[str] = set()
    for a in agents or []:
        if isinstance(a, str):
            out.add(a)
        elif isinstance(a, dict):
            for k in ("agent_id", "id", "agent"):
                if a.get(k):
                    out.add(str(a[k]))
    return out


def listener_state(facts: dict[str, Any], now: dt.datetime, entry: dict[str, Any], runtime: str,
                   present: set[str] | None = None) -> tuple[str, Any, float | None]:
    """(state, heartbeat deadline, registration age in hours) for one registered agent — the reading `listeners` gives a
    role, for any registry entry (the wake plan addresses a spawned role's session by its item or PR, not by role).
    States as in `listeners`."""
    present = roster_ids(facts.get("agents", [])) if present is None else present
    beats = facts.get("listener_beats")
    aid = entry.get("agent_id")
    beat = next((b for b in beats or [] if isinstance(b, dict) and aid and str(b.get("agent_id")) == str(aid)), None)
    until = (beat or {}).get("until")
    until_at = parse_ts(until)
    if not aid:
        state = "unregistered"
    elif beat is not None:
        state = "lapsed" if until_at and until_at <= now else "parked"
    elif aid in present:
        state = "present" if beats is not None else "unknown"
    elif beats is None and facts.get("agents") is None:
        state = "unknown"
    else:
        state = "absent"
    age = hours(entry.get("registered_at"), now.isoformat()) if entry.get("registered_at") else None
    if (runtime == "session" and state in ("present", "absent") and beats is not None
            and age is not None and age < PERSISTENT_MIDTURN_HOURS):
        state = "midturn"   # woken, working, not yet re-parked: the gap `switchboard listen` leaves by exiting on the wake
    return state, until, age


def not_listening(facts: dict[str, Any], now: dt.datetime, entry: dict[str, Any], runtime: str,
                  present: set[str] | None = None) -> str | None:
    """Why a DM to this registered agent would reach no listener, or None when it may: a heartbeat past its deadline, no
    heartbeat and off the roster, or on the roster with no heartbeat for longer than a turn (`PERSISTENT_MIDTURN_HOURS`,
    `SPAWNED_MIDTURN_HOURS` for a spawned session). The roster alone never says listening: an away row stays on it for
    hours after the listener is gone (org-core 2026-10-14 00:09Z: the verifier "away 4h21m", no heartbeat, three DMs
    read back `peer_parked false`). None when the heartbeats were not read — the caller keeps the roster's reading."""
    state, until, age = listener_state(facts, now, entry, runtime, present=present)
    if state == "lapsed":
        return f"its listener's heartbeat deadline passed ({until})"
    if state == "absent":
        return "no listener heartbeat and not on the roster"
    if state == "present":
        bound = SPAWNED_MIDTURN_HOURS if runtime == "spawned" else PERSISTENT_MIDTURN_HOURS
        if age is None or age > bound:
            return (f"on the roster with no listener heartbeat, registered {age:.1f} h ago, past the {bound} h a turn is given"
                    if age is not None else "on the roster with no listener heartbeat and no registration time")
    return None


def listeners(facts: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Per persistent role: registered agent, whether a listener is parked, until when, and the age of the registration.

    `listening` is read from the listener's own heartbeat (`listener/<agent id>`, which only a running `switchboard listen`
    keeps alive), never from the roster: a session mid-turn is on the roster with nothing parked, and a DM does not wake
    it. Measured 2026-09-28 on switchboard 2.5.0 (org-core 0.45.0, NumeroTech main dfc12fa): check 4 read every role
    "listening … (parked until 09-21…09-25)" from the roster and the `listen_until` stored at registration, days past.
    `state` says what was read: parked (a heartbeat, deadline ahead), lapsed (a heartbeat whose deadline passed), present
    (on the roster, no heartbeat: mid-turn, or its listener died), absent (neither), unknown (on the roster, heartbeats
    unread — facts gathered before 0.42.0), midturn (a persistent role with no heartbeat, registered within
    PERSISTENT_MIDTURN_HOURS: the session is working the wake its listener exited on — not judged a lapse). `park_until` is the heartbeat's live deadline; `listen_until` the registration's."""
    reg = agents_registry(facts.get("board", []))
    present = roster_ids(facts.get("agents", []))
    beats = facts.get("listener_beats")
    out = []
    for role, meta in facts.get("roles", {}).items():
        runtime = meta.get("runtime") or ""
        if runtime not in ("session", "spawned"):
            continue   # a `fresh` routine session ends with its run: a parked one per fire would pile up (SPEC row 178)
        e = reg.get(role) or {}
        aid = e.get("agent_id")
        state, until, age = listener_state(facts, now, e, runtime, present=present)
        # a spawned role parks no listener (ruling 7, 2026-10-19/20, `parks_listener`): it is started per item and reached
        # through the actuator, so no reading of it is a lapse — never `judged` (the doctor's `_spawned_listening` reads the
        # same). A heartbeat it carries is an older package's session, still DMed while it lasts.
        out.append({"role": role, "agent_id": aid, "session_id": e.get("session_id"), "registered_at": e.get("registered_at"),
                    "registered_age_hours": age,
                    "listen_until": e.get("listen_until"), "park_until": until,
                    "on_roster": bool(aid and aid in present), "state": state, "runtime": runtime,
                    "listening": state == "parked", "roster_read": bool(facts.get("agents") is not None),
                    "beats_read": beats is not None,
                    # judged: the reading can say whether it listens — a heartbeat read, or a roster that does not carry the
                    # agent at all (a parked listener keeps its agent on the roster)
                    "judged": False if runtime == "spawned" else bool(aid) and state not in ("unknown", "midturn")})
    return out
#: a verdict is the first line of a reviewer's comment, or the machine line; an author's reply that quotes one is not
MACHINE_VERDICT_RE = re.compile(r"^\s*verdict:\s*(SOUND|UNSOUND|CANNOT TELL)\s+head:\s*([0-9a-f]{7,40})", re.I | re.M)
VERDICT_HEAD_STARTS = ("#", "**", "_", "verdict", "re-review", "reviewed", "review:", "review —", "review -")
SHA_RE = re.compile(r"(?:pinned to|pinned at|reviewed at|verdict at|at|head:?|@)\s*`?([0-9a-f]{7,40})`?", re.I)
AUTHOR_ROLES = ("ceo", "builder", "methods", "installer", "account-manager", "registrar", "verifier", "doctor", "checks-watch", "dispatcher")


def verdict_of(body: str, role: str = "unknown") -> tuple[str, str | None, str] | None:
    """(verdict, pinned sha, via) when a comment IS a verdict: the machine line `verdict: X head: <sha>`, or a first line
    that opens like a verdict headline. A comment signed by a non-reviewer role, or whose first line quotes
    `your <verdict>`, is an author's note (measured: #203 "your CANNOT TELL surfaced…", #208's own PR note)."""
    if not body or role in AUTHOR_ROLES:
        return None
    m = MACHINE_VERDICT_RE.search(body)
    if m:
        return m.group(1).upper(), m.group(2), "machine line"
    first = body.strip().splitlines()[0].strip() if body.strip() else ""
    low = first.lower()
    vm = VERDICT_RE.search(first[:200])
    if not vm or not low.startswith(VERDICT_HEAD_STARTS) or re.search(r"\byour\s+(?:sound|unsound|cannot tell)", low):
        return None
    sha = SHA_RE.search(first) or SHA_RE.search(body[:400])
    return vm.group(1), (sha.group(1) if sha else None), "headline"
FACTS_DIR = ".org/tempo"


#: the GitHub token of the org being read, when it is not the process's own (0.42.2). A fleet reader reads several orgs
#: from one process, one thread each, and a fine-grained token covers one owner only (the operator, 2026-09-25: "one
#: token … + override per repo which I'll use for numerotech"). A context variable, so each reader's thread carries its
#: own and none leaks into another's; never os.environ, which every thread shares.
_GH_TOKEN: contextvars.ContextVar[str | None] = contextvars.ContextVar("org_gh_token", default=None)


def org_token(org_id: str) -> str | None:
    """`GH_TOKEN_<ORG ID>` (upper-cased, anything not a letter or digit as `_`) when set and not empty, else None — and
    None means the process's own `GH_TOKEN`."""
    return os.environ.get("GH_TOKEN_" + re.sub(r"[^A-Za-z0-9]", "_", str(org_id)).upper()) or None


@contextlib.contextmanager
def gh_token(token: str | None):
    """Read with this org's token for the duration (`org_token`); a None token changes nothing."""
    reset = _GH_TOKEN.set(token) if token else None
    try:
        yield
    finally:
        if reset is not None:
            _GH_TOKEN.reset(reset)


def _gh_env(env: dict[str, str] | None) -> dict[str, str]:
    tok = _GH_TOKEN.get()
    return {**os.environ, **({"GH_TOKEN": tok, "GITHUB_TOKEN": tok} if tok else {}), **(env or {})}


def _run(cmd: list[str], env: dict[str, str] | None = None) -> str:
    if cmd[:2] == ["gh", "api"] and len(cmd) == 3 and not shutil.which("gh"):
        return _gh_api_get(cmd[2])
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120, env=_gh_env(env))
    if out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd[:3])}: {(out.stderr or out.stdout).strip()[:300]}")
    return out.stdout


def _gh_api_get(path: str) -> str:
    """`gh api <path>` where `gh` is not installed: the same GET, by `curl`, with the token `gh` would have used.

    Measured 2026-09-24 in the org-core CEO's cloud container: no `gh` on PATH, `GH_TOKEN` set, and api.github.com
    reachable — so every reading taken there drew its pull-request tiers DARK (`prs: [Errno 2] … 'gh'`) and the page had
    no pull request to show. Only a plain three-word GET falls back; a write never does. `curl` rather than urllib, so an
    empty PATH still makes the port unreachable (the tests' way of cutting it), and the token goes in on stdin, never in
    argv. A missing `curl` or token is an OSError, which every caller already records as a source it could not read."""
    token = _GH_TOKEN.get() or os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if not token:
        raise FileNotFoundError("gh: not installed, and no GH_TOKEN to read the API without it")
    if not shutil.which("curl"):
        raise FileNotFoundError("gh: not installed, and no curl to read the API without it")
    url = "https://api.github.com/" + path.lstrip("/")
    out = subprocess.run(["curl", "-sS", "-L", "-K", "-", "-H", "Accept: application/vnd.github+json",
                          "-w", "\n%{http_code}", url], input=f'header = "Authorization: Bearer {token}"\n',
                         capture_output=True, text=True, timeout=120)
    body, _, code = (out.stdout or "").rpartition("\n")
    if out.returncode != 0 or not code.isdigit() or int(code) >= 400:
        why = (out.stderr or "").strip() or f"HTTP {code} {body.strip()[:200]}"
        raise RuntimeError(f"gh api {path} (by curl): {why[:300]}")
    return body


def parse_ts(s: Any) -> dt.datetime | None:
    if not s or not isinstance(s, str):
        return None
    s = s.strip().replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(s)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)


def hours(a: Any, b: Any) -> float | None:
    ta, tb = parse_ts(a), parse_ts(b)
    if ta is None or tb is None:
        return None
    return round((tb - ta).total_seconds() / 3600, 2)


def _min_ts(a: str | None, b: str | None) -> str | None:
    if not a:
        return b
    if not b:
        return a
    return a if (parse_ts(a) or dt.datetime.max.replace(tzinfo=dt.timezone.utc)) <= (parse_ts(b) or dt.datetime.max.replace(tzinfo=dt.timezone.utc)) else b


def pr_numbers(val: Any) -> list[int]:
    """Every PR number a record field names: an int, a URL, '#204', or a list of those."""
    if isinstance(val, bool):
        return []
    if isinstance(val, int):
        return [val]
    if isinstance(val, list):
        return [n for v in val for n in pr_numbers(v)]
    if isinstance(val, dict):
        return pr_numbers(val.get("number") or val.get("pr") or val.get("url"))
    if isinstance(val, str):
        return [int(m.group(1) or m.group(2)) for m in PR_NUMBER_RE.finditer(val)]
    return []


# --- gather ------------------------------------------------------------------

def listener_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Every parked listener, from a `board list`: switchboard's `listener/<agent id>` heartbeat, whose value (inline in
    the listing, no `get` needed) says what wakes the agent — any message, or on do-not-disturb (`dnd`) only the types
    it names — and until when. The key exists only while a listener process keeps it alive (switchboard 2.5.0,
    `rendezvous.reachable_now`): present is parked, absent is not."""
    out = []
    for r in rows or []:
        key = str(r.get("key", ""))
        if not key.startswith("listener/"):
            continue
        v = r.get("value")
        if isinstance(v, str):
            try:
                v = json.loads(v)
            except json.JSONDecodeError:
                v = {}
        v = v if isinstance(v, dict) else {}
        dnd = v.get("dnd") if isinstance(v.get("dnd"), dict) else None
        out.append({"agent_id": key[len("listener/"):], "until": v.get("until"), "updated_at": r.get("updated_at"),
                    "dnd": ({"wakes_on": list(dnd.get("wakes_on_types") or []),
                             "reads_rest_at": dnd.get("reads_everything_else_at")} if dnd else None)})
    return out


def gather_presence(workspace: str, run: Runner = _run, url: str | None = None,
                    now: dt.datetime | None = None) -> dict[str, Any]:
    """Who is here and who can be woken (0.42.0): the roster and the listener heartbeats, in two switchboard calls — cheap
    enough for the fast lane, so the page's marks move within its seconds."""
    env = {"SWITCHBOARD_WORKSPACE": workspace, **({"SWITCHBOARD_URL": url} if url else {})}
    at = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    out: dict[str, Any] = {"read_at": at, "agents": None, "listeners": None, "asks": None, "knobs": None, "why": None}
    try:
        rows = json.loads(run(["switchboard", "--json", "board", "list"], env) or "[]")
        out["listeners"] = listener_rows(rows)
        # the operator's asks ride in the same listing (`asks.BOARD_PREFIX`), so the page shows them as they land
        out["asks"] = [{"key": r.get("key"), "value": r.get("value")} for r in rows
                       if str(r.get("key", "")).startswith("coord/asks/")]
        # so do the operator's knobs (SPEC §10): a knob set from the page or the CLI reaches the page in seconds
        out["knobs"] = [{"key": r.get("key"), "value": r.get("value")} for r in rows
                        if str(r.get("key", "")).startswith("org/knobs/")]
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        out["why"] = f"board: {str(e)[:160]}"
    try:
        out["agents"] = json.loads(run(["switchboard", "--json", "agents"], env) or "[]")
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        out["why"] = (out["why"] + "; " if out["why"] else "") + f"agents: {str(e)[:160]}"
    return out


def gather_board(workspace: str, run: Runner = _run, prefixes: tuple[str, ...] = ("roles/", "coord/"),
                 url: str | None = None, listeners: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Every board row under the prefixes, with its value parsed. Records are JSON strings inside `value`.

    `url` is the manifest's `ports.coordination.url`. Without it the CLI dials whatever `SWITCHBOARD_URL`
    the ambient environment holds — which is not this org's hub, and on a fleet machine is another org's.
    Measured 2026-09-20 against switchboard 2.4.1: a hub prints "agents started here will dial
    https://switchboard.lucille-ai.com, not this hub" on startup for exactly this reason. Every other reader
    in the package already passes it (doctor.py:74-75, cli.py:238/251/275); these two did not.

    **One call, however many keys.** `board list` carries each row's value, updated_at and updated_by whole, so the listing
    is the read. Until this change each roles/ and coord/ key was fetched again with `switchboard --json board get <key>` —
    one Python process of ~0.5-0.7 CPU-s per key, 274 keys on gald33/lucille, ~1.8 spawns/s under `org command --serve`
    (Wren, org-core 0.60.45). Wren compared 280 keys on switchboard 2.5.0: list and `get` identical, longest value 143,670
    chars. Broken looks like: a `switchboard --json board get` in the process list while a dashboard is open, or a row whose
    value is `{"_raw": ...}` for a record that parses — a listing that truncated a value (not seen on 2.5.0).
    """
    env = {"SWITCHBOARD_WORKSPACE": workspace}
    if url:
        env["SWITCHBOARD_URL"] = url
    rows = json.loads(run(["switchboard", "--json", "board", "list"], env) or "[]")
    if listeners is not None:          # the heartbeats ride in the same listing: no extra call (0.42.0)
        listeners.extend(listener_rows(rows))
    out: list[dict[str, Any]] = []
    for r in rows:
        key = str(r.get("key", ""))
        if not key.startswith(prefixes):
            continue
        value = r.get("value")
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                value = {"_raw": value[:400]}
        out.append({"key": key, "updated_at": r.get("updated_at"), "expires_at": r.get("expires_at"), "value": value,
                    **({"updated_by": by} if (by := r.get("updated_by")) else {})})
    return out


def classify_paths(paths: list[str]) -> str:
    if any(p.startswith(PRODUCT_PREFIXES) for p in paths):
        return "product"
    if paths and all(p.startswith(ROADMAP_PREFIXES) for p in paths):
        return "roadmap"
    if paths and all(p.startswith(ORG_PREFIXES) or p.startswith(ROADMAP_PREFIXES) for p in paths):
        return "org"
    return "docs" if paths else "unknown"


def author_role(body: str, head_ref: str = "") -> str:
    m = ROLE_SIG_RE.search(body or "")
    if m:
        return m.group(2)
    if "org-core CEO session" in (body or ""):
        return "installer"
    if head_ref.startswith(("cursor/", "e2e/", "dependabot/")):
        return "human"
    return "unknown"


#: a slug-shaped token — what a roadmap item's key looks like. A pull request names an item when a whole token of its
#: branch, title or body IS the key; a token is bounded by anything that cannot sit inside a slug, so `d1-name` never
#: matches inside `ad1-names`, and a date (`2026-09-24`) is not one.
SLUG_TOKEN_RE = re.compile(r"(?<![A-Za-z0-9_-])[a-z0-9]+(?:-[a-z0-9]+)+(?![A-Za-z0-9_-])")
#: how many distinct slugs a pull request's body keeps in the facts: the candidates, not the body
MENTIONS_KEPT = 120


#: a key written as code (`a`) or as its file (roadmap/items/a.yaml) names it even when it is one word
KEY_CODE_RE = re.compile(r"`([a-z0-9][a-z0-9-]{0,80})`|items/([a-z0-9][a-z0-9-]{0,80})\.ya?ml\b")


def slug_tokens(text: Any) -> set[str]:
    """Every token in a text an item key is matched against (`explorer.model`): a slug (a date is not one), a word in
    backticks, or an item file's name. A bare word in prose is not a key — `a` and `claims` are English first."""
    t = str(text or "")
    return ({x for x in SLUG_TOKEN_RE.findall(t) if not x.replace("-", "").isdigit()}
            | {a or b for a, b in KEY_CODE_RE.findall(t)})


#: how a builder's pull request names the item it built: a line that opens ``Item: `<key>` `` or ``Item `<key>` ``, the key
#: (or a list of keys) straight after the word — read 2026-10-10 on #103, #110, #111, #114, #116, #118, #120, #153, #156.
#: A key merely mentioned elsewhere is related, not built: #92 ("Follow-up to #87 (item `…`") is a partial, and this PR's
#: own body names a dozen items it does not build.
ITEM_LINE_RE = re.compile(r"^[^\w`]*items?[^\w`]*((?:`[a-z0-9][a-z0-9-]{0,159}`[^\w`]*(?:and[^\w`]+)?)+)", re.I | re.M)
#: a backticked key on that line. Longer than `KEY_CODE_RE`'s 81: #153's key is 84 characters
ITEM_KEY_RE = re.compile(r"`([a-z0-9][a-z0-9-]{0,159})`")


def built_items(body: Any, head_ref: Any = "") -> list[str]:
    """The item keys a pull request says it BUILT: the backticked keys on its `Item:` line, and its branch's last segment
    when that is slug-shaped. Candidates only — the caller keeps the ones that are items (`actuator.settle_merged`).
    Broken looks like: a key mentioned in prose (a related item, a list of claims) returned here."""
    keys: set[str] = set()
    for line in ITEM_LINE_RE.findall(str(body or "")):
        keys |= set(ITEM_KEY_RE.findall(line))
    tail = str(head_ref or "").rsplit("/", 1)[-1]
    if SLUG_TOKEN_RE.fullmatch(tail):
        keys.add(tail)
    return sorted(keys)


def gather_prs(slug: str, since: str, run: Runner = _run, limit: int = 80) -> list[dict[str, Any]]:
    """Pull requests updated since `since` with their files, comments and reviews — the timestamps a cycle time needs."""
    prs = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=all&sort=updated&direction=desc&per_page={limit}"], None) or "[]")
    out: list[dict[str, Any]] = []
    for pr in prs:
        if str(pr.get("updated_at", "")) < since:
            continue
        n = pr["number"]
        files = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}/files?per_page=100"], None) or "[]")
        comments = json.loads(run(["gh", "api", f"repos/{slug}/issues/{n}/comments?per_page=100"], None) or "[]")
        reviews = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}/reviews?per_page=50"], None) or "[]")
        paths = [f.get("filename", "") for f in files]
        events = [{"at": c.get("created_at"), "body": c.get("body") or ""} for c in comments]
        events += [{"at": r.get("submitted_at"), "body": r.get("body") or "", "state": r.get("state")} for r in reviews]
        verdicts = []
        for e in events:
            v = verdict_of(e["body"], author_role(e["body"])) if e.get("at") else None
            if v:
                verdicts.append({"at": e["at"], "verdict": v[0], "sha": v[1], "via": v[2]})
        verdicts.sort(key=lambda x: x["at"])
        head_sha = (pr.get("head") or {}).get("sha")
        latest_review: dict[str, str] = {}
        for r in sorted(reviews, key=lambda r: r.get("submitted_at") or ""):
            if r.get("state") in ("APPROVED", "CHANGES_REQUESTED", "DISMISSED"):
                latest_review[str((r.get("user") or {}).get("login") or "")] = str(r["state"])
        out.append({
            "repo": slug, "number": n, "title": pr.get("title"), "state": pr.get("state"), "draft": bool(pr.get("draft")),
            "url": pr.get("html_url"),
            # the item keys its body could be naming, kept as candidates rather than the body (explorer.model)
            "mentions": sorted(slug_tokens(pr.get("body") or ""))[:MENTIONS_KEPT],
            "builds": built_items(pr.get("body"), (pr.get("head") or {}).get("ref")),
            "head_ref": (pr.get("head") or {}).get("ref"), "head_sha": head_sha,
            "opened_at": pr.get("created_at"), "updated_at": pr.get("updated_at"),
            "merged_at": pr.get("merged_at"), "closed_at": pr.get("closed_at"),
            "head": head_state(slug, n, head_sha, run) if pr.get("state") == "open" and head_sha else None,
            "changes_requested": "CHANGES_REQUESTED" in latest_review.values(),
            "author_role": author_role(pr.get("body") or "", (pr.get("head") or {}).get("ref") or ""),
            "kind": classify_paths(paths), "files": paths[:200],
            "first_verdict_at": verdicts[0]["at"] if verdicts else None, "first_verdict": verdicts[0]["verdict"] if verdicts else None,
            "verdicts": verdicts,
            "comments": [{"at": e.get("at"), "role": author_role(e.get("body") or ""), "head": (e.get("body") or "")[:120]} for e in events],
        })
    return out


#: how many pull requests the index keeps: one API page, newest-updated first — enough to tie a done item to the pull
#: request that shipped it, where `gather_prs` keeps only the window's
PR_INDEX_KEPT = 100


def gather_pr_index(slug: str, run: Runner = _run, limit: int = PR_INDEX_KEPT) -> list[dict[str, Any]]:
    """Every recent pull request in ONE call: its number, title, state, branch, link and the item keys its body names.

    The explorer's list (0.41.0), and the fast lane's (`refresh_fast`): cheap enough to re-read every few seconds where
    `gather_prs` costs 1 + 3N calls (org-core, 2026-09-24: 88 for 29 pull requests). It carries no review and no check —
    those stay the full read's, so nothing the chain or the chair measures is ever taken from this."""
    rows = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=all&sort=updated&direction=desc&per_page={limit}"], None) or "[]")
    return [{"number": pr.get("number"), "title": pr.get("title") or "", "state": pr.get("state"),
             "draft": bool(pr.get("draft")), "head_ref": (pr.get("head") or {}).get("ref"), "url": pr.get("html_url"),
             "opened_at": pr.get("created_at"), "updated_at": pr.get("updated_at"), "merged_at": pr.get("merged_at"),
             "closed_at": pr.get("closed_at"),
             "author_role": author_role(pr.get("body") or "", (pr.get("head") or {}).get("ref") or ""),
             "mentions": sorted(slug_tokens(pr.get("body") or ""))[:MENTIONS_KEPT]}
            for pr in rows if isinstance(pr, dict) and pr.get("number")]


RED_CONCLUSIONS = ("failure", "timed_out", "startup_failure", "action_required")


def head_state(slug: str, n: int, sha: str, run: Runner = _run) -> dict[str, Any]:
    """What GitHub says about an open PR's head now: the check runs' conclusions, the commit's combined status — a
    status-API red (Vercel's) is not a check run and is absent from the check-runs list, so a chair reading that list
    alone reads green (Lucille 2026-09-21, row 112) — and `mergeable_state`, which GitHub recomputes after a push and
    reports `unknown` meanwhile. Each endpoint is read on its own; one that fails leaves `None`, never a green."""
    out: dict[str, Any] = {"sha": sha, "checks": None, "status": None, "mergeable_state": None, "mergeable": None}
    try:
        cr = (json.loads(run(["gh", "api", f"repos/{slug}/commits/{sha}/check-runs?per_page=100"], None) or "{}") or {}).get("check_runs") or []
        out["checks"] = {"total": len(cr), "red": sorted({str(c.get("name") or "?") for c in cr if c.get("conclusion") in RED_CONCLUSIONS}),
                         "pending": sorted({str(c.get("name") or "?") for c in cr if c.get("status") != "completed"})}
    except Exception as e:  # noqa: BLE001 — unread is unread; the row says so
        out["checks_error"] = str(e)[:120]
    try:
        st = json.loads(run(["gh", "api", f"repos/{slug}/commits/{sha}/status"], None) or "{}") or {}
        out["status"] = {"state": st.get("state"), "failing": sorted({str(x.get("context") or "?") for x in st.get("statuses") or [] if x.get("state") in ("failure", "error")}),
                         "pending": sorted({str(x.get("context") or "?") for x in st.get("statuses") or [] if x.get("state") == "pending"})}
    except Exception as e:  # noqa: BLE001
        out["status_error"] = str(e)[:120]
    try:
        pr = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}"], None) or "{}") or {}
        out["mergeable_state"], out["mergeable"] = pr.get("mergeable_state"), pr.get("mergeable")
    except Exception as e:  # noqa: BLE001
        out["mergeable_error"] = str(e)[:120]
    return out


def needs_action(p: dict[str, Any]) -> list[str]:
    """Why an open PR waits on somebody's act: CI red, a status-API failure, a conflict, or changes requested."""
    h = p.get("head") or {}
    why: list[str] = []
    if (h.get("checks") or {}).get("red"):
        why.append("ci red: " + ", ".join(h["checks"]["red"][:4]))
    if (h.get("status") or {}).get("failing"):
        why.append("status failure: " + ", ".join(h["status"]["failing"][:4]))
    if h.get("mergeable_state") == "dirty":
        why.append("conflicted")
    if p.get("changes_requested"):
        why.append("changes requested")
    return why


def _default(role: str, attr: str) -> Any:
    """A role's package default for `attr` (`runtime`, `cadence`, …): the package attribute when it has one, else the
    contract's field, unwrapped from role.yaml's `{allowed, default}` / `{default, label}` shape to the default itself."""
    try:
        from .roles import discover
        pkg = discover().get(role)
        if not pkg:
            return None
        v = getattr(pkg, attr, None)
        if v is None and isinstance(getattr(pkg, "contract", None), dict):
            v = pkg.contract.get(attr)
        if isinstance(v, dict) and "default" in v:
            v = v["default"]
        return v
    except Exception:
        return None


def gather_runs(repo: Path) -> list[dict[str, Any]]:
    """The committed run ledgers, `.org/runs/<role>.jsonl`, one record per line."""
    out: list[dict[str, Any]] = []
    d = repo / ".org" / "runs"
    if not d.is_dir():
        return out
    for p in sorted(d.glob("*.jsonl")):
        for line in p.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            rec.setdefault("role", p.stem)
            out.append(rec)
    return out


def role_tempo(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Each enabled role's tempo: the package default under the manifest's `roles.<r>.tempo`."""
    out: dict[str, dict[str, Any]] = {}
    for r, e in manifest.get("roles", {}).items():
        if not e.get("enabled", True):
            continue
        cfg = dict(DEFAULT_ROLE_TEMPO.get(r, {}))
        cfg.update(e.get("tempo") or {})
        if cfg:
            out[r] = cfg
    return out


def targets(manifest: dict[str, Any], now: dt.datetime | None = None) -> dict[str, float]:
    """The edge targets: the package defaults, then — when nothing wakes the CEO on demand (row 77) and it has a cron — the
    CEO's own period as `verdict_to_merge`, since a SOUND verdict waits for that clock by design; the manifest's
    `tempo.targets` wins over both."""
    t = dict(DEFAULT_TARGETS)
    ceo = (manifest.get("roles") or {}).get("ceo") or {}
    if ceo.get("enabled", True) and not (role_tempo(manifest).get("ceo") or {}).get("wake_on"):
        period = cron_period_hours(str(ceo.get("cadence") or _default("ceo", "cadence") or ""), now)
        if period:
            t["verdict_to_merge"] = period
    t.update({k: float(v) for k, v in ((manifest.get("tempo") or {}).get("targets") or {}).items()})
    return t


#: bullets under the operator file's waiting heading, capped: each undated one costs a `git log -S` over the file's
#: whole history, and `org status` gathers live.
OPERATOR_BULLET_CAP = 40

#: a bullet the operator file's author marked as an open decision: `- [open] …` at its start. Only a marked bullet is counted as a
#: waiting decision lacking a recommendation (`handoffs.missing`); an unmarked one still shows, uncounted. A proposal, not a ruling.
OPEN_MARK_RE = re.compile(r"^\s*\[open\]", re.I)


def _lock_facts(repo: Path) -> dict[str, Any]:
    """The applied lock, carried in the facts so a reading can say which org-core wrote each record without reaching
    the disk again (SPEC §18, rows 87, 88). `{}` when the repo was never applied, which is itself the finding."""
    import yaml

    from .lock import read as read_lock
    try:
        return read_lock(repo) or {}
    except (OSError, ValueError, yaml.YAMLError):
        return {}


#: an operator arc's items that wait on the operator: startable, so nothing but a ruling stands between them and done.
#: `blocked` waits on another item, `deferred` was put off on purpose, `verifying` and `done` are past the ruling.
OPERATOR_ARC_STATUSES = ("ready",)


def _first_paragraph(text: Any, limit: int = 300) -> str:
    para = str(text or "").strip().split("\n\n", 1)[0]
    flat = " ".join(para.split())
    return flat if len(flat) <= limit else flat[:limit].rsplit(" ", 1)[0] + "…"


def _operator_arc(repo: Path, manifest: dict[str, Any]) -> dict[str, Any] | None:
    """The open items of the roadmap arc the manifest names as the operator's (`ports.work_store.operator_arc`),
    each dated by the commit that introduced its file — the repo half of the operator queue for an org that keeps it
    in its roadmap rather than in an operator file.

    Measured 2026-09-23 on org-core's own reading: "Waiting on you — not checked", because org-core has no operator
    file, while the decisions only the operator can rule sat in `roadmap/items/` under `org-core-decisions` — four
    `ready`, the oldest filed 2026-09-20. The queue existed; the reading had no way to be told where.

    `None` when no arc is declared or the items directory cannot be read — never an empty queue (row 65). An item
    that does not parse is named in `unparsed`, not skipped in silence."""
    import yaml

    from . import doctor as dr
    ws = (manifest.get("ports") or {}).get("work_store") or {}
    arc = ws.get("operator_arc")
    if not arc:
        return None
    base = str(ws.get("files") or "roadmap/").strip("/")
    d = repo / base / "items"
    if not d.is_dir():
        return None
    items, unparsed, carried = [], [], 0
    for path in sorted(d.glob("*.yaml")):
        try:
            doc = yaml.safe_load(path.read_text()) or {}
        except (OSError, yaml.YAMLError):
            unparsed.append(path.name)
            continue
        if not isinstance(doc, dict) or doc.get("arc") != arc:
            continue
        carried += 1
        if doc.get("status") not in OPERATOR_ARC_STATUSES:
            continue
        rel = f"{base}/items/{path.name}"
        since = dr._introduced_at(repo, rel, f"id: {doc.get('id')}") if doc.get("id") else None
        items.append({"head": str(doc.get("title") or doc.get("id") or path.stem), "body": _first_paragraph(doc.get("evidence")),
                      "since": since.isoformat() if since else None, "source": rel, "id": doc.get("id"),
                      "dated_by": "the commit that introduced it" if since else "nothing"})
    return {"arc": str(arc), "dir": f"{base}/items", "carried": carried, "items": items[:OPERATOR_BULLET_CAP],
            "unparsed": unparsed}


def _operator_waiting(repo: Path, manifest: dict[str, Any], *, refresh: bool = False, now: dt.datetime | None = None) -> dict[str, Any] | None:
    """The repo half of the operator queue: the operator file's `Waiting on the operator` bullets, and — when the
    manifest names one — the open items of the operator's roadmap arc. Either is the half; both are read when both exist.

    `None`, never `{}`, when neither could be read: an unread half must not read as an empty one (row 65)."""
    arc = _operator_arc(repo, manifest)
    fq = _operator_file(repo, manifest, refresh=refresh, now=now)
    if arc is None:
        return fq
    label = f"the `{arc['arc']}` arc" + (" and the operator file" if fq else "")
    return {"file": fq["file"] if fq else arc["dir"], "label": label,
            # the arc IS a surface: the file's missing section is not a missing surface when the arc stands in for it
            "has_section": bool(arc["carried"]) or bool(fq and fq["has_section"]),
            "items": list(arc["items"]) + (fq["items"] if fq else []),
            "arc": arc["arc"], "arc_dir": arc["dir"], "arc_carried": arc["carried"], "arc_unparsed": arc["unparsed"],
            "file_read": fq is not None, "checkout": fq["checkout"] if fq else None}


#: the UTC instant a two-clocks stamp carries after its local half (rows 142-143): `(2026-09-24 18:40Z)` or `(18:40Z)`
UTC_BESIDE_RE = re.compile(r"^\s*[A-Z]{2,5}\s*\((?:(20\d\d-\d\d-\d\d)[T ])?(\d\d:\d\d)Z\)")


def _bullet_instant(text: str, m: re.Match) -> dt.datetime | None:
    """When a bullet was written, from the date it carries. A two-clocks stamp is local first with the UTC instant beside
    it, and the local half was read as UTC: measured on org-core 2026-09-24, `2026-09-24 21:40 IDT (18:40Z)` dated the
    bullet three hours in the future, and the page aged it "1 minute". The instant beside it is the one to read; a
    short `(HH:MMZ)` takes the UTC date nearest the local one (a local 01:30 in Jerusalem is the previous day's 22:30Z).
    Broken looks like: a local stamp with a UTC instant beside it aged from the local half."""
    from . import doctor as dr
    u = UTC_BESIDE_RE.match(text[m.end():]) if m.group(2) else None
    if u:
        if u.group(1):
            return dr.parse_ts(f"{u.group(1)}T{u.group(2)}Z")
        local = dt.datetime.fromisoformat(f"{m.group(1)}T{m.group(2)}+00:00")
        day = dt.datetime.fromisoformat(f"{m.group(1)}T{u.group(2)}+00:00")
        return min((day + dt.timedelta(days=k) for k in (-1, 0, 1)), key=lambda c: abs(c - local))
    return dr.parse_ts(m.group(1) + ("T" + m.group(2) if m.group(2) else "T00:00") + "Z")


def _git_out(repo: Path, *args: str) -> str | None:
    out = _git_out_raw(repo, *args)
    return out.strip() if out is not None else None


def _git_out_raw(repo: Path, *args: str) -> str | None:
    try:
        p = subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True, timeout=60)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    return p.stdout if p.returncode == 0 else None


def _git_try(repo: Path, *args: str) -> tuple[bool, str]:
    """`(ok, text)`: stdout on success, else what git said (stderr, one line, cut) or why it could not run."""
    try:
        p = subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        return False, "git is not installed"
    except subprocess.TimeoutExpired:
        return False, "git timed out after 60s"
    if p.returncode == 0:
        return True, p.stdout
    return False, " ".join((p.stderr or p.stdout or f"exit {p.returncode}").split())[:200]


#: how long a fetch that met another fetch's lock waits before its one retry (seconds)
FETCH_LOCK_RETRY_S = 2.0


def _fetch_branch(repo: Path, branch: str) -> tuple[bool, str | None]:
    """Fetch one branch of `origin`. `(True, None)` when it landed; else `(False, why)` with git's own words, so a page that
    reads DARK says why (Lucille and numerotech VMs, 2026-10-07: "the fetch failed" for both, cause unreadable from the
    page). A lock another fetch holds (`index.lock`, `shallow.lock`, `*.lock`) is retried once and, if still held, is said
    to be that. Broken looks like: a failed fetch whose reason is only "the fetch failed"."""
    ok, text = _git_try(repo, "fetch", "--quiet", "origin", branch)
    if not ok and ".lock" in text:
        time.sleep(FETCH_LOCK_RETRY_S)
        ok, text = _git_try(repo, "fetch", "--quiet", "origin", branch)
        if not ok and ".lock" in text:
            return False, f"another fetch holds a lock on this checkout ({text})"
    return (True, None) if ok else (False, text)


def checkout_stamp(repo: Path, *, refresh: bool = False, now: dt.datetime | None = None) -> dict[str, Any]:
    """Which commit a count over this checkout was read at, when, and how far the remote's default branch is ahead.

    `refresh` fetches the default branch first (every full read, and the CEO's refresh call); a failed fetch is said in
    `why`, never read as current. `read_commit` is the commit the files were taken from: the remote's when the checkout is
    behind it, else HEAD. Reported 2026-10-07 by numerotech's CEO (their inference, not my measurement): the page counted from
    a checkout `_operator_file` never fetched. Broken looks like: a count with no `read_commit`, or `behind` > 0 with the
    count taken from HEAD."""
    at = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    head = _git_out(repo, "rev-parse", "HEAD")
    if head is None:
        return {"read_commit": None, "head": None, "remote": None, "behind": None, "read_at": at, "fetched": False,
                "why": "not a git checkout, or it has no commit — the files were read as they stand"}
    ref = _git_out(repo, "symbolic-ref", "--short", "refs/remotes/origin/HEAD") or "origin/main"
    why = None
    fetched = False
    if refresh:
        fetched, err = _fetch_branch(repo, ref.split("/", 1)[-1])
        if not fetched:
            why = f"the fetch failed ({err}) — the remote may be ahead of this reading"
    remote = _git_out(repo, "rev-parse", ref)
    behind = None
    if remote:
        n = _git_out(repo, "rev-list", "--count", f"{head}..{remote}")
        behind = int(n) if n and n.isdigit() else None
    taken = remote if behind else head
    return {"read_commit": taken, "head": head, "remote": remote, "remote_ref": ref, "behind": behind, "read_at": at,
            "fetched": fetched, "why": why or (None if remote else f"no `{ref}` to compare against")}


def _read_operator_text(repo: Path, rel: str, stamp: dict[str, Any]) -> str | None:
    """The file at the commit the stamp says it was read at: the remote's when the checkout is behind it."""
    if stamp.get("behind") and stamp.get("remote"):
        t = _git_out_raw(repo, "show", f"{stamp['remote']}:{rel}")
        if t is not None:
            return t
        stamp["why"] = "the file is not at the remote's commit — read from the checkout"
        stamp["read_commit"] = stamp["head"]
    try:
        return (repo / rel).read_text()
    except OSError:
        return None


def _operator_file(repo: Path, manifest: dict[str, Any], *, refresh: bool = False, now: dt.datetime | None = None) -> dict[str, Any] | None:
    """The operator file's `Waiting on the operator` bullets, each dated by the ISO date it carries, else by the commit
    that introduced it — the half of the operator queue that lives in the repo rather than on the board (doctor check 15).

    `None`, never `{}`, when the port or the file is missing: an unread half must not read as an empty one (row 65)."""
    from . import doctor as dr
    rel = (manifest.get("ports") or {}).get("operator_surface")
    if not rel:
        return None
    stamp = checkout_stamp(repo, refresh=refresh, now=now)
    text = _read_operator_text(repo, str(rel), stamp)
    if text is None:
        return None
    items = []
    for b in [x for x in dr._bullets_under(text, dr.WAITING_HEADING_RE) if not dr.DONE_MARK_RE.match(x)][:OPERATOR_BULLET_CAP]:   # `[done]`: answered, waits on no one
        m = dr.ISO_DATE_RE.search(b)
        raw = b[:48].rsplit(" ", 1)[0] if len(b) > 48 else b   # `git log -S` needs what the file says, markup included
        since = (_bullet_instant(b, m) if m else dr._introduced_at(repo, str(rel), raw, at=stamp.get("read_commit")))
        items.append({"open": bool(OPEN_MARK_RE.match(b)), "head": dr._bullet_head(b), "body": dr._bullet_body(b), "body_full": dr._bullet_body(b, None), "source": str(rel),
                      "since": since.isoformat() if since else None,
                      "dated_by": "its own date" if m else ("the commit that introduced it" if since else "nothing")})
    return {"file": str(rel), "label": "the operator file", "has_section": bool(dr.WAITING_HEADING_RE.search(text)),
            "items": items, "checkout": stamp}


#: when a claim reads as suspect: roadmap-core's own bar (`roadmap_core.graph.STALE_CLAIM_DAYS` = 3,
#: `VERIFYING_CLAIM_DAYS` = 14 — `verifying` keeps its claim by design). Copied, not imported, because CI installs
#: org-core without roadmap-core; a surfacing bar, never an expiry — nothing in org-core releases a claim.
STALE_CLAIM_DAYS = 3.0
STALE_CLAIM_DAYS_BY_STATUS = {"verifying": 14.0}
#: the order a reading counts statuses in — roadmap-core's `graph.STATUSES`, in the order work moves through them
ROADMAP_STATUSES = ("ready", "claimed", "verifying", "blocked", "deferred", "done")


def derive_item_status(item: dict[str, Any], by_key: dict[str, dict[str, Any]]) -> str:
    """The status the queue shows, not the one stored: roadmap-core's `graph.derive_status`. `done` and `verifying` are
    facts; a claim is `claimed`; a dependency not `done` (a dangling one included) is `blocked`; a `defer_reason` is
    `deferred`; anything else is `ready`. A served store already answers derived; deriving again changes nothing there.
    Measured 2026-09-23 on org-core (roadmap-core 0.3.2): the file said `p5-role-builder` is `deferred`, and
    `roadmap list` showed it `blocked` on p4-learn."""
    st = str(item.get("status") or "")
    if st in ("done", "verifying"):
        return st
    if item.get("claimed_by"):
        return "claimed"
    if any(d not in by_key or by_key[d].get("status") != "done" for d in (item.get("blocked_on") or [])):
        return "blocked"
    if str(item.get("defer_reason") or "").strip():
        return "deferred"
    return "ready"


def _item_row(key: str, doc: dict[str, Any]) -> dict[str, Any]:
    """One item as a reading keeps it. Since 0.41.0 that includes what the page's explorer opens onto — the evidence,
    the refs, the items it relates to and the tickets it answers — because a drill-down that has to go back to the
    store for its content is a second reading of a different age (`explorer.model`)."""
    claim = doc.get("claim") if isinstance(doc.get("claim"), dict) else {}
    return {"key": key, "title": str(doc.get("title") or key), "status": str(doc.get("status") or ""),
            "arc": doc.get("arc"), "priority": doc.get("priority"),
            "blocked_on": [str(d) for d in (doc.get("blocked_on") or [])], "defer_reason": doc.get("defer_reason"),
            "claimed_by": doc.get("claimed_by") or claim.get("by"), "claimed_at": doc.get("claimed_at") or claim.get("at"),
            "evidence": str(doc.get("evidence") or ""), "refs": [str(r) for r in (doc.get("refs") or [])],
            "related_to": [{"key": str(r.get("key")), "note": str(r.get("note") or "")}
                           for r in (doc.get("related_to") or []) if isinstance(r, dict) and r.get("key")],
            "tickets": [str(t) for t in (doc.get("tickets") or [])], "done_at": doc.get("done_at")}


#: how much evidence a COMMITTED facts file keeps per item (`for_commit`). A live reading keeps it all — the page's
#: drill-down reads it — but `.org/tempo/facts-<date>.json` is written every day into the org's history, and the full
#: text is already in the item file one link away.
COMMITTED_EVIDENCE_CHARS = 400


def for_commit(facts: dict[str, Any]) -> dict[str, Any]:
    """The facts as a file commits them: each item's evidence cut to its opening, marked cut, and no ticket's words — a
    body is never committed, and an in-app ticket's title is a person's own words from a private store, so it goes too
    (Reed's UNSOUND on #34, 2026-09-24: a planted phone number reached the committed page and facts). Everything a
    reading counts or dates is kept whole — only prose is shortened or withheld."""
    out = dict(facts)
    rm = facts.get("roadmap")
    if isinstance(rm, dict) and rm.get("items"):
        items = []
        for i in rm["items"]:
            ev = str(i.get("evidence") or "")
            items.append(dict(i, evidence=ev[:COMMITTED_EVIDENCE_CHARS], evidence_cut=True)
                         if len(ev) > COMMITTED_EVIDENCE_CHARS else i)
        out["roadmap"] = dict(rm, items=items)
    tk = facts.get("tickets")
    if isinstance(tk, dict) and tk.get("rows"):
        out["tickets"] = dict(tk, rows=[withhold_ticket(t) if t.get("private") else dict(t, body="")
                                        for t in tk["rows"]])
    return out


def withhold_ticket(t: dict[str, Any]) -> dict[str, Any]:
    """An in-app ticket without its words: what it is, where it stands, never what its reporter wrote."""
    return dict(t, title="", body="", withheld=True)


def _arc_files(repo: Path, base: str) -> dict[str, dict[str, Any]]:
    """Each arc's own words from `<base>/arcs/*.yaml`: title, priority, narrative and refs. Arcs are authored by PR and
    pushed after the merge (roadmap-core serves them too, `/admin/roadmap/arcs`), so the files are the source that needs
    no credential in every mode. An arc's `priority` is org-core's (0.40.0, the operator's "or arcs"): roadmap-core
    0.4.0 validates a file carrying it and ignores it, and `push` does not upload it, so the files are where it lives in
    every mode. The narrative and refs are what the explorer opens an arc onto (0.41.0). An arc file that does not parse
    is simply absent here — the items that name it still count, and `roadmap validate` is what names the file."""
    import yaml
    out: dict[str, dict[str, Any]] = {}
    for path in sorted((repo / base / "arcs").glob("*.yaml")):
        try:
            doc = yaml.safe_load(path.read_text()) or {}
        except (OSError, yaml.YAMLError):
            continue
        if isinstance(doc, dict):
            out[str(doc.get("id") or path.stem)] = {"title": str(doc.get("title") or ""), "priority": doc.get("priority"),
                                                    "narrative": str(doc.get("narrative") or ""),
                                                    "refs": [str(r) for r in (doc.get("refs") or [])]}
    return out


def _roadmap_files(repo: Path, base: str) -> tuple[list[dict[str, Any]], list[str]] | None:
    import yaml
    d = repo / base / "items"
    if not d.is_dir():
        return None
    rows, unparsed = [], []
    for path in sorted(d.glob("*.yaml")):
        try:
            doc = yaml.safe_load(path.read_text()) or {}
        except (OSError, yaml.YAMLError):
            unparsed.append(path.name)
            continue
        if isinstance(doc, dict):
            rows.append(_item_row(str(doc.get("id") or path.stem), doc))
        else:
            unparsed.append(path.name)
    return rows, unparsed


def _utc_iso(when: str) -> str | None:
    try:
        return dt.datetime.fromisoformat(when.strip()).astimezone(dt.timezone.utc).isoformat(timespec="seconds")
    except ValueError:
        return None


#: the item files' statuses whose first commit a lifetime marks: shipped (`verifying`) and closed (`done`)
HISTORY_MARKS = ("verifying", "done")


def _item_history(repo: Path, rel_dir: str) -> dict[str, Any]:
    """Each item's lifetime from its file's history: the commit that added it, the first commit that set it
    `verifying`, the first that set it `done`, and the last that touched it — one `git log -p` over the items directory,
    first-parent, so each date is when the change landed on the checkout's branch, not when a branch commit was written.

    The operator, 2026-09-24: *"in the dashboard I want to be able to open a gantt for every arc"*, ruled as item
    lifetimes. The store keeps no such history: measured on org-core's served store (roadmap-core 0.4.0) the same day,
    `done_at` was null on all 50 items and a claim is kept only while it is held. The files are the one durable record,
    so a status moved on the server alone (row 144) has no date here, and the page says so rather than inventing one.

    A truncated history answers from what it has, so an item added AT a graft (`doctor._grafted`) is `undated`, never
    dated to the clone (the depth-1 lesson of 2026-09-22). `{"read": False, "why": …}` when there is no history."""
    from . import doctor as dr
    from . import gitfiles as gf
    if not gf.is_git_repo(repo):
        return {"read": False, "why": f"{repo} is not a git checkout, so the items carry no history"}
    try:
        p = subprocess.run(["git", "log", "--first-parent", "--diff-merges=first-parent", "--reverse", "-p",
                            "--no-renames", "--format=\x1e%H %cI", "HEAD", "--", rel_dir],
                           cwd=repo, capture_output=True, text=True, timeout=60)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return {"read": False, "why": f"git log: {str(e)[:160]}"}
    if p.returncode != 0:
        return {"read": False, "why": f"git log: {(p.stderr or '').strip()[:160]}"}
    grafted = dr._grafted(repo)
    items: dict[str, dict[str, Any]] = {}
    sha = when = cur = None
    added = False
    for line in (p.stdout or "").split("\n"):       # not splitlines(): it breaks on the \x1e separator itself
        if line.startswith("\x1e"):
            sha, _, when = line[1:].partition(" ")
            when = _utc_iso(when)
            cur = None
            continue
        if line.startswith("diff --git "):
            path = line.split(" b/", 1)[-1]
            cur = Path(path).stem if path.endswith(".yaml") and path.startswith(rel_dir.rstrip("/") + "/") else None
            added = False
            if cur:
                h = items.setdefault(cur, {"opened_at": None, "verifying_at": None, "done_at": None, "last_at": None,
                                           "undated": False, "deleted": False})
                h["last_at"] = when
            continue
        if cur is None:
            continue
        h = items[cur]
        if line.startswith("new file mode") or line == "--- /dev/null":
            if not added and h["opened_at"] is None and not h["undated"]:
                if sha in grafted:
                    h["undated"] = True
                else:
                    h["opened_at"] = when
            added = True
        elif line.startswith("deleted file mode"):
            h["deleted"] = True
        elif line.startswith("+status:") and not (added and sha in grafted):
            # a status that arrives with the file's add AT the graft is the clone's, not a transition: it is undated
            # like the add itself (the adversarial review of #34 — the explorer printed the clone as "done")
            val = line.split(":", 1)[1].strip().strip("'\"")
            if val in HISTORY_MARKS and not h[f"{val}_at"]:
                h[f"{val}_at"] = when
    shallow = bool(grafted)
    return {"read": True, "items": items, "shallow": shallow,
            "note": ("the checkout's history is truncated, so an item older than it is undated" if shallow else None)}


def _roadmap(repo: Path, manifest: dict[str, Any], run: Runner | None = None,
             now: dt.datetime | None = None) -> dict[str, Any] | None:
    """The org's work graph as a reading shows it: every item with the status the queue derives, and its claim.

    Files mode reads `roadmap/items/*.yaml`, which is where a claim durably lives there. A served store is where claims
    live (row 144), so it is asked through the org's own CLI, `<cli> list --source db --json`; when that cannot be read,
    the committed items are read instead and `source` says so: the projection, which lacks live claims. Never an empty
    graph. `None` only when the manifest declares no roadmap-core work store; `{"items": None, "why": …}` when nothing
    could be read (row 65: an unread source is never rendered as an empty one)."""
    ws = (manifest.get("ports") or {}).get("work_store") or {}
    if ws.get("tool") != "roadmap-core":
        return None
    mode = str(ws.get("mode") or "files")
    base = str(ws.get("files") or "roadmap/").strip("/")
    rows: list[dict[str, Any]] | None = None
    unparsed: list[str] = []
    source, note = "files", None
    if mode == "served":
        cmd = [*str(ws.get("cli") or "roadmap").split(), "list", "--source", "db", "--json"]
        try:
            out = (run or (lambda c, e: _run_in(repo, c, e, manifest)))(cmd, None)
            rows = [_item_row(str(k), v) for k, v in (json.loads(out or "{}") or {}).items() if isinstance(v, dict)]
            source = "the served store"
        except (RuntimeError, json.JSONDecodeError, OSError, AttributeError, subprocess.TimeoutExpired) as e:
            note = (f"the served store was not read ({str(e)[:160]}); read from the committed items instead, which "
                    "carry no live claim")
    if rows is None:
        got = _roadmap_files(repo, base)
        if got is None:
            return {"items": None, "why": note or f"no {base}/items in {repo}", "source": None, "mode": mode}
        rows, unparsed = got
        source = "files" if mode == "files" else "the committed items"
    by_key = {r["key"]: r for r in rows}
    files = {p.stem for p in (repo / base / "items").glob("*.yaml")}
    for r in rows:
        r["derived"] = derive_item_status(r, by_key)
        r["in_files"] = r["key"] in files          # a served item nobody filed has no file to link to
    return {"items": rows, "unparsed": unparsed, "source": source, "note": note, "mode": mode, "dir": f"{base}/items",
            "arcs_dir": f"{base}/arcs", "arcs": _arc_files(repo, base),
            "read_at": (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds"),
            "history": _item_history(repo, f"{base}/items")}


#: how many tickets a reading keeps: the newest, open first. A queue longer than this is said to be, never cut silently.
TICKETS_KEPT = 200
TICKET_BODY_CHARS = 2000


def _tickets(repo: Path, manifest: dict[str, Any], run: Runner = _run, now: dt.datetime | None = None) -> dict[str, Any]:
    """The org's ticket queue as the page's explorer shows it (0.41.0): each ticket's id, words, status and link.

    `github-issues` is one `gh api` read of the issues under the port's label (a pull request is not a ticket, though
    GitHub's issues endpoint returns both). `in-app` reads the org's own admin API with the credential the port names,
    when the environment holds it — read, never minted (SPEC §17). `absent` is a declaration, and the reading says so;
    it is never an empty queue (row 65). `rows` is None whenever nothing was read, with `why`."""
    port = (manifest.get("ports") or {}).get("tickets") or {}
    tool = str(port.get("tool") or "absent")
    at = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    base = {"tool": tool, "rows": None, "why": None, "complete": False, "read_at": at, "note": None}
    if tool == "absent":
        return dict(base, why="this org declares no ticket queue (`ports.tickets: absent`)")
    if tool == "github-issues":
        slug = (manifest.get("org") or {}).get("repo")
        label = str(port.get("label") or "ticket")
        try:
            got = json.loads(run(["gh", "api", f"repos/{slug}/issues?labels={label}&state=all&sort=created&direction=desc"
                                  f"&per_page=100"], None) or "[]")
        except (RuntimeError, json.JSONDecodeError, OSError) as e:
            return dict(base, why=f"the `{label}` issues of {slug} could not be read ({str(e)[:160]})")
        rows = []
        for i in got:
            if not isinstance(i, dict) or "pull_request" in i:
                continue
            labels = sorted(str((x or {}).get("name") or "") for x in (i.get("labels") or []) if isinstance(x, dict))
            rows.append({"id": str(i.get("number")), "label": f"#{i.get('number')}", "title": i.get("title") or "",
                         "status": str(i.get("state") or ""), "open": i.get("state") == "open", "labels": labels,
                         # what the ticket IS, for its stage: not the queue's own label, a triage state or a check's
                         "kinds": [x for x in labels if x != label and not x.startswith(("ticket:", "severity:", "check:"))],
                         "created_at": i.get("created_at"), "closed_at": i.get("closed_at"), "url": i.get("html_url"),
                         "source": "github", "body": str(i.get("body") or "")[:TICKET_BODY_CHARS],
                         "private": False})   # an issue's words are already public on GitHub
        return dict(base, rows=rows[:TICKETS_KEPT], complete=len(got) < 100,
                    note=None if len(got) < 100 else "the newest 100 issues under the label were read; an older one is not shown")
    if tool == "in-app":
        from .tickets import adapters as ad
        from .tickets import core as tc
        api = port.get("api")
        if not api:
            return dict(base, why="the port names no `api` to read the queue from")
        if run is not _run:        # a scripted reading reaches no network it did not script
            return dict(base, why="a scripted reading does not read an in-app queue")
        try:
            token = ad.token_from_env(str(port.get("token_env") or "TICKETS_TOKEN"), port.get("token_file"))
        except RuntimeError as e:
            return dict(base, why=f"not read — {e}")
        try:
            got, complete = ad.api_tickets(str(api), token)
        except Exception as e:  # noqa: BLE001 — an unreachable queue is a reason, not a crash
            return dict(base, why=f"{api} could not be read ({type(e).__name__}: {str(e)[:140]})")
        people = set(port.get("person_sources") or tc.DEFAULT_PERSON_SOURCES)
        rows = []
        for raw in got:
            t = tc.normalize_ticket(raw)
            text = str(t.get("feedback_text") or "").strip()
            rows.append({"id": t["id"], "label": t["id"][:8], "title": text.split("\n", 1)[0][:140],
                         "status": t["status"], "open": t["status"] not in tc.TERMINAL_TICKET_STATUSES,
                         "labels": list(t.get("kinds") or []), "kinds": list(t.get("kinds") or []),
                         "created_at": t.get("created_at"), "url": None,
                         "source": t["source"] + (" (a person)" if t["source"] in people else ""),
                         "body": text[:TICKET_BODY_CHARS],
                         # a person's own words, from the org's private store: they stay on the machine that read them —
                         # never in a committed file, a committed page or a store's copy (Reed's UNSOUND on #34)
                         "private": True})
        rows.sort(key=lambda r: str(r.get("created_at") or ""), reverse=True)    # the newest,
        rows.sort(key=lambda r: not r["open"])                                  # open ones first
        return dict(base, rows=rows[:TICKETS_KEPT], complete=complete and len(rows) <= TICKETS_KEPT,
                    note=None if len(rows) <= TICKETS_KEPT else f"{len(rows)} tickets; the {TICKETS_KEPT} shown are open first")
    return dict(base, why=f"org-core cannot read a `{tool}` ticket queue")


#: what an org's own code gets from this process's environment (0.44.0, Reed on #45): the basics a CLI needs to start
#: and reach the network — never another org's token, the room key or the proxy secret
ORG_ENV_KEEP = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "TZ", "TMPDIR", "VIRTUAL_ENV", "SSL_CERT_FILE", "SSL_CERT_DIR",
                "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy",
                "http_proxy", "no_proxy")
ORG_ENV_PREFIXES = ("LC_",)


#: the reader's own secrets: never an org's store credential, whatever its manifest names (Reed on #47)
READER_SECRETS = ("SWITCHBOARD_KEY", "SWITCHBOARD_TOKEN", "ORG_PROXY_SECRET", "ORG_AGENT_READ_TOKEN")
READER_SECRET_PREFIXES = ("GH_TOKEN", "GITHUB_TOKEN")

#: the org whose unsuffixed store credential this process holds, while reading a fleet (0.44.2): None outside one
_STORE_HOME: contextvars.ContextVar[str | None] = contextvars.ContextVar("org_store_home", default=None)


@contextlib.contextmanager
def store_home(org_id: str | None):
    """Read a fleet whose unsuffixed store credential (`ROADMAP_API_TOKEN`, …) is `org_id`'s alone: every other org
    gets only its own `<VAR>_<ID>`. `org command` sets it to its `--repo`'s org; a single-org reading never does."""
    reset = _STORE_HOME.set(org_id or "")
    try:
        yield
    finally:
        _STORE_HOME.reset(reset)


def _org_var(name: str, org_id: str | None, tenant: str | None = None) -> str | None:
    """`<NAME>_<ORG ID>` when set, else `<NAME>` — the per-org override `GH_TOKEN_<ID>` already follows (0.42.2).
    Inside a fleet reading (`store_home`), the unsuffixed one is the home org's only (0.44.2, Reed on #48): the fleet
    reader's `ROADMAP_API_TOKEN` is org-core's tenant, and a third org naming it with no `_<ID>` pair read org-core's
    roadmap again — row 163's bug by another door."""
    if org_id:
        v = os.environ.get(f"{name}_" + re.sub(r"[^A-Za-z0-9]", "_", str(org_id)).upper())
        if v:
            return v
    home = _STORE_HOME.get()
    if home is not None and home != (org_id or "") and not tenant:
        return None
    # with a tenant named (0.45.0), the shared pair is safe for any org: roadmap-core 0.5.0 serves a user token only
    # inside its grants, and refuses a tenant token that names another tenant — the server confines it, not this lookup
    return os.environ.get(name) or None


def _org_env(env: dict[str, str] | None, manifest: dict[str, Any] | None = None) -> dict[str, str]:
    """The environment for a command from an org's checkout: an allow-list, that org's own GitHub token, and the one
    store credential its manifest names (`work_store.credential`) — nothing else of this process's.

    The store credential is the org's, not the process's (0.44.1). The fleet reader's `ROADMAP_API_URL`/`_TOKEN` are
    org-core's tenant, and roadmap-core 0.4.0 prefers them over an org's own backend (`LUCILLE_BACKEND_URL`,
    `LUCILLE_ADMIN_JWT`; its cli.py:716 and :742), so Lucille's `scripts/roadmap.py` read org-core's roadmap and the
    page drew it as Lucille's (the operator, 2026-09-26). So `ROADMAP_*` pass only to an org whose manifest names
    `ROADMAP_API_TOKEN`, and `<VAR>_<ORG ID>` overrides the unsuffixed one, as for GitHub tokens."""
    out = {k: v for k, v in os.environ.items() if k in ORG_ENV_KEEP or k.startswith(ORG_ENV_PREFIXES)}
    org_id = str(((manifest or {}).get("org") or {}).get("id") or "") or None
    tok = _GH_TOKEN.get() or os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if tok:
        out.update(GH_TOKEN=tok, GITHUB_TOKEN=tok)
    cred = str((((manifest or {}).get("ports") or {}).get("work_store") or {}).get("credential") or "")
    if re.fullmatch(r"[A-Z][A-Z0-9_]{0,63}", cred) and cred not in READER_SECRETS and not cred.startswith(READER_SECRET_PREFIXES):
        wanted = [cred] + (["ROADMAP_API_URL"] if cred == "ROADMAP_API_TOKEN" else [])
        from .suite import store_tenant
        tenant = store_tenant(manifest or {}) if cred == "ROADMAP_API_TOKEN" else None
        for name in wanted:
            v = _org_var(name, org_id, tenant)
            if v:
                out[name] = v
        if tenant and out.get("ROADMAP_API_TOKEN"):
            out["ROADMAP_TENANT"] = tenant   # the org's own tenant, named on every request (roadmap-core 0.5.0)
    return {**out, **(env or {})}


def _run_in(repo: Path, cmd: list[str], env: dict[str, str] | None = None, manifest: dict[str, Any] | None = None) -> str:
    """A command from the org's checkout: an org's CLI can be a path relative to it (Lucille's `python scripts/roadmap.py`).
    It is that org's code, so it runs with that org's credentials only (`_org_env`)."""
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=120, cwd=repo, env=_org_env(env, manifest))
    except FileNotFoundError as e:
        raise RuntimeError(f"{cmd[0]}: not installed") from e
    if out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd[:3])}: {(out.stderr or out.stdout).strip()[:300]}")
    return out.stdout


def _session_rows(sessions: Any) -> list[dict[str, Any]]:
    """The rows of a `list_sessions` dump: a bare list, or the tool's own page (`{"data": [...], "has_more": …}`)."""
    if isinstance(sessions, dict):
        return list(sessions.get("data") or [])
    return list(sessions or [])


def _sessions_complete(sessions: Any) -> bool | None:
    """Whether the dump holds every session the account lists: True only when the page itself says `has_more: false`.
    A bare list cannot say, so it is None — never True (row 115; org-core 2026-09-23, a 60-row page read as the org's
    whole spend while the session costing most of it was older than the page)."""
    if isinstance(sessions, dict) and "has_more" in sessions:
        return sessions.get("has_more") is False
    return None


def gather(repo: Path, manifest: dict[str, Any], *, since: str, triggers: list[dict[str, Any]] | None = None,
           sessions: list[dict[str, Any]] | None = None, run: Runner = _run, now: dt.datetime | None = None,
           prior: dict[str, Any] | None = None) -> dict[str, Any]:
    """One facts file for a tempo reading. `triggers`/`sessions` come from a session holding the sessions port; the rest is read here.
    `prior` is the last reading's facts, when the caller keeps one (the served reader): the pull-request history is read in full
    once a UTC day from it, and caught up in between (`prplots.due`)."""
    from . import delegations as _delegations
    ws = manifest["ports"]["coordination"]["workspace"]
    hub = (manifest["ports"]["coordination"] or {}).get("url")
    slug = manifest["org"]["repo"]
    now = now or dt.datetime.now(dt.timezone.utc)
    facts: dict[str, Any] = {
        "kind": "tempo-facts", "org": manifest["org"]["id"], "gathered_at": now.isoformat(timespec="seconds"), "since": since,
        "operator_timezone": (manifest["org"].get("operator") or {}).get("timezone") or "UTC",
        "roles": {r: {"name": e.get("name"), "cadence": e.get("cadence") or _default(r, "cadence"), "runtime": e.get("runtime") or _default(r, "runtime"),
                      "report_key": e.get("report_key") or f"roles/{r}/last-run", "tempo": role_tempo(manifest).get(r),
                      "tolerance": e.get("tolerance", 1.5), "period_hours": e.get("period_hours")}
                  for r, e in manifest["roles"].items() if e.get("enabled", True)},
        # the cast the manifest leaves off: the page lists them as not set up, with a Set up ask (0.44.0)
        "roles_off": {r: {"name": (e or {}).get("name") or r, "runtime": _default(r, "runtime")}
                      for r, e in manifest["roles"].items() if not (e or {}).get("enabled", True)},
        "targets": targets(manifest),
        # what the operator may set per role (SPEC §10): the command page's range, from the manifest and the package default
        "knob_ranges": {r: list(_kn.declared_range(_kn.name_for(r), manifest) or ()) for r, e in manifest["roles"].items() if (e or {}).get("enabled", True)},
        "board": [], "prs": [], "agents": None, "runs": gather_runs(repo), "triggers": triggers or [],
        "sessions": _session_rows(sessions), "sessions_complete": _sessions_complete(sessions), "could_not_read": [],
        # what a reading needs that is neither the board nor GitHub: which org-core was applied (rows 87, 88), the
        # ceiling the spend is read against, and the repo half of the operator queue
        "repo": slug, "budget": manifest.get("budget") or {}, "lock": _lock_facts(repo),
        "operator_waiting": _operator_waiting(repo, manifest, refresh=True, now=now),
        # whether a missing heartbeat is a death: an org that routes no role through an actuator has none to lose
        "actuator_duty": actuator_duty(manifest),
        # the work graph and who holds what in it (row 145): read from the served store where claims live (row 144)
        "roadmap": _roadmap(repo, manifest, None if run is _run else run, now),
        # the org's room, non-secret — hub and workspace — so the page can link the viewer to it (0.42.0)
        "room": {"url": hub, "workspace": ws, "note": manifest["org"]["id"]},
        # the org's ticket queue and the branch a link on the page resolves against (0.41.0, the explorer)
        "tickets": _tickets(repo, manifest, run, now),
        "default_branch": manifest["org"].get("default_branch") or "main",
        # the operator's standing decisions and every use of one (SPEC row 180); read here, from the manifest and the log
        "delegations": _delegations.read(repo, manifest, now),
    }
    if not (repo / ".org" / "runs").is_dir():
        # A fire is echoed by the receiver's board record OR by its committed run file, so a reading taken
        # outside the org's checkout judges `fired_no_receiver` from half the evidence and reads the missing
        # half as silence — row 121's lesson, in the actuator tile. An EMPTY `.org/runs` is a real answer
        # (nothing ran); an ABSENT one means this is not the checkout, and that is not an answer.
        facts["could_not_read"].append(f"runs: no {repo}/.org/runs — the git tier of the wake ledger is not "
                                       "in this checkout, so a fire echoed only in a run file reads as unanswered")
    try:
        beats: list[dict[str, Any]] = []
        # the knobs ride with the board (SPEC §10): `wake_now` reads the operator's interval multipliers from it
        facts["board"] = gather_board(ws, run, url=hub, listeners=beats, prefixes=("roles/", "coord/", "org/knobs/"))
        facts["listener_beats"] = beats
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["could_not_read"].append(f"board: {e}")
    facts["handoffs_left"] = handoffs_left(repo, facts, prior)
    facts["handoffs_closed"] = handoffs_closed(repo, facts, prior)
    # sessions and routines, when no session holding the sessions port passed them in: the snapshots that port's holder
    # (the CEO) publishes to the board each wake — the only way a reader with no claude.ai account, the VM's, sees them
    team_from_board(facts, triggers_given=bool(triggers), sessions_given=sessions is not None)
    try:
        agent_env = {"SWITCHBOARD_WORKSPACE": ws, **({"SWITCHBOARD_URL": hub} if hub else {})}
        facts["agents"] = json.loads(run(["switchboard", "--json", "agents"], agent_env) or "[]")
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["agents"] = None
        facts["could_not_read"].append(f"agents: {e}")
    try:
        facts["prs"] = gather_prs(slug, since, run)
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["could_not_read"].append(f"prs: {e}")
    facts.update(_pr_index(slug, run, now))
    facts["pr_daily"] = _pr_daily(slug, run, now, (prior or {}).get("pr_daily"))
    # the runners and the Actions queue (ci.py, 0.74.0): re-read on the fast lane too, so a job stuck waiting shows in minutes
    from . import ci
    facts["actions"] = ci.gather(slug, run, now)
    return facts


#: where the port holder publishes its session and routine lists (0.44.0; `org tempo sessions`, `org tempo triggers`)
SESSIONS_KEY = "coord/tempo/sessions"
TRIGGERS_KEY = "coord/tempo/triggers"


def team_from_board(facts: dict[str, Any], *, triggers_given: bool, sessions_given: bool) -> None:
    """Fill `triggers` and `sessions` from the board snapshots when they were not passed in, and say how old each is.
    The operator, 2026-09-25: "let's add visibility into the team and its status" — the served page on the VM has no
    claude.ai account, so it reads what the CEO, which has one, writes down."""
    latest = _latest_records(facts.get("board") or [])
    snap: dict[str, Any] = {}
    for key, field in ((TRIGGERS_KEY, "triggers"), (SESSIONS_KEY, "sessions")):
        row = latest.get(key)
        v = _value(row) if row else None
        if not isinstance(v, dict):
            snap[field] = None
            continue
        # an archived row is id and status only (it is there so a lease's holder can be seen archived): not a session counted
        snap[field] = {"at": v.get("at"), "complete": v.get("complete"),
                       "n": len([x for x in (v.get(field) or []) if not (isinstance(x, dict) and str(x.get("session_status") or "").upper().endswith("ARCHIVED"))])}
        if field == "triggers" and not triggers_given:
            facts["triggers"] = list(v.get("triggers") or [])
        if field == "sessions" and not sessions_given:
            facts["sessions"] = list(v.get("sessions") or [])
            facts["sessions_complete"] = v.get("complete")
    facts["team_snapshot"] = snap


def _pr_index(slug: str, run: Runner, now: dt.datetime | None) -> dict[str, Any]:
    at = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    try:
        return {"pr_index": gather_pr_index(slug, run), "pr_index_at": at, "pr_index_why": None}
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        return {"pr_index": None, "pr_index_at": at, "pr_index_why": str(e)[:200]}


def _pr_daily(slug: str, run: Runner, now: dt.datetime | None, prior: dict[str, Any] | None = None) -> dict[str, Any]:
    """The record of pull requests opened, merged and closed per UTC day. The full paged read (`prplots.fetch`) runs once a UTC day
    (the operator, 2026-10-10: *"Read history once a day"*); a `prior` record read today is caught up from the most-recently-updated
    pages instead (`prplots.catch_up`, stale when they do not reach the read's day). A failed full read is `{read: False, why}`."""
    from . import prplots
    now = now or dt.datetime.now(dt.timezone.utc)
    if not prplots.due(prior, now):
        return prplots.catch_up(prior, slug, run, now)
    try:
        return prplots.fetch(slug, run, now)
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        return prplots.unread(str(e))


def reread_if_moved(repo: Path, manifest: dict[str, Any], prior: dict[str, Any] | None, now: dt.datetime | None = None,
                    *, force: bool = False) -> dict[str, Any] | None:
    """Re-read the operator queue when the default branch moved since the last read, or at once on `force` (the CEO's refresh
    call: `org status --refresh`, and the same in the served fast lane). One `git ls-remote` decides; an unmoved remote keeps
    the prior reading with its commit and time."""
    ck = (prior or {}).get("checkout")
    if not force and ck and ck.get("remote"):
        branch = str(ck.get("remote_ref") or "origin/main").split("/", 1)[-1]
        ls = _git_out(repo, "ls-remote", "origin", f"refs/heads/{branch}")    # exact: a bare name also matches `refs/heads/x/<branch>`
        row = next((ln.split() for ln in (ls or "").splitlines() if ln.split()[-1:] == [f"refs/heads/{branch}"]), None)
        if row and row[0] == ck["remote"]:
            return prior
    return _operator_waiting(repo, manifest, refresh=True, now=now)


def refresh_fast(repo: Path, manifest: dict[str, Any], facts: dict[str, Any], *, run: Runner = _run,
                 now: dt.datetime | None = None) -> dict[str, Any]:
    """The fast lane (0.41.0): the last full facts with the three cheap sources re-read — the roadmap (claims and
    statuses: one store read), the ticket queue (one read) and the pull-request index (one call). Since 0.74.0 also the
    runners and the Actions queue (`ci.gather`: two run lists, the runner list, the workflow list, and one call per run's jobs
    up to `ci.RUNS_READ_CAP`), because a job stuck waiting is worth knowing in minutes, not at the next full read.

    The operator, 2026-09-24: *"can we make it live data as much as possible?"* A full read is the board (1 + 32
    switchboard calls on org-core) and every pull request's reviews and checks (1 + 3N `gh` calls: ~91 a read on
    org-core, measured 2026-09-24); at the old 30-second floor that projects to ~10,900 an hour, against the 15,000/h the
    API reported through that container's proxy (which bucket, unverified). These three are what moves fastest and
    costs least, so they move on their own clock; the rest keeps its own age, and the page shows both."""
    slug = manifest["org"]["repo"]
    out = dict(facts)
    out["roadmap"] = _roadmap(repo, manifest, None if run is _run else run, now)
    out["operator_waiting"] = reread_if_moved(repo, manifest, facts.get("operator_waiting"), now)
    out["tickets"] = _tickets(repo, manifest, run, now)
    out.update(_pr_index(slug, run, now))
    # the runners and the Actions queue (ci.py, 0.74.0): at most 4 + ci.RUNS_READ_CAP calls, the fast lane's largest share
    from . import ci
    out["actions"] = ci.gather(slug, run, now)
    from . import prplots
    out["pr_daily"] = prplots.extend(facts.get("pr_daily"), out.get("pr_index"), now or dt.datetime.now(dt.timezone.utc))
    # who is here and who can be woken: two switchboard calls, so the page's listening marks move in seconds (0.42.0)
    c = (manifest.get("ports") or {}).get("coordination") or {}
    pres = gather_presence(c.get("workspace") or "", run, url=c.get("url"), now=now)
    if pres["agents"] is not None:
        out["agents"] = pres["agents"]
    if pres["listeners"] is not None:
        out["listener_beats"] = pres["listeners"]
        # the asks the page shows: replace the full read's `coord/asks/` rows with the listing's, which is newer
        out["board"] = [r for r in (out.get("board") or []) if not str(r.get("key", "")).startswith(("coord/asks/", "org/knobs/"))] \
            + [dict(r, updated_at=None, expires_at=None) for r in (pres.get("asks") or []) + (pres.get("knobs") or [])]
    out["presence_at"] = pres["read_at"]
    out["fast_at"] = (now or dt.datetime.now(dt.timezone.utc)).isoformat(timespec="seconds")
    return out


def handoffs_left(repo: Path, facts: dict[str, Any], prior: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """The operator cards that left the board unanswered, as board rows (`handoffs.left_rows`), carried in every facts file so the list
    outlives the oldest one (item `command-center-decide-and-the-operator-queue` row 5: the files kept on 2026-10-12 began 2026-10-07, and a
    card that left before then was gone). Read from the committed facts and the ledger they carry, the served reader's last reading
    (`prior`), and this reading's board. With the board unread nothing can be told left: the ledger already carried is kept as it was,
    never recomputed against an empty board, which would list every live card as gone."""
    from . import handoffs as hf
    hist = latest_facts(repo, n=10**6) or {}
    rows = [r for src in (hist, prior or {}) for r in (src.get("board") or []) + (src.get("handoffs_left") or [])
            + (src.get("handoffs_closed") or []) if str(r.get("key", "")).startswith(hf.BOARD_PREFIX)]
    if any(str(c).startswith("board:") for c in facts.get("could_not_read") or []):
        kept = {(r["key"], str(r.get("updated_at"))): r for r in (hist.get("handoffs_left") or []) + ((prior or {}).get("handoffs_left") or [])}
        return sorted(kept.values(), key=lambda r: (r["key"], str(r.get("updated_at"))))
    return hf.left_rows(rows + [r for r in facts.get("board") or [] if str(r.get("key", "")).startswith(hf.BOARD_PREFIX)], facts.get("board"))


def handoffs_closed(repo: Path, facts: dict[str, Any], prior: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """The operator cards whose last write is a close, as board rows (`handoffs.closed_rows`), carried in every facts file beside
    `handoffs_left`: the board drops a close in 7 days like any record, and without this ledger the card's earlier open write, still in
    a facts file, read as a card that left unanswered (item `a-card-whose-board-key-expired-can-still-be-closed`). Read from the same
    sources as `handoffs_left`; a close never depends on the board's absence, so an unread board changes nothing here."""
    from . import handoffs as hf
    hist = latest_facts(repo, n=10**6) or {}
    return hf.closed_rows([r for src in (hist, prior or {}, facts) for r in (src.get("board") or []) + (src.get("handoffs_closed") or [])
                           if str(r.get("key", "")).startswith(hf.BOARD_PREFIX)])


def merge_facts(files: list[dict[str, Any]]) -> dict[str, Any]:
    """A week from a day's files: board rows by (key, updated_at), PRs by number (latest wins), runs by (role, run_id).
    The board keeps one record per key and overwrites it every wake, so history only exists in gathered files."""
    files = sorted((f for f in files if f), key=lambda f: f.get("gathered_at") or "")
    if not files:
        return {"kind": "tempo-facts", "board": [], "prs": [], "runs": [], "triggers": [], "sessions": [], "roles": {}, "could_not_read": []}
    out = dict(files[-1])
    board: dict[tuple[str, str], dict[str, Any]] = {}
    prs: dict[tuple[str, int], dict[str, Any]] = {}
    runs: dict[tuple[str, str], dict[str, Any]] = {}
    for f in files:
        for row in f.get("board", []):
            board[(row["key"], str(row.get("updated_at")))] = row
        for p in f.get("prs", []):
            k = (p.get("repo", ""), p["number"])
            if k not in prs or str(p.get("updated_at")) >= str(prs[k].get("updated_at")):
                prs[k] = p
        for r in f.get("runs", []):
            runs[(r.get("role", "?"), str(r.get("run_id") or r.get("started_at")))] = r
    out["board"] = sorted(board.values(), key=lambda r: (r["key"], str(r.get("updated_at"))))
    # the ledger of cards that left the board (`handoffs_left`): every file's, so a card one file carried is not lost to a later one's
    left = {(r["key"], str(r.get("updated_at"))): r for f in files for r in f.get("handoffs_left") or []}
    if left or any("handoffs_left" in f for f in files):
        out["handoffs_left"] = sorted(left.values(), key=lambda r: (r["key"], str(r.get("updated_at"))))
    closed = {(r["key"], str(r.get("updated_at"))): r for f in files for r in f.get("handoffs_closed") or []}
    if closed or any("handoffs_closed" in f for f in files):
        out["handoffs_closed"] = sorted(closed.values(), key=lambda r: (r["key"], str(r.get("updated_at"))))
    out["prs"] = sorted(prs.values(), key=lambda p: p["number"])
    out["runs"] = list(runs.values())
    out["since"] = min(f.get("since") or "" for f in files) or out.get("since")
    out["merged_from"] = [f.get("gathered_at") for f in files]
    out["could_not_read"] = sorted({c for f in files for c in f.get("could_not_read", [])})
    return out


def latest_facts(repo: Path, n: int = 14) -> dict[str, Any] | None:
    """The committed facts under .org/tempo, merged; None if there are none."""
    d = repo / FACTS_DIR
    if not d.is_dir():
        return None
    files = []
    for p in sorted(d.glob("facts-*.json"))[-n:]:
        try:
            files.append(json.loads(p.read_text()))
        except (OSError, json.JSONDecodeError):
            continue
    return merge_facts(files) if files else None


# --- report -------------------------------------------------------------------

HANDOFF_RE = re.compile(r"^coord/handoffs?/(?P<from>[a-z-]+)-to-(?P<to>[a-z-]+)-(?P<item>.+)$")
ACK_RE = re.compile(r"^coord/handoffs?/(?P<to>[a-z-]+)-ack-(?P<item>.+)$")
ROLE_KEY_RE = re.compile(r"^roles/(?P<role>[a-z-]+)/(?P<rest>.+)$")
HANDOFF_PREFIX_RE = re.compile(r"^coord/handoffs?/")


def _role_prefix(text: str, roles: tuple[str, ...]) -> str | None:
    """The longest known role id that `text` starts with, followed by a hyphen."""
    for r in sorted(roles, key=len, reverse=True):
        if text.startswith(r + "-"):
            return r
    return None


def parse_handoff(key: str, roles: tuple[str, ...] = ROLE_IDS) -> dict[str, str] | None:
    """`coord/handoffs/<from>-to-<to>-<item>` read with the roles known: the receiver is the longest known role id the
    text after `-to-` starts with, else its first word; the sender likewise before the first `-to-` that a known role
    precedes. HANDOFF_RE matched the receiver greedily, so `builder-to-reviewer-stated-appointment-check-cannot-fail`
    read as receiver `reviewer-stated-appointment-check-cannot` and item `fail`: 23 of Lucille's 46 handoff keys on
    2026-09-20 named a receiver no role has, and no ack, record or PR act could ever pair with them (row 105)."""
    if not HANDOFF_PREFIX_RE.match(key):
        return None
    rest = HANDOFF_PREFIX_RE.sub("", key, count=1)
    sender = _role_prefix(rest, roles)
    if sender and rest.startswith(sender + "-to-"):
        after = rest[len(sender) + 4:]
    else:
        head, sep, after = rest.partition("-to-")
        if not sep or not head:
            return None
        sender = head
    to = _role_prefix(after, roles)
    if to is None:
        to, sep, _ = after.partition("-")
        if not sep or not to:
            return None
    item = after[len(to) + 1:]
    if not item:
        return None
    return {"from": sender, "to": to, "item": item}


def _median(xs: list[float | None]) -> float | None:
    ys = sorted(x for x in xs if x is not None)
    if not ys:
        return None
    m = len(ys) // 2
    return round(ys[m] if len(ys) % 2 else (ys[m - 1] + ys[m]) / 2, 2)


def _value(row: dict[str, Any]) -> dict[str, Any]:
    v = row.get("value")
    return v if isinstance(v, dict) else {}


def _record_at(row: dict[str, Any]) -> str | None:
    return _value(row).get("at") or row.get("updated_at")


def _latest_records(board: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """key -> its newest row (merged facts carry several rows per key)."""
    out: dict[str, dict[str, Any]] = {}
    for row in board:
        k = row["key"]
        if k not in out or str(row.get("updated_at")) >= str(out[k].get("updated_at")):
            out[k] = row
    return out


def attribute_prs(prs: list[dict[str, Any]], board: list[dict[str, Any]], runs: list[dict[str, Any]]) -> None:
    """Fill author_role from what the roles themselves recorded (`pr` / `pr_url` in any roles/<role>/* record,
    `artifacts.pr` in a ledger); a PR body signature is the fallback, a branch prefix the last resort.
    A reviewer's record names the PR it reviewed, not one it wrote, so reviewer keys never attribute."""
    by_number: dict[int, str] = {}
    for row in board:
        m = ROLE_KEY_RE.match(row["key"])
        v = _value(row)
        if not m or not v or m["role"] == "reviewer":
            continue
        for field in ("pr", "pr_url", "prs", "url"):
            for num in pr_numbers(v.get(field)):
                by_number.setdefault(num, m["role"])
    for r in runs:
        for num in pr_numbers((r.get("artifacts") or {}).get("pr")):
            by_number.setdefault(num, r.get("role", "unknown"))
    for p in prs:
        if p.get("author_role") in (None, "unknown") and p["number"] in by_number:
            p["author_role"] = by_number[p["number"]]


def merge_board_verdicts(prs: list[dict[str, Any]], board: list[dict[str, Any]]) -> None:
    """A reviewer that records `roles/reviewer/pr-<n>` = {verdict, at} and never comments on the PR still gave a verdict."""
    by_number = {p["number"]: p for p in prs}
    for row in board:
        m = ROLE_KEY_RE.match(row["key"])
        v = _value(row)
        if not m or m["role"] != "reviewer" or not v.get("verdict"):
            continue
        vm = VERDICT_RE.search(str(v["verdict"]))
        nums = pr_numbers(v.get("pr")) or pr_numbers(m["rest"].replace("pr-", "#"))
        at = v.get("at") or row.get("updated_at")
        if not vm or not nums or not at:
            continue
        p = by_number.get(nums[0])
        if not p:
            continue
        if any(x.get("at") == at for x in p.get("verdicts", [])):
            continue
        p.setdefault("verdicts", []).append({"at": at, "verdict": vm.group(1), "sha": (str(v.get("head") or "")[:40] or None), "via": "board"})
        p["verdicts"].sort(key=lambda x: x["at"])
        p["first_verdict_at"], p["first_verdict"] = p["verdicts"][0]["at"], p["verdicts"][0]["verdict"]


def pr_cycle(prs: list[dict[str, Any]], now: dt.datetime) -> dict[str, Any]:
    """Opened → first verdict → merged, per kind and overall; what is open now and for how long."""
    by_kind: dict[str, dict[str, Any]] = {}
    for kind in ("product", "org", "roadmap", "docs", "unknown", "all"):
        rows = [p for p in prs if kind == "all" or p.get("kind") == kind]
        if not rows:
            continue
        merged = [p for p in rows if p.get("merged_at")]
        by_kind[kind] = {
            "opened": len(rows), "merged": len(merged), "open_now": len([p for p in rows if p.get("state") == "open"]),
            "median_hours_open_to_verdict": _median([hours(p["opened_at"], p["first_verdict_at"]) for p in rows if p.get("first_verdict_at")]),
            "median_hours_verdict_to_merge": _median([hours(p["first_verdict_at"], p["merged_at"]) for p in merged if p.get("first_verdict_at")]),
            "median_hours_open_to_merge": _median([hours(p["opened_at"], p["merged_at"]) for p in merged]),
        }
    open_prs = sorted((p for p in prs if p.get("state") == "open" and not p.get("draft")), key=lambda p: p.get("opened_at") or "")
    waiting = [{"number": p["number"], "kind": p.get("kind"), "author_role": p.get("author_role"), "age_hours": hours(p["opened_at"], now.isoformat()),
                "opened_at": p.get("opened_at"), "head_sha": p.get("head_sha"), "updated_at": p.get("updated_at"),
                "verdict": (p.get("verdicts") or [{}])[-1].get("verdict") if p.get("verdicts") else None,
                "verdict_at": p["verdicts"][-1]["at"] if p.get("verdicts") else None,
                "verdict_sha": (p["verdicts"][-1].get("sha") if p.get("verdicts") else None),
                "hours_since_verdict": hours(p["verdicts"][-1]["at"], now.isoformat()) if p.get("verdicts") else None}
               for p in open_prs]
    needing = [{"number": p["number"], "kind": p.get("kind"), "author_role": p.get("author_role"), "why": needs_action(p),
                "idle_hours": hours(p.get("updated_at"), now.isoformat()), "updated_at": p.get("updated_at"), "head_sha": p.get("head_sha"),
                # the items its body's `Item:` line or its branch names: the arc Decide files it under (item `decide-filtered-to-one-arc`)
                "builds": list(p.get("builds") or built_items(None, p.get("head_ref")))}
               for p in open_prs if needs_action(p)]
    last_merge = max((p["merged_at"] for p in prs if p.get("merged_at")), default=None)
    # The chair's contract is "only on a reviewer's verdict pinned to the head, never on green alone". Lucille 2026-09-20
    # (row 96): 66 of 76 merges since 09-17 carried no verdict at all and check 14 read PASS, because it only ever
    # looked at SOUND PRs still open. A merge with no verdict before it is the chair merging on green.
    merged_all = [p for p in prs if p.get("merged_at")]
    no_verdict = [{"number": p["number"], "kind": p.get("kind"), "merged_at": p["merged_at"], "author_role": p.get("author_role")}
                  for p in merged_all if not any(v.get("at") and v["at"] <= p["merged_at"] for v in (p.get("verdicts") or []))]
    unsound_last = [{"number": p["number"], "kind": p.get("kind"), "merged_at": p["merged_at"]} for p in merged_all
                    if (vs := [v for v in (p.get("verdicts") or []) if v.get("at") and v["at"] <= p["merged_at"]]) and vs[-1].get("verdict") == "UNSOUND"]
    return {"by_kind": by_kind, "open": waiting, "needing_action": needing, "last_merge_at": last_merge, "hours_since_last_merge": hours(last_merge, now.isoformat()) if last_merge else None,
            "merged": len(merged_all), "merged_without_verdict": no_verdict, "merged_on_unsound": unsound_last}


ITEM_PR_RE = re.compile(r"^pr-?(\d{1,6})$")


def _handoff_prs(value: dict[str, Any] | None, item: str) -> list[int]:
    """The PRs a handoff names: `pr` / `url` / `prs` / `pr_url` in its value, else an item spelled `pr1599`."""
    nums: list[int] = []
    for field in ("pr", "url", "prs", "pr_url"):
        nums += pr_numbers((value or {}).get(field))
    m = ITEM_PR_RE.match(item)
    if m:
        nums.append(int(m.group(1)))
    return sorted(set(nums))


def _received_on_pr(to: str, written: str, prs_by_number: dict[int, dict[str, Any]], nums: list[int]) -> tuple[str | None, str | None]:
    """The first thing the receiver did on a named PR after the handoff was written: a verdict (reviewer), a merge
    (ceo), or a comment by that role. Lucille 2026-09-20: 37 handoffs stood NOT RECEIVED while every PR they named was
    reviewed or merged — the receiver acted on the PR and wrote no ack key, and the truest signal went unread."""
    best: tuple[str, str] | None = None
    for n in nums:
        p = prs_by_number.get(n)
        if not p:
            continue
        cands: list[tuple[str, str]] = []
        if to == "reviewer":
            cands += [(v["at"], f"PR #{n}: verdict {v.get('verdict')}") for v in (p.get("verdicts") or []) if v.get("at")]
        if to == "ceo" and p.get("merged_at"):
            cands.append((p["merged_at"], f"PR #{n}: merged"))
        cands += [(c["at"], f"PR #{n}: comment by {to}") for c in (p.get("comments") or []) if c.get("at") and c.get("role") == to]
        for at, via in cands:
            if _ts(at) >= _ts(written) and (best is None or _ts(at) < _ts(best[0])):
                best = (at, via)
    return (best[0], best[1]) if best else (None, None)


def _ts(s: Any) -> dt.datetime:
    return parse_ts(s) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)


def _overtaken_on_pr(written: str, prs_by_number: dict[int, dict[str, Any]], nums: list[int]) -> tuple[str | None, str | None, str | None]:
    """(closed_at, why, pr_state) when every PR a handoff names is closed and the receiver never acted on it: the wait
    is over, not by receipt. Lucille 2026-09-20 14:26Z: all 37 handoffs still unreceived after the PR path named a
    merged PR with no verdict — 17 merged after the builder's handoff to the reviewer, 20 written by the chair after
    its own merge (`ceo-to-reviewer-pr<n>`, "no verdict yet") to a role nothing wakes for a closed PR."""
    named = [prs_by_number[n] for n in nums if n in prs_by_number]
    if not named:
        return None, None, None
    if any(p.get("state") == "open" and not p.get("merged_at") for p in named):
        return None, None, "open"
    last = max(named, key=lambda p: _ts(p.get("merged_at") or p.get("closed_at")))
    at = last.get("merged_at") or last.get("closed_at")
    if not at:
        return None, None, "closed"
    if _ts(at) < _ts(written):
        # A handoff written after every PR it names had closed is a message ABOUT a closed PR, and a close cannot
        # overtake a message written after it. Measured on org-core 2026-09-24 (0.37.1): `reviewer-to-ceo-pr-23`,
        # Reed's UNSOUND on a PR merged 3 minutes before it, read as `OVERTAKEN … 1 written after the merge` and
        # turned the chain tile red: the one handoff that carried news for the receiver was filed as moot. It is
        # judged the way a handoff naming no PR is — by an ack or the receiver's record (`handoff_edges`).
        return None, f"PR #{last['number']} had closed before the handoff was written", "closed_before"
    n = last["number"]
    why = f"PR #{n} merged with no act by the receiver" if last.get("merged_at") else f"PR #{n} closed unmerged"
    return at, why, "closed"


#: fields an ack's value names the handoff it answers in (`{"received": "coord/handoffs/<key>"}` — Wren's own, 2026-09-24)
ACK_NAMES_FIELDS = ("received", "ack", "acks", "handoff", "key")


def _acked_handoff_keys(value: dict[str, Any]) -> list[str]:
    """The handoff keys an ack's value names outright. The key name alone is ambiguous when a sender or receiver is
    hyphenated: measured on org-core 2026-09-24, `ceo-old-to-ceo-new-standing-picture` parses as receiver `ceo`, item
    `new-standing-picture`, so Wren's `ceo-ack-standing-picture` — whose value said `received:
    coord/handoffs/ceo-old-to-ceo-new-standing-picture` — paired with nothing, and the handoffs tile read NOT RECEIVED
    for 4.8 h. A value naming the full key is unambiguous, so it pairs whatever the names parse to."""
    out: list[str] = []
    for f in ACK_NAMES_FIELDS:
        v = value.get(f)
        for x in (v if isinstance(v, list) else [v]):
            if isinstance(x, str) and HANDOFF_PREFIX_RE.match(x.strip()):
                out.append(re.sub(r"^coord/handoff/", "coord/handoffs/", x.strip()))
    return out


def handoff_edges(board: list[dict[str, Any]], now: dt.datetime, prs: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """coord/handoffs/<from>-to-<to>-<item> paired with <to>-ack-<item>, with the receiver's record naming the key, or
    with the receiver's own act on the PR the handoff names (verdict, merge, comment); else never received."""
    latest = _latest_records(board)
    prs_by_number = {p["number"]: p for p in (prs or []) if isinstance(p.get("number"), int)}
    acks: dict[tuple[str, str], str] = {}
    acked_keys: dict[str, str] = {}
    records: dict[str, list[dict[str, Any]]] = {}
    for row in board:
        m = ACK_RE.match(row["key"])
        if m:
            acks[(m["to"], m["item"])] = _min_ts(acks.get((m["to"], m["item"])), _record_at(row))
            for named in _acked_handoff_keys(_value(row)):
                acked_keys[named] = _min_ts(acked_keys.get(named), _record_at(row))
        m2 = ROLE_KEY_RE.match(row["key"])
        if m2:
            records.setdefault(m2["role"], []).append(row)
    edges = []
    for key, row in sorted(latest.items()):
        m = parse_handoff(key)
        if not m:
            continue
        written = min((_record_at(r) or "" for r in board if r["key"] == key), default=_record_at(row)) or _record_at(row)
        received = acks.get((m["to"], m["item"]))
        via = "ack key" if received else None
        if not received and key in acked_keys:
            received, via = acked_keys[key], "ack key naming it"
        if not received:
            for rec in sorted(records.get(m["to"], []), key=lambda r: str(r.get("updated_at"))):
                v = _value(rec)
                at = v.get("at") or rec.get("updated_at")
                if v and (key in json.dumps(v) or m["item"] in json.dumps(v)) and (parse_ts(at) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)) >= (parse_ts(written) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)):
                    received, via = at, "receiver's record"
                    break
        nums = _handoff_prs(_value(row), m["item"])
        overtaken, pr_state = None, None
        if not received and prs_by_number:
            received, via = _received_on_pr(m["to"], written or "", prs_by_number, nums)
            if not received:
                overtaken, via, pr_state = _overtaken_on_pr(written or "", prs_by_number, nums)
                if pr_state == "closed_before":
                    pr_state = "closed"   # `via` keeps why no act on the PR can receive it; receipt is the ack's alone
        waiting = None if received else (max(0.0, hours(written, overtaken) or 0.0) if overtaken else hours(written, now.isoformat()))
        edges.append({"key": key, "from": m["from"], "to": m["to"], "item": m["item"], "written_at": written,
                      "received_at": received, "overtaken_at": overtaken, "pr_state": pr_state, "via": via, "prs": nums,
                      "latency_hours": hours(written, received) if received else None,
                      "waiting_hours": waiting})
    return edges


def _item_names(v: dict[str, Any], field: str) -> list[str]:
    """Item keys a verifier record names under `<field>_items`, or under `<field>` when that is a list. The record
    schema declares `confirmed`/`refuted` as COUNTS, and this function iterated them as lists: the first run in which
    Vera confirmed anything (Lucille 2026-09-20 06:56Z, confirmed=5 refuted=1) raised TypeError inside `tp.report`,
    and both Docs' full `org doctor` runs produced a traceback and zero checks (row 94). A count carries no names."""
    for key in (f"{field}_items", field):
        val = v.get(key)
        if isinstance(val, list):
            return [x for x in val if isinstance(x, str) and x]
    return []


def _as_list(val: Any) -> list[Any]:
    """A record field read as a list whatever a role wrote there: Lucille's dispatcher wrote
    `spawned: "0 builders, 1 reviewer (pr-1616)"` (2026-09-20 09:26Z) and `list + str` crashed the whole report (row 95)."""
    if isinstance(val, list):
        return val
    if isinstance(val, dict):
        return [val]
    return []


def _stamp_from_record(items: dict[str, dict[str, Any]], role: str, v: dict[str, Any], at: Any) -> None:
    def it(name: str) -> dict[str, Any]:
        return items.setdefault(name, {"item": name})
    if role == "verifier":
        for name in _item_names(v, "refuted"):
            it(name)["refuted_at"] = _min_ts(it(name).get("refuted_at"), at)
        for name in _item_names(v, "confirmed"):
            it(name)["verified_at"] = _min_ts(it(name).get("verified_at"), at)
    elif role == "dispatcher":
        for s in _as_list(v.get("spawned")) + _as_list(v.get("spawned_builders")):
            name = s.get("item") if isinstance(s, dict) else (s if isinstance(s, str) else None)
            if name:
                it(name)["dispatched_at"] = _min_ts(it(name).get("dispatched_at"), at)
    elif role == "builder":
        name = v.get("item")
        if isinstance(name, str) and name:
            row_i = it(name)
            row_i["builder_at"] = _min_ts(row_i.get("builder_at"), at)
            nums = pr_numbers(v.get("pr")) or pr_numbers(v.get("pr_url"))
            if nums and not row_i.get("pr"):
                row_i["pr"] = nums[0]


def item_flow(board: list[dict[str, Any]], prs: list[dict[str, Any]], now: dt.datetime) -> dict[str, Any]:
    """The chain an item travels, stamped where each role recorded it: the verifier's `refuted_items`, the dispatcher's
    `spawned[].item`, the builder's `item`+`pr`, the PR's own timestamps, the verifier's `confirmed_items`. One record
    a role wrote in an unexpected shape is skipped and NAMED in `unreadable` — never a crash that takes the report with
    it (rows 94, 95: two shapes in two days, each aborting every check that reads the board)."""
    items: dict[str, dict[str, Any]] = {}
    unreadable: list[str] = []

    for row in sorted(board, key=lambda r: str(r.get("updated_at"))):
        m = ROLE_KEY_RE.match(str(row.get("key") or ""))
        v = _value(row)
        if not m or not isinstance(v, dict):
            continue
        at = v.get("at") or row.get("updated_at")
        try:
            _stamp_from_record(items, m["role"], v, at)
        except Exception as e:  # noqa: BLE001 — the record is the org's writing; the report says which one it could not read
            unreadable.append(f"{row.get('key')}: {type(e).__name__}: {str(e)[:80]}")
    by_number = {p["number"]: p for p in prs}
    for name, row in items.items():
        pr = by_number.get(row.get("pr")) if row.get("pr") else None
        if pr is None:
            pr = next((p for p in prs if name and (name in (p.get("head_ref") or "") or name in (p.get("title") or ""))), None)
        if pr:
            row.update({"pr": pr["number"], "pr_opened_at": pr.get("opened_at"), "verdict_at": pr.get("first_verdict_at"),
                        "verdict": pr.get("first_verdict"), "merged_at": pr.get("merged_at")})
    edge_defs = [("finding_to_dispatch", "refuted_at", "dispatched_at"), ("dispatch_to_pr", "dispatched_at", "pr_opened_at"),
                 ("open_to_verdict", "pr_opened_at", "verdict_at"), ("verdict_to_merge", "verdict_at", "merged_at"),
                 ("merge_to_verified", "merged_at", "verified_at")]
    edges: dict[str, dict[str, Any]] = {}
    for name, a, b in edge_defs:
        done = [hours(r[a], r[b]) for r in items.values() if r.get(a) and r.get(b)]
        waiting = [(r["item"], hours(r[a], now.isoformat())) for r in items.values() if r.get(a) and not r.get(b)]
        worst = max(waiting, key=lambda x: x[1] or 0, default=None)
        edges[name] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                       "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    # open_to_verdict / verdict_to_merge are better measured over every PR, not only the ones an item names.
    # verdict_to_merge is the CEO's edge: from the latest SOUND verdict to the merge. A PR whose latest verdict is
    # UNSOUND waits on its builder, not on a merge — that is `unsound_open`.
    def latest_sound(p: dict[str, Any]) -> str | None:
        vs = [v["at"] for v in p.get("verdicts", []) if v.get("verdict") == "SOUND" and v.get("at")]
        return max(vs) if vs else None

    def latest_verdict(p: dict[str, Any]) -> str | None:
        return (p.get("verdicts") or [{}])[-1].get("verdict") if p.get("verdicts") else None

    open_prs = [p for p in prs if p.get("state") == "open" and not p.get("draft")]
    done = [hours(p["opened_at"], p["first_verdict_at"]) for p in prs if p.get("opened_at") and p.get("first_verdict_at")]
    waiting = [(f"#{p['number']}", hours(p["opened_at"], now.isoformat())) for p in open_prs if p.get("opened_at") and not p.get("first_verdict_at")]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["open_to_verdict"] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                               "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    done = [hours(latest_sound(p), p["merged_at"]) for p in prs if p.get("merged_at") and latest_sound(p) and latest_sound(p) <= p["merged_at"]]
    waiting = [(f"#{p['number']}", hours(latest_sound(p), now.isoformat())) for p in open_prs if latest_verdict(p) == "SOUND"]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["verdict_to_merge"] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                                "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    waiting = [(f"#{p['number']}", hours(p["verdicts"][-1]["at"], now.isoformat())) for p in open_prs if latest_verdict(p) == "UNSOUND"]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["unsound_open"] = {"n": 0, "median_hours": None, "waiting": len(waiting),
                            "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    return {"items": sorted(items.values(), key=lambda r: r["item"]), "edges": edges, "unreadable": unreadable}


#: a bare `no\b` here read "No production credential path for this routine" as *not a blocker* — the reading
#: lying in the reassuring direction, on a role that had been blocked four days (Lucille's doctor, 2026-09-22).
#: "No" is an answer to "are you blocked?" only when it ends there, or names the absence of one.
NOT_BLOCKED_RE = re.compile(
    r"^\s*(?:nothing blocks|nothing is blocking|none\b|n/a\b|nil\b|—|-|null\b|false\b"
    r"|no(?:\s*[.!,;)]|\s*$|\s+(?:blockers?|blocks?|blocking\b|issues?|problems?|concerns?)\b))", re.I)


def is_blocked(text: Any) -> bool:
    """A `blocked` field is a blocker when it is non-empty and does not open by saying it is not one — roles write
    "Nothing blocks me. TWO things need someone else…" in prose, and forwarding that as a blocker is noise."""
    if not text or isinstance(text, bool) and not text:
        return False
    return not NOT_BLOCKED_RE.match(str(text))


def _cut(text: Any, n: int = 200) -> str:
    """A blocker, cut where a reader can see it was cut. Lucille 2026-09-22: three blocked lines ended `Bu`,
    `0` and `MECHA` — a bare truncation reads as a broken writer, not as a long field."""
    t = str(text)
    return t if len(t) <= n else t[:n] + "…"


def _record_subjects(v: dict[str, Any]) -> dict[str, str]:
    """What the role itself says its blocked field is about: a `subjects` map of condition name -> text (one row each),
    else a top-level `subject` string (one condition, the whole blocked text). Names are slugged; a malformed value
    (not a mapping, not a string, empty) is no subject, so the row stays as it was derived from the text."""
    def slug(x: Any) -> str:
        return re.sub(r"[^a-z0-9._-]+", "-", str(x).strip().lower()).strip("-")
    m = v.get("subjects")
    if isinstance(m, dict):
        out = {slug(k): " ".join(str(t).split()) for k, t in m.items() if slug(k) and isinstance(t, str) and t.strip()}
        if out:
            return out
    one = v.get("subject")
    if isinstance(one, str) and slug(one):
        return {slug(one): ""}
    return {}


def blocked_now(board: list[dict[str, Any]], roles: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    latest = _latest_records(board)
    out = []
    for role, meta in roles.items():
        key = meta.get("report_key") or f"roles/{role}/last-run"
        row = latest.get(key)
        v = _value(row) if row else {}
        if not v:
            out.append({"role": role, "record": None})
            continue
        b = v.get("blocked")
        subj = _record_subjects(v) if is_blocked(b) else {}
        out.append({"role": role, "record_at": v.get("at") or row.get("updated_at"), "record_age_hours": hours(v.get("at") or row.get("updated_at"), now.isoformat()),
                    "blocked": (_cut(b) if is_blocked(b) else None), "blocked_text": (_cut(b) if b else None), "subjects": subj})
    return out


def _triggers_by_role(facts: dict[str, Any]) -> dict[str, dict[str, Any]]:
    from .doctor import _trigger_for
    org = facts.get("org", "")
    out: dict[str, dict[str, Any]] = {}
    for role, meta in facts.get("roles", {}).items():
        t = _trigger_for(role, str(meta.get("name") or role), facts.get("triggers", []), org)
        if t is not None:
            out[role] = t
    return out


def wake_stats(facts: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """What can be seen of each role's wakes: the board's records, the run ledger, the routine's last fire."""
    out = []
    runs_by_role: dict[str, list[dict[str, Any]]] = {}
    for r in facts.get("runs", []):
        runs_by_role.setdefault(r.get("role", "?"), []).append(r)
    trig_by_role = _triggers_by_role(facts)
    records_seen: dict[str, set[str]] = {}
    for row in facts.get("board", []):
        m = ROLE_KEY_RE.match(row["key"])
        if m and m["rest"] == "last-run" or (m and (facts.get("roles", {}).get(m["role"]) or {}).get("report_key") == row["key"]):
            records_seen.setdefault(m["role"], set()).add(str(_record_at(row)))
    for role, meta in facts.get("roles", {}).items():
        t = trig_by_role.get(role) or {}
        last = t.get("last_run") or {}
        runs = runs_by_role.get(role, [])
        out.append({
            "role": role, "cadence": meta.get("cadence"), "runtime": meta.get("runtime") or t.get("runtime"),
            "last_fired_at": last.get("fired_at") or t.get("last_fired_at"), "last_finished_at": last.get("finished_at"),
            "last_run_minutes": (hours(last.get("fired_at"), last.get("finished_at")) or 0) * 60 if last.get("fired_at") and last.get("finished_at") else None,
            "records_seen": len(records_seen.get(role, ())), "ledger_runs": len(runs),
            "ledger_empty": sum(1 for r in runs if r.get("outcome") == "ran_empty"),
            "ledger_last": max((r.get("ended_at") or r.get("started_at") or "" for r in runs), default=None),
            "tempo": meta.get("tempo"),
        })
    return out


def _last_fire(role: str, facts: dict[str, Any], latest: dict[str, dict[str, Any]]) -> str | None:
    t = _triggers_by_role(facts).get(role) or {}
    fired = (t.get("last_run") or {}).get("fired_at")
    key = (facts.get("roles", {}).get(role) or {}).get("report_key") or f"roles/{role}/last-run"
    rec = latest.get(key)
    rec_at = _record_at(rec) if rec else None
    return max((x for x in (fired, rec_at) if x), default=None)


def wake_now(facts: dict[str, Any], now: dt.datetime, *, cycle: dict[str, Any] | None = None, edges: list[dict[str, Any]] | None = None,
             flow: dict[str, Any] | None = None, requested: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """The variable half. For each role with `tempo.wake_on`: the events waiting on it longer than its target, and
    whether a port holder should fire it now (or hold, because it fired within `min_interval_hours`). `requested` are the
    routed DMs in the actuator's inbox (`requests_from_inbox`): an event they name counts whatever its age, and a role with
    a requested event fires regardless of its minimum interval — the sender asked now."""
    board, prs = facts.get("board", []), facts.get("prs", [])
    latest = _latest_records(board)
    cycle = cycle or pr_cycle(prs, now)
    edges = edges if edges is not None else handoff_edges(board, now, prs)
    flow = flow or item_flow(board, prs, now)
    from . import knobs as kn
    knob_rows = kn.from_board(board, now)
    out: list[dict[str, Any]] = []
    for role, meta in facts.get("roles", {}).items():
        cfg = meta.get("tempo") or DEFAULT_ROLE_TEMPO.get(role)
        if not cfg or not cfg.get("wake_on"):
            continue
        # the operator's `<role>.cadence_multiplier` (SPEC §10) stretches or shrinks both of the role's intervals
        mult = kn.multiplier(knob_rows, role, rng=(facts.get("knob_ranges") or {}).get(role))
        target = float(cfg.get("target_hours", 2)) * mult
        asked = {str(r.get("what")) for r in (requested or []) if r.get("role") == role}

        def past(what: str, waited: float | None) -> bool:
            return what in asked or (waited or 0) >= target

        events: list[dict[str, Any]] = []
        for ev in cfg["wake_on"]:
            if ev == "pr_opened":
                events += [{"event": ev, "what": f"#{p['number']}", "waiting_hours": p["age_hours"], "event_at": p.get("opened_at")}
                           for p in cycle["open"] if not p.get("verdict") and past(f"#{p['number']}", p["age_hours"])]
            elif ev == "correction_pushed":
                for p in cycle["open"]:
                    sha, head = p.get("verdict_sha"), p.get("head_sha")
                    if p.get("verdict") and sha and head and not head.startswith(sha) and not sha.startswith(head):
                        w = hours(p.get("updated_at"), now.isoformat())
                        if past(f"#{p['number']}", w):
                            events.append({"event": ev, "what": f"#{p['number']}", "waiting_hours": w, "event_at": p.get("updated_at"),
                                           "scope": f"pinned confirmation {sha[:7]}→{head[:7]}"})
            elif ev == "verdict_sound":
                events += [{"event": ev, "what": f"#{p['number']}", "waiting_hours": p["hours_since_verdict"], "event_at": p.get("verdict_at")}
                           for p in cycle["open"] if p.get("verdict") == "SOUND" and past(f"#{p['number']}", p["hours_since_verdict"])
                           and (not p.get("verdict_sha") or not p.get("head_sha") or p["head_sha"].startswith(p["verdict_sha"]) or p["verdict_sha"].startswith(p["head_sha"]))]
            elif ev == "handoff_written":
                events += [{"event": ev, "what": e["key"], "waiting_hours": e["waiting_hours"], "event_at": e["written_at"]}
                           for e in edges if e["to"] == role and not e["received_at"] and not e.get("overtaken_at") and past(e["key"], e["waiting_hours"])]
            elif ev == "merged":
                since_fire = _last_fire(role, facts, latest)
                for p in prs:
                    m = p.get("merged_at")
                    w = hours(m, now.isoformat()) if m else None
                    if w is not None and w <= MERGED_WINDOW_HOURS and not (since_fire and _ts(m) <= _ts(since_fire)) and past(f"#{p['number']}", w):
                        events.append({"event": ev, "what": f"#{p['number']}", "waiting_hours": w, "event_at": m})
            elif ev == "finding_refuted":
                events += [{"event": ev, "what": r["item"], "waiting_hours": hours(r["refuted_at"], now.isoformat()), "event_at": r["refuted_at"]}
                           for r in flow["items"] if r.get("refuted_at") and not r.get("dispatched_at") and not r.get("pr")
                           and past(r["item"], hours(r["refuted_at"], now.isoformat()))]
        if not events:
            continue
        for e in events:
            if e["what"] in asked:
                e["requested"] = True
        last = _last_fire(role, facts, latest)
        since = hours(last, now.isoformat()) if last else None
        min_h = float(cfg.get("min_interval_hours", 1)) * mult
        t = _triggers_by_role(facts).get(role) or {}
        rec = latest.get(meta.get("report_key") or f"roles/{role}/last-run")
        blocked = _value(rec).get("blocked") if rec else None
        row = {"role": role, "events": sorted(events, key=lambda e: -(e["waiting_hours"] or 0)), "target_hours": target,
               "interval_multiplier": mult if mult != 1.0 else None, "last_fire_at": last, "hours_since_last_fire": since, "min_interval_hours": min_h, "trigger": t.get("id"),
               "blocked": str(blocked)[:160] if blocked else None}
        if any(e.get("requested") for e in events):
            row["fire"] = True
            row["why"] = "requested by DM: " + ", ".join(e["what"] for e in events if e.get("requested")) + (
                f"; {sum(1 for e in events if not e.get('requested'))} more past the {target}h target" if any(not e.get("requested") for e in events) else "")
        elif since is not None and min_h > 0 and since < min_h:
            row["fire"] = False
            row["why"] = f"hold: fired {since}h ago, min interval {min_h}h"
        else:
            row["fire"] = True
            row["why"] = f"{len(events)} event(s) past the {target}h target; " + ("never seen firing" if since is None else f"last fire {since}h ago")
        if mult != 1.0:
            row["why"] += f" (intervals ×{mult:g}: the operator's knob)"
        out.append(row)
    return out


def handoff_unreachable(e: dict[str, Any], roles: dict[str, Any] | None, listening: set[str] | None) -> str:
    """Why nobody will ever read this handoff key, or `""` when somebody will. The receiver wakes on no
    `handoff_written`, has no listener parked, and the key names no open PR that would spawn it — so the
    difference between "late" and "addressed to nobody" is a sentence, not a guess. `roles` None means the
    roster was not read at all, and an unread roster decides nothing (row 65)."""
    if roles is None:
        return ""
    cfg = (roles.get(e["to"]) or {}).get("tempo") or DEFAULT_ROLE_TEMPO.get(e["to"]) or {}
    wake_on = list(cfg.get("wake_on") or [])
    if "handoff_written" in wake_on or e["to"] in (listening or set()) or e.get("pr_state") == "open":
        return ""
    return f"{e['to']} wakes on {', '.join(wake_on) or 'nothing'} and is not listening; nobody reads this key"


def slow_edges(flow: dict[str, Any], tgt: dict[str, float], edges: list[dict[str, Any]], roles: dict[str, Any] | None = None,
               listening: set[str] | None = None) -> list[str]:
    """SLOW / WAITING per edge; per unreceived handoff WAITING, or UNREACHABLE when the receiver wakes on no
    `handoff_written`, is not listening, and the handoff names no open PR that would spawn it — nobody reads that key.
    Overtaken handoffs are one aggregated line, not one alarm each (row 100's lesson)."""
    out = []
    for name, e in flow["edges"].items():
        t = tgt.get(name)
        if t is None:
            continue
        if e["median_hours"] is not None and e["median_hours"] > t:
            out.append(f"SLOW {name}: median {e['median_hours']}h over {e['n']} (target {t}h)")
        if e["worst_waiting_hours"] is not None and e["worst_waiting_hours"] > t:
            out.append(f"WAITING {name}: {e['worst_waiting_item']} for {e['worst_waiting_hours']}h (target {t}h), {e['waiting']} waiting")
    t = tgt.get("handoff_received")
    for e in edges:
        if e["received_at"] or e.get("overtaken_at") or t is None or (e["waiting_hours"] or 0) <= t:
            continue
        if e.get("unjudged_why"):   # a receipt nobody could look for is not a receipt that did not happen (row 65)
            continue
        why = handoff_unreachable(e, roles, listening)
        if why:
            out.append(f"UNREACHABLE handoff_received: {e['from']} → {e['to']} [{e['item']}] for {e['waiting_hours']}h — {why}")
        else:
            out.append(f"WAITING handoff_received: {e['from']} → {e['to']} [{e['item']}] for {e['waiting_hours']}h (target {t}h)")
    over = [e for e in edges if e.get("overtaken_at")]
    if over:
        # every one closed AFTER its handoff: one written after the close is judged on its ack (`_overtaken_on_pr`)
        out.append(f"OVERTAKEN handoff_received: {len(over)} handoff(s) whose PR closed after the handoff with no act "
                   f"by the receiver")
    return out


def report(facts: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    now = now or dt.datetime.now(dt.timezone.utc)
    board, prs = facts.get("board", []), facts.get("prs", [])
    attribute_prs(prs, board, facts.get("runs", []))
    merge_board_verdicts(prs, board)
    edges = handoff_edges(board, now, prs)
    # Row 105: the receiver's act on the PR the handoff names is the truest signal of receipt, and 37 handoffs
    # stood NOT RECEIVED while every PR they named was reviewed. So when the PR half is UNREAD, a PR-named
    # handoff cannot be judged at all — with `prs` empty every one of them falls through to "never received",
    # which is row 65 wearing the handoffs tile. Measured on Lucille 2026-09-22: a `gh` 403 turned 62 of 70
    # handoff keys into 50 findings about receipts nobody had looked for.
    prs_unread = next((c for c in facts.get("could_not_read", []) if c.startswith("prs:")), "")
    for e in edges:
        e["unjudged_why"] = (f"it names {', '.join('#%d' % n for n in e['prs'])} and the PR half of receipt was "
                             f"not read — {prs_unread}"
                             if prs_unread and e["prs"] and not e["received_at"] and not e.get("overtaken_at") else "")
    cycle = pr_cycle(prs, now)
    flow = item_flow(board, prs, now)
    tgt = dict(DEFAULT_TARGETS)
    tgt.update(facts.get("targets") or {})
    lst = listeners(facts, now)
    from . import actuator as ac
    acfg = ac.org_tempo({"tempo": facts.get("tempo_cfg") or {}})
    ledger = ac.ledger_rows(board, acfg)
    hb = ac.heartbeat(board, acfg)
    actuator = {
        "heartbeat": hb, "heartbeat_age_hours": hours(hb.get("at"), now.isoformat()) if hb else None,
        "wakes": len(ledger), "wakes_idle": sum(1 for r in ledger if r.get("idle")),
        "spawns": sum(1 for r in ledger for f in r.get("fired", []) if f.get("kind") == "spawn" and not f.get("could_not")),
        "fires": sum(1 for r in ledger for f in r.get("fired", []) if f.get("kind") == "fire_trigger" and not f.get("could_not")),
        "refused": sum(1 for r in ledger for f in r.get("fired", []) if f.get("could_not")),
        "cost_per_wake": ac.wake_cost_series(board, acfg)[-12:],
        "orphans": {k: v for k, v in ac.orphans(facts, now, acfg).items() if k != "losses"},
    }
    return {
        "listeners": lst,
        "actuator": actuator,
        "org": facts.get("org"), "at": now.isoformat(timespec="seconds"), "facts_gathered_at": facts.get("gathered_at"), "since": facts.get("since"),
        "merged_from": facts.get("merged_from"),
        "cycle": cycle, "edges": flow["edges"], "items": flow["items"], "targets": tgt,
        "slow": slow_edges(flow, tgt, edges, roles=facts.get("roles", {}), listening={l["role"] for l in lst if l.get("listening")}),
        "handoffs": edges, "handoffs_unreceived": [dict(e, unreachable_why=handoff_unreachable(e, facts.get("roles"), {l["role"] for l in lst if l.get("listening")}))
                                                   for e in edges if not e["received_at"] and not e.get("overtaken_at")],
        "handoffs_overtaken": [e for e in edges if e.get("overtaken_at")],
        "blocked": blocked_now(board, facts.get("roles", {}), now),
        "wakes": wake_stats(facts, now),
        "wake_now": wake_now(facts, now, cycle=cycle, edges=edges, flow=flow),
        "could_not_read": list(facts.get("could_not_read", [])) + [f"record {u} — skipped, not crashed (rows 94, 95)" for u in flow.get("unreadable", [])],
    }


def render(rep: dict[str, Any]) -> str:
    L = [f"tempo — {rep['org']} at {rep['at']} (facts {rep.get('facts_gathered_at')}, since {rep.get('since')}" + (f", merged from {len(rep['merged_from'])} files" if rep.get("merged_from") else "") + ")", ""]
    L.append("edges: median hours, and the worst thing waiting now (target)")
    for name, e in rep["edges"].items():
        t = rep["targets"].get(name)
        L.append(f"  {name:<20} n {e['n']:>3} median {str(e['median_hours']):>7}h  waiting {e['waiting']:>3}" + (f"  worst {e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e["worst_waiting_item"] else "") + (f"  (target {t}h)" if t is not None else ""))
    for s in rep["slow"]:
        L.append(f"  {s}")
    L.append("")
    c = rep["cycle"]
    L.append("pull requests: opened → verdict → merged, median hours")
    for kind, k in c["by_kind"].items():
        L.append(f"  {kind:<8} opened {k['opened']:>3} merged {k['merged']:>3} open now {k['open_now']:>3}  open→verdict {k['median_hours_open_to_verdict']}  verdict→merge {k['median_hours_verdict_to_merge']}  open→merge {k['median_hours_open_to_merge']}")
    L.append(f"  last merge {c['last_merge_at']} — {c['hours_since_last_merge']}h ago")
    if c["open"]:
        L.append("  open now: " + ", ".join(f"#{p['number']} {p['kind']} {p['author_role']} {p['age_hours']}h" + (f" ({p['verdict']} {p['hours_since_verdict']}h ago)" if p.get('verdict') else "") for p in c["open"]))
    for p in c.get("needing_action") or []:
        L.append(f"  needing action: #{p['number']} ({'; '.join(p['why'])}) idle {p['idle_hours']}h" + (f"  (target {rep['targets'].get('pr_needing_action')}h)" if rep["targets"].get("pr_needing_action") is not None else ""))
    L.append("")
    L.append("handoffs (coord/handoffs/*)")
    for e in rep["handoffs"]:
        L.append(f"  {e['from']} → {e['to']} [{e['item']}] written {e['written_at']} " + (f"received {e['received_at']} via {e['via']} — {e['latency_hours']}h" if e['received_at'] else (f"OVERTAKEN — {e['via']} at {e['overtaken_at']}, {e['waiting_hours']}h after" if e.get('overtaken_at') else f"NOT RECEIVED — waiting {e['waiting_hours']}h")))
    if not rep["handoffs"]:
        L.append("  none on the board")
    L.append("")
    L.append("blocked fields now")
    for b in rep["blocked"]:
        L.append(f"  {b['role']:<16} " + ("no record" if not b.get("record_at") and b.get("record") is None else f"record {b['record_at']} ({b['record_age_hours']}h) blocked: {b['blocked'] or '—'}"))
    L.append("")
    L.append("wakes")
    for w in rep["wakes"]:
        L.append(f"  {w['role']:<16} {str(w['cadence']):<14} {str(w['runtime']):<8} last fire {w['last_fired_at']} run {w['last_run_minutes'] and round(w['last_run_minutes'])} min  records seen {w['records_seen']}  ledger {w['ledger_runs']} runs ({w['ledger_empty']} empty)")
    L.append("")
    L.append("listeners (every role: registered in coord/tempo/agents, and a listener heartbeat live now; a spawned role with no session is idle)")
    said = {"parked": "LISTENING", "lapsed": "heartbeat past its deadline", "present": "on the roster, no listener parked",
            "absent": "no listener, not on the roster", "midturn": "mid-turn, not yet re-parked (within the bound)", "unknown": "park unknown (heartbeats unread)"}
    for l in rep.get("listeners") or []:
        L.append(f"  {l['role']:<16} " + (f"{l['agent_id']} " + said.get(l.get("state"), str(l.get("state"))) + f" — registered {l['registered_age_hours']}h ago"
                                           + (f", parked until {l['park_until'] or 'no deadline'}" if l.get("state") in ("parked", "lapsed") else "")
                                           if l.get("agent_id") else ("spawned — no live session, idle" if l.get("runtime") == "spawned"
                                                                      else "never registered — no `org tempo register` from its session yet")))
    if not rep.get("listeners"):
        L.append("  no persistent roles declared")
    L.append("")
    a = rep.get("actuator") or {}
    L.append("actuator (coord/tempo/*)")
    if a.get("heartbeat"):
        L.append(f"  heartbeat {a['heartbeat'].get('at')} ({a['heartbeat_age_hours']}h ago) next wake {a['heartbeat'].get('next_wake_at')} session {a['heartbeat'].get('session_id')} {a['heartbeat'].get('context_tokens')} tokens")
        L.append(f"  wakes {a['wakes']} ({a['wakes_idle']} idle), spawns {a['spawns']}, fires {a['fires']}, refused {a['refused']}; $/wake " + ", ".join(f"{c['usd']}" for c in a["cost_per_wake"][-8:]))
        for k in ("fired_no_receiver", "suppressed", "unforwarded"):
            if a["orphans"].get(k):
                L.append(f"  {k}: {json.dumps(a['orphans'][k], ensure_ascii=False)[:240]}")
    else:
        L.append("  no heartbeat — no actuator has written coord/tempo/actuator yet (the dispatcher's routine prompt carries the four-call wake once it is updated)")
    L.append("")
    L.append("wake now (roles a port holder should fire before their next cron tick)")
    for w in rep["wake_now"]:
        L.append(f"  {'FIRE' if w['fire'] else 'HOLD'} {w['role']:<16} {w['why']}" + (f" — trigger {w['trigger']}" if w.get("trigger") else "") + (f" — its record says blocked: {w['blocked']}" if w.get("blocked") else ""))
        for e in w["events"][:5]:
            L.append(f"       {e['event']:<16} {e['what']} waiting {e['waiting_hours']}h")
    if not rep["wake_now"]:
        L.append("  nothing past target")
    if rep["could_not_read"]:
        L.append("")
        L.append("could not read: " + "; ".join(rep["could_not_read"]))
    return "\n".join(L) + "\n"
