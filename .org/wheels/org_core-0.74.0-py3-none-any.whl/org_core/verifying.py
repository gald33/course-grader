"""The `verifying` queue as the registrar keeps it (`coord/registrar/settle`, `{key: {state, date, reason}}`) read against the
verifier's last record: what is due, what waits and on what, and what has been due too long with nothing named.

Measured 2026-10-12 (item the-verifying-queue-drains-at-least-as-fast-as-it-fills, read from the settle table at 07:12Z and
Vera's records of 10-08..10-12 in `.org/tempo/facts-*.json` and on the board): four items placed `due_now` on 2026-10-07 were
counted "unreached on a fifth day", yet Vera had read all four on 10-11 and written, in prose, what each waits on (a tenant
transition log, org-side renders, an observed short-window doctor run). Nothing carried that wait back into the table, so they
stayed due, were handed to her again each day, and each re-read spent her ten-item budget on a known `cannot tell`. Of about 46
items she checked over those five days, 6 were settled. The verifier now names each wait in her record (`waits`), and `fold`
moves the item out of *due* into the state that wait names, so the queue counts it as waiting, not due.

Broken looks like: a due item whose settle date is more than `OVERDUE_DAYS` old with no named wait (`overdue`), or an item in a
state that is neither due nor a named wait (`unplaced`, e.g. `status_on_server` with no date, read 2026-10-12 on six items).

Read 2026-10-15 on 0.60.55 (item org-verifying-counts-an-item-the-settle-table-lacks): the store held 37 items in `verifying`
and the table 30, and the reading printed "0 unplaced" and its pass line, because it iterated the table alone — an item that
entered `verifying` after the registrar's last run was in no count. So the reading takes the work store's `verifying` set too:
a key the table lacks is `unplaced` ("not in the settle table"), a table key the store no longer holds in `verifying` is
`stale`, and with the store unread there is no pass line at all.
"""

from __future__ import annotations

import datetime as _dt
from typing import Any

OVERDUE_DAYS = 2   # the item's done-line: "the registrar's count of due items unreached for more than 2 days is 0"

WAITING = ("due_on_date", "due_on_event", "waiting_on_access", "waiting_on_operator")
# what a verifier's named wait (`waits[<key>].on`) places the item as
WAIT_STATE = {"access": "waiting_on_access", "operator": "waiting_on_operator", "event": "due_on_event", "date": "due_on_date"}


def _day(s: Any) -> _dt.date | None:
    try:
        return _dt.date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def _wait_ok(w: Any) -> str:
    """'' when a verifier's wait is usable, else why not: it must say what kind of wait (`on`) and what exactly (`what`), and a
    `date` wait the date."""
    if not isinstance(w, dict):
        return "not an object"
    if w.get("on") not in WAIT_STATE:
        return f"`on` is {w.get('on')!r}, not one of {', '.join(WAIT_STATE)}"
    if not str(w.get("what") or "").strip():
        return "names no `what` — a wait that names nothing is not a wait"
    if w["on"] == "date" and not _day(w.get("date")):
        return "a `date` wait with no ISO `date`"
    return ""


def _due_on(row: dict[str, Any], day: _dt.date) -> bool:
    d = _day(row.get("date"))
    return row.get("state") == "due_now" or (row.get("state") == "due_on_date" and d is not None and d <= day)


def fold(table: dict[str, Any], record: dict[str, Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """The settle table with the verifier's record applied: a due item it confirmed or refuted leaves the table (it is no
    longer `verifying`), and a due item it named a wait for moves to the state that wait names, its reason the verifier's words
    with the record's time. A wait on an item that is not due on the record's day is kept as it was (the registrar placed it). Returns the new table
    and one note per change or refusal, so the registrar's record can say what moved and why."""
    out = {k: dict(v) if isinstance(v, dict) else v for k, v in (table or {}).items()}
    notes: list[dict[str, Any]] = []
    rec = record or {}
    by, at = str(rec.get("by") or "verifier"), str(rec.get("at") or "")[:16]
    for key in [*(rec.get("confirmed_items") or []), *(rec.get("refuted_items") or [])]:
        if key in out:
            out.pop(key)
            notes.append({"key": key, "to": "settled", "why": f"{by} {at}Z: a verdict"})
    for key, w in (rec.get("waits") or {}).items():
        why = _wait_ok(w)
        if why:
            notes.append({"key": key, "to": None, "why": f"wait refused: {why}"})
            continue
        row = out.get(key)
        if not isinstance(row, dict) or not _due_on(row, _day(at) or _dt.date.max):
            continue
        state = WAIT_STATE[w["on"]]
        out[key] = {"state": state, "date": str(w.get("date"))[:10] if state == "due_on_date" else None,
                    "reason": f"{by} {at}Z: {str(w['what']).strip()}"}
        notes.append({"key": key, "to": state, "why": out[key]["reason"]})
    return out, notes


def reading(table: dict[str, Any], today: _dt.date, store: Any = None) -> dict[str, Any]:
    """Every item placed: `due` (its evidence is readable today), `waiting` (a named wait, or a date still ahead), `unplaced`
    (neither). A due item whose date is more than OVERDUE_DAYS before today is also `overdue`, with its age in days.

    `store` is the keys the work store holds in `verifying` (any iterable), or None when it was not read. Read, every key the
    table lacks is `unplaced` — the table is the registrar's copy and the store is the queue — and a table key the store no
    longer holds in `verifying` is `stale`, out of every other count. Not read, `store_read` is False and no pass is claimed."""
    due, waiting, unplaced, overdue, stale = [], [], [], [], []
    held = None if store is None else {str(k) for k in store}
    for key, row in sorted((table or {}).items()):
        if held is not None and key not in held:
            stale.append({"key": key, "state": row.get("state") if isinstance(row, dict) else None,
                          "why": "in the settle table, not `verifying` in the work store"})
            continue
        st = row.get("state") if isinstance(row, dict) else None
        d = _day(row.get("date")) if isinstance(row, dict) else None
        reason = str((row or {}).get("reason") or "").strip() if isinstance(row, dict) else ""
        if isinstance(row, dict) and _due_on(row, today):
            since = d or today
            due.append({"key": key, "since": since.isoformat(), "days": (today - since).days})
            if (today - since).days > OVERDUE_DAYS:
                overdue.append({"key": key, "since": since.isoformat(), "days": (today - since).days})
        elif st in WAITING and reason and (st != "due_on_date" or d):
            waiting.append({"key": key, "state": st, "date": d.isoformat() if d else None, "on": reason})
        else:
            unplaced.append({"key": key, "state": st, "why": "no date and no named wait" if st else "no state"})
    for key in sorted((held or set()) - set(table or {})):
        unplaced.append({"key": key, "state": None, "why": "not in the settle table"})
    return {"today": today.isoformat(), "total": len(table or {}) - len(stale), "store_read": held is not None,
            "store_verifying": None if held is None else len(held), "due": due, "waiting": waiting, "unplaced": unplaced,
            "overdue": overdue, "stale": stale,
            "counts": {"due": len(due), "waiting": len(waiting), "unplaced": len(unplaced), "overdue": len(overdue),
                       "stale": len(stale)}}


def render_text(r: dict[str, Any], notes: list[dict[str, Any]]) -> str:
    c = r["counts"]
    store = (f"; the work store holds {r['store_verifying']} in verifying, {c['stale']} table keys stale" if r.get("store_read")
             else "; the work store was not read — items it holds in verifying that the table lacks are not checked")
    lines = [f"verifying queue {r['today']}: {r['total']} placed — {c['due']} due, {c['waiting']} waiting, "
             f"{c['unplaced']} unplaced; {c['overdue']} due more than {OVERDUE_DAYS} days with nothing named{store}"]
    for n in notes:
        lines.append(f"  folded   {n['key']} -> {n['to'] or 'unchanged'}   {n['why']}")
    for o in r["overdue"]:
        lines.append(f"  OVERDUE  {o['key']}   due since {o['since']} ({o['days']} d), no verdict and no named wait")
    for u in r["unplaced"]:
        lines.append(f"  UNPLACED {u['key']}   state {u['state']!r}: {u['why']}")
    for t in r.get("stale") or []:
        lines.append(f"  stale    {t['key']}   {t['why']}")
    for d in r["due"]:
        if d["days"] <= OVERDUE_DAYS:
            lines.append(f"  due      {d['key']}   since {d['since']}")
    if not r.get("store_read"):
        lines.append("not checked: no pass without the work store's verifying set. Broken looks like: a pass line printed "
                     "while the store holds a verifying item the table lacks.")
        return "\n".join(lines)
    broken = (f"Broken looks like: a due item more than {OVERDUE_DAYS} days old with no named wait, an item no state places, "
              "or a verifying item the table lacks.")
    if r["overdue"] or r["unplaced"]:
        lines.append(f"FAIL: {c['overdue']} overdue, {c['unplaced']} unplaced. {broken}")
    else:
        lines.append(f"pass: 0 overdue and 0 unplaced. {broken}")
    return "\n".join(lines)
