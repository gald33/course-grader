"""One vocabulary for what the pages draw: a SHAPE says what a thing is, a COLOUR says what state it is in.

The status page, the command page and the explorer each grew their own marks, and the same hue came to mean
three things (the operator, 2026-10-03: *"entity type icons and consistent color meaning, because it is
confusing to understand what I'm looking at"*). Measured on the live page that day, before this module:

  - amber was `blocked on another item`, a `busy` agent and a waiting ask — three meanings;
  - green was a healthy tile, a `ready to start` item and a parked listener — healthy, startable and listening;
  - blue was `shipped, being verified`, a link, and an agent `between turns`;
  - an item's state was a bare dot, so every row read the same until its colour was learned.

The rule from here, for every page: **colour in a mark is a state, and means one thing; colour in text is a link.**

  crit  red     broken, failing, gone                       ✕ on a disc
  wait  amber   stopped until a person (or another item) acts   pause on a disc
  live  blue    in motion: being built, being verified, busy    disc / part-filled ring
  ok    green   healthy, clear, listening                       ✓ on a disc
  idle  grey    not started, settled, parked, not measured      ring, ✓ ring, dashed ring

Colour is never alone: every state has its own shape (the red/green pair fails the colour-blind floor at
ΔE 4.1 — measured below) and every row that wears one also says the state in words.

Entities (arc, item, ticket, pull request, role, ask, org, routine) have an icon each, drawn in the page's
neutral ink, never in a state colour — so an icon answers *what is this* and a glyph answers *how is it*.

Shapes are CSS masks over a data-URI SVG, not inline SVG: the static page and the live page repaint rows from
different code (Python and the page's own script), and a class name is the one thing both already write.
Nothing here needs a script, a font or the network.

Measured (dataviz `validate_palette.js`, bundled skills 2.1.288, 2026-10-03):
  stage bars, violet #4a3aa7 + magenta #e87ba4 (light) / #9085e9 + #d55181 (dark): ALL CHECKS PASS;
    magenta is 2.69:1 on light, so the bars keep their words and a table.
  item progress, ordinal #86b6ef→#2a78d6 (light) / #1c5cab→#3987e5 (dark): ALL CHECKS PASS.
  the five state colours together: normal-vision floor PASS (worst ΔE 22.6–23.6) but red↔green ΔE 4.1 light /
    5.1 dark under deuteranopia, and amber 1.83:1 on light — both legal only because the glyph shapes differ
    and every state is also written in words. A state colour never carries a meaning alone.
"""
from __future__ import annotations

import urllib.parse

# --- the shapes ------------------------------------------------------------------------------------------

_NS = "xmlns='http://www.w3.org/2000/svg'"


def _uri(svg: str) -> str:
    return 'url("data:image/svg+xml,' + urllib.parse.quote(svg, safe="/:=' ()") + '")'


def _disc(cut: str, *, vb: int = 12) -> str:
    """A solid disc with a mark knocked out of it (a mask inside the SVG): solid reads at 12px where an outline
    in amber on white (1.83:1) would not."""
    return (f"<svg {_NS} viewBox='0 0 {vb} {vb}'><mask id='m'><rect width='{vb}' height='{vb}' fill='white'/>"
            f"<path d='{cut}' fill='none' stroke='black' stroke-width='1.4' stroke-linecap='round' "
            f"stroke-linejoin='round'/></mask><circle cx='6' cy='6' r='5.5' mask='url(#m)'/></svg>")


def _ring(extra: str = "", *, dash: str = "") -> str:
    d = f" stroke-dasharray='{dash}'" if dash else ""
    return (f"<svg {_NS} viewBox='0 0 12 12'><circle cx='6' cy='6' r='4.6' fill='none' stroke='black' "
            f"stroke-width='1.6'{d}/>{extra}</svg>")


#: state glyphs, 12px, one colour (the mask's alpha is the shape)
GLYPHS = {
    "crit": _disc("M4.1 4.1l3.8 3.8M7.9 4.1l-3.8 3.8"),
    "wait": _disc("M4.7 3.9v4.2M7.3 3.9v4.2"),
    "live": f"<svg {_NS} viewBox='0 0 12 12'><circle cx='6' cy='6' r='5.2'/></svg>",
    "ok": _disc("M3.6 6.2l1.8 1.8 3.2-3.8"),
    "idle": _ring(),
    "parked": _ring(dash="1.5 1.7"),
    "claimed": _ring("<path d='M6 1.4A4.6 4.6 0 0 0 6 10.6Z'/>"),                       # half filled
    "verifying": _ring("<path d='M6 6V1.4A4.6 4.6 0 1 1 1.4 6Z'/>"),                    # three quarters
    "done": _ring("<path d='M3.7 6.2l1.7 1.7 3-3.6' fill='none' stroke='black' stroke-width='1.4' "
                  "stroke-linecap='round' stroke-linejoin='round'/>"),
}

#: entity icons, 14px, line drawings in the page's ink
_STROKE = "fill='none' stroke='black' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'"
ICONS = {
    "arc": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><path d='M2.4 12.6a5.6 5.6 0 0 1 11.2 0'/>"
           "<circle cx='2.4' cy='12.6' r='1.2'/><circle cx='13.6' cy='12.6' r='1.2'/></svg>",
    "item": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><rect x='2.6' y='2.6' width='10.8' height='10.8' rx='2.4'/>"
            "<path d='M5.4 6.4h5.2M5.4 9.6h3'/></svg>",
    "ticket": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><path d='M2.6 5.4a1 1 0 0 1 1-1h8.8a1 1 0 0 1 1 1v1.3"
              "a1.4 1.4 0 0 0 0 2.6v1.3a1 1 0 0 1-1 1H3.6a1 1 0 0 1-1-1V9.3a1.4 1.4 0 0 0 0-2.6z'/>"
              "<path d='M9.6 5v1M9.6 7.5v1M9.6 10v1'/></svg>",
    "pr": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><circle cx='4' cy='3.6' r='1.5'/><circle cx='4' cy='12.4' r='1.5'/>"
          "<circle cx='12' cy='12.4' r='1.5'/><path d='M4 5.1v5.8M12 10.9V7.4a2 2 0 0 0-2-2H8.4M9.9 3.6L8.4 5.4 9.9 7.2'/></svg>",
    "role": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><circle cx='8' cy='5.4' r='2.6'/><path d='M3 13.6a5 5 0 0 1 10 0'/></svg>",
    "ask": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><path d='M3.4 3.4h9.2a1 1 0 0 1 1 1v5.6a1 1 0 0 1-1 1H8.2L5.4 13.6V11H3.4"
           "a1 1 0 0 1-1-1V4.4a1 1 0 0 1 1-1z'/></svg>",
    "org": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><rect x='2.6' y='2.6' width='4.6' height='4.6' rx='1'/>"
           "<rect x='8.8' y='2.6' width='4.6' height='4.6' rx='1'/><rect x='2.6' y='8.8' width='4.6' height='4.6' rx='1'/>"
           "<rect x='8.8' y='8.8' width='4.6' height='4.6' rx='1'/></svg>",
    "routine": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><circle cx='8' cy='8' r='5.6'/><path d='M8 4.9V8l2.2 1.5'/></svg>",
    "rule": f"<svg {_NS} viewBox='0 0 16 16' {_STROKE}><path d='M4 2.6h5.6L12.4 5.4v8H4z'/><path d='M9.4 2.8v2.8h2.8M6.2 9.2l1.5 1.5 2.7-3'/></svg>",
}

# --- what the pages print ------------------------------------------------------------------------------

#: item status → (glyph, state colour class, the words the legend uses)
ITEM_STATE = {
    "ready":     ("idle",      "s-ring", "ready to start"),
    "claimed":   ("claimed",   "s-live2", "someone is building it"),
    "verifying": ("verifying", "s-live", "shipped, being verified"),
    "done":      ("done",      "s-idle", "done"),
    "blocked":   ("wait",      "s-wait", "blocked on another item"),
    "deferred":  ("parked",    "s-idle", "deferred"),
}

#: the five states, in the order the key prints them
STATES = (
    ("crit", "s-crit", "broken", "failing, dead or gone"),
    ("wait", "s-wait", "waiting", "stopped until a person or another item acts"),
    ("live", "s-live", "in motion", "being built, verified or worked on now"),
    ("ok", "s-ok", "healthy", "clear, on time, listening"),
    ("idle", "s-idle", "idle", "not started, settled, parked or not measured"),
)

ENTITIES = (("arc", "arc"), ("item", "item"), ("ticket", "ticket"), ("pr", "pull request"), ("role", "role"),
            ("ask", "ask for a person"), ("routine", "routine"), ("org", "org"), ("rule", "standing decision"))


def key_html() -> str:
    """The key at the top of a page: what the colours mean, and what the shapes are. Words beside each, so the
    key is readable without learning either."""
    states = "".join(f"<span class='skeyi'><i class='sg {c} g-{g}'></i><b>{_e(w)}</b> {_e(m)}</span>"
                     for g, c, w, m in STATES)
    prog = "".join(f"<span class='skeyi'><i class='sg {ITEM_STATE[s][1]} g-{ITEM_STATE[s][0]}'></i>{_e(ITEM_STATE[s][2])}</span>"
                   for s in ("ready", "claimed", "verifying", "done", "blocked", "deferred"))
    ents = "".join(f"<span class='skeyi'><i class='ic ic-{k}'></i>{_e(w)}</span>" for k, w in ENTITIES)
    return ("<details class='skey'><summary>How to read the marks — a shape says what a thing is, a colour says "
            "what state it is in</summary>"
            f"<div class='skeyr'><span class='skeyk'>state</span>{states}</div>"
            f"<div class='skeyr'><span class='skeyk'>an item</span>{prog}</div>"
            f"<div class='skeyr'><span class='skeyk'>a thing</span>{ents}</div>"
            "<p class='skeyn'>Colour in a mark is a state and means one thing everywhere; colour in text is a link. "
            "Every state also has its own shape and is written in words, because red and green cannot be told "
            "apart by everyone.</p></details>")


def _e(x: str) -> str:
    import html
    return html.escape(x)


def _css() -> str:
    root = ":root{" + "".join(f"--g-{g}:{_uri(v)};" for g, v in GLYPHS.items()) \
        + "".join(f"--i-{k}:{_uri(v)};" for k, v in ICONS.items()) + "}"
    classes = "".join(f".g-{g}{{--m:var(--g-{g})}}" for g in GLYPHS) \
        + "".join(f".ic-{k}{{--m:var(--i-{k})}}" for k in ICONS)
    return ("/* --- shapes and states (org_core/vocab.py): a shape says what a thing is, a colour says its state --- */\n"
            + root + "\n" + _STATIC_CSS + "\n" + classes + "\n")


_STATIC_CSS = """
.sg,.ic,.dot,.pdot,.pmark,.xdot,.xarcmark,.xtk,.xpr{display:inline-block;flex:none;background-color:currentColor;
  -webkit-mask:var(--m) center/contain no-repeat;mask:var(--m) center/contain no-repeat;vertical-align:-2px}
.sg,.dot,.pdot,.pmark,.xdot{width:12px;height:12px}
.sg.sg,.dot.dot,.pdot.pdot,.pmark.pmark,.xdot.xdot,.xarcmark.xarcmark,.xtk.xtk,.xpr.xpr{background:currentColor;box-shadow:none}
.ic,.xarcmark,.xtk,.xpr{width:14px;height:14px}
.ic{color:var(--ink-2);margin-right:5px;vertical-align:-3px}
.s-crit{color:var(--c-crit)} .s-wait{color:var(--c-wait)} .s-live{color:var(--c-live)} .s-live2{color:var(--c-live2)}
.s-ok{color:var(--c-ok)} .s-idle{color:var(--c-idle)} .s-ring{color:var(--c-ring)}
/* the tones a row, a tile and the fleet matrix already write: RED / CLEAR / OPEN / DARK */
.dot{margin-top:4px;color:var(--c-ring);--m:var(--g-idle)} .dot.RED{color:var(--c-crit);--m:var(--g-crit)}
.dot.CLEAR{color:var(--c-ok);--m:var(--g-ok)} .dot.OPEN{color:var(--c-wait);--m:var(--g-wait)}
.fleet .cell b{width:12px;height:12px;border-radius:0;background:currentColor;color:var(--c-ring);--m:var(--g-idle);
  display:inline-block;-webkit-mask:var(--m) center/contain no-repeat;mask:var(--m) center/contain no-repeat}
.fleet .cell.RED b{color:var(--c-crit);--m:var(--g-crit)} .fleet .cell.CLEAR b{color:var(--c-ok);--m:var(--g-ok)}
/* an item's status, in the explorer's rows, its filter pills and its drawer */
.xdot{width:12px;height:12px;border-radius:0;color:var(--c-ring)}
.xrow>.xdot{margin-top:4px}
.st-ready.xdot{color:var(--c-ring);--m:var(--g-idle)} .st-claimed.xdot{color:var(--c-live2);--m:var(--g-claimed)}
.st-verifying.xdot{color:var(--c-live);--m:var(--g-verifying)} .st-done.xdot{color:var(--c-idle);--m:var(--g-done)}
.st-blocked.xdot{color:var(--c-wait);--m:var(--g-wait)} .st-deferred.xdot{color:var(--c-idle);--m:var(--g-parked)}
/* the explorer's leading marks name the entity, so they are the entity's ink like every other icon: a ticket's or a
   pull request's state is the words in its row and its drawer chip, never its icon's colour (Reed, #71: an open ticket
   drawn amber and an open PR drawn blue put two state hues back on two entities). A closed one is only quieter. */
.xarcmark{--m:var(--i-arc)} .xtk{--m:var(--i-ticket)} .xpr{--m:var(--i-pr)}
.xarcmark,.xtk,.xpr{color:var(--ink-2)}
.xtk.closed,.xpr.closed,.xpr.merged{opacity:.6}
/* a stacked bar's segments (the arcs, the roadmap): the same six states as fills */
.st-ready{background:var(--surface-2);box-shadow:inset 0 0 0 1.5px var(--c-ring)}
.st-deferred{background:repeating-linear-gradient(135deg,var(--c-idle) 0 2px,transparent 2px 5px);
  box-shadow:inset 0 0 0 1px var(--c-idle)}
/* the key */
details.skey{margin-top:14px;padding:9px 14px;border:1px solid var(--border);border-radius:8px;background:var(--surface)}
details.skey>summary{cursor:pointer;font-size:12.5px;color:var(--ink-2);list-style:none}
details.skey>summary::-webkit-details-marker{display:none}
details.skey>summary::before{content:"\\25B8\\00a0";color:var(--muted)}
details.skey[open]>summary::before{content:"\\25BE\\00a0"}
details.skey>summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px;border-radius:4px}
.skeyr{display:flex;flex-wrap:wrap;gap:4px 16px;align-items:center;margin-top:9px;font-size:12px;color:var(--ink-2)}
.skeyk{flex:0 0 52px;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.skeyi{display:inline-flex;align-items:center;gap:6px}
.skeyi b{font-weight:600;color:var(--ink)}
.skeyn{margin:10px 0 0;font-size:11.5px;color:var(--muted);max-width:74ch}
@media (max-width:460px){.skeyk{flex-basis:100%}}
/* a heading names its entity: the icon is the page's own, in ink, before the words; a heading with no entity has none */
.sechead h2::before{content:"";display:none;width:14px;height:14px;margin-right:7px;vertical-align:-2px;
  background-color:var(--ink-2);-webkit-mask:var(--m) center/contain no-repeat;mask:var(--m) center/contain no-repeat}
.sec.you .sechead h2::before,.act .sechead h2::before{--m:var(--i-ask);display:inline-block}
.sec.team .sechead h2::before{--m:var(--i-role);display:inline-block}
.sec.rm .sechead h2::before,.sec.ag .sechead h2::before{--m:var(--i-arc);display:inline-block}
.sec.tl .sechead h2::before{--m:var(--i-pr);display:inline-block}
.sec.machinery .sechead h2::before{--m:var(--i-routine);display:inline-block}
.sec.xp .sechead h2::before{--m:var(--i-item);display:inline-block}
.sec.dg .sechead h2::before{--m:var(--i-rule);display:inline-block}
/* every row under "Waiting on you" is waiting on a person, whatever its age says; a red one is overdue */
.sec.you .row .dot:not(.RED){color:var(--c-wait);--m:var(--g-wait)}
/* an item the roadmap shows as held is in motion, not waiting */
.sec.rm>.row .dot.OPEN{color:var(--c-live);--m:var(--g-live)}
.fleet td.org a::before{content:"";display:inline-block;width:14px;height:14px;margin-right:6px;vertical-align:-2px;
  background-color:var(--ink-2);-webkit-mask:var(--i-org) center/contain no-repeat;mask:var(--i-org) center/contain no-repeat}
.gplot .glabel::before{content:"";display:inline-block;width:12px;height:12px;margin-right:4px;vertical-align:-2px;
  background-color:var(--muted);-webkit-mask:var(--i-pr) center/contain no-repeat;mask:var(--i-pr) center/contain no-repeat}
.rmgantt .glabel::before{-webkit-mask-image:var(--i-item);mask-image:var(--i-item)}
"""

CSS = _css()
